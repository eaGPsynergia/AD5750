//
// Contains code to load and access patterns.
//
// History:
// 11/29/05 - CTS - Template Created.
//
using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{
	//
	// DP - Add code to load/create patterns here
	// 
	#region DP                              :
	/// <summary>
	/// Encapsulates patterns for the application.
	/// </summary>
	public class DP 
	{
		/// <summary>
		/// Patterns are loaded/created here.
		/// </summary>
		public static void Load ( )
		{
			//
			// Add user code here
			//

			TP.Session.PatternManager.CreateFromFile("write_16bits");
			TP.Session.PatternManager.CreateFromFile("write_24bits");
			TP.Session.PatternManager.CreateFromFile("read_data");
			TP.Session.PatternManager.CreateFromFile("hw_reset");
			TP.Session.PatternManager.CreateFromFile("blow_fuse");
			TP.Session.PatternManager.CreateFromFile("read_fuse");
			TP.Session.PatternManager.CreateFromFile("checkFaultCond");
			TP.Session.PatternManager.CreateFromFile("blowMasterFuse");
			TP.Session.PatternManager.CreateFromFile("ContinuityLowPat");
			TP.Session.PatternManager.CreateFromFile("ncPat");
			TP.Session.PatternManager.CreateFromFile("ContinuityHighPat");
			TP.Session.PatternManager.CreateFromFile("hw_clear");
			TP.Session.PatternManager.CreateFromFile("t5_write_24bits");
			TP.Session.PatternManager.CreateFromFile("t6_dual_write");
			TP.Session.PatternManager.CreateFromFile("t5_write_16bits");
			TP.Session.PatternManager.CreateFromFile("addrFuncPat");
			TP.Session.PatternManager.CreateFromFile("t11_read_data");
		}

		public static TestPattern write_16bits
		{
			get
			{
				return(TP.Session.PatternManager["write_16bits"]);
			}
		}

		public static TestPattern write_24bits
		{
			get
			{
				return(TP.Session.PatternManager["write_24bits"]);
			}
		}

		public static TestPattern read_data
		{
			get
			{
				return(TP.Session.PatternManager["read_data"]);
			}
		}

		public static TestPattern hw_reset
		{
			get
			{
				return(TP.Session.PatternManager["hw_reset"]);
			}
		}

		public static TestPattern blow_fuse
		{
			get
			{
				return(TP.Session.PatternManager["blow_fuse"]);
			}
		}

		public static TestPattern read_fuse
		{
			get
			{
				return(TP.Session.PatternManager["read_fuse"]);
			}
		}

		public static TestPattern checkFaultCond
		{
			get
			{
				return(TP.Session.PatternManager["checkFaultCond"]);
			}
		}

		public static TestPattern blowMasterFuse
		{
			get
			{
				return(TP.Session.PatternManager["blowMasterFuse"]);
			}
		}

		public static TestPattern ContinuityLowPat
		{
			get
			{
				return(TP.Session.PatternManager["ContinuityLowPat"]);
			}
		}

		public static TestPattern ncPat
		{
			get
			{
				return(TP.Session.PatternManager["ncPat"]);
			}
		}

		public static TestPattern ContinuityHighPat
		{
			get
			{
				return(TP.Session.PatternManager["ContinuityHighPat"]);
			}
		}

		public static TestPattern hw_clear
		{
			get
			{
				return(TP.Session.PatternManager["hw_clear"]);
			}
		}

		public static TestPattern t5_write_24bits
		{
			get
			{
				return(TP.Session.PatternManager["t5_write_24bits"]);
			}
		}

		public static TestPattern t6_dual_write
		{
			get
			{
				return(TP.Session.PatternManager["t6_dual_write"]);
			}
		}

		public static TestPattern t5_write_16bits
		{
			get
			{
				return(TP.Session.PatternManager["t5_write_16bits"]);
			}
		}

		public static TestPattern addrFuncPat
		{
			get
			{
				return(TP.Session.PatternManager["addrFuncPat"]);
			}
		}

		public static TestPattern t11_read_data
		{
			get
			{
				return(TP.Session.PatternManager["t11_read_data"]);
			}
		}

	} // end of class DP
	#endregion


	//
	// DS - Add code to load/create statics here
	// 
	#region DS                              :
	/// <summary>
	/// Encapsulates statics for the application.
	/// </summary>
	public class DS 
	{
		/// <summary>
		/// Statics are loaded/created here.
		/// </summary>
		public static void Load ( )
		{
			//
			// Add user code here
			//
			TP.Session.SettingManager.CreateFromFile("timing_settings");

			TP.Session.SettingManager.CreateFromFile("Default_Setting");
		}

		public static TestSetting timing_settings
		{
			get
			{
				return(TP.Session.SettingManager["timing_settings"]);
			}
		}

		public static TestSetting Default_Setting
		{
			get
			{
				return(TP.Session.SettingManager["Default_Setting"]);
			}
		}
	} // end of class DS
	#endregion

} // end of namespace Adi.Cts.TestProgram
