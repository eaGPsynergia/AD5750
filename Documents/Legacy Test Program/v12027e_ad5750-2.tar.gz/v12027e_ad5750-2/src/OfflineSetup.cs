using System;
using System.IO;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{
	//
	// OC - Add code to setup the offline cache here
	// 
	#region OC                              :
	/// <summary>
	/// Encapsulates the details of setting up the offline data cache for the application.
	/// </summary>
	public class OC : OfflineProxy
	{
		//
		// Offline Data Cache Setup
		//
		#region Offline Cache Initialization    :
		public OC ( )
		{
			//      Method Name                    PL/Job       Site Mask           Test Entry Name

			//
			// When setting up an offline cache for tests that are binned in one test function
			// we must set the context to the ID of the first test entry that calls into the 
			// test function as this is the actual call context when these test entry results 
			// are being determined.
			//
			Add(new CallContext(
				"HW.Dvi.ReadI",                Dvi.A02DVIA, SiteMask.ALL_SITES, IDs.Idd15Stby),
				new DataCache(1.1e-6)); // IDs.Idd15Stby
			Add(new CallContext(
				"HW.Dvi.ReadI",                Dvi.A02DVIB, SiteMask.ALL_SITES, IDs.Idd15Stby),
				new DataCache(2.2e-9)); // IDs.IddRefStby
			Add(new CallContext(
				"HW.Dvi.ReadI",                Dvi.A02DVIC, SiteMask.ALL_SITES, IDs.Idd15Stby),
				new DataCache(3.3e-3)); // IDs.IddDigStby

			//
			// When setting up an offline cache for a test entry that makes multiple calls to 
			// a hardware method with the same pin list then it is important to note the 
			// order data items are added to the cache as this will be used to determine
			// what value to return from a particular call.
			// 
			// e.g.
			//Add(new CallContext(
			//		"HW.Dmm.Read",                 Dmm.G22DMM,  SiteMask.ALL_SITES, IDs.Functionality),
			//	new DataCache(-2.20, -2.205, -2.195)); // 3 HW.Dmm.Read() calls are made

			//
			// ZRandom can be used to have the cache return a random value each time it is accessed.
			// ZRandom can be setup to return a gaussian distribution with or without outliers.
			// The first parameter to ZRandom is the mean and the second is the standard deviation.
			//
			// e.g.
			//Add(new CallContext(
			//		"HW.Dmm.Read",                 Dmm.G22DMM,  SiteMask.ALL_SITES, IDs.Functionality),
			//	new DataCache(new ZRandom(0.001, 0.0005)));

		}
		#endregion

		//
		// User Offline Cache Read Method
		//
		#region Read Callback Method            :
		/// <summary>
		/// Callback during resource read operations. The user should use the call context
		/// to determine what call is currently underway and return an appropriate value
		/// given the current state of the application.
		/// </summary>
		/// <param name="context">Current call context</param>
		/// <returns>the value to return from the read operation</returns>
		public override object Read (CallContext context)
		{
			return(0.0);
		}
		#endregion

		//
		// Add public overrides of LotStart, SubLotStart and PartStart here
		//
		#region Program Context Hooks           :

		public override void PartStart ( )
		{
		}

		#endregion

		//
		// Add private variables here (these will visible only to this class)
		//
		#region Local Variables                 :
		#endregion



		#region System Code (Do not edit)
		/// <summary>
		/// Load the offline data cache for this application.
		/// </summary>
		public static void Load ( )
		{
			if (TP.System.Simulated)
			{
				if (_oc == null)
				{
					_oc = new OC();
				}
			}
		}
		private static OC _oc = null;
		#endregion

	} // end of class 
	#endregion

} // end of namespace Adi.Cts.TestProgram