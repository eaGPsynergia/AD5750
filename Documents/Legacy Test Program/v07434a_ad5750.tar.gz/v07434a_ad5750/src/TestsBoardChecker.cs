// Contains Board Checker Tests only.
//
// History:
// 11/29/05 - CTS - Template Created.



using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{

	public class BoardCheckUtl
	{
		//
		//RelayChecker method
		//
		#region RelayChecker  				:
		/// <summary>
		/// Checks all on-board relays
		/// </summary>

		public static int RelayChecker ( )
		{
			MsDouble unloadedSupplyV, loadedSupplyV, diodeDrop, coilVoltage;
			MsDouble coilRes;
			MsDouble rSense = 10.0; // sense resistor on the relay supplies
			MsDouble vOC = 0.20;  
			MsDouble result = 0.0;
			MsDouble current;
			MsDouble comparatorInput;

			// (Voc is the voltage drop across the open collector relay driver transistor 
			// typical spec. taken from the cts5400 specifications.)

			int numSingleDrivers = 48;
			int numSingleDrivers_probe = 40;
			int SingleDrivers = 0;

			int numDoubleDrivers = 6;
			int numDoubleDrivers_probe = 2;
			int DoubleDrivers = 0;

			int numQuadDrivers = 8;
			int i;
			int passFail = 0;

			TP.Console.WriteLine("***********************************");
			TP.Console.WriteLine("********Relay Checker Tests********");
			TP.Console.WriteLine("***********************************");
			TP.Console.WriteLine("");

			//Open all relays & measure 12V supply using VIF.
			HW.Rdc.Set(PM.ALL_RELAYS, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.RelaySettle);

			HW.Dvi.IRange(PM.RELAY_CHECKER, Dvi.IRanges.I_10_MA);
			HW.Dvi.VRange(PM.RELAY_CHECKER, Dvi.VRanges.V_20_V);
			HW.Dvi.Bandwidth(PM.RELAY_CHECKER, Dvi.Band.LOW);
			HW.Dvi.Mode(PM.RELAY_CHECKER, Dvi.FMMode.FIMV);
			HW.Dvi.NumAverages(PM.RELAY_CHECKER, 100);
			HW.Dvi.WriteI(PM.RELAY_CHECKER, 0.0);
			HW.Dvi.Gate(PM.RELAY_CHECKER, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.VifDelay);

			unloadedSupplyV = HW.Dvi.ReadV(PM.RELAY_CHECKER);
			if(App.Globals.OfflineDev)
				unloadedSupplyV = 12.0;

			passFail += TestResult("12V Supply", 13.0, 11.0, (double)unloadedSupplyV, "V");

			// ---- Measure schottky diode's forward voltage ----
			// Close all relays so that the voltage drop across the 
			// sense resistor is large enough to turn on the diode.
			// Measure 12V supply again => Difference should be the diode on-voltage.

			HW.Rdc.Set(PM.ALL_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.DvccDelay);
			loadedSupplyV = HW.Dvi.ReadV(PM.RELAY_CHECKER);
			if(App.Globals.OfflineDev)
				loadedSupplyV = 11.4;
			diodeDrop = unloadedSupplyV - loadedSupplyV;
			passFail += TestResult("Diode Drop", 0.9, 0.4, (double)diodeDrop, "V");

			//Open all Relays
			HW.Rdc.Set(PM.ALL_RELAYS, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.VifDelay);

			TP.Console.WriteLine("");
			TP.Console.WriteLine("***Single Relays***");

			//Start with relays that do not share drivers
			#region singleRelays
			//Individually switch each relay driver closed and measure voltage drop across the relays.

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
				SingleDrivers = numSingleDrivers;
			else
				SingleDrivers = numSingleDrivers_probe;

			for(i = 0; i < SingleDrivers; i++)
			{

				if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
				{
					HW.Rdc.Set(PM.SINGLE_DRIVERS[i], OpenClose.CLOSE);
					App.Time.MsDelay(App.TC.DvccDelay);
					coilVoltage = HW.Dvi.ReadV(PM.RELAY_CHECKER);

					if(App.Globals.OfflineDev)
						coilVoltage = 11.9;

					// guard against possible division by 0.
					if (TP.Math.MS.Abs(unloadedSupplyV - coilVoltage) > 0.002)
					{
						coilRes  = (rSense*(coilVoltage - vOC)/(unloadedSupplyV - coilVoltage));
					}
					else
					{
						coilRes =  9999.0;
					}

					passFail += TestResult(PM.SINGLE_DRIVERS[i].Name, 1400, 100, (double)coilRes, "Ohm");
					HW.Rdc.Set(PM.SINGLE_DRIVERS[i], OpenClose.OPEN);
				}
				else
				{
					HW.Rdc.Set(PM.SINGLE_DRIVERS_PROBE[i], OpenClose.CLOSE);
					App.Time.MsDelay(App.TC.DvccDelay);
					coilVoltage = HW.Dvi.ReadV(PM.RELAY_CHECKER);

					if(App.Globals.OfflineDev)
						coilVoltage = 11.9;

					// guard against possible division by 0.
					if (TP.Math.MS.Abs(unloadedSupplyV - coilVoltage) > 0.002)
					{
						coilRes  = (rSense*(coilVoltage - vOC)/(unloadedSupplyV - coilVoltage));
					}
					else
					{
						coilRes =  9999.0;
					}

					passFail += TestResult(PM.SINGLE_DRIVERS_PROBE[i].Name, 1450, 100, (double)coilRes, "Ohm");
					HW.Rdc.Set(PM.SINGLE_DRIVERS_PROBE[i], OpenClose.OPEN);
				}
			}
			#endregion


			TP.Console.WriteLine("");
			TP.Console.WriteLine("***2 Relays driven by same driver***");

			//Next, do relays that share a driver with one other relay
			#region dualRelays
			//Individually switch each relay driver closed and measure voltage drop across the relays.
			
			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
				DoubleDrivers = numDoubleDrivers;
			else
				DoubleDrivers = numDoubleDrivers_probe;

			for(i = 0; i < DoubleDrivers; i++)
			{

				if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
				{
					HW.Rdc.Set(PM.DOUBLE_DRIVERS[i], OpenClose.CLOSE);
					App.Time.MsDelay(App.TC.DvccDelay);
					coilVoltage = HW.Dvi.ReadV(PM.RELAY_CHECKER);

					if(App.Globals.OfflineDev)
						coilVoltage = 11.8;

					// guard against possible division by 0.
					if (TP.Math.MS.Abs(unloadedSupplyV - coilVoltage) > 0.002)
					{
						coilRes  = (rSense*(coilVoltage - vOC)/(unloadedSupplyV - coilVoltage));
					}
					else
					{
						coilRes =  9999.0;
					}

					passFail += TestResult(PM.DOUBLE_DRIVERS[i].Name, 700, 100, (double)coilRes, "Ohm");
					HW.Rdc.Set(PM.DOUBLE_DRIVERS[i], OpenClose.OPEN);
				}
				else
				{
					HW.Rdc.Set(PM.DOUBLE_DRIVERS_PROBE[i], OpenClose.CLOSE);
					App.Time.MsDelay(App.TC.DvccDelay);
					coilVoltage = HW.Dvi.ReadV(PM.RELAY_CHECKER);

					if(App.Globals.OfflineDev)
						coilVoltage = 11.8;

					// guard against possible division by 0.
					if (TP.Math.MS.Abs(unloadedSupplyV - coilVoltage) > 0.002)
					{
						coilRes  = (rSense*(coilVoltage - vOC)/(unloadedSupplyV - coilVoltage));
					}
					else
					{
						coilRes =  9999.0;
					}

					passFail += TestResult(PM.DOUBLE_DRIVERS_PROBE[i].Name, 700, 100, (double)coilRes, "Ohm");
					HW.Rdc.Set(PM.DOUBLE_DRIVERS_PROBE[i], OpenClose.OPEN);
				}
			}
			#endregion

			TP.Console.WriteLine("");
			TP.Console.WriteLine("***4 Relays driven by same driver***");
			//Finally, check relays that share a driver with four other relays
			#region quadRelays
			//Individually switch each relay driver closed and measure voltage drop across the relays.
			for(i = 0; i < numQuadDrivers; i++)
			{
				HW.Rdc.Set(PM.QUAD_DRIVERS[i], OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.DvccDelay);
				coilVoltage = HW.Dvi.ReadV(PM.RELAY_CHECKER);

				if(App.Globals.OfflineDev)
					coilVoltage = 11.6;

				// guard against possible division by 0.
				if (TP.Math.MS.Abs(unloadedSupplyV - coilVoltage) > 0.002)
				{
					coilRes  = (rSense*(coilVoltage - vOC)/(unloadedSupplyV - coilVoltage));
				}
				else
				{
					coilRes =  9999.0;
				}

				passFail += TestResult(PM.QUAD_DRIVERS[i].Name, 450, 100, (double)coilRes, "Ohm");
				HW.Rdc.Set(PM.QUAD_DRIVERS[i], OpenClose.OPEN);
			}
			#endregion

			//Ensure all relays are open.
			HW.Rdc.Set(PM.ALL_RELAYS, OpenClose.OPEN);

			TP.Console.WriteLine("");
			TP.Console.WriteLine("***High Voltage Relays***");

			//Check HV Relays
			#region HighVoltageRelays
			//In order to check these relays, need to turn on HV circuit. 
			//Force 1uA from DVcc VIF and sink through pincard on DVcc. This will generate
			//0.01V across inputs of AD620 => 1V on AD620 output.
			//Set Comparator negative input to 0.9V. This should turn on be enough to turn on transistor
			//TRx01. When transistor is on, current flows in high voltage relays to turn them on. 


			//Set "DVcc" current to 1uA. Use 10kOhm resistor => 0.01V 
			//AD620 has gain of 100 => output = 1V. Set -ve input of comparator to 0.5V
			current = 1e-6;
			comparatorInput = 0.5;
			
			//Set up low side of comparator (should already be setup)
			HW.Dvi.WriteV(PM.HV_COMP_INPUT, comparatorInput);

			//1uA setup
			HW.Rdc.Set(PM.D3, OpenClose.CLOSE);
			HW.Dss.PmuConnectMode(PM.DVCC, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.PmuModeValue(PM.DVCC, Dss.PmuMode.FVMI_20_UA, 0.0);
			HW.Dss.PmuConnectMode(PM.DVCC, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.DVCC, Dss.ConnectionMode.OUTPUT_AND_PMU);

			//Remove cap load setting for this function
			HW.Dvi.CapacitiveLoad(PM.DVCC, 0.0);
			HW.Dvi.Mode(PM.DVCC, Dvi.FMMode.FIMV);
			HW.Dvi.Gate(PM.DVCC, OpenClose.CLOSE);
			HW.Dvi.WriteI(PM.DVCC, current);
			App.Time.MsDelay(100);

			//All 4 HV Relays should be on now 
			//**NOTE: D3 is also on to switch in pincard (need to consider this in limits)
			coilVoltage = HW.Dvi.ReadV(PM.RELAY_CHECKER);

			if(App.Globals.OfflineDev)
				coilVoltage = 11.5;

			// guard against possible division by 0.
			if (TP.Math.MS.Abs(unloadedSupplyV - coilVoltage) > 0.002)
			{
				coilRes  = (rSense*(coilVoltage - vOC)/(unloadedSupplyV - coilVoltage));
			}
			else
			{
				coilRes =  9999.0;
			}

			passFail += TestResult("High Voltage Relays", 350, 100, (double)coilRes, "Ohm");

			//Cleanup
			//Ensure all relays are open again
			HW.Dvi.WriteI(PM.DVCC, 0.0);
			HW.Dvi.Mode(PM.DVCC, Dvi.FMMode.FVMI);
			HW.Dvi.CapacitiveLoad(PM.DVCC, 10.0e-6);
			HW.Dvi.Gate(PM.DVCC, OpenClose.OPEN);
			HW.Dss.ConnectionSet(PM.DVCC, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.PmuConnectMode(PM.DVCC, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Rdc.Set(PM.D3, OpenClose.OPEN);

			HW.Dvi.WriteV(PM.HV_COMP_INPUT, App.TC.CompInput);
			#endregion
			
			TP.Console.WriteLine("");
			TP.Console.WriteLine("");
			return passFail;
		}
		#endregion

		//
		//MuxChecker method
		//
		#region MuxChecker  				:
		/// <summary>
		/// Checks functionality of all 3 muxes.
		/// </summary>

		public static int MuxChecker ( )
		{
			MsDouble vrefVoltage, vinVoltage, ioutVoltage;
			MsDouble vsensenVoltage, dutgndVoltage;
			MsDouble voutScaleVoltage = 0;
			MsDouble vGainCheckVoltage;
			int passFail = 0;

			TP.Console.WriteLine("*********************************");
			TP.Console.WriteLine("********MUX Checker Tests********");
			TP.Console.WriteLine("*********************************");

			//*******Check Mux A (IC1)*******
			TP.Console.WriteLine("");
			TP.Console.WriteLine("***MuxA Tests***");
			#region MuxA
			//Setup voltage on MuxA inputs
			HW.Rdc.Set(PM.D6, OpenClose.CLOSE);		//(So that Vref/Vin voltages are only connected to mux)
			HW.Dcs.VOut(PM.VREF, 1.0);
			HW.Dcs.VOut(PM.VIN, 2.0);

			//HW.Dvi.WriteV(PM.IOUT, 0.0);			//Tie lower side of resistor divider to 0V
			HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.OPEN);
			HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FVMI);
			HW.Dvi.WriteV(PM.IOUT_RES_MEAS, 3.5);	//Should see 3.5 * (300/2100) = 0.5V on mux pin
	
			//Measure each voltage using MuxA
			vrefVoltage = Utl.MeasureNode(App.MuxNodes.VREF_MEAS, App.MeasOptions.DMM);
			vinVoltage = Utl.MeasureNode(App.MuxNodes.VIN_MEAS, App.MeasOptions.DMM);
			ioutVoltage = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, App.MeasOptions.DMM);
				
			if(App.Globals.OfflineDev)
			{
				vrefVoltage = 1.0;
				vinVoltage = 2.0;
				ioutVoltage = 0.5;
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				passFail += TestResult("MuxA - VRef", 1.1, 0.9, (double)vrefVoltage[site], "V");
				passFail += TestResult("MuxA - Vin", 2.1, 1.9, (double)vinVoltage[site], "V");
				passFail += TestResult("MuxA - Iout", 0.6, 0.4, (double)ioutVoltage[site], "V");
			}

			//cleanup
			HW.Dcs.VOut(PM.DC_SOURCES, 0.0);
			HW.Dvi.WriteV(PM.IOUT_RES_MEAS, 0.0);
			HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FIMV);
			//HW.Dvi.WriteV(PM.IOUT, 0.0);
			HW.Rdc.Set(PM.D6, OpenClose.OPEN);
			#endregion

			//*******Check Mux B (IC3)*******
			TP.Console.WriteLine("");
			TP.Console.WriteLine("***MuxB Tests***");
			#region MuxB
			//Setup voltage on MuxB inputs
			HW.Rdc.Set(PM.RLX14_RELAYS, OpenClose.CLOSE);
			HW.Dvi.WriteV(PM.VSENSEN, 1.0);
			//Switch in 1/1.58 resistor divider
			HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.CLOSE);
			HW.Dvi.Mode(PM.VOUT_RES_MEAS, Dvi.FMMode.FVMI);
			HW.Dvi.WriteV(PM.VOUT_RES_MEAS, 4.45);	//4.45*0.449 = 2V

			//Measure each voltage using MuxB
			vsensenVoltage = Utl.MeasureNode(App.MuxNodes.VSENSEN_MEAS, App.MeasOptions.DMM);

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
				voutScaleVoltage = Utl.MeasureNode(App.MuxNodes.VOUT_SCALE_MEAS, App.MeasOptions.DMM);

			dutgndVoltage = Utl.MeasureNode(App.MuxNodes.DUTGND, App.MeasOptions.DMM);

			if(App.Globals.OfflineDev)
			{
				vsensenVoltage = 1.0;
				voutScaleVoltage = 2.0;
				dutgndVoltage = 0.0;
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				passFail += TestResult("MuxB - VsenseN", 1.1, 0.9, (double)vsensenVoltage[site], "V");
				
				if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
				{
					passFail += TestResult("MuxB - Vout Scale", 2.1, 1.9, (double)voutScaleVoltage[site], "V");
				}

				passFail += TestResult("MuxB - Dutgnd", 0.1, -0.1, (double)dutgndVoltage[site], "V");
			}

			//cleanup
			HW.Dvi.WriteV(PM.VSENSEN, 0.0);
			HW.Rdc.Set(PM.RLX14_RELAYS, OpenClose.OPEN);
			HW.Dvi.WriteV(PM.VOUT_RES_MEAS, 0.0);
			HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.OPEN);
			#endregion

			//*******Check Mux C (IC5)*******
			TP.Console.WriteLine("");
			TP.Console.WriteLine("***MuxC Tests***");
			#region MuxC
			//Setup voltage on MuxC inputs	
			//Switch in 1/1.58 resistor divider
			HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.CLOSE);
			HW.Dvi.Mode(PM.VOUT_RES_MEAS, Dvi.FMMode.FVMI);
			HW.Dvi.WriteV(PM.VOUT_RES_MEAS, 2.0);
			App.Time.MsDelay(1.0);

			//Measure each voltage using MuxC
			vGainCheckVoltage = Utl.MeasureNode(App.MuxNodes.V_GAIN_CHECK, App.MeasOptions.DMM);
			if(App.Globals.OfflineDev)
				vGainCheckVoltage = 2.0;

			foreach(Site site in TP.MS.ActiveSites)
			{
				passFail += TestResult("MuxC - VGainCheck", 2.1, 1.8, (double)vGainCheckVoltage[site], "V");
			}

			//cleanup
			HW.Dvi.WriteV(PM.VOUT_RES_MEAS, 0.0);
			HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.OPEN);
			#endregion

			TP.Console.WriteLine("");
			TP.Console.WriteLine("");
			return passFail;
		}
		#endregion

		//
		//MeasureOnboardResistances method
		//
		#region MeasureOnboardResistances  				:
		/// <summary>
		/// Measures Iout loads, Rext resistive value and Voltage scale circuit ratios.
		/// </summary>

		public static int MeasureOnboardResistances ( )
		{
			MsDouble forcedVoltage = 4.0, 
				forcedCurrent= 0.0,
				ioutMeasVolt, resRatio, highRes, lowRes,
				rextMeasVolt, rextRes,
				voutScaleIP, voutScaleVolt, highRatio, lowRatio;
			int num_averages = 1000;
			int passFail = 0;
			MsDouble rLoadLowLimit = 0, rLoadHighLimit = 0;
			String testName;

			//4pt measurement of rload on Brd1 produced the following measurements:
			//S1: 300.033Ohm
			//S2: 300.19Ohm
			//S3: 300.10Ohm
			//S4: 300.075Ohm

			rLoadLowLimit[Site.S1] = 299;
			rLoadLowLimit[Site.S2] = 299;
			rLoadLowLimit[Site.S3] = 299;
			rLoadLowLimit[Site.S4] = 299;

			rLoadHighLimit[Site.S1] = 301;
			rLoadHighLimit[Site.S2] = 301;
			rLoadHighLimit[Site.S3] = 301;
			rLoadHighLimit[Site.S4] = 301;

			HW.Dmm.Integration(PM.DMM, 0.02);

			TP.Console.WriteLine("******************************************");
			TP.Console.WriteLine("********On-board resistances Tests********");
			TP.Console.WriteLine("******************************************");

			//Measure Iout Loads
			TP.Console.WriteLine("");
			TP.Console.WriteLine("***Iout Loads***");
			#region IoutLoads
			forcedCurrent = 9.5e-3;

			//Ensure both resistors are switched through
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.OPEN);

			//Setup VIF to force voltage across resistor divider 
			//HW.Dvi.WriteV(PM.IOUT, 0.0);
			HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FVMI);	
			HW.Dvi.VRange(PM.IOUT_RES_MEAS, Dvi.VRanges.V_5_V);
			HW.Dvi.IRange(PM.IOUT_RES_MEAS, Dvi.IRanges.I_10_MA);
			HW.Dvi.WriteV(PM.IOUT_RES_MEAS, forcedVoltage);
			App.Time.MsDelay(100);

			//Measure resistor ratio
			ioutMeasVolt = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, App.MeasOptions.DMM);
			if(App.Globals.OfflineDev)
				ioutMeasVolt = 2.14;
			resRatio = ioutMeasVolt/forcedVoltage;

			HW.Dvi.WriteV(PM.IOUT_RES_MEAS, 0.0);
			//Force current through load to determine actual resistance of low resistor
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
			HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FIMV);
			HW.Dvi.IRange(PM.IOUT_RES_MEAS, Dvi.IRanges.I_10_MA);
			HW.Dvi.WriteI(PM.IOUT_RES_MEAS, forcedCurrent);
			App.Time.MsDelay(100);

			//Measure voltage at top of low resistor
			ioutMeasVolt = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, App.MeasOptions.DMM);
			if(App.Globals.OfflineDev)
				ioutMeasVolt = 1.2;
			lowRes = ioutMeasVolt/forcedCurrent;

			//Low Resistance/Total Resistance = Resistor Ratio
			highRes = lowRes/resRatio - lowRes;

			//cleanup
			HW.Dvi.WriteI(PM.IOUT_RES_MEAS, 0.0);
			HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FVMI);	
			HW.Dvi.VRange(PM.IOUT_RES_MEAS, Dvi.VRanges.V_5_V);
			HW.Dvi.IRange(PM.IOUT_RES_MEAS, Dvi.IRanges.I_10_MA);
			HW.Dvi.WriteV(PM.IOUT_RES_MEAS, 0.0);

			foreach(Site site in TP.MS.ActiveSites)
			{
				TP.Console.WriteLine("Site {0}:", site);
				passFail += TestResult("Iout Low Load Value", rLoadHighLimit[site], rLoadLowLimit[site], (double)lowRes[site], "Ohm");
				passFail += TestResult("Iout High Load Value", 1802, 1797, (double)highRes[site], "Ohm");
				passFail += TestResult("Iout Load Resistor Ratio", 0.143, 0.141, (double)resRatio[site], "");
				TP.Console.WriteLine("");
			}

			//Set global variables for use later in the program
			App.TC.BoardVars.IoutLoadRatio = resRatio;
			App.TC.BoardVars.IoutLowRes = lowRes;
			App.TC.BoardVars.IoutHighRes = highRes;

			#endregion


			forcedCurrent = 600e-6;
			//Measure Rext
			TP.Console.WriteLine("");
			TP.Console.WriteLine("***Rext Resistors***");


			#region RextMeas

			//Switch in VIF & force current through 15k resistor
			HW.Rdc.Set(PM.RLX05_RELAYS, OpenClose.CLOSE);
			HW.Dvi.Mode(PM.REXT1_RES_MEAS, Dvi.FMMode.FIMV);
			HW.Dvi.IRange(PM.REXT1_RES_MEAS, Dvi.IRanges.I_10_MA);
			HW.Dvi.WriteI(PM.REXT1_RES_MEAS, forcedCurrent);
			HW.Dvi.NumAverages(PM.REXT1_RES_MEAS, num_averages);
			//Why such a long delay needed here???
			App.Time.MsDelay(1000.0);

			//Measure voltage dropped across resistor
			rextMeasVolt = HW.Dvi.ReadV(PM.REXT1_RES_MEAS);
			if(App.Globals.OfflineDev)
				rextMeasVolt = 10.5;
			rextRes = rextMeasVolt/forcedCurrent;

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				foreach(Site site in TP.MS.ActiveSites)
				{
					testName = String.Format("Rext Value, {0}", site);
					passFail += TestResult(testName, 15500, 14500, (double)rextRes[site], "Ohm");
				}
			}
			else
			{
				testName = String.Format("Rext Value, {0}", Site.S1);
				passFail += TestResult(testName, 15500, 14500, (double)rextRes[Site.S1], "Ohm");
			}

			TP.Console.WriteLine("");

			//Set global variables for use later in the program
			App.TC.BoardVars.RextVal = rextRes;

			//cleanup
			HW.Dvi.NumAverages(PM.REXT1_RES_MEAS, 100);
			HW.Dvi.WriteI(PM.REXT1_RES_MEAS, 0.0);
			HW.Rdc.Set(PM.RLX05_RELAYS, OpenClose.OPEN);
			#endregion

			forcedCurrent = 40e-6;

			//  if not probe run voutscaleratios, if probe dont run it

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{

				//Measure Vout Scale Resistor Divider Ratio
				TP.Console.WriteLine("");
				TP.Console.WriteLine("***Vout Scale Resistor Dividers***");

				#region VoutScaleRatios
				//Force voltage from VIF through 1/5.3 resistor divider
				//Measure corresponding out and calculate ratio
				HW.Dvi.Mode(PM.VOUT_RES_MEAS, Dvi.FMMode.FIMV);
				HW.Dvi.IRange(PM.VOUT_RES_MEAS, Dvi.IRanges.I_50_UA);
				HW.Dvi.WriteI(PM.VOUT_RES_MEAS, forcedCurrent);
				HW.Dvi.NumAverages(PM.VOUT_RES_MEAS, 100);
				App.Time.MsDelay(1000);

				voutScaleIP = Utl.MeasureNode(App.MuxNodes.V_GAIN_CHECK, App.MeasOptions.DMM);
				App.TC.BoardVars.VoutScaleHighLoad = voutScaleIP / forcedCurrent;
				voutScaleVolt = Utl.MeasureNode(App.MuxNodes.VOUT_SCALE_MEAS, App.MeasOptions.DMM);

				if(App.Globals.OfflineDev)
				{
					voutScaleIP = 10.0;
					voutScaleVolt = 1.577;
				}
				highRatio = voutScaleVolt/voutScaleIP;

				//Run the same procedure for the 1/2.58 divider
				forcedCurrent = 2e-3;
				HW.Dvi.WriteI(PM.VOUT_RES_MEAS, 0.0);
				HW.Dvi.IRange(PM.VOUT_RES_MEAS, Dvi.IRanges.I_10_MA);
				HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.CLOSE);
				HW.Dvi.WriteI(PM.VOUT_RES_MEAS, forcedCurrent);
				App.Time.MsDelay(1000);
	
				voutScaleIP = Utl.MeasureNode(App.MuxNodes.V_GAIN_CHECK, App.MeasOptions.DMM);
				App.TC.BoardVars.VoutScaleLowLoad = voutScaleIP/forcedCurrent;
				voutScaleVolt = Utl.MeasureNode(App.MuxNodes.VOUT_SCALE_MEAS, App.MeasOptions.DMM);

				if(App.Globals.OfflineDev)
				{
					voutScaleIP = 10.0;
					voutScaleVolt = 4.5;
				}
				lowRatio = voutScaleVolt/voutScaleIP;

				foreach(Site site in TP.MS.ActiveSites)
				{
					TP.Console.WriteLine("Site {0}:", site);
					passFail += TestResult("Vout Scale Cct1 Gain", 0.170, 0.155, (double)highRatio[site], "");
					passFail += TestResult("Vout Scale Cct1 Load", 239.5e3, 238.0e3, (double)App.TC.BoardVars.VoutScaleHighLoad[site], "Ohm");
					passFail += TestResult("Vout Scale Cct2 Gain", 0.451, 0.447, (double)lowRatio[site], "");
					passFail += TestResult("Vout Scale Cct2 Load", 5.1e3, 4.7e3, (double)App.TC.BoardVars.VoutScaleLowLoad[site], "Ohm");
					TP.Console.WriteLine("");
				}
				TP.Console.WriteLine("");

				//Set global variables for use later in the program
				App.TC.BoardVars.VoutScaleHighGain = highRatio;
				App.TC.BoardVars.VoutScaleLowGain = lowRatio;

				//cleanup
				HW.Dvi.WriteI(PM.VOUT_RES_MEAS, 0.0);
				HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.OPEN);
				HW.Dvi.NumAverages(PM.VOUT_RES_MEAS, 1);
				HW.Dvi.Mode(PM.VOUT_RES_MEAS, Dvi.FMMode.FVMI);
				#endregion

			}

			HW.Dmm.Integration(PM.DMM, 0.002);

			return passFail;
		}
		#endregion

		//
		//MeasureDvccDiode method
		//
		#region MeasureDvccDiode  				:
		/// <summary>
		/// Measures diode drop on DVcc when high voltage protection circuit is utilised
		/// </summary>

		public static void MeasureDvccDiode ( )
		{
			MsDouble targetVoltage = 5.0,
				forcedVoltage = 0.0, 
				measuredVoltage = 0.0,
				diodeDrop = 0.0;
			int numAverages = 500;

			//Set up DVcc PMU to FIMV so that it can measure voltage on other side of the diode
			HW.Dss.ConnectionSet(PM.DVCC, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuConnectMode(PM.DVCC, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FIMV_200_UA);
			HW.Dss.PmuModeValue(PM.DVCC, Dss.PmuMode.FIMV_200_UA, -2.0e-6);
			HW.Rdc.Set(PM.D3, OpenClose.CLOSE);

			//Setup DVcc VIF to force voltage across diode
			//HW.Dvi.WriteV(PM.IOUT, 0.0);
			HW.Dvi.WriteV(PM.DVCC, targetVoltage);
			App.Time.MsDelay(100);

			//Measure actual VIF voltage first with no diode drop
			HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);
			forcedVoltage = HW.Dss.PmuRead(PM.DVCC, numAverages);

			//Now check voltage with diode in the path
			HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.RelaySettle);
			measuredVoltage = HW.Dss.PmuRead(PM.DVCC, numAverages);

			diodeDrop = forcedVoltage - measuredVoltage;

			//cleanup
			HW.Dvi.WriteV(PM.DVCC, 0.0);
			HW.Dss.PmuConnectMode(PM.DVCC, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_200_UA);
			HW.Dss.ConnectionSet(PM.DVCC, Dss.ConnectionMode.DISCONNECT);
			HW.Rdc.Set(PM.D3, OpenClose.OPEN);

			foreach(Site site in TP.MS.ActiveSites)
			{
				TestResult("DVcc Diode Value", 0.9, 0.4, diodeDrop[site], "Ohm");
			}
				
			//Set global variables for use later in the program
			App.TC.BoardVars.DvccDiodeVoltage = diodeDrop;

		}
		#endregion
	
		//
		//DigitiserCal method
		//	

		#region DigitiserCal  				:
		/// <summary>
		/// This method calculates and offset and gain error associated with each digitiser channel.
		/// These values are in turn used in each digitiser measurement during a test program run.
		/// </summary>

		public static int DigitiserCal ( )
		{
			//
			// if not probe run digitiser cal
			//
			int passFail = 0;

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				int numMeasPoints = 5, i;

				double stepVoltage, forceV = 0;
				double stepCurr, forceI = 0;
				//double ioutMaxVoltage = 7.5, ioutMinVoltage = -7.5;
				double ioutMaxCurr = 24.0e-3, ioutMinCurr = -24.0e-3;
				double vsenseNMaxVolt = 10, vsenseNMinVolt = -10;
				//20V max VIF output but this node is connected to mux input so max voltage on this node <= 15V
				double vscaleMaxVolt = 15, vscaleMinVolt = -15;	
				String testName;

				MsDouble [] dmmVoltage = new MsDouble[numMeasPoints];
				MsDouble [] digVoltage = new MsDouble[numMeasPoints];
				MsDouble [] error = new MsDouble[numMeasPoints];

				HW.Dmm.Integration(PM.DMM, 0.020);

				TP.Console.WriteLine("*********************************");
				TP.Console.WriteLine("*******DIGITISER Cal Tests*******");
				TP.Console.WriteLine("*********************************");

				//Initialise all variables to default values first
				App.TC.BoardVars.dig14offset1 = 0.0;
				App.TC.BoardVars.dig14offset2 = 0.0;
				App.TC.BoardVars.dig15offset1 = 0.0;
				App.TC.BoardVars.dig15offset2 = 0.0;
				App.TC.BoardVars.dig14gain1 = 1.0;
				App.TC.BoardVars.dig14gain2 = 1.0;
				App.TC.BoardVars.dig15gain1 = 1.0;
				App.TC.BoardVars.dig15gain2 = 1.0;

				//*******Check DIG SLOT 14 *******
				TP.Console.WriteLine("");
				TP.Console.WriteLine("***DIG SLOT 14 Tests***");

				#region DIG14
				//Iout Connections - DIG 14 - 1

				#region IoutCalc
				//Hardware setup
				HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
				HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FIMV);
				HW.Dvi.IRange(PM.IOUT_RES_MEAS, Dvi.IRanges.I_250_MA);
				HW.Dvi.VRange(PM.IOUT_RES_MEAS, Dvi.VRanges.V_20_V);

				//max current in Iout = 24.5mA -> 24.5mA*300Ohm = 7.35V
				//Only check digitiser to 7.5V as this will only cause ~190mW across 300Ohm resistor
				//If checked all the way to 10V, this would cause 300mW power and resistor is not spec'ed
				//to handle this over temperature.

				//stepVoltage = (ioutMaxVoltage - ioutMinVoltage)/(numMeasPoints - 1);
				stepCurr = (ioutMaxCurr - ioutMinCurr)/(numMeasPoints - 1);

				for(i = 0; i < numMeasPoints; i++)
				{
					//forceV = ioutMinVoltage + i*stepVoltage;
					forceI = ioutMinCurr + i*stepCurr;
					HW.Dvi.WriteI(PM.IOUT_RES_MEAS, forceI);	
					App.Time.MsDelay(App.TC.VifDelay);

					//Measure voltage across 300 resistor
					dmmVoltage[i] = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, App.MeasOptions.DMM);
					digVoltage[i] = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, App.MeasOptions.DIG);

				}
	
				foreach(Site site in TP.MS.ActiveSites)
				{
					//Offset calculated from the Zero Point, i.e. Viout = 0V
					App.TC.BoardVars.dig14offset1[site] = digVoltage[((numMeasPoints - 1)/2)][site] - dmmVoltage[((numMeasPoints - 1)/2)][site];
					//Gain calculated as (DigFS - DigZS) / (DmmFS - DmmZS), i.e. inputs are measured by Dmm, outputs by DIG.
					App.TC.BoardVars.dig14gain1[site] = (digVoltage[numMeasPoints-1][site] - digVoltage[0][site]) / (dmmVoltage[numMeasPoints - 1][site] - dmmVoltage[0][site]);

					TP.Console.WriteLine("Site {0}:", site);
					passFail += TestResult("V(Iout) (DIG14, CH1) Offset", 0.0007, -0.0007, App.TC.BoardVars.dig14offset1[site], "V");
					passFail += TestResult("V(Iout) (DIG14, CH1) Gain", 1.001, 0.999, App.TC.BoardVars.dig14gain1[site], "");
					TP.Console.WriteLine("");
				}
			
				//Now repeat with new m & c variables and check errors.
				for(i = 0; i < numMeasPoints; i++)
				{
					//forceV = ioutMinVoltage + i*stepVoltage;
					forceI = ioutMinCurr + i*stepCurr;
					HW.Dvi.WriteI(PM.IOUT_RES_MEAS, forceI);	
					App.Time.MsDelay(App.TC.VifDelay);

					//Measure voltage across 300 resistor
					dmmVoltage[i] = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, App.MeasOptions.DMM);
					digVoltage[i] = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, App.MeasOptions.DIG);

					error[i] = digVoltage[i] - dmmVoltage[i];
					foreach(Site site in TP.MS.ActiveSites)
					{
						testName = String.Format("Iout Node {0} Error, {1}", i, site);
						passFail += TestResult(testName, 0.0005, -0.0005, error[i][site], "V");
					}
					TP.Console.WriteLine("");
				}



				//cleanup
				HW.Dvi.WriteI(PM.IOUT_RES_MEAS, 0.0);
				HW.Dvi.IRange(PM.IOUT_RES_MEAS, Dvi.IRanges.I_10_MA);
				HW.Dvi.VRange(PM.IOUT_RES_MEAS, Dvi.VRanges.V_5_V);
				HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FVMI);
				HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.OPEN);

				TP.Console.WriteLine("");
				TP.Console.WriteLine("");
				#endregion

				//VsenseN Connections - DIG 14 - 2

				#region VsenseNCalc
				//Hardware Setup
				HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX14_RELAYS, OpenClose.CLOSE);
				HW.Dvi.Mode(PM.VSENSEN, Dvi.FMMode.FVMI);

				stepVoltage = (vsenseNMaxVolt - vsenseNMinVolt)/(numMeasPoints - 1);

				for(i = 0; i < numMeasPoints; i++)
				{
					forceV = vsenseNMinVolt + i*stepVoltage;
					HW.Dvi.WriteV(PM.VSENSEN, forceV);	
					App.Time.MsDelay(App.TC.VifDelay);

					//Measure voltage on VsenseN using dmm & dig
					dmmVoltage[i] = Utl.MeasureNode(App.MuxNodes.VSENSEN_MEAS, App.MeasOptions.DMM);
					digVoltage[i] = Utl.MeasureNode(App.MuxNodes.VSENSEN_MEAS, App.MeasOptions.DIG);
				}
	
				foreach(Site site in TP.MS.ActiveSites)
				{
					//Offset calculated from the Zero Point, i.e. Viout = 0V
					App.TC.BoardVars.dig14offset2[site] = digVoltage[((numMeasPoints - 1)/2)][site] - dmmVoltage[((numMeasPoints - 1)/2)][site];
					//Gain calculated as (DigFS - DigZS) / (DmmFS - DmmZS), i.e. inputs are measured by Dmm, outputs by DIG.
					App.TC.BoardVars.dig14gain2[site] = (digVoltage[numMeasPoints-1][site] - digVoltage[0][site]) / (dmmVoltage[numMeasPoints - 1][site] - dmmVoltage[0][site]);

					TP.Console.WriteLine("Site {0}:", site);
					passFail += TestResult("V(VsenseN) (DIG14, CH2) Offset", 0.0007, -0.0007, App.TC.BoardVars.dig14offset2[site], "V");
					passFail += TestResult("V(VsenseN) (DIG14, CH2) Gain", 1.001, 0.999, App.TC.BoardVars.dig14gain2[site], "");
					TP.Console.WriteLine("");
				}

				//Now repeat with new m & c variables and check errors.
				for(i = 0; i < numMeasPoints; i++)
				{
					forceV = vsenseNMinVolt + i*stepVoltage;
					HW.Dvi.WriteV(PM.VSENSEN, forceV);	
					App.Time.MsDelay(App.TC.VifDelay);

					//Measure voltage on VsenseN using dmm & dig
					dmmVoltage[i] = Utl.MeasureNode(App.MuxNodes.VSENSEN_MEAS, App.MeasOptions.DMM);
					digVoltage[i] = Utl.MeasureNode(App.MuxNodes.VSENSEN_MEAS, App.MeasOptions.DIG);

					error[i] = digVoltage[i] - dmmVoltage[i];
					foreach(Site site in TP.MS.ActiveSites)
					{
						testName = String.Format("VsenseN Node {0} Error, {1}", i, site);
						passFail += TestResult(testName, 0.0005, -0.0005, error[i][site], "V");
					}
					TP.Console.WriteLine("");
				}

				//cleanup
				HW.Dvi.WriteV(PM.VSENSEN, 0.0);
				HW.Dvi.Mode(PM.VSENSEN, Dvi.FMMode.FVMI);
				HW.Rdc.Set(PM.RLX14_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.OPEN);
				TP.Console.WriteLine("");
				TP.Console.WriteLine("");
				#endregion

				#endregion

				//*******Check DIG SLOT 15 *******
				TP.Console.WriteLine("");
				TP.Console.WriteLine("***DIG SLOT 15 Tests***");

				#region DIG15
				//Iout Connections - DIG 15 - 1

				#region VoutCalc
				//No resource on the board to allow us to sweep voltage on Vout and measure offset/gain.
				//Only possibility is to tie Vout to ground via load resistor and measure digitiser offset only.

				//Hardware setup
				HW.Rdc.Set(PM.D15, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
				HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.OPEN);

				//Measure Vout voltage
				dmmVoltage[0] = Utl.MeasureNode(App.MuxNodes.VOUT_MEAS, App.MeasOptions.DMM);
				digVoltage[0] = Utl.MeasureNode(App.MuxNodes.VOUT_MEAS, App.MeasOptions.DIG);
	
				foreach(Site site in TP.MS.ActiveSites)
				{
					//Offset calculated from the Zero Point, i.e. Viout = 0V
					App.TC.BoardVars.dig15offset1[site] = digVoltage[0][site] - dmmVoltage[0][site];
					//Since gain can't be measured, have to assume it's 1.
					App.TC.BoardVars.dig15gain1[site] = 1;

					TP.Console.WriteLine("Site {0}:", site);
					passFail += TestResult("V(Vout) (DIG15, CH1) Offset", 0.0007, -0.0007, App.TC.BoardVars.dig15offset1[site], "V");
					passFail += TestResult("V(Vout) (DIG15, CH1) Gain", 1.001, 0.999, App.TC.BoardVars.dig15gain1[site], "");
					TP.Console.WriteLine("");
				}

				//Now repeat with new m & c variables and check errors.

				//Measure Vout voltage
				dmmVoltage[0] = Utl.MeasureNode(App.MuxNodes.VOUT_MEAS, App.MeasOptions.DMM);
				digVoltage[0] = Utl.MeasureNode(App.MuxNodes.VOUT_MEAS, App.MeasOptions.DIG);

				error[0] = digVoltage[0] - dmmVoltage[0];
				foreach(Site site in TP.MS.ActiveSites)
				{
					testName = String.Format("Vout Node {0} Error, {1}", 0, site);
					passFail += TestResult(testName, 0.0005, -0.0005, error[0][site], "V");
				}
				TP.Console.WriteLine("");


				//cleanup
				HW.Rdc.Set(PM.D15, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.OPEN);
				TP.Console.WriteLine("");
				TP.Console.WriteLine("");
				#endregion

				//Vout Scale Connections - DIG 15 - 2

				#region VscaleCalc
			
				//Use low ratio resistor divider circuit to 
				//setup voltage on vscale pins
				HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX19_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.CLOSE);
				HW.Dvi.Mode(PM.VOUT_RES_MEAS, Dvi.FMMode.FVMI);
				HW.Dvi.IRange(PM.VOUT_RES_MEAS, Dvi.IRanges.I_250_MA);
				HW.Dvi.VRange(PM.VOUT_RES_MEAS, Dvi.VRanges.V_20_V);

				stepVoltage = (vscaleMaxVolt - vscaleMinVolt)/(numMeasPoints - 1);

				for(i = 0; i < numMeasPoints; i++)
				{
					forceV = vscaleMinVolt + i*stepVoltage;
					HW.Dvi.WriteV(PM.VOUT_RES_MEAS, forceV);	
					App.Time.MsDelay(App.TC.VifDelay);

					//Measure voltage across 300 resistor
					dmmVoltage[i] = Utl.MeasureNode(App.MuxNodes.VOUT_SCALE_MEAS, App.MeasOptions.DMM);
					digVoltage[i] = Utl.MeasureNode(App.MuxNodes.VOUT_SCALE_MEAS, App.MeasOptions.DIG);
				}

				foreach(Site site in TP.MS.ActiveSites)
				{
					//Offset calculated from the Zero Point, i.e. Viout = 0V
					App.TC.BoardVars.dig15offset2[site] = digVoltage[((numMeasPoints - 1)/2)][site] - dmmVoltage[((numMeasPoints - 1)/2)][site];
					//Gain calculated as (DigFS - DigZS) / (DmmFS - DmmZS), i.e. inputs are measured by Dmm, outputs by DIG.
					App.TC.BoardVars.dig15gain2[site] = (digVoltage[numMeasPoints-1][site] - digVoltage[0][site]) / (dmmVoltage[numMeasPoints - 1][site] - dmmVoltage[0][site]);

					TP.Console.WriteLine("Site {0}:", site);
					passFail += TestResult("V(Vscale) (DIG15, CH2) Offset", 0.0007, -0.0007, App.TC.BoardVars.dig15offset2[site], "V");
					passFail += TestResult("V(Vscale) (DIG15, CH2) Gain", 1.001, 0.999, App.TC.BoardVars.dig15gain2[site], "");
					TP.Console.WriteLine("");
				}

				//Now repeat with new m & c variables and check errors.
				for(i = 0; i < numMeasPoints; i++)
				{
					forceV = vscaleMinVolt + i*stepVoltage;
					HW.Dvi.WriteV(PM.VOUT_RES_MEAS, forceV);	
					App.Time.MsDelay(App.TC.VifDelay);

					//Measure voltage across 300 resistor
					dmmVoltage[i] = Utl.MeasureNode(App.MuxNodes.VOUT_SCALE_MEAS, App.MeasOptions.DMM);
					digVoltage[i] = Utl.MeasureNode(App.MuxNodes.VOUT_SCALE_MEAS, App.MeasOptions.DIG);

					error[i] = digVoltage[i] - dmmVoltage[i];
					foreach(Site site in TP.MS.ActiveSites)
					{
						testName = String.Format("Vscale Node {0} Error, {1}", i, site);
						passFail += TestResult(testName, 0.0005, -0.0005, error[i][site], "V");
					}
					TP.Console.WriteLine("");
				}

				//cleanup
				HW.Dvi.WriteV(PM.VOUT_RES_MEAS, 0.0);	
				HW.Dvi.IRange(PM.VOUT_RES_MEAS, Dvi.IRanges.I_10_MA);
				TP.Console.WriteLine("");
				TP.Console.WriteLine("");
				#endregion

				#endregion

				TP.Console.WriteLine("");
				TP.Console.WriteLine("");
			
			
				HW.Dmm.Integration(PM.DMM, 0.002);

			}
			
			return passFail;
		}
		#endregion
	
		//
		//TestResult method
		//
		#region TestResult  				:
		/// <summary>
		/// Checks/Prints pass/fail results based on test limits
		/// </summary>

		public static int TestResult ( string testName, double higherLimit, double lowerLimit, double result, string units )
		{
			int passFailInt = 0;
			string passFail = "PASS";

			if((result < lowerLimit) || (result > higherLimit))
			{
				passFail = "FAIL";
				passFailInt++;
			}

			TP.Console.WriteLine("{0}: {1} {2} < {3} {4} < {5} {6}	=> {7}", testName, lowerLimit, units, result, units, higherLimit, units, passFail);
	
			return passFailInt;
		}
		#endregion



	}	// end of class BoardCheckUtl

}
