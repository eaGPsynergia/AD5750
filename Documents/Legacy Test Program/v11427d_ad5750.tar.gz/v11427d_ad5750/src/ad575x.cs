//
// Main program entry point and initialization/cleanup functions.
//
// History:
// 11/29/05 - CTS - Template Created.
//
using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{
	/// <summary>
	/// AD575x application.
	/// </summary>
	public class App : ProgramProxy
	{
		//
		// All types, variables and constants used throughout the program are declared here
		//
		#region Types, Constants and Global Variables                 :
		//
		// Add Custom Type Definitions here (e.g. types declared as structs in C++) :
		//

		#region Custom Types                    :
		//
		// RangeData custom type
		//
		#region RangeData                       :
		/// <summary>
		/// Contains information on each of the different current and voltage ranges of the AD5750/1
		/// </summary>
		public class RangeData
		{
			/// <summary>
			/// Default constructor, used when initializing arrays and standalone variables.
			/// </summary>
			public RangeData ( )
			{
				// For most types nothing special needs to be done here, the compiler will
				// automatically initialize all basic types (double, int, etc) with 0,
				// bools to false and strings to null.
			}
			
			/// <summary>
			/// This constructor is used when initializing a range type for the AD5750/51
			/// </summary>
			public RangeData (string RangeName, int ProgBits, int Index, double MaxValue, double MinValue, double MidValue, App.RangeType VoltageCurrentIdentifier, MsInt GainTrimCode, MsInt OffsetTrimCode, MsInt ExtGainTrimCode, MsInt ExtOffsetTrimCode, App.RangeAccType RangeAccType)
			{
				this.RangeName = RangeName;
				this.ProgBits = ProgBits;
				this.Index = Index;
				this.MaxValue = MaxValue;
				this.MinValue = MinValue;
				this.MidValue = MidValue;
				this.VoltageCurrentIdentifier = VoltageCurrentIdentifier;
				this.GainTrimCode = GainTrimCode;
				this.OffsetTrimCode = OffsetTrimCode;
				this.ExtGainTrimCode = ExtGainTrimCode;
				this.ExtOffsetTrimCode = ExtOffsetTrimCode;
				this.RangeAccType = RangeAccType;
			}
			
			/// <summary>
			/// A string to represent the name of the range
			/// </summary>
			public string RangeName;
			
			/// <summary>
			/// 4 bit number used to program this range
			/// </summary>
			public int ProgBits;
			
			/// <summary>
			/// Replace this comment with a description of this parameter
			/// </summary>
			public int Index;
			
			/// <summary>
			/// Maximum value of the range
			/// </summary>
			public double MaxValue;
			
			/// <summary>
			/// Minimum value of the range
			/// </summary>
			public double MinValue;
			
			/// <summary>
			/// Midscale value of the range
			/// </summary>
			public double MidValue;
			
			/// <summary>
			/// This variable is set to 1 when range is a voltage range and 0 when range is a current range
			/// </summary>
			public App.RangeType VoltageCurrentIdentifier;

			/// <summary>
			/// Gain Trim Code for this range
			/// </summary>
			public MsInt GainTrimCode;

			/// <summary>
			/// Offset Trim Code for this range
			/// </summary>
			public MsInt OffsetTrimCode;

			/// <summary>
			/// Gain Trim Code for this range
			/// </summary>
			public MsInt ExtGainTrimCode;

			/// <summary>
			/// Offset Trim Code for this range
			/// </summary>
			public MsInt ExtOffsetTrimCode;

			/// <summary>
			/// This variable is set to 0 when range is a trimmable range and 0 when range is an over-range
			/// </summary>
			public App.RangeAccType RangeAccType;
			
		}
		#endregion


		//
		// TimingConditions custom type
		//
		#region TimingConditions                :
		/// <summary>
		/// Contains all relative timing edges for normal operation of the device.
		/// </summary>
		public class TimingConditions
		{
			/// <summary>
			/// Default constructor, used when initializing arrays and standalone variables.
			/// </summary>
			public TimingConditions ( )
			{
				// For most types nothing special needs to be done here, the compiler will
				// automatically initialize all basic types (double, int, etc) with 0,
				// bools to false and strings to null.
			}
			
			/// <summary>
			/// This constructor is used when initializing a variable/array on declaration.
			/// </summary>
			public TimingConditions (double SyncLead, double SyncTrail, double SclkLead, double SclkTrail, double SdinLead, double SdinTrail, double SdoStrobe, double ResetLead, double ResetTrail, double ClearLead)
			{
				this.SyncLead = SyncLead;
				this.SyncTrail = SyncTrail;
				this.SclkLead = SclkLead;
				this.SclkTrail = SclkTrail;
				this.SdinLead = SdinLead;
				this.SdinTrail = SdinTrail;
				this.SdoStrobe = SdoStrobe;
				this.ResetLead = ResetLead;
				this.ResetTrail = ResetTrail;
				this.ClearLead = ClearLead;
			}
			
			/// <summary>
			/// Sync Falling Edge
			/// </summary>
			public double SyncLead;
			
			/// <summary>
			/// Sync Rising Edge
			/// </summary>
			public double SyncTrail;
			
			/// <summary>
			/// SCLK Rising Edge
			/// </summary>
			public double SclkLead;
			
			/// <summary>
			/// Sclk Falling Edge
			/// </summary>
			public double SclkTrail;
			
			/// <summary>
			/// SDIN Leading Edge
			/// </summary>
			public double SdinLead;
			
			/// <summary>
			/// SDIN Trailing Edge
			/// </summary>
			public double SdinTrail;
			
			/// <summary>
			/// SDO Strobe Edge
			/// </summary>
			public double SdoStrobe;
			
			/// <summary>
			/// RESET Edge (RZ)
			/// </summary>
			public double ResetLead;
		
			/// <summary>
			/// RESET Edge (RZ)
			/// </summary>
			public double ResetTrail;

			/// <summary>
			/// CLEAR Edge (NRZ)
			/// </summary>
			public double ClearLead;
	
		}
		#endregion


		//
		// BoardVariables custom type
		//
		#region BoardVariables                  :
		/// <summary>
		/// Replace this comment with a description on the purpose of this data type
		/// </summary>
		public class BoardVariables
		{
			/// <summary>
			/// Default constructor, used when initializing arrays and standalone variables.
			/// </summary>
			public BoardVariables ( )
			{
				// For most types nothing special needs to be done here, the compiler will
				// automatically initialize all basic types (double, int, etc) with 0,
				// bools to false and strings to null.
			}
			
			/// <summary>
			/// This constructor is used when initializing a variable/array on declaration.
			/// </summary>
			public BoardVariables (MsDouble VoutScaleHighGain, MsDouble VoutScaleHighLoad, MsDouble VoutScaleLowGain, 
				MsDouble VoutScaleLowLoad, MsDouble IoutLoadRatio, MsDouble IoutHighRes, MsDouble IoutLowRes, 
				MsDouble RextVal, MsDouble VoutHighRes, MsDouble VoutLowRes, MsDouble DvccDiodeVoltage,
				MsDouble dig14offset1, MsDouble dig14offset2, MsDouble dig15offset1, MsDouble dig15offset2, 
				MsDouble dig14gain1, MsDouble dig14gain2, MsDouble dig15gain1, MsDouble dig15gain2)
			{
				this.VoutScaleHighGain = VoutScaleHighGain;
				this.VoutScaleHighLoad = VoutScaleHighLoad;
				this.VoutScaleLowGain = VoutScaleLowGain;
				this.VoutScaleLowLoad = VoutScaleLowLoad;
				this.IoutLoadRatio = IoutLoadRatio;
				this.IoutHighRes = IoutHighRes;
				this.IoutLowRes = IoutLowRes;
				this.RextVal = RextVal;
				this.VoutHighRes = VoutHighRes;
				this.VoutLowRes = VoutLowRes;
				this.DvccDiodeVoltage = DvccDiodeVoltage;
				this.dig14offset1 = dig14offset1;
				this.dig14offset2 = dig14offset2;
				this.dig15offset1 = dig15offset1;
				this.dig15offset2 = dig15offset2;
				this.dig14gain1 = dig14gain1;
				this.dig14gain2 = dig14gain2;
				this.dig15gain1 = dig15gain1;
				this.dig15gain2 = dig15gain2;
			}
			
			/// <summary>
			/// Replace this comment with a description of this parameter
			/// </summary>
			public MsDouble VoutScaleHighGain;

			/// <summary>
			/// Actual value of load on high gain circuit
			/// </summary>
			public MsDouble VoutScaleHighLoad;
			
			/// <summary>
			/// Replace this comment with a description of this parameter
			/// </summary>
			public MsDouble VoutScaleLowGain;

			/// <summary>
			/// Actual value of load on low gain circuit
			/// </summary>
			public MsDouble VoutScaleLowLoad;
			
			/// <summary>
			/// Replace this comment with a description of this parameter
			/// </summary>
			public MsDouble IoutLoadRatio;
			
			/// <summary>
			/// Highest value load resistance for Iout
			/// </summary>
			public MsDouble IoutHighRes;
			
			/// <summary>
			/// Lowest value load resistance for Iout
			/// </summary>
			public MsDouble IoutLowRes;
			
			/// <summary>
			/// Replace this comment with a description of this parameter
			/// </summary>
			public MsDouble RextVal;

			/// <summary>
			/// Highest value load resistance for Vout
			/// </summary>
			public MsDouble VoutHighRes;

			/// <summary>
			/// Lowest value load resistance for Vout
			/// </summary>
			public MsDouble VoutLowRes;

			/// <summary>
			/// Diode voltage drop on high voltage protection circuit
			/// </summary>
			public MsDouble DvccDiodeVoltage;

			/// <summary>
			/// Digitiser (14 1A - 1D) offset error
			/// </summary>
			public MsDouble dig14offset1;

			/// <summary>
			/// Digitiser (14 2A - 2D) offset error
			/// </summary>
			public MsDouble dig14offset2;

			/// <summary>
			/// Digitiser (15 1A - 1D) offset error
			/// </summary>
			public MsDouble dig15offset1;

			/// <summary>
			/// Digitiser (15 2A - 2D) offset error
			/// </summary>
			public MsDouble dig15offset2;

			/// <summary>
			/// Digitiser (14 1A - 1D) gain error
			/// </summary>
			public MsDouble dig14gain1;

			/// <summary>
			/// Digitiser (14 2A - 2D) gain error
			/// </summary>
			public MsDouble dig14gain2;

			/// <summary>
			/// Digitiser (15 1A - 1D) gain error
			/// </summary>
			public MsDouble dig15gain1;

			/// <summary>
			/// Digitiser (15 2A - 2D) gain error
			public MsDouble dig15gain2;
			
		}
		#endregion
		
		#endregion

		//
		// Add Custom Enum Definitions here
		//
		#region Custom Enums                    :

		/// <summary>
		/// V mode level.
		/// </summary>
		public enum Level
		{
			THRESH = 0,
			RAIL
		}

		/// <summary>
		/// Device operation mode
		/// </summary>
		public enum OpMode
		{
			SOFTWARE = 0,
			HARDWARE = 1
		}
	
		/// <summary>
		/// Clear to midscale or zeroscale
		/// </summary>
		public enum ClearMode
		{
			CLR_TO_ZERO = 0,
			CLR_TO_MID = 1
		}

		/// <summary>
		/// Internal or external resistor select
		/// </summary>
		public enum ResSel
		{
			R_EXT = 0,
			R_INT = 1
		}

		/// <summary>
		/// Output enable/disable
		/// </summary>
		public enum OutputEn
		{
			OP_DISABLE = 0,
			OP_ENABLE = 1
		}

		/// <summary>
		/// Clear/No clear select
		/// </summary>
		public enum ClearEn
		{
			NO_CLEAR = 0,
			CLEAR = 1
		}

		/// <summary>
		/// Software reset/no reset bits
		/// </summary>
		public enum SoftResetEn
		{
			NO_RESET = 0,
			RESET = 1
		}

		/// <summary>
		/// Hardware reset/no reset select
		/// </summary>
		public enum HardResetEn
		{
			HRDWR_RESET = 0,
			NO_HRDWR_RESET = 1
		}

		/// <summary>
		/// Range identifiers
		/// </summary>
		public enum RangeOptions
		{
			FOUR_TWENTY_MA = 0,
			TWENTY_MA = 1,
			TWENTY_FOUR_MA = 2,
			TWENTY_MA_BIP = 3,
			TWENTY_FOUR_MA_BIP = 4,
			THREE_TWENTY_MA = 5,
			TWENTY_P_FOUR_MA = 6,
			TWENTY_FOUR_P_FIVE_MA = 7,
			FIVE_V = 8,
			TEN_V = 9,
			FIVE_V_BIP = 10,
			TEN_V_BIP = 11,
			SIX_V = 12,
			TWELVE_V = 13,
			SIX_V_BIP = 14,
			TWELVE_V_BIP = 15,
			TWO_P_FIVE_V_BIP = 16,
			FORTY_V = 17,
			FORTY_FOUR_V = 18
		}

		/// <summary>
		/// Current/Voltage range identifier
		/// </summary>
		public enum RangeType
		{
			CURRENT = 0,
			VOLTAGE = 1
		}

		/// <summary>
		/// Test Mode Options programming bits
		/// </summary>
		public enum TestModes
		{
			TM_USER = 0x0,
			TM_FUSE_BYPASS = 0x2,
			TM_OFFSET_REG = 0x4,
			TM_GAIN_REG = 0x6,
			TM_BIAS_REG = 0x8,
			TM_TC_REG = 0xA,
			TM_FUSE_READ = 0x7,
			TM_TMUX = 0xF,
			TM_BLOW_FUSE = 0xC,
			TM_BLOW_MASTER = 0xE
		}

		/// <summary>
		/// Fuse read block bits
		/// </summary>
		public enum BlockBits
		{
			GAIN_BLOCK = 0x0,
			WAFER_BLOCK = 0x1,
			BIAS_BLOCK = 0x2,
			OFFSET_BLOCK = 0x3
		}

		/// <summary>
		/// Fuse blow block bits
		/// </summary>
		public enum BlowBlockBits
		{
			GAIN_BLOCK = 0x0,
			OFFSET_BLOCK = 0x1,
			BIAS_BLOCK = 0x2,
			WAFER_BLOCK = 0x3
		}

		/// <summary>
		/// Tmux nodes for switching to NC/IFAULT pin
		/// </summary>
		public enum TmuxBits
		{
			VIN_OUT = 0x1,
			VREF_OUT = 0x2,
			VOFS_DAC_OUT = 0x3,
			VOFS_BUF_OUT = 0x4,
			VOFS_BUF_NEG = 0x5,
			VTOI_1 = 0x6,
			VREF_DIV_2 = 0x7,
			VGEN_5V = 0x9,
			VGEN_7V = 0xA,
			VIN_1V_NEG = 0xB, 
			VOFF_1V_NEG = 0xC,
			TEMP_DIODE = 0xD, 
			TEMP_DIODE_UNB = 0xE,
			V_DAC = 0xF,
			TEMP_SHUTDOWN_EN = 0x18
		}

		/// <summary>
		/// Mux input nodes - per site
		/// </summary>
		public enum MuxPerSiteNodes
		{
			VREF_MEAS_0 = 0,
			VREF_MEAS_1 = 1,
			VREF_MEAS_2 = 2,
			VREF_MEAS_3 = 3,
			VIN_MEAS_0 = 4,
			VIN_MEAS_1 = 5,
			VIN_MEAS_2 = 6,
			VIN_MEAS_3 = 7,
			VOUT_MEAS_0 = 8,
			VOUT_MEAS_1 = 9,
			VOUT_MEAS_2 = 10,
			VOUT_MEAS_3 = 11,
			IOUT_MEAS_0 = 12,
			IOUT_MEAS_1 = 13,
			IOUT_MEAS_2 = 14,
			IOUT_MEAS_3 = 15,
			IFAULT_MEAS_0 = 16, 
			IFAULT_MEAS_1 = 17,
			IFAULT_MEAS_2 = 18,
			IFAULT_MEAS_3 = 19,
			VSENSEN_MEAS_0 = 20,
			VSENSEN_MEAS_1 = 21,
			VSENSEN_MEAS_2 = 22,
			VSENSEN_MEAS_3 = 23,
			VOUT_SCALE_MEAS_0 = 24,
			VOUT_SCALE_MEAS_1 = 25,
			VOUT_SCALE_MEAS_2 = 26,
			VOUT_SCALE_MEAS_3 = 27,
			DUTGND_0 = 28,
			DUTGND_1 = 29,
			DUTGND_2 = 30,
			DUTGND_3 = 31,
			V_GAIN_CHECK_0 = 32,
			V_GAIN_CHECK_1 = 33,
			V_GAIN_CHECK_2 = 34,
			V_GAIN_CHECK_3 = 35
		}
		 
		/// <summary>
		/// Mux Nodes (site independant)
		/// </summary>
		public enum MuxNodes
		{
			VREF_MEAS = 0,
			VIN_MEAS = 4,
			VOUT_MEAS = 8,
			IOUT_MEAS = 12,
			IFAULT_MEAS = 16, 
			VSENSEN_MEAS = 20,
			VOUT_SCALE_MEAS = 24,
			DUTGND = 28,
			V_GAIN_CHECK = 32
		}

		/// <summary>
		/// Iout load options - 300ohm or 2.1K
		/// </summary>
		public enum ILoads
		{
			LOAD300 = 0,
			LOAD2100 = 1,
		}

		public enum DigLevelsOpts
		{
			DEFAULT = 0,
			JEDEC = 1, 
			TIMING = 2
		}

		public enum VLoadOptions
		{
			LOAD_ON = 0,
			LOAD_OFF = 1
		}

		public enum MeasOptions
		{
			DMM = 0,
			DIG = 1
		}

		//Used to define if range is a Trimmable range or just an over-range
		public enum RangeAccType
		{
			TRIM_RANGE = 0,
			OVER_RANGE = 1,
		}

		public enum GenericType
		{
			LV_GEN = 0,
			HV_GEN = 1, 
		}
		#endregion

		//
		// Add Global Constants here  :
		//
		#region Constants                       :
		/// <summary>
		/// Test constants
		/// </summary>
		public class Consts
		{
			//
			// Note: A word about the (or rather lack of) use of the 'const' type qualifier.
			//       It is not recommended that const be used for most constants as it
			//       does not facilitate any debugging support. The variable will not be
			//       visible in the debugger and the value cannot be determined. This is
			//       due to the compiler replacing all instances of the constant's 
			//       variable with a reference to the literal in the text segment of the
			//       assembly - thus there is no longer any variable left in the program
			//       after compilation.
			//
			//       However, if you intend to use the constants in a switch statement
			//       then you will need the 'const' qualifier instead of 'static readonly'
			//       as the program will not compile otherwise.
			//

			/// <summary>
			/// Number of characterization cycles.
			/// </summary>
			public static readonly int CHAR_TEST_CYCLES = 1;

			/// <summary>
			/// Number of YA cycles.
			/// </summary>
			public static readonly int YA_TEST_CYCLES = 3;

			/// <summary>
			/// Maximum number of codes for this part
			/// </summary>
			public static readonly uint MAX_CODES = 65536;

			/// <summary>
			/// Number of codes for 16-bit part
			/// </summary>
			public static readonly uint NUM_CODES_16 = App.Consts.MAX_CODES; 

			/// <summary>
			/// Number of codes for 14-bit part
			/// </summary>
			public static readonly uint NUM_CODES_14 = App.Consts.MAX_CODES/4; 

			/// <summary>
			/// Number of codes for 12-bit part
			/// </summary>
			public static readonly uint NUM_CODES_12 = App.Consts.MAX_CODES/16; 

			/// <summary>
			/// 2 load options for Vout - load/No load
			/// </summary>
			public static readonly uint NUM_LOAD_OPTIONS = 2;

			/// <summary>
			/// 2 resistor modes - Internal & External
			/// </summary>
			public static readonly uint NUM_RES_MODES = 2;

			/// <summary>
			/// Temptronics gpib address.
			/// </summary>
			public static readonly int TEMPTRONICS_GPIB_ADDR = 1;

			/// <summary>
			/// Contains user EC name constants.
			/// </summary>
			public class EC
			{

				//
				// Note: Regarding the naming of user ECs - please follow the convention
				//       of naming all custom ECs with the prefix "USER_". This will 
				//       allow the EC tool's filtering capability to better screen between
				//       system ECs : "SYS_" and Test program framework ECs : "TP_" and your
				//       ECs : "USER_".
				//

				/// <summary>
				/// Name of the EC that contains the debug flag for fuse blowing
				/// </summary>
				public static readonly string FUSE_DEBUG_ENABLE_EC = "USER_FUSE_DEBUG_ENABLE";

				/// <summary>
				/// Name of the EC that contains the char testing flag
				/// </summary>
				public static readonly string CHAR_TESTING_ENABLE_EC = "USER_CHAR_TESTING_ENABLE";

				/// <summary>
				/// Name of the EC that contains the char testing flag
				/// </summary>
				public static readonly string YA_TESTING_ENABLE_EC = "USER_YA_TESTING_ENABLE";
			}
		}
		#endregion

		//
		// Add Global Variables here (including struct variables) :
		//
		#region Variables                       :

		//
		// General purpose variables used throughout the program
		//
		#region General Purpose Globals         :
		/// <summary>
		/// General purpose global variables
		/// </summary>
		public class Globals
		{
			/// <summary>
			/// Debug flag
			/// </summary>
			public static TestSwitch DebugEnable;

			/// <summary>
			/// If running offline, this switch is used to set realistic read/measure values
			/// </summary>
			public static TestSwitch OfflineDev;

			/// <summary>
			/// Turns on/off additional test verbosity
			/// Prints debugging information to the console output
			/// </summary>
			public static TestSwitch VerbosityGeneral;

			/// <summary>
			/// Turns on/off additional text for Apps Plots
			/// </summary>
			public static TestSwitch AppsPlots;

			/// <summary>
			/// Enables/Disables fuse blow
			/// </summary>
			public static TestSwitch FuseBlowEnable;

			/// <summary>
			/// Enables/Disables boardchecker
			/// </summary>
			public static TestSwitch RunBoardChecker;

			/// <summary>
			/// Enables pincheck testing
			/// </summary>
			public static TestSwitch PincheckEnable;

			/// <summary>
			/// Debug flag
			/// </summary>
			public static TestSwitch GndSnsEnable;

			/// <summary>
			/// Switch to allow monitoring of Bin 8 failures in production
			/// </summary>
			public static TestSwitch MonitorBin8;

			/// <summary>
			/// Delay on powerup
			/// </summary>
			public static TestTimer PowerUpDelay;

			/// <summary>
			/// Timer description
			/// </summary>
			public static TestTimer RelayDelay;

			/// <summary>
			/// DUT Output Settle Time
			/// </summary>
			public static TestTimer OutputSettleDelay;

			/// <summary>
			/// Application's selector (specified via EC.SELECTOR)
			/// </summary>
			public static Selector ActiveSelector;

			/// <summary>
			/// Fuse debug flag (specified via EC "USER_FUSE_DEBUG_ENABLE")
			/// </summary>
			public static bool FuseDebugEnable = false;

			/// <summary>
			/// Characterization flag (specified via EC "USER_CHAR_TESTING_ENABLE")
			/// </summary>
			public static bool CharTestingEnable = false;

			/// <summary>
			/// YA flag (specified via EC "USER_YA_TESTING_ENABLE")
			/// </summary>
			public static bool YaTestingEnable = false;

			/// <summary>
			/// Number of averages used for each pmu read
			/// </summary>
			public static int NumPmuAverages = 10;

			/// <summary>
			/// Number of trim bits available for trimming offset/gain on eacch of hte ranges
			/// </summary>
			public static int NumTrimBits = 13;

			/// <summary>
			/// Total number of voltage ranges available
			/// </summary>
			public static int NumVoltageRanges = 9;

			/// <summary>
			/// Total number of current ranges available
			/// </summary>
			public static int NumCurrentRanges = 8;

			/// <summary>
			/// Total number of trimmable voltage ranges
			/// </summary>
			public static int NumTrimVRanges = 5;

			/// <summary>
			/// Total number of trimmable current ranges
			/// </summary>
			public static int NumTrimIRanges = 5;

			/// <summary>
			/// Total number of trimmable bipolar voltage ranges
			/// </summary>
			public static int NumBipVRanges = 2;

			/// <summary>
			/// Total number of trimmable bipolar current ranges
			/// </summary>
			public static int NumBipIRanges = 2;

			/// <summary>
			/// Number of measure options - i.e. DMM or DIG
			/// </summary>
			public static int NumMeasOptions = 2;

			/// <summary>
			/// Temptronics flag.
			/// </summary>
			public static TestSwitch TemptronicsEnable;

			/// <summary>
			/// Flag which determines whether Dmm or dig is used post trim. True for Dig, False for Dmm
			/// </summary>
			public static TestSwitch PostTrimDigDmm;

			/// <summary>
			/// Flag which determines whether Dmm or dig is used pre trim. True for Dig, False for Dmm
			/// </summary>
			public static TestSwitch PreTrimDigDmm;

			/// <summary>
			/// List of temperatures for characterisation
			/// </summary>
			public static double[] CharTemp = new double[5] { 25, 0, -40, 85, 105};

			/// <summary>
			/// List of AVdd values for characterisation
			/// </summary>
			public static double[] CharLVAvdd = new double[4] { 11.2, 15.0, 24.0, 26.4 };

			/// <summary>
			/// List of AVss values for characterisation
			/// </summary>
			public static double[] CharLVAvss = new double[4] { -10.8, -15.0, -24.0, -26.4 };

			/// <summary>
			/// List of AVdd values for characterisation
			/// </summary>
			public static double[] CharHVAvdd = new double[4] { 12.0, 24.0, 48.0, 60.0 };

			/// <summary>
			/// List of AVss values for characterisation
			/// </summary>
			public static double[] CharHVAvss = new double[4] { 0.0, 0.0, 0.0, 0.0 };

			/// <summary>
			/// List of DVcc values for characterisation
			/// </summary>
			public static double[] CharDvcc = new double[4] { 2.7, 3.3, 5.0, 5.5 };

			/// <summary>
			/// Delay time for the temptronics in seconds
			/// </summary>
			public static int SoakTime = 120;

			/// <summary>
			/// Variable holding pass/fail information from boardchecker.
			/// </summary>
			public static int boardCheckPass = 0;

			/// <summary>
			/// Generic Type indicates whether low or high voltage option is chosen
			/// </summary>
			public static App.GenericType GenericType = App.GenericType.LV_GEN;

			/// <summary>
			/// Integer to track number of parts tested in any one lot
			/// </summary>
			public static int PartCounter = 0;
		}
		#endregion

		//
		// Test condition variables
		//
		#region Test Setup Variables            :
		/// <summary>
		/// Test Conditions Globals (i.e. test setup)
		/// </summary>
		public class TC
		{
			/// <summary>
			/// DUT AVcc 
			/// </summary>
			public static TestParameter DVcc;

			/// <summary>
			/// DUT AVdd
			/// </summary>
			public static TestParameter AVdd;

			/// <summary>
			/// DUT AVss
			/// </summary>
			public static TestParameter AVss;

			/// <summary>
			/// DUT VRef
			/// </summary>
			public static TestParameter VRef;

			/// <summary>
			/// Maximum possible voltage on Vin
			/// </summary>
			public static TestParameter MaxInputVoltage;
			
			/// <summary>
			/// Minimum possible voltage on Vin
			/// </summary>
			public static TestParameter MinInputVoltage;

			/// <summary>
			/// Mid voltage on Vin
			/// </summary>
			public static TestParameter MidInputVoltage;

			/// <summary>
			/// Input logic level high
			/// </summary>
			public static TestParameter Vih;

			/// <summary>
			/// Input logic level low
			/// </summary>
			public static TestParameter Vil;

			/// <summary>
			/// Output logic level high
			/// </summary>
			public static TestParameter Voh;

			/// <summary>
			/// Output logic level low
			/// </summary>
			public static TestParameter Vol;

			/// <summary>
			/// DUT Temperature
			/// </summary>
			public static TestParameter Temp;

			/// <summary>
			/// Interface Frequency
			/// </summary>
			public static TestParameter Frequency;

			/// <summary>
			/// Settle time for outputs 
			/// </summary>
			public static TestParameter OutputSettle;

			/// <summary>
			/// Settle time for VIE voltage adjust 
			/// </summary>
			public static TestParameter VieDelay;

			/// <summary>
			/// Delay time for Vfault 
			/// </summary>
			public static TestParameter VfaultDelay;

			/// <summary>
			/// Delay time for Ifault
			/// </summary>
			public static TestParameter IfaultDelay;

			/// <summary>
			/// Settle time for Vref leakage currents
			/// </summary>
			public static TestParameter VrefLkgSettle;

			/// <summary>
			/// Settle time for NC/Ifault leakage currents
			/// </summary>
			public static TestParameter IfaultLkgSettle;

			/// <summary>
			/// Settle time for outputs 
			/// </summary>
			public static TestParameter RelaySettle;

			/// <summary>
			/// Settle time for outputs 
			/// </summary>
			public static TestParameter VsenseNSettle;

			/// <summary>
			/// Settle time for outputs 
			/// </summary>
			public static TestParameter PmuMultiDelay;

			/// <summary>
			/// Number of averages used in any digitiser measurement
			/// </summary>
			public static TestParameter NumDigAvgs;

			/// <summary>
			/// Delay required for VIF to settle
			/// </summary>
			public static TestParameter VifDelay;

			/// <summary>
			/// Number of averages used in any digitiser measurement
			/// </summary>
			public static TestParameter DvccDelay;

			/// <summary>
			/// delay required for Rext2 Continuity Check
			/// </summary>
			public static TestParameter Rext2Delay;

			/// <summary>
			/// Wafer number being tested
			/// </summary>
			public static int WaferNum = 0;

			/// <summary>
			/// Blow fuses during this test run ?
			/// </summary>
			public static bool BlowFuses = false;

			/// <summary>
			/// Voltage used for fuse blowing
			/// </summary>
			public static double FuseV = 6.50;

			/// <summary>
			/// Voltage used on negative input of comparator in HV circuit
			/// </summary>
			public static double CompInput = 4.0;

			/// <summary>
			/// Default DUT address for Software mode
			/// </summary>
			public static int DutAddress = 0;

			/// <summary>
			/// Trim code for Ibias 
			/// </summary>
			public static MsInt IbiasTrimCode = 0;

			/// <summary>
			/// Trim code for TC 
			/// </summary>
			public static MsInt TcTrimCode = 0;

			/// <summary>
			/// Master Fuse set bit
			/// </summary>
			public static MsInt MasterFuse = 0;

			/// <summary>
			/// Device Id for tracking ESD/YA parts etc
			/// </summary>
			public static MsInt DeviceId = 0;

			/// <summary>
			/// Array to hold active ranges for specific generic
			/// </summary>
			public static App.RangeOptions [] ActiveRanges;

			/// <summary>
			/// Array to hold inactive ranges for specific generic
			/// </summary>
			public static App.RangeOptions [] DudRanges;

			/// <summary>
			/// Number of active ranges for specific generic
			/// </summary>
			public static int NumActiveRanges;

			/// <summary>
			/// Number of active voltage ranges for specific generic
			/// </summary>
			public static int NumActiveVRanges;

			/// <summary>
			/// Number of active current ranges for specific generic
			/// </summary>
			public static int NumActiveIRanges;

			/// <summary>
			/// Number of inactive ranges for specific generic
			/// </summary>
			public static int NumDudRanges;

			/// <summary>
			/// Number of pincheck measurements
			/// </summary>
			public static int NumPinChecks = 500; 

			/// <summary>
			/// Pincheck measurements count
			/// </summary>
			public static int PincheckCount = 0;

			/// <summary>
			/// Pincheck measurements count
			/// </summary>
			public static int PinCount = 0;

			/// <summary>
			/// Current voltage supplied to AVdd
			/// </summary>
			public static MsDouble CurrentVdd = 0.0;

			/// <summary>
			/// Current voltage supplied to AVss
			/// </summary>
			public static MsDouble CurrentVss = 0.0;

			/// <summary>
			/// Current voltage supplied to DVcc
			/// </summary>
			public static MsDouble CurrentVcc = 0.0;

			/// <summary>
			/// Current address used in readback pattern
			/// </summary>
			public static double CurrentReadAddr = 0;

			/// <summary>
			/// Current 16bit write word loaded in pattern
			/// </summary>
			public static MsInt Current16bitWord = 0;

			/// <summary>
			/// Current 24bit write word loaded in pattern
			/// </summary>
			public static MsInt Current24bitWord = 0;

			/// <summary>
			/// Current fuse blow word loaded in blow fuse pattern
			/// </summary>
			public static MsInt CurrentBlowWord = 0;

			/// <summary>
			/// Current fuse read word loaded in fuse read pattern
			/// </summary>
			public static MsInt CurrentFuseReadWord = 0;


			/// <summary>
			/// Current fuse read word loaded in fuse read pattern
			/// </summary>
			public static SiteMask CurrentActiveSites = 0;


			/// <summary>
			/// Current pattern loaded to formatters
			/// </summary>
			public static TestPattern CurrentLoadedPat = null;

			/// <summary>
			/// Index used to count post trim ranges
			/// </summary>
			public static int RangeIndex = 0;

			/// <summary>
			/// Max current limit of AVdd current 
			/// </summary>
			public static double AvddCurrentClamp = 30.0e-3;

			/// <summary>
			/// Slew rate of high voltage sources to AVdd 
			/// </summary>
			public static double AvddSlewRate = 500;

			/// <summary>
			/// Test names array for pincheck measurements
			/// </summary>
			public static string [] TestName = new string[App.TC.NumPinChecks];

			/// <summary>
			/// Array for storage of pincheck measurements
			/// </summary>
			public static MsDouble [] PincheckMeas = MsDouble.CreateArray(App.TC.NumPinChecks, 0);

			/// <summary>
			/// RangeData lookup table
			/// </summary>
			public static RangeData[] RangeData = new RangeData[19]
			{
				//***********Range Name**ProgBits**Index*****Max*****Min******Mid***************V/I?************GainCode***OffsetCode**ExtGainCode**ExtOffsetCode
				new RangeData("4-20mA",		0x0,	0,		0.0200,	0.00400, 0.01200,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("20mA",		0x1,	1,		0.0200,	0.00000, 0.01000,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("24mA",		0x2,	2,		0.0240,	0.00000, 0.01200,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("20mABip",	0x3,	3,		0.0200,	-0.0200, 0.00000,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("24mABip",	0x4,	4,		0.0240,	-0.0240, 0.00000,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("3.92-20.4mA",0xD,	5,		0.0200,	0.00400, 0.01216,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
				new RangeData("20.4mA",		0xE,	6,		0.0200,	0.00000, 0.01020,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
				new RangeData("24.5mA",		0xF,	7,		0.0240,	0.00000, 0.01225,	App.RangeType.CURRENT,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),

				new RangeData("5V",			0x5,	8,		5.0000,	0.00000, 2.50000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("10V",		0x6,	9,		10.000,	0.00000, 5.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("5VBip",		0x7,	10,		5.0000,	-5.0000, 0.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("10VBip",		0x8,	11,		10.000,	-10.000, 0.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("6V",			0x9,	12,		6.0000,	0.00000, 3.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
				new RangeData("12V",		0xA,	13,		12.000,	0.00000, 6.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
				new RangeData("6VBip",		0xB,	14,		6.0000,	-6.0000, 0.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
				new RangeData("12VBip",		0xC,	15,		12.000,	-12.000, 0.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
				new RangeData("2.5VBip",	0xD,	16,		2.5000,	-2.5000, 0.00000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
				new RangeData("40V",		0xE,	17,		40.000,	0.00000, 20.0000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.TRIM_RANGE),
				new RangeData("44V",		0xF,	18,		44.000,	0.00000, 22.0000,	App.RangeType.VOLTAGE,		0,			0,			0,			0,			App.RangeAccType.OVER_RANGE),
			};

			public static TimingConditions TimingData  = new TimingConditions();
			public static BoardVariables BoardVars = new BoardVariables();

		}
		#endregion

		#endregion

		//
		// Add Program Selectors here :
		//
		#region Selectors                       :
		public class Selectors
		{
			public static Selector PD_LV_5750 = new Selector("AD5750_PD");
			public static Selector QC_LV_5750 = new Selector("AD5750_QC");
			public static Selector PD_HV_5751 = new Selector("AD5751_PD");
			public static Selector QC_HV_5751 = new Selector("AD5751_QC");
			public static Selector PD_LV_5750_1 = new Selector("AD5750_1_PD");
			public static Selector QC_LV_5750_1 = new Selector("AD5750_1_QC");
			public static Selector RESC_LV_5750 = new Selector("AD5750_RESC");
		}
		#endregion
		
		//
		// Add Private Variables here (these will visible only to this class) :
		//
		#region Local Variables                 :
		private static SequencerProxy selectedSeq;
		#endregion
		#endregion

		//
		// The test loop entry points are accessible here
		//
		#region Test Entry Points (e.g. ProgramStart, LotStart, etc.) :

		//
		// ProgramStart entry hook
		//
		#region ProgramStart                    :
		/// <summary>
		/// Called during program startup.
		/// </summary>
		public override void ProgramStart ( )
		{
			//
			// Initialize global variables 
			//
			#region Initialize Global Variables                     :
			OneTimeVariableInit();
			#endregion

			//
			// Initialize PinLists, Patterns, Limits, IDs, Bins, Statics and Offline Data Caches
			//
			#region Initialize PLs, DPs, LTs, IDs, BNs, DSs and ODs :
			App.Time.Initialize();
			PM.Load("AD575x.pin.xml");
			DP.Load();
			DS.Load();
			Limits.Load();
			IDs.Load();
			Bins.Load();
			OC.Load();
			#endregion

			//
			// Initialize the test parameters, switches and timers
			//
			#region Initialize Test Parameters, Switches and Timers :

			App.Globals.DebugEnable = TP.Program.CreateTestSwitch("Globals.DebugEnable", false);
			App.Globals.OfflineDev = TP.Program.CreateTestSwitch("Globals.OfflineDev", false);
            App.Globals.VerbosityGeneral = TP.Program.CreateTestSwitch("Globals.VerbosityGeneral", false);
			App.Globals.AppsPlots = TP.Program.CreateTestSwitch("Globals.AppsPlots", false);
			App.Globals.FuseBlowEnable = TP.Program.CreateTestSwitch("Globals.FuseBlowEnable", true);
			App.Globals.RunBoardChecker = TP.Program.CreateTestSwitch("Globals.RunBoardChecker", true);
			App.Globals.PincheckEnable = TP.Program.CreateTestSwitch("Globals.PincheckEnable", false);
			App.Globals.TemptronicsEnable = TP.Program.CreateTestSwitch("Globals.TemptronicsEnable", false);
			App.Globals.PostTrimDigDmm = TP.Program.CreateTestSwitch("Globals.PostTrimDigDmm", true);
			App.Globals.PreTrimDigDmm = TP.Program.CreateTestSwitch("Globals.PreTrimDigDmm", true);
			App.Globals.GndSnsEnable = TP.Program.CreateTestSwitch("Globals.GndSnsEnable", false);
			App.Globals.MonitorBin8 = TP.Program.CreateTestSwitch("Monitor Bin8 Percentage", false); 

			App.Globals.PowerUpDelay = TP.Program.CreateTestTimer("Globals.PowerUpDelay");
			//App.Globals.PowerUpDelay.Set(3.0);	

			App.Globals.RelayDelay = TP.Program.CreateTestTimer("Globals.RelayDelay");
			//App.Globals.RelayDelay.Set(3.0);

			App.Globals.OutputSettleDelay = TP.Program.CreateTestTimer("Globals.OutputSettleDelay");
			//App.Globals.OutputSettleDelay.Set(1.0);

			//Slew Rate of Vout = 2V/us -> Max output change: 44V which is equivalent to 44us..delay 100us.
			App.TC.OutputSettle = TP.Program.CreateTestParameter("TC.OutputSettle", 0.3, 0.01, 100);
			App.TC.OutputSettle[App.Selectors.PD_HV_5751] = 0.6;
			App.TC.OutputSettle[App.Selectors.QC_HV_5751] = 0.6;

			App.TC.VieDelay = TP.Program.CreateTestParameter("TC.VieDelay", 0.5, 0.01, 10);
			App.TC.VfaultDelay = TP.Program.CreateTestParameter("TC.VfaultDelay", 50.0, 1.0, 100);
			App.TC.IfaultDelay = TP.Program.CreateTestParameter("TC.IfaultDelay", 1.0, 0.1, 100);
			App.TC.VrefLkgSettle = TP.Program.CreateTestParameter("TC.VrefLkgSettle", 5.0, 0.1, 20);
			App.TC.IfaultLkgSettle = TP.Program.CreateTestParameter("TC.IfaultLkgSettle", 0.1, 0.1, 2000);
			App.TC.RelaySettle = TP.Program.CreateTestParameter("TC.RelaySettle", 3.0, 1.0, 100);
			App.TC.VsenseNSettle = TP.Program.CreateTestParameter("TC.VsenseNSettle", 1.0, 0.1, 200);
			App.TC.PmuMultiDelay = TP.Program.CreateTestParameter("TC.PmuMultiDelay", 2.0, 0.01, 5.0);
			App.TC.VifDelay =	TP.Program.CreateTestParameter("TC.VifDelay", 1000, 0.0, 2000);
			App.TC.DvccDelay =	TP.Program.CreateTestParameter("TC.DvccDelay", 25, 0.0, 100);
			App.TC.Rext2Delay =	TP.Program.CreateTestParameter("TC.Rext2Delay", 5, 0.0, 10000);

			App.TC.NumDigAvgs = TP.Program.CreateTestParameter("TC.NumDigAvgs", 10000, 1, 10000);

			App.TC.DVcc = TP.Program.CreateTestParameter("TC.DVcc", 5.0, 0.0, 5.5);

			App.TC.AVdd = TP.Program.CreateTestParameter("TC.AVdd", 24.0, 0.0, 60.0);
			App.TC.AVdd[App.Selectors.PD_HV_5751] = 48.0;
			App.TC.AVdd[App.Selectors.QC_HV_5751] = 48.0;
			App.TC.AVdd[App.Selectors.PD_LV_5750] = 24.0;
			App.TC.AVdd[App.Selectors.QC_LV_5750] = 24.0;
			App.TC.AVdd[App.Selectors.PD_LV_5750_1] = 24.0;
			App.TC.AVdd[App.Selectors.QC_LV_5750_1] = 24.0;
			App.TC.AVdd[App.Selectors.RESC_LV_5750] = 24.0;

			App.TC.AVss = TP.Program.CreateTestParameter("TC.AVss", -24.0, -26.4, 0.0);
			App.TC.AVss[App.Selectors.PD_LV_5750] = -24.0;
			App.TC.AVss[App.Selectors.QC_LV_5750] = -24.0;
			App.TC.AVss[App.Selectors.PD_HV_5751] = 0.0;
			App.TC.AVss[App.Selectors.QC_HV_5751] = 0.0;
			App.TC.AVss[App.Selectors.PD_LV_5750_1] = -24.0;
			App.TC.AVss[App.Selectors.QC_LV_5750_1] = -24.0;
			App.TC.AVss[App.Selectors.RESC_LV_5750] = -24.0;

			App.TC.VRef = TP.Program.CreateTestParameter("TC.VRef", 4.096, 0.0, 4.096);
			App.TC.VRef[App.Selectors.PD_HV_5751] = 4.096;
			App.TC.VRef[App.Selectors.QC_HV_5751] = 4.096;
			App.TC.VRef[App.Selectors.PD_LV_5750] = 4.096;
			App.TC.VRef[App.Selectors.QC_LV_5750] = 4.096;
			App.TC.VRef[App.Selectors.PD_LV_5750_1] = 1.25;
			App.TC.VRef[App.Selectors.QC_LV_5750_1] = 1.25;
			App.TC.VRef[App.Selectors.RESC_LV_5750] = 4.096;

			App.TC.MaxInputVoltage = TP.Program.CreateTestParameter("TC.MaxInputVoltage", 4.096, 2.5, 4.096);
			App.TC.MaxInputVoltage[App.Selectors.PD_HV_5751] = 4.096;
			App.TC.MaxInputVoltage[App.Selectors.QC_HV_5751] = 4.096;
			App.TC.MaxInputVoltage[App.Selectors.PD_LV_5750] = 4.096;
			App.TC.MaxInputVoltage[App.Selectors.QC_LV_5750] = 4.096;
			App.TC.MaxInputVoltage[App.Selectors.PD_LV_5750_1] = 2.5;
			App.TC.MaxInputVoltage[App.Selectors.QC_LV_5750_1] = 2.5;
			App.TC.MaxInputVoltage[App.Selectors.RESC_LV_5750] = 4.096;

			App.TC.MinInputVoltage = TP.Program.CreateTestParameter("TC.MinInputVoltage", 0.0, 0.0, 0.0);
			App.TC.MinInputVoltage[App.Selectors.PD_HV_5751] = 0.0;
			App.TC.MinInputVoltage[App.Selectors.QC_HV_5751] = 0.0;
			App.TC.MinInputVoltage[App.Selectors.PD_LV_5750] = 0.0;
			App.TC.MinInputVoltage[App.Selectors.QC_LV_5750] = 0.0;
			App.TC.MinInputVoltage[App.Selectors.PD_LV_5750_1] = 0.0;
			App.TC.MinInputVoltage[App.Selectors.QC_LV_5750_1] = 0.0;
			App.TC.MinInputVoltage[App.Selectors.RESC_LV_5750] = 0.0;

			App.TC.MidInputVoltage = TP.Program.CreateTestParameter("TC.MidInputVoltage", 2.048, 1.25, 2.048);
			App.TC.MidInputVoltage[App.Selectors.PD_HV_5751] = 2.048;
			App.TC.MidInputVoltage[App.Selectors.QC_HV_5751] = 2.048;
			App.TC.MidInputVoltage[App.Selectors.PD_LV_5750] = 2.048;
			App.TC.MidInputVoltage[App.Selectors.QC_LV_5750] = 2.048;
			App.TC.MidInputVoltage[App.Selectors.PD_LV_5750_1] = 1.25;
			App.TC.MidInputVoltage[App.Selectors.QC_LV_5750_1] = 1.25;
			App.TC.MidInputVoltage[App.Selectors.RESC_LV_5750] = 2.048;

			App.TC.Vih = TP.Program.CreateTestParameter("TC.Vih", 2.0, 0.0, 5.5);
			App.TC.Vih[App.Selectors.PD_HV_5751] = App.TC.DVcc;
			App.TC.Vih[App.Selectors.QC_HV_5751] = App.TC.DVcc;

			App.TC.Vil = TP.Program.CreateTestParameter("TC.Vil", 0.8, 0.0, 2.0);
			App.TC.Vil[App.Selectors.PD_HV_5751] = 0.0;
			App.TC.Vil[App.Selectors.QC_HV_5751] = 0.0;

			App.TC.Voh = TP.Program.CreateTestParameter("TC.Voh", 4.0, 0.0, 5.5);
			App.TC.Vol = TP.Program.CreateTestParameter("TC.Vol", 0.4, 0.0, 2.0);

			App.TC.Temp = TP.Program.CreateTestParameter("TC.Temp", 25.0, -40.0, 105.0);

			App.TC.Frequency = TP.Program.CreateTestParameter("TC.Frequency", 30.3e6, 1.0e6, 50.0e6);

			App.TC.BoardVars.IoutHighRes = 1800;
			App.TC.BoardVars.IoutLowRes = 300.08;
			App.TC.BoardVars.VoutScaleHighGain = 0.163;
			App.TC.BoardVars.VoutScaleHighLoad = 239000;
			App.TC.BoardVars.VoutScaleLowGain = 0.448;
			App.TC.BoardVars.VoutScaleLowLoad = 4900;
			App.TC.BoardVars.VoutHighRes = 5000;
			App.TC.BoardVars.VoutLowRes = 1000;
			App.TC.BoardVars.DvccDiodeVoltage = 0.0;
			App.TC.BoardVars.dig14offset1 = 0.0;
			App.TC.BoardVars.dig14offset2 = 0.0;
			App.TC.BoardVars.dig15offset1 = 0.0;
			App.TC.BoardVars.dig15offset2 = 0.0;
			App.TC.BoardVars.dig14gain1 = 1.0;
			App.TC.BoardVars.dig14gain2 = 1.0;
			App.TC.BoardVars.dig15gain1 = 1.0;
			App.TC.BoardVars.dig15gain2 = 1.0;

			//Initialise "current" values for parameters used in program
			App.TC.Current16bitWord = 0;
			App.TC.Current24bitWord = 0;
			App.TC.CurrentBlowWord = 0;
			App.TC.CurrentFuseReadWord = 0;
			App.TC.CurrentLoadedPat = null;
			App.TC.CurrentReadAddr = 0;
			#endregion

			//
			// Setup active selector 
			// (Note: Must be done after test parameters are initialized)
			//
			#region Setup Active Selector                           :
			TP.Program.ActiveSelector = App.Globals.ActiveSelector;
			#endregion

			//
			// Begin adding user ProgramStart code here
			// (Note: Must be done after system ActiveSelector is set)
			//
			#region User ProgramStart Code                          :
			//
			// Setup Sequencer based on ActiveSelector (which is a combination of variant and QC/PD).
			// We check the ActiveSelector for a known selector, this is good programming practise
			// and ensures that the EC settings line up with the code's expectations.
			//
			// Note : We only need one sequencer for all variants and PD/QC combinations but we
			//        have a higher level sequencer to control characterization testing.
			//
			if (TP.Program.ActiveSelector == App.Selectors.PD_LV_5750 ||
				TP.Program.ActiveSelector == App.Selectors.QC_LV_5750 ||
				TP.Program.ActiveSelector == App.Selectors.PD_HV_5751 ||
				TP.Program.ActiveSelector == App.Selectors.QC_HV_5751 ||
				TP.Program.ActiveSelector == App.Selectors.PD_LV_5750_1 ||
				TP.Program.ActiveSelector == App.Selectors.QC_LV_5750_1 ||
				TP.Program.ActiveSelector == App.Selectors.RESC_LV_5750)
			{
				selectedSeq = new AD575xSeq();
			}
			else
			{
				// Error and exit
				String message = String.Format(
					"Unknown active variant '{0}' - unable to select sequencer, Program exiting!!!", 
					TP.Program.ActiveSelector.ToString());

				TP.Console.AskConfirm(message) ;
				TP.Program.End() ;
			}

			// Add the selected seqeucner to the master sequencer
			TP.Sequencer.Add(selectedSeq);

			//Enable Bin8 Monitoring for 25C trim programs.
			if (TP.Program.ActiveSelector == App.Selectors.PD_LV_5750 ||
				TP.Program.ActiveSelector == App.Selectors.PD_HV_5751 ||
				TP.Program.ActiveSelector == App.Selectors.PD_LV_5750_1)
			{
				App.Globals.MonitorBin8.Enabled = true;
			}
														
		#endregion

	} 
		#endregion

		//
		// LotStart entry hook
		//
		#region LotStart                        :
		/// <summary>
		/// Called at the start of each new lot.
		/// </summary>
		public override void LotStart()
		{
			// Write out lot banner
			TP.Console.WriteLineIf(App.Globals.DebugEnable, 
				"@Lot Start: {0} selected", selectedSeq.Name);

			//
			// Reinitialize global variables 
			//
			#region Reinitialize Global Variables                   :
			PerLotVariableInit();
			#endregion

			//
			// Reestablish active selector 
			//
			#region Reestablish Active Selector                     :
			TP.Program.ActiveSelector = App.Globals.ActiveSelector;
			#endregion

			//
			// Begin adding user LotStart code here
			//
			#region User LotStart Code                              :


	
			if(App.Globals.CharTestingEnable)
			{
				//
				// A test cycle refers to a part loop. Normally there is only
				// one test cycle, but a user can increase this number and the
				// parts currently in the sockets will be tested for each part
				// cycle.
				//
				// Even if a handler is connected the parts will not be binned
				// until all test cycles have completed. Stdf records will be
				// generated for each test cycle. 
				// 
				// The main application for test cycles is during char testing.
				// One can change the test conditions for each test cycle and 
				// have a complete record of all the testing in the stdf file.

				TP.Part.TestCycles = App.Consts.CHAR_TEST_CYCLES;
			}
			else if(App.Globals.YaTestingEnable)
				TP.Part.TestCycles = App.Consts.YA_TEST_CYCLES;

			if (App.Globals.TemptronicsEnable)
			{
				TX.TemptronicThermoStream.Reset(App.Consts.TEMPTRONICS_GPIB_ADDR);
			}

			#region templateCode
			/*
			if (App.Globals.FuseDebugEnable)
			{
				string info = null;
				string[] fusevChoices = 
					new string[] {
									 " 1:-> 5.30V Fuse Blowing",
									 " 2:-> 5.50V Fuse Blowing",
									 " 3:-> 5.70V Fuse Blowing",
									 " 4:-> Retest",
									 " 5:-> Samples"
								 };

				// Ask user to select fuse voltage (Returns 1, 2, 3, 4, 5. Displays 1, 2, 3, 4, and 5 to user)
				int fuseV = TP.Console.AskOption("Which program option?", fusevChoices, 2);

				// Set fuse voltage according to choice
				switch (fuseV)
				{
					case 1 : 
						App.TC.BlowFuses = true;
						App.TC.FuseV     = 5.3;
						info                = "Fuses @ 5.30V";
						break;

					case 3 :
						App.TC.BlowFuses = true;
						App.TC.FuseV     = 5.7;
						info                = "Fuses @ 5.70V";
						break;

					case 4 : // Disable fuse blowing on retest
						App.TC.BlowFuses = false;
						info                = "Retest";
						break; 

					case 5 :
						App.TC.BlowFuses = true;
						App.TC.FuseV     = 6.5;
						info                = "Normal Testing";
						break;

					default:
						App.TC.BlowFuses = true;
						App.TC.FuseV     = 5.5;
						info                = "Fuses @ 5.50V";
						break;
				}

				TP.Console.WriteLine("\n\nFuse Option Selected : {0}\n\n", info);
			}
		*/	
			#endregion

			#region RangeInit
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{			
				App.TC.ActiveRanges = new App.RangeOptions[17]; 
				App.TC.ActiveRanges[0] = App.RangeOptions.FOUR_TWENTY_MA;
				App.TC.ActiveRanges[1] = App.RangeOptions.TWENTY_MA;
				App.TC.ActiveRanges[2] = App.RangeOptions.TWENTY_FOUR_MA;
				App.TC.ActiveRanges[3] = App.RangeOptions.TWENTY_MA_BIP;
				App.TC.ActiveRanges[4] = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				App.TC.ActiveRanges[5] = App.RangeOptions.THREE_TWENTY_MA;
				App.TC.ActiveRanges[6] = App.RangeOptions.TWENTY_P_FOUR_MA;
				App.TC.ActiveRanges[7] = App.RangeOptions.TWENTY_FOUR_P_FIVE_MA;
				App.TC.ActiveRanges[8] = App.RangeOptions.FIVE_V;
				App.TC.ActiveRanges[9] = App.RangeOptions.TEN_V;
				App.TC.ActiveRanges[10] = App.RangeOptions.FIVE_V_BIP;
				App.TC.ActiveRanges[11] = App.RangeOptions.TEN_V_BIP;
				App.TC.ActiveRanges[12] = App.RangeOptions.SIX_V;
				App.TC.ActiveRanges[13] = App.RangeOptions.TWELVE_V;
				App.TC.ActiveRanges[14] = App.RangeOptions.SIX_V_BIP;
				App.TC.ActiveRanges[15] = App.RangeOptions.TWELVE_V_BIP;
				App.TC.ActiveRanges[16] = App.RangeOptions.TWO_P_FIVE_V_BIP;

				App.TC.DudRanges = new App.RangeOptions[2];
				App.TC.DudRanges[0] = App.RangeOptions.FORTY_V;
				App.TC.DudRanges[1] = App.RangeOptions.FORTY_FOUR_V;

				App.TC.NumDudRanges = 2;
				App.TC.NumActiveRanges = 17;
				App.TC.NumActiveVRanges = 9;
				App.TC.NumActiveIRanges = 8;
			}
			else if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				App.TC.ActiveRanges = new App.RangeOptions[12]; 
				App.TC.ActiveRanges[0] = App.RangeOptions.FOUR_TWENTY_MA;
				App.TC.ActiveRanges[1] = App.RangeOptions.TWENTY_MA;
				App.TC.ActiveRanges[2] = App.RangeOptions.TWENTY_FOUR_MA;
				App.TC.ActiveRanges[3] = App.RangeOptions.THREE_TWENTY_MA;
				App.TC.ActiveRanges[4] = App.RangeOptions.TWENTY_P_FOUR_MA;
				App.TC.ActiveRanges[5] = App.RangeOptions.TWENTY_FOUR_P_FIVE_MA;
				App.TC.ActiveRanges[6] = App.RangeOptions.FIVE_V;
				App.TC.ActiveRanges[7] = App.RangeOptions.TEN_V;
				App.TC.ActiveRanges[8] = App.RangeOptions.FORTY_V;
				App.TC.ActiveRanges[9] = App.RangeOptions.SIX_V;
				App.TC.ActiveRanges[10] = App.RangeOptions.TWELVE_V;
				App.TC.ActiveRanges[11] = App.RangeOptions.FORTY_FOUR_V;

				App.TC.DudRanges = new App.RangeOptions[6];
				App.TC.DudRanges[0] = App.RangeOptions.TWENTY_MA_BIP;
				App.TC.DudRanges[1] = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				App.TC.DudRanges[2] = App.RangeOptions.FIVE_V_BIP;
				App.TC.DudRanges[3] = App.RangeOptions.TEN_V_BIP;
				App.TC.DudRanges[4] = App.RangeOptions.SIX_V_BIP;
				App.TC.DudRanges[5] = App.RangeOptions.TWELVE_V_BIP;

				App.TC.NumDudRanges = 6;
				App.TC.NumActiveRanges = 12;
				App.TC.NumActiveVRanges = 6;
				App.TC.NumActiveIRanges = 6;
			}

			App.TC.DeviceId[Site.S1] = 1;
			App.TC.DeviceId[Site.S2] = 1024;
			App.TC.DeviceId[Site.S3] = 2048;
			App.TC.DeviceId[Site.S4] = 3072;
			#endregion

			#endregion

			//
			// Call user initialization routine
			//
			Utl.UserInit();

			#region BoardChecker
			//if(App.Globals.GenericType == App.GenericType.HV_GEN)
				//BoardCheckUtl.MeasureDvccDiode();

			if(App.Globals.RunBoardChecker)
			{
				TP.Console.WriteLine("");
				TP.Console.WriteLine("");
				TP.Console.AskConfirm("Starting Board Checker - Please confirm that there's no part in the socket:");
				App.Globals.boardCheckPass = 0;

				//Run Board Checker sequence
				App.Globals.boardCheckPass += BoardCheckUtl.RelayChecker();
				TP.Console.WriteLine("");
				App.Globals.boardCheckPass += BoardCheckUtl.MuxChecker();
				TP.Console.WriteLine("");
				App.Globals.boardCheckPass += BoardCheckUtl.MeasureOnboardResistances();
				TP.Console.WriteLine("");
				App.Globals.boardCheckPass += BoardCheckUtl.DigitiserCal();
				TP.Console.WriteLine("");

				if(App.Globals.boardCheckPass != 0)
				{
					TP.Console.AskConfirm("Board Checker has Failed! Please check failing tests. Ending lot...");
					TP.Lot.End();
				}
				else
				{
					TP.Console.AskConfirm("Board Checker Passed");
				}
				App.TC.BoardVars.DvccDiodeVoltage = 0.0;
			}
				
			//Board variables to suit all boards.
			App.TC.BoardVars.IoutLowRes[Site.S1] = 300.06;
			App.TC.BoardVars.IoutLowRes[Site.S2] = 300.15;
			App.TC.BoardVars.IoutLowRes[Site.S3] = 300.10;
			App.TC.BoardVars.IoutLowRes[Site.S4] = 300.07;


			//App.TC.BoardVars.IoutLoadRatio = 0.1429;	
			//App.TC.BoardVars.IoutLowRes = 300.00;
			//App.TC.BoardVars.IoutHighRes = 1800.00;	
			App.TC.BoardVars.DvccDiodeVoltage = 0.0;

			#endregion

			//Always reset Bin8 Counter and Part Counter at the start of each lot. 
			App.Globals.PartCounter = 0;
		}
		#endregion

		//
		// SubLotStart entry hook
		//
		#region SubLotStart                     :
		/// <summary>
		/// Called at the start of each new sub-lot.
		/// </summary>
		public override void SubLotStart()
		{
			// Write out sublot banner
			TP.Console.WriteLineIf(App.Globals.DebugEnable, 
				"@SubLot Start: {0} selected", selectedSeq.Name);

			//
			// Reinitialize global variables 
			//
			#region Reinitialize Global Variables                   :
			PerLotVariableInit();
			#endregion

			//
			// Reestablish active selector 
			//
			#region Reestablish Active Selector                     :
			TP.Program.ActiveSelector = App.Globals.ActiveSelector;
			#endregion
		} 
		#endregion

		//
		// PartStart entry hook
		//
		#region PartStart                       :
		/// <summary>
		/// Called at the start of each new part.
		/// </summary>
		public override void PartStart()
		{
			// Display site details banner
			Utl.DisplaySiteDetails();

			if (App.Globals.CharTestingEnable)
			{
				// 
				// When there is more than one test cycle, one can determine the
				// current test cycle using TP.Part.CurrentTestCycle. Note: the
				// test cycle index is 1 based.
				//
				TP.Console.WriteLine("@Part Start: Char Loop (Setup Index) {0}", 
					TP.Part.CurrentTestCycle);

				if(App.Globals.GenericType == App.GenericType.LV_GEN)
					Utl.SetLVTestConditions();
				else if(App.Globals.GenericType == App.GenericType.HV_GEN)
					Utl.SetHVTestConditions();
			}
			else if(App.Globals.YaTestingEnable)
			{
				TP.Console.WriteLine("@Part Start: Char Loop (Setup Index) {0}", 
					TP.Part.CurrentTestCycle);

				Utl.SetYaConditions();
			}

			//Initialise approx trim codes based on averages from previously tested devices
			App.TC.RangeData[(int)App.RangeOptions.FIVE_V].OffsetTrimCode = 5504;
			App.TC.RangeData[(int)App.RangeOptions.TEN_V].OffsetTrimCode = 5632;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				App.TC.RangeData[(int)App.RangeOptions.FIVE_V_BIP].OffsetTrimCode = 4224;
				App.TC.RangeData[(int)App.RangeOptions.TEN_V_BIP].OffsetTrimCode = 4224;
			}
			else
                App.TC.RangeData[(int)App.RangeOptions.FORTY_V].ExtOffsetTrimCode = 6000;

			App.TC.RangeData[(int)App.RangeOptions.FOUR_TWENTY_MA].OffsetTrimCode = 3200;
			App.TC.RangeData[(int)App.RangeOptions.TWENTY_MA].OffsetTrimCode = 384;
			App.TC.RangeData[(int)App.RangeOptions.TWENTY_FOUR_MA].OffsetTrimCode = 768;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				App.TC.RangeData[(int)App.RangeOptions.TWENTY_MA_BIP].OffsetTrimCode = 2816;
				App.TC.RangeData[(int)App.RangeOptions.TWENTY_FOUR_MA_BIP].OffsetTrimCode = 3456;
			}
			App.TC.RangeData[(int)App.RangeOptions.FOUR_TWENTY_MA].ExtOffsetTrimCode = 4224;
			App.TC.RangeData[(int)App.RangeOptions.TWENTY_MA].ExtOffsetTrimCode = 640;
			App.TC.RangeData[(int)App.RangeOptions.TWENTY_FOUR_MA].ExtOffsetTrimCode = 2816;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				App.TC.RangeData[(int)App.RangeOptions.TWENTY_MA_BIP].ExtOffsetTrimCode = 3200;
				App.TC.RangeData[(int)App.RangeOptions.TWENTY_FOUR_MA_BIP].ExtOffsetTrimCode = 3968;
			}
			//Enable blowing of fuses
			App.TC.BlowFuses = true;

			//Setup timing details?
		} 
		#endregion

		//
		// PartEnd entry hook
		//
		#region PartEnd                         :
		/// <summary>
		/// Called after each part has finished testing.
		/// </summary>
		public override void PartEnd()
		{
			//Power down the DUT
			Utl.PowerDownDevice();
			//Open all relays except D1 - with D1 open, 100mV - 200mV on DVcc
			HW.Rdc.Set(PM.ALL_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.CLOSE);

			if (App.Globals.TemptronicsEnable)
			{
				if (TP.Part.CurrentTestCycle == TP.Part.TestCycles) // Final test cycle
				{
					// Heat up board to eliminate condensation
					TX.TemptronicThermoStream.SetAndWaitTemperature(25.0, 30); 
					TP.Console.WriteLine("Currently at {0}C\n", 25.0);
					TX.TemptronicThermoStream.HeadUp();
				}
			}
			//Utl.ResetResources();

			if(App.Globals.PincheckEnable)
				Utl.WritePincheckFile();

			//Track the number of parts being tested. 
			foreach (Site site in TP.Part.TestSites)	App.Globals.PartCounter++;

			//Once the number of parts tested exceed 30, start monitoring the number of bin8 failures.
			if(App.Globals.PartCounter>30 && App.Globals.MonitorBin8)	Utl.TrackBin8Failures();
		} 
		#endregion

		//
		// SubLotEnd entry hook
		//
		#region SubLotEnd                       :
		/// <summary>
		/// Called after each sub-lot has finished.
		/// </summary>
		public override void SubLotEnd()
		{
		} 
		#endregion

		//
		// LotEnd entry hook
		//
		#region LotEnd                          :
		/// <summary>
		/// Called after each lot has finished.
		/// </summary>
		public override void LotEnd()
		{
			Utl.ResetResources();
			Utl.UserPowerOff();
		} 
		#endregion

		//
		// ProgramEnd entry hook
		//
		#region ProgramEnd                      :
		/// <summary>
		/// Called just before the program exits.
		/// </summary>
		public override void ProgramEnd()
		{
			Utl.ResetResources();
			Utl.UserPowerOff();
		} 
		#endregion

		#endregion

		//
		// Program setup and initialization methods are added (i.e. implemented) here
		//
		#region Setup/Initialization Methods                          :

		//
		// OneTimeVariableInit global method
		//
		#region OneTimeVariableInit             :
		/// <summary>
		/// Initialize global variables that are based on EC's that are marked as 'once' 
		/// (i.e. loaded once).
		/// </summary>
		/// <remarks>
		/// This method is called at program start only. 
		/// </remarks>
		public static void OneTimeVariableInit ( )
		{
			App.Globals.ActiveSelector = App.Selectors.PD_LV_5750;
			if (TP.EC.Contains(EC.SELECTOR))
			{
				App.Globals.ActiveSelector = TP.EC[EC.SELECTOR];
			}

			App.Globals.CharTestingEnable = false;
			if (TP.EC.Contains(App.Consts.EC.CHAR_TESTING_ENABLE_EC))
			{
				App.Globals.CharTestingEnable = TP.EC[App.Consts.EC.CHAR_TESTING_ENABLE_EC];
			}

			App.Globals.YaTestingEnable = false;
			if (TP.EC.Contains(App.Consts.EC.YA_TESTING_ENABLE_EC))
			{
				App.Globals.YaTestingEnable = TP.EC[App.Consts.EC.YA_TESTING_ENABLE_EC];
			}

			if(App.Globals.ActiveSelector == App.Selectors.PD_LV_5750 ||
				App.Globals.ActiveSelector == App.Selectors.QC_LV_5750 ||
				App.Globals.ActiveSelector == App.Selectors.PD_LV_5750_1 ||
				App.Globals.ActiveSelector == App.Selectors.QC_LV_5750_1 ||
				App.Globals.ActiveSelector == App.Selectors.RESC_LV_5750)
			{
				App.Globals.GenericType = App.GenericType.LV_GEN;
			}
			else if(App.Globals.ActiveSelector == App.Selectors.PD_HV_5751 ||
				App.Globals.ActiveSelector == App.Selectors.QC_HV_5751)
			{
				App.Globals.GenericType = App.GenericType.HV_GEN;
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{			
				App.TC.ActiveRanges = new App.RangeOptions[17]; 
				App.TC.ActiveRanges[0] = App.RangeOptions.FOUR_TWENTY_MA;
				App.TC.ActiveRanges[1] = App.RangeOptions.TWENTY_MA;
				App.TC.ActiveRanges[2] = App.RangeOptions.TWENTY_FOUR_MA;
				App.TC.ActiveRanges[3] = App.RangeOptions.TWENTY_MA_BIP;
				App.TC.ActiveRanges[4] = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				App.TC.ActiveRanges[5] = App.RangeOptions.THREE_TWENTY_MA;
				App.TC.ActiveRanges[6] = App.RangeOptions.TWENTY_P_FOUR_MA;
				App.TC.ActiveRanges[7] = App.RangeOptions.TWENTY_FOUR_P_FIVE_MA;
				App.TC.ActiveRanges[8] = App.RangeOptions.FIVE_V;
				App.TC.ActiveRanges[9] = App.RangeOptions.TEN_V;
				App.TC.ActiveRanges[10] = App.RangeOptions.FIVE_V_BIP;
				App.TC.ActiveRanges[11] = App.RangeOptions.TEN_V_BIP;
				App.TC.ActiveRanges[12] = App.RangeOptions.SIX_V;
				App.TC.ActiveRanges[13] = App.RangeOptions.TWELVE_V;
				App.TC.ActiveRanges[14] = App.RangeOptions.SIX_V_BIP;
				App.TC.ActiveRanges[15] = App.RangeOptions.TWELVE_V_BIP;
				App.TC.ActiveRanges[16] = App.RangeOptions.TWO_P_FIVE_V_BIP;

				App.TC.DudRanges = new App.RangeOptions[2];
				App.TC.DudRanges[0] = App.RangeOptions.FORTY_V;
				App.TC.DudRanges[1] = App.RangeOptions.FORTY_FOUR_V;

				App.TC.NumDudRanges = 2;
				App.TC.NumActiveRanges = 17;
				App.TC.NumActiveVRanges = 9;
				App.TC.NumActiveIRanges = 8;
				App.Globals.NumTrimVRanges = 4;
				App.Globals.NumTrimIRanges = 5;
			}
			else if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				App.TC.ActiveRanges = new App.RangeOptions[12]; 
				App.TC.ActiveRanges[0] = App.RangeOptions.FOUR_TWENTY_MA;
				App.TC.ActiveRanges[1] = App.RangeOptions.TWENTY_MA;
				App.TC.ActiveRanges[2] = App.RangeOptions.TWENTY_FOUR_MA;
				App.TC.ActiveRanges[3] = App.RangeOptions.THREE_TWENTY_MA;
				App.TC.ActiveRanges[4] = App.RangeOptions.TWENTY_P_FOUR_MA;
				App.TC.ActiveRanges[5] = App.RangeOptions.TWENTY_FOUR_P_FIVE_MA;
				App.TC.ActiveRanges[6] = App.RangeOptions.FIVE_V;
				App.TC.ActiveRanges[7] = App.RangeOptions.TEN_V;
				App.TC.ActiveRanges[8] = App.RangeOptions.FORTY_V;
				App.TC.ActiveRanges[9] = App.RangeOptions.SIX_V;
				App.TC.ActiveRanges[10] = App.RangeOptions.TWELVE_V;
				App.TC.ActiveRanges[11] = App.RangeOptions.FORTY_FOUR_V;

				App.TC.DudRanges = new App.RangeOptions[6];
				App.TC.DudRanges[0] = App.RangeOptions.TWENTY_MA_BIP;
				App.TC.DudRanges[1] = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				App.TC.DudRanges[2] = App.RangeOptions.FIVE_V_BIP;
				App.TC.DudRanges[3] = App.RangeOptions.TEN_V_BIP;
				App.TC.DudRanges[4] = App.RangeOptions.SIX_V_BIP;
				App.TC.DudRanges[5] = App.RangeOptions.TWELVE_V_BIP;

				App.TC.NumDudRanges = 6;
				App.TC.NumActiveRanges = 12;
				App.TC.NumActiveVRanges = 6;
				App.TC.NumActiveIRanges = 6;
				App.Globals.NumTrimVRanges = 3;
				App.Globals.NumTrimIRanges = 3;
			}
			// Also load per lot ECs at program start so we don't have to repeat EC load code here
			PerLotVariableInit();
		}
		#endregion

		//
		// PerLotVariableInit global method
		//
		#region PerLotVariableInit              :
		/// <summary>
		/// Initialize global variables
		/// </summary>
		/// <remarks>
		/// This method is called at lot start. As most global
		/// variables are initialized via ECs this allows the user to 
		/// alter these settings from one lot to the next via the dynamic
		/// EC editor in Tester Tool.
		/// </remarks>
		public static void PerLotVariableInit ( )
		{
			App.Globals.FuseDebugEnable = false;
			if (TP.EC.Contains(App.Consts.EC.FUSE_DEBUG_ENABLE_EC))
			{
				App.Globals.FuseDebugEnable = TP.EC[App.Consts.EC.FUSE_DEBUG_ENABLE_EC];
			}
		}
		#endregion

		#endregion

		//
		// Code requried by tester operating system framework
		//
		#region System Code (Do not edit)
		/// <summary>
		/// The main entry point for the application
		/// </summary>
		[MTAThread]
		static void Main(string[] args)
		{
			(new App()).Run("v11427_ad5750.ec.xml", args);
		}
		#endregion

	} // end of class App
}  // end of namespace Adi.Cts.TestProgram

