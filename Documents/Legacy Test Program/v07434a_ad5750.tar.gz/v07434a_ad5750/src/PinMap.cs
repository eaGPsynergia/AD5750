//
// Contains the pin map for the application.
//
// History:
// 11/29/05 - CTS - Template Created.
//
using System;
using System.IO;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{
	//
	// PM - The pin map is loaded and processed here.
	//
	#region Tool Generated Code (Do not edit)
	/// <summary>
	/// Encapsulates the Pin map for the the application.
	/// </summary>
	public class PM
	{
		#region System Code (Do not edit)
		/// <summary>
		/// Pins/PinLists are created here.
		/// </summary>
		public static void Load (String pinMap)
		{
			if (File.Exists(pinMap))
			{
				try
				{
					TP.Session.PinManager.Load(Path.GetFullPath(pinMap));
				}
				catch (Exception e)
				{
					throw new CtsException(String.Format(
						"There was a problem loading the pin map. Execution cannot continue. Please check pin map with pin map tool.\n\nDetails :\n{0}",
						e.ToString()));
				}
			}
		}
		#endregion

		public static PinList SDO_VFAULT
		{
			get
			{
				if (_sdo_vfault == null)
				{
					_sdo_vfault = TP.Session.PinManager.PinLists["SDO_VFAULT"];
				}
				return(_sdo_vfault);
			}
		}
		public static PinList _sdo_vfault = null;

		public static PinList CLRSEL
		{
			get
			{
				if (_clrsel == null)
				{
					_clrsel = TP.Session.PinManager.PinLists["CLRSEL"];
				}
				return(_clrsel);
			}
		}
		public static PinList _clrsel = null;

		public static PinList CLEAR
		{
			get
			{
				if (_clear == null)
				{
					_clear = TP.Session.PinManager.PinLists["CLEAR"];
				}
				return(_clear);
			}
		}
		public static PinList _clear = null;

		public static PinList DVCC
		{
			get
			{
				if (_dvcc == null)
				{
					_dvcc = TP.Session.PinManager.PinLists["DVCC"];
				}
				return(_dvcc);
			}
		}
		public static PinList _dvcc = null;

		public static PinList SYNC_RSEL
		{
			get
			{
				if (_sync_rsel == null)
				{
					_sync_rsel = TP.Session.PinManager.PinLists["SYNC_RSEL"];
				}
				return(_sync_rsel);
			}
		}
		public static PinList _sync_rsel = null;

		public static PinList SCLK_OUTEN
		{
			get
			{
				if (_sclk_outen == null)
				{
					_sclk_outen = TP.Session.PinManager.PinLists["SCLK_OUTEN"];
				}
				return(_sclk_outen);
			}
		}
		public static PinList _sclk_outen = null;

		public static PinList SDIN_R0
		{
			get
			{
				if (_sdin_r0 == null)
				{
					_sdin_r0 = TP.Session.PinManager.PinLists["SDIN_R0"];
				}
				return(_sdin_r0);
			}
		}
		public static PinList _sdin_r0 = null;

		public static PinList AD2_R1
		{
			get
			{
				if (_ad2_r1 == null)
				{
					_ad2_r1 = TP.Session.PinManager.PinLists["AD2_R1"];
				}
				return(_ad2_r1);
			}
		}
		public static PinList _ad2_r1 = null;

		public static PinList AD1_R2
		{
			get
			{
				if (_ad1_r2 == null)
				{
					_ad1_r2 = TP.Session.PinManager.PinLists["AD1_R2"];
				}
				return(_ad1_r2);
			}
		}
		public static PinList _ad1_r2 = null;

		public static PinList AD0_R3
		{
			get
			{
				if (_ad0_r3 == null)
				{
					_ad0_r3 = TP.Session.PinManager.PinLists["AD0_R3"];
				}
				return(_ad0_r3);
			}
		}
		public static PinList _ad0_r3 = null;

		public static PinList REXT1
		{
			get
			{
				if (_rext1 == null)
				{
					_rext1 = TP.Session.PinManager.PinLists["REXT1"];
				}
				return(_rext1);
			}
		}
		public static PinList _rext1 = null;

		public static PinList REXT2
		{
			get
			{
				if (_rext2 == null)
				{
					_rext2 = TP.Session.PinManager.PinLists["REXT2"];
				}
				return(_rext2);
			}
		}
		public static PinList _rext2 = null;

		public static PinList VREF
		{
			get
			{
				if (_vref == null)
				{
					_vref = TP.Session.PinManager.PinLists["VREF"];
				}
				return(_vref);
			}
		}
		public static PinList _vref = null;

		public static PinList VIN
		{
			get
			{
				if (_vin == null)
				{
					_vin = TP.Session.PinManager.PinLists["VIN"];
				}
				return(_vin);
			}
		}
		public static PinList _vin = null;

		public static PinList AVDD
		{
			get
			{
				if (_avdd == null)
				{
					_avdd = TP.Session.PinManager.PinLists["AVDD"];
				}
				return(_avdd);
			}
		}
		public static PinList _avdd = null;

		public static PinList IOUT
		{
			get
			{
				if (_iout == null)
				{
					_iout = TP.Session.PinManager.PinLists["IOUT"];
				}
				return(_iout);
			}
		}
		public static PinList _iout = null;

		public static PinList COMP1
		{
			get
			{
				if (_comp1 == null)
				{
					_comp1 = TP.Session.PinManager.PinLists["COMP1"];
				}
				return(_comp1);
			}
		}
		public static PinList _comp1 = null;

		public static PinList COMP2
		{
			get
			{
				if (_comp2 == null)
				{
					_comp2 = TP.Session.PinManager.PinLists["COMP2"];
				}
				return(_comp2);
			}
		}
		public static PinList _comp2 = null;

		public static PinList AVSS
		{
			get
			{
				if (_avss == null)
				{
					_avss = TP.Session.PinManager.PinLists["AVSS"];
				}
				return(_avss);
			}
		}
		public static PinList _avss = null;

		public static PinList VSENSEN
		{
			get
			{
				if (_vsensen == null)
				{
					_vsensen = TP.Session.PinManager.PinLists["VSENSEN"];
				}
				return(_vsensen);
			}
		}
		public static PinList _vsensen = null;

		public static PinList VOUT
		{
			get
			{
				if (_vout == null)
				{
					_vout = TP.Session.PinManager.PinLists["VOUT"];
				}
				return(_vout);
			}
		}
		public static PinList _vout = null;

		public static PinList VSENSEP
		{
			get
			{
				if (_vsensep == null)
				{
					_vsensep = TP.Session.PinManager.PinLists["VSENSEP"];
				}
				return(_vsensep);
			}
		}
		public static PinList _vsensep = null;

		public static PinList NC1
		{
			get
			{
				if (_nc1 == null)
				{
					_nc1 = TP.Session.PinManager.PinLists["NC1"];
				}
				return(_nc1);
			}
		}
		public static PinList _nc1 = null;

		public static PinList NC2
		{
			get
			{
				if (_nc2 == null)
				{
					_nc2 = TP.Session.PinManager.PinLists["NC2"];
				}
				return(_nc2);
			}
		}
		public static PinList _nc2 = null;

		public static PinList NC3
		{
			get
			{
				if (_nc3 == null)
				{
					_nc3 = TP.Session.PinManager.PinLists["NC3"];
				}
				return(_nc3);
			}
		}
		public static PinList _nc3 = null;

		public static PinList NC4
		{
			get
			{
				if (_nc4 == null)
				{
					_nc4 = TP.Session.PinManager.PinLists["NC4"];
				}
				return(_nc4);
			}
		}
		public static PinList _nc4 = null;

		public static PinList HW_SELECT
		{
			get
			{
				if (_hw_select == null)
				{
					_hw_select = TP.Session.PinManager.PinLists["HW_SELECT"];
				}
				return(_hw_select);
			}
		}
		public static PinList _hw_select = null;

		public static PinList RESET
		{
			get
			{
				if (_reset == null)
				{
					_reset = TP.Session.PinManager.PinLists["RESET"];
				}
				return(_reset);
			}
		}
		public static PinList _reset = null;

		public static PinList FAULT_TEMP
		{
			get
			{
				if (_fault_temp == null)
				{
					_fault_temp = TP.Session.PinManager.PinLists["FAULT_TEMP"];
				}
				return(_fault_temp);
			}
		}
		public static PinList _fault_temp = null;

		public static PinList NC_IFAULT
		{
			get
			{
				if (_nc_ifault == null)
				{
					_nc_ifault = TP.Session.PinManager.PinLists["NC_IFAULT"];
				}
				return(_nc_ifault);
			}
		}
		public static PinList _nc_ifault = null;

		public static PinList HV_COMP_INPUT
		{
			get
			{
				if (_hv_comp_input == null)
				{
					_hv_comp_input = TP.Session.PinManager.PinLists["HV_COMP_INPUT"];
				}
				return(_hv_comp_input);
			}
		}
		public static PinList _hv_comp_input = null;

		public static PinList IOUT_RES_MEAS
		{
			get
			{
				if (_iout_res_meas == null)
				{
					_iout_res_meas = TP.Session.PinManager.PinLists["IOUT_RES_MEAS"];
				}
				return(_iout_res_meas);
			}
		}
		public static PinList _iout_res_meas = null;

		public static PinList VOUT_RES_MEAS
		{
			get
			{
				if (_vout_res_meas == null)
				{
					_vout_res_meas = TP.Session.PinManager.PinLists["VOUT_RES_MEAS"];
				}
				return(_vout_res_meas);
			}
		}
		public static PinList _vout_res_meas = null;

		public static PinList V_PINCHECK
		{
			get
			{
				if (_v_pincheck == null)
				{
					_v_pincheck = TP.Session.PinManager.PinLists["V_PINCHECK"];
				}
				return(_v_pincheck);
			}
		}
		public static PinList _v_pincheck = null;

		public static PinList REXT1_RES_MEAS
		{
			get
			{
				if (_rext1_res_meas == null)
				{
					_rext1_res_meas = TP.Session.PinManager.PinLists["REXT1_RES_MEAS"];
				}
				return(_rext1_res_meas);
			}
		}
		public static PinList _rext1_res_meas = null;

		public static PinList DMM
		{
			get
			{
				if (_dmm == null)
				{
					_dmm = TP.Session.PinManager.PinLists["DMM"];
				}
				return(_dmm);
			}
		}
		public static PinList _dmm = null;

		public static PinList MUX_A0
		{
			get
			{
				if (_mux_a0 == null)
				{
					_mux_a0 = TP.Session.PinManager.PinLists["MUX_A0"];
				}
				return(_mux_a0);
			}
		}
		public static PinList _mux_a0 = null;

		public static PinList MUX_A1
		{
			get
			{
				if (_mux_a1 == null)
				{
					_mux_a1 = TP.Session.PinManager.PinLists["MUX_A1"];
				}
				return(_mux_a1);
			}
		}
		public static PinList _mux_a1 = null;

		public static PinList MUX_A2
		{
			get
			{
				if (_mux_a2 == null)
				{
					_mux_a2 = TP.Session.PinManager.PinLists["MUX_A2"];
				}
				return(_mux_a2);
			}
		}
		public static PinList _mux_a2 = null;

		public static PinList MUX_A3
		{
			get
			{
				if (_mux_a3 == null)
				{
					_mux_a3 = TP.Session.PinManager.PinLists["MUX_A3"];
				}
				return(_mux_a3);
			}
		}
		public static PinList _mux_a3 = null;

		public static PinList MUXA_EN
		{
			get
			{
				if (_muxa_en == null)
				{
					_muxa_en = TP.Session.PinManager.PinLists["MUXA_EN"];
				}
				return(_muxa_en);
			}
		}
		public static PinList _muxa_en = null;

		public static PinList MUXB_EN
		{
			get
			{
				if (_muxb_en == null)
				{
					_muxb_en = TP.Session.PinManager.PinLists["MUXB_EN"];
				}
				return(_muxb_en);
			}
		}
		public static PinList _muxb_en = null;

		public static PinList MUXC_EN
		{
			get
			{
				if (_muxc_en == null)
				{
					_muxc_en = TP.Session.PinManager.PinLists["MUXC_EN"];
				}
				return(_muxc_en);
			}
		}
		public static PinList _muxc_en = null;

		public static PinList HFDIG_TRIG
		{
			get
			{
				if (_hfdig_trig == null)
				{
					_hfdig_trig = TP.Session.PinManager.PinLists["HFDIG_TRIG"];
				}
				return(_hfdig_trig);
			}
		}
		public static PinList _hfdig_trig = null;

		public static PinList D1
		{
			get
			{
				if (_d1 == null)
				{
					_d1 = TP.Session.PinManager.PinLists["D1"];
				}
				return(_d1);
			}
		}
		public static PinList _d1 = null;

		public static PinList D2
		{
			get
			{
				if (_d2 == null)
				{
					_d2 = TP.Session.PinManager.PinLists["D2"];
				}
				return(_d2);
			}
		}
		public static PinList _d2 = null;

		public static PinList D3
		{
			get
			{
				if (_d3 == null)
				{
					_d3 = TP.Session.PinManager.PinLists["D3"];
				}
				return(_d3);
			}
		}
		public static PinList _d3 = null;

		public static PinList D4
		{
			get
			{
				if (_d4 == null)
				{
					_d4 = TP.Session.PinManager.PinLists["D4"];
				}
				return(_d4);
			}
		}
		public static PinList _d4 = null;

		public static PinList D5
		{
			get
			{
				if (_d5 == null)
				{
					_d5 = TP.Session.PinManager.PinLists["D5"];
				}
				return(_d5);
			}
		}
		public static PinList _d5 = null;

		public static PinList D6
		{
			get
			{
				if (_d6 == null)
				{
					_d6 = TP.Session.PinManager.PinLists["D6"];
				}
				return(_d6);
			}
		}
		public static PinList _d6 = null;

		public static PinList D7
		{
			get
			{
				if (_d7 == null)
				{
					_d7 = TP.Session.PinManager.PinLists["D7"];
				}
				return(_d7);
			}
		}
		public static PinList _d7 = null;

		public static PinList D8
		{
			get
			{
				if (_d8 == null)
				{
					_d8 = TP.Session.PinManager.PinLists["D8"];
				}
				return(_d8);
			}
		}
		public static PinList _d8 = null;

		public static PinList D9
		{
			get
			{
				if (_d9 == null)
				{
					_d9 = TP.Session.PinManager.PinLists["D9"];
				}
				return(_d9);
			}
		}
		public static PinList _d9 = null;

		public static PinList D10
		{
			get
			{
				if (_d10 == null)
				{
					_d10 = TP.Session.PinManager.PinLists["D10"];
				}
				return(_d10);
			}
		}
		public static PinList _d10 = null;

		public static PinList D11
		{
			get
			{
				if (_d11 == null)
				{
					_d11 = TP.Session.PinManager.PinLists["D11"];
				}
				return(_d11);
			}
		}
		public static PinList _d11 = null;

		public static PinList D12
		{
			get
			{
				if (_d12 == null)
				{
					_d12 = TP.Session.PinManager.PinLists["D12"];
				}
				return(_d12);
			}
		}
		public static PinList _d12 = null;

		public static PinList D13
		{
			get
			{
				if (_d13 == null)
				{
					_d13 = TP.Session.PinManager.PinLists["D13"];
				}
				return(_d13);
			}
		}
		public static PinList _d13 = null;

		public static PinList D14
		{
			get
			{
				if (_d14 == null)
				{
					_d14 = TP.Session.PinManager.PinLists["D14"];
				}
				return(_d14);
			}
		}
		public static PinList _d14 = null;

		public static PinList D15
		{
			get
			{
				if (_d15 == null)
				{
					_d15 = TP.Session.PinManager.PinLists["D15"];
				}
				return(_d15);
			}
		}
		public static PinList _d15 = null;

		public static PinList D16
		{
			get
			{
				if (_d16 == null)
				{
					_d16 = TP.Session.PinManager.PinLists["D16"];
				}
				return(_d16);
			}
		}
		public static PinList _d16 = null;

		public static PinList D17
		{
			get
			{
				if (_d17 == null)
				{
					_d17 = TP.Session.PinManager.PinLists["D17"];
				}
				return(_d17);
			}
		}
		public static PinList _d17 = null;

		public static PinList D18
		{
			get
			{
				if (_d18 == null)
				{
					_d18 = TP.Session.PinManager.PinLists["D18"];
				}
				return(_d18);
			}
		}
		public static PinList _d18 = null;

		public static PinList D19
		{
			get
			{
				if (_d19 == null)
				{
					_d19 = TP.Session.PinManager.PinLists["D19"];
				}
				return(_d19);
			}
		}
		public static PinList _d19 = null;

		public static PinList D20
		{
			get
			{
				if (_d20 == null)
				{
					_d20 = TP.Session.PinManager.PinLists["D20"];
				}
				return(_d20);
			}
		}
		public static PinList _d20 = null;

		public static PinList D21
		{
			get
			{
				if (_d21 == null)
				{
					_d21 = TP.Session.PinManager.PinLists["D21"];
				}
				return(_d21);
			}
		}
		public static PinList _d21 = null;

		public static PinList D22
		{
			get
			{
				if (_d22 == null)
				{
					_d22 = TP.Session.PinManager.PinLists["D22"];
				}
				return(_d22);
			}
		}
		public static PinList _d22 = null;

		public static PinList D23
		{
			get
			{
				if (_d23 == null)
				{
					_d23 = TP.Session.PinManager.PinLists["D23"];
				}
				return(_d23);
			}
		}
		public static PinList _d23 = null;

		public static PinList D24
		{
			get
			{
				if (_d24 == null)
				{
					_d24 = TP.Session.PinManager.PinLists["D24"];
				}
				return(_d24);
			}
		}
		public static PinList _d24 = null;

		public static PinList D25
		{
			get
			{
				if (_d25 == null)
				{
					_d25 = TP.Session.PinManager.PinLists["D25"];
				}
				return(_d25);
			}
		}
		public static PinList _d25 = null;

		public static PinList D26
		{
			get
			{
				if (_d26 == null)
				{
					_d26 = TP.Session.PinManager.PinLists["D26"];
				}
				return(_d26);
			}
		}
		public static PinList _d26 = null;

		public static PinList D27
		{
			get
			{
				if (_d27 == null)
				{
					_d27 = TP.Session.PinManager.PinLists["D27"];
				}
				return(_d27);
			}
		}
		public static PinList _d27 = null;

		public static PinList D28
		{
			get
			{
				if (_d28 == null)
				{
					_d28 = TP.Session.PinManager.PinLists["D28"];
				}
				return(_d28);
			}
		}
		public static PinList _d28 = null;

		public static PinList D29
		{
			get
			{
				if (_d29 == null)
				{
					_d29 = TP.Session.PinManager.PinLists["D29"];
				}
				return(_d29);
			}
		}
		public static PinList _d29 = null;

		public static PinList D30
		{
			get
			{
				if (_d30 == null)
				{
					_d30 = TP.Session.PinManager.PinLists["D30"];
				}
				return(_d30);
			}
		}
		public static PinList _d30 = null;

		public static PinList D31
		{
			get
			{
				if (_d31 == null)
				{
					_d31 = TP.Session.PinManager.PinLists["D31"];
				}
				return(_d31);
			}
		}
		public static PinList _d31 = null;

		public static PinList D32
		{
			get
			{
				if (_d32 == null)
				{
					_d32 = TP.Session.PinManager.PinLists["D32"];
				}
				return(_d32);
			}
		}
		public static PinList _d32 = null;

		public static PinList D33
		{
			get
			{
				if (_d33 == null)
				{
					_d33 = TP.Session.PinManager.PinLists["D33"];
				}
				return(_d33);
			}
		}
		public static PinList _d33 = null;

		public static PinList D34
		{
			get
			{
				if (_d34 == null)
				{
					_d34 = TP.Session.PinManager.PinLists["D34"];
				}
				return(_d34);
			}
		}
		public static PinList _d34 = null;

		public static PinList D35
		{
			get
			{
				if (_d35 == null)
				{
					_d35 = TP.Session.PinManager.PinLists["D35"];
				}
				return(_d35);
			}
		}
		public static PinList _d35 = null;

		public static PinList D36
		{
			get
			{
				if (_d36 == null)
				{
					_d36 = TP.Session.PinManager.PinLists["D36"];
				}
				return(_d36);
			}
		}
		public static PinList _d36 = null;

		public static PinList D37
		{
			get
			{
				if (_d37 == null)
				{
					_d37 = TP.Session.PinManager.PinLists["D37"];
				}
				return(_d37);
			}
		}
		public static PinList _d37 = null;

		public static PinList D38
		{
			get
			{
				if (_d38 == null)
				{
					_d38 = TP.Session.PinManager.PinLists["D38"];
				}
				return(_d38);
			}
		}
		public static PinList _d38 = null;

		public static PinList D39
		{
			get
			{
				if (_d39 == null)
				{
					_d39 = TP.Session.PinManager.PinLists["D39"];
				}
				return(_d39);
			}
		}
		public static PinList _d39 = null;

		public static PinList D40
		{
			get
			{
				if (_d40 == null)
				{
					_d40 = TP.Session.PinManager.PinLists["D40"];
				}
				return(_d40);
			}
		}
		public static PinList _d40 = null;

		public static PinList D41
		{
			get
			{
				if (_d41 == null)
				{
					_d41 = TP.Session.PinManager.PinLists["D41"];
				}
				return(_d41);
			}
		}
		public static PinList _d41 = null;

		public static PinList D42
		{
			get
			{
				if (_d42 == null)
				{
					_d42 = TP.Session.PinManager.PinLists["D42"];
				}
				return(_d42);
			}
		}
		public static PinList _d42 = null;

		public static PinList D43
		{
			get
			{
				if (_d43 == null)
				{
					_d43 = TP.Session.PinManager.PinLists["D43"];
				}
				return(_d43);
			}
		}
		public static PinList _d43 = null;

		public static PinList D44
		{
			get
			{
				if (_d44 == null)
				{
					_d44 = TP.Session.PinManager.PinLists["D44"];
				}
				return(_d44);
			}
		}
		public static PinList _d44 = null;

		public static PinList D45
		{
			get
			{
				if (_d45 == null)
				{
					_d45 = TP.Session.PinManager.PinLists["D45"];
				}
				return(_d45);
			}
		}
		public static PinList _d45 = null;

		public static PinList D46
		{
			get
			{
				if (_d46 == null)
				{
					_d46 = TP.Session.PinManager.PinLists["D46"];
				}
				return(_d46);
			}
		}
		public static PinList _d46 = null;

		public static PinList D47
		{
			get
			{
				if (_d47 == null)
				{
					_d47 = TP.Session.PinManager.PinLists["D47"];
				}
				return(_d47);
			}
		}
		public static PinList _d47 = null;

		public static PinList D48
		{
			get
			{
				if (_d48 == null)
				{
					_d48 = TP.Session.PinManager.PinLists["D48"];
				}
				return(_d48);
			}
		}
		public static PinList _d48 = null;

		public static PinList D49
		{
			get
			{
				if (_d49 == null)
				{
					_d49 = TP.Session.PinManager.PinLists["D49"];
				}
				return(_d49);
			}
		}
		public static PinList _d49 = null;

		public static PinList D50
		{
			get
			{
				if (_d50 == null)
				{
					_d50 = TP.Session.PinManager.PinLists["D50"];
				}
				return(_d50);
			}
		}
		public static PinList _d50 = null;

		public static PinList D51
		{
			get
			{
				if (_d51 == null)
				{
					_d51 = TP.Session.PinManager.PinLists["D51"];
				}
				return(_d51);
			}
		}
		public static PinList _d51 = null;

		public static PinList D52
		{
			get
			{
				if (_d52 == null)
				{
					_d52 = TP.Session.PinManager.PinLists["D52"];
				}
				return(_d52);
			}
		}
		public static PinList _d52 = null;

		public static PinList D53
		{
			get
			{
				if (_d53 == null)
				{
					_d53 = TP.Session.PinManager.PinLists["D53"];
				}
				return(_d53);
			}
		}
		public static PinList _d53 = null;

		public static PinList D54
		{
			get
			{
				if (_d54 == null)
				{
					_d54 = TP.Session.PinManager.PinLists["D54"];
				}
				return(_d54);
			}
		}
		public static PinList _d54 = null;

		public static PinList D55
		{
			get
			{
				if (_d55 == null)
				{
					_d55 = TP.Session.PinManager.PinLists["D55"];
				}
				return(_d55);
			}
		}
		public static PinList _d55 = null;

		public static PinList D56
		{
			get
			{
				if (_d56 == null)
				{
					_d56 = TP.Session.PinManager.PinLists["D56"];
				}
				return(_d56);
			}
		}
		public static PinList _d56 = null;

		public static PinList D57
		{
			get
			{
				if (_d57 == null)
				{
					_d57 = TP.Session.PinManager.PinLists["D57"];
				}
				return(_d57);
			}
		}
		public static PinList _d57 = null;

		public static PinList D58
		{
			get
			{
				if (_d58 == null)
				{
					_d58 = TP.Session.PinManager.PinLists["D58"];
				}
				return(_d58);
			}
		}
		public static PinList _d58 = null;

		public static PinList D59
		{
			get
			{
				if (_d59 == null)
				{
					_d59 = TP.Session.PinManager.PinLists["D59"];
				}
				return(_d59);
			}
		}
		public static PinList _d59 = null;

		public static PinList D60
		{
			get
			{
				if (_d60 == null)
				{
					_d60 = TP.Session.PinManager.PinLists["D60"];
				}
				return(_d60);
			}
		}
		public static PinList _d60 = null;

		public static PinList D63
		{
			get
			{
				if (_d63 == null)
				{
					_d63 = TP.Session.PinManager.PinLists["D63"];
				}
				return(_d63);
			}
		}
		public static PinList _d63 = null;

		public static PinList D64
		{
			get
			{
				if (_d64 == null)
				{
					_d64 = TP.Session.PinManager.PinLists["D64"];
				}
				return(_d64);
			}
		}
		public static PinList _d64 = null;

		public static PinList POS24V
		{
			get
			{
				if (_pos24v == null)
				{
					_pos24v = TP.Session.PinManager.PinLists["POS24V"];
				}
				return(_pos24v);
			}
		}
		public static PinList _pos24v = null;

		public static PinList NEG24V
		{
			get
			{
				if (_neg24v == null)
				{
					_neg24v = TP.Session.PinManager.PinLists["NEG24V"];
				}
				return(_neg24v);
			}
		}
		public static PinList _neg24v = null;

		public static PinList POS12V
		{
			get
			{
				if (_pos12v == null)
				{
					_pos12v = TP.Session.PinManager.PinLists["POS12V"];
				}
				return(_pos12v);
			}
		}
		public static PinList _pos12v = null;

		public static PinList DIG14
		{
			get
			{
				if (_dig14 == null)
				{
					_dig14 = TP.Session.PinManager.PinLists["DIG14"];
				}
				return(_dig14);
			}
		}
		public static PinList _dig14 = null;

		public static PinList DIG15
		{
			get
			{
				if (_dig15 == null)
				{
					_dig15 = TP.Session.PinManager.PinLists["DIG15"];
				}
				return(_dig15);
			}
		}
		public static PinList _dig15 = null;

		public static PinList HFDIG
		{
			get
			{
				if (_hfdig == null)
				{
					_hfdig = TP.Session.PinManager.PinLists["HFDIG"];
				}
				return(_hfdig);
			}
		}
		public static PinList _hfdig = null;

		public static PinList AD861_NEG_SUPPLY
		{
			get
			{
				if (_ad861_neg_supply == null)
				{
					_ad861_neg_supply = TP.Session.PinManager.PinLists["AD861_NEG_SUPPLY"];
				}
				return(_ad861_neg_supply);
			}
		}
		public static PinList _ad861_neg_supply = null;

		public static PinList HV_SUPPLY1_HI
		{
			get
			{
				if (_hv_supply1_hi == null)
				{
					_hv_supply1_hi = TP.Session.PinManager.PinLists["HV_SUPPLY1_HI"];
				}
				return(_hv_supply1_hi);
			}
		}
		public static PinList _hv_supply1_hi = null;

		public static PinList HV_SUPPLY1_LO
		{
			get
			{
				if (_hv_supply1_lo == null)
				{
					_hv_supply1_lo = TP.Session.PinManager.PinLists["HV_SUPPLY1_LO"];
				}
				return(_hv_supply1_lo);
			}
		}
		public static PinList _hv_supply1_lo = null;

		public static PinList HV_SUPPLY2_HI
		{
			get
			{
				if (_hv_supply2_hi == null)
				{
					_hv_supply2_hi = TP.Session.PinManager.PinLists["HV_SUPPLY2_HI"];
				}
				return(_hv_supply2_hi);
			}
		}
		public static PinList _hv_supply2_hi = null;

		public static PinList HV_SUPPLY2_LO
		{
			get
			{
				if (_hv_supply2_lo == null)
				{
					_hv_supply2_lo = TP.Session.PinManager.PinLists["HV_SUPPLY2_LO"];
				}
				return(_hv_supply2_lo);
			}
		}
		public static PinList _hv_supply2_lo = null;

		public static PinList EXT_TRIG_A
		{
			get
			{
				if (_ext_trig_a == null)
				{
					_ext_trig_a = TP.Session.PinManager.PinLists["EXT_TRIG_A"];
				}
				return(_ext_trig_a);
			}
		}
		public static PinList _ext_trig_a = null;

		public static PinList EXT_TRIG_B
		{
			get
			{
				if (_ext_trig_b == null)
				{
					_ext_trig_b = TP.Session.PinManager.PinLists["EXT_TRIG_B"];
				}
				return(_ext_trig_b);
			}
		}
		public static PinList _ext_trig_b = null;

		public static PinList MMX_PIN
		{
			get
			{
				if (_mmx_pin == null)
				{
					_mmx_pin = TP.Session.PinManager.PinLists["MMX_PIN"];
				}
				return(_mmx_pin);
			}
		}
		public static PinList _mmx_pin = null;

		public static PinList RELAY_CHECKER
		{
			get
			{
				if (_relay_checker == null)
				{
					_relay_checker = TP.Session.PinManager.PinLists["RELAY_CHECKER"];
				}
				return(_relay_checker);
			}
		}
		public static PinList _relay_checker = null;

		public static PinList GND1_PMU
		{
			get
			{
				if (_gnd1_pmu == null)
				{
					_gnd1_pmu = TP.Session.PinManager.PinLists["GND1_PMU"];
				}
				return(_gnd1_pmu);
			}
		}
		public static PinList _gnd1_pmu = null;

		public static PinList AVSS_POWER_UP
		{
			get
			{
				if (_avss_power_up == null)
				{
					_avss_power_up = TP.Session.PinManager.PinLists["AVSS_POWER_UP"];
				}
				return(_avss_power_up);
			}
		}
		public static PinList _avss_power_up = null;

		public static PinList VGEN_PINCARDS
		{
			get
			{
				if (_vgen_pincards == null)
				{
					_vgen_pincards = TP.Session.PinManager.PinLists["VGEN_PINCARDS"];
				}
				return(_vgen_pincards);
			}
		}
		public static PinList _vgen_pincards = null;

		public static PinList IOUT_PINCARD
		{
			get
			{
				if (_iout_pincard == null)
				{
					_iout_pincard = TP.Session.PinManager.PinLists["IOUT_PINCARD"];
				}
				return(_iout_pincard);
			}
		}
		public static PinList _iout_pincard = null;

		public static PinList DIG_PINS
		{
			get
			{
				if (_dig_pins == null)
				{
					_dig_pins = TP.Session.PinManager.PinLists["DIG_PINS"];
				}
				return(_dig_pins);
			}
		}
		public static PinList _dig_pins = null;

		public static PinList ADDR_PINS
		{
			get
			{
				if (_addr_pins == null)
				{
					_addr_pins = TP.Session.PinManager.PinLists["ADDR_PINS"];
				}
				return(_addr_pins);
			}
		}
		public static PinList _addr_pins = null;

		public static PinList RANGE_PINS
		{
			get
			{
				if (_range_pins == null)
				{
					_range_pins = TP.Session.PinManager.PinLists["RANGE_PINS"];
				}
				return(_range_pins);
			}
		}
		public static PinList _range_pins = null;

		public static PinList NO_CONNECTS
		{
			get
			{
				if (_no_connects == null)
				{
					_no_connects = TP.Session.PinManager.PinLists["NO_CONNECTS"];
				}
				return(_no_connects);
			}
		}
		public static PinList _no_connects = null;

		public static PinList SUPPLIES
		{
			get
			{
				if (_supplies == null)
				{
					_supplies = TP.Session.PinManager.PinLists["SUPPLIES"];
				}
				return(_supplies);
			}
		}
		public static PinList _supplies = null;

		public static PinList CONT_PINS
		{
			get
			{
				if (_cont_pins == null)
				{
					_cont_pins = TP.Session.PinManager.PinLists["CONT_PINS"];
				}
				return(_cont_pins);
			}
		}
		public static PinList _cont_pins = null;

		public static PinList EVERY_PIN
		{
			get
			{
				if (_every_pin == null)
				{
					_every_pin = TP.Session.PinManager.PinLists["EVERY_PIN"];
				}
				return(_every_pin);
			}
		}
		public static PinList _every_pin = null;

		public static PinList ALL_RELAYS
		{
			get
			{
				if (_all_relays == null)
				{
					_all_relays = TP.Session.PinManager.PinLists["ALL_RELAYS"];
				}
				return(_all_relays);
			}
		}
		public static PinList _all_relays = null;

		public static PinList BOARD_SOURCES
		{
			get
			{
				if (_board_sources == null)
				{
					_board_sources = TP.Session.PinManager.PinLists["BOARD_SOURCES"];
				}
				return(_board_sources);
			}
		}
		public static PinList _board_sources = null;

		public static PinList VIES
		{
			get
			{
				if (_vies == null)
				{
					_vies = TP.Session.PinManager.PinLists["VIES"];
				}
				return(_vies);
			}
		}
		public static PinList _vies = null;

		public static PinList DC_SOURCES
		{
			get
			{
				if (_dc_sources == null)
				{
					_dc_sources = TP.Session.PinManager.PinLists["DC_SOURCES"];
				}
				return(_dc_sources);
			}
		}
		public static PinList _dc_sources = null;

		public static PinList MUX_PINS
		{
			get
			{
				if (_mux_pins == null)
				{
					_mux_pins = TP.Session.PinManager.PinLists["MUX_PINS"];
				}
				return(_mux_pins);
			}
		}
		public static PinList _mux_pins = null;

		public static PinList HV_SUPPLIES
		{
			get
			{
				if (_hv_supplies == null)
				{
					_hv_supplies = TP.Session.PinManager.PinLists["HV_SUPPLIES"];
				}
				return(_hv_supplies);
			}
		}
		public static PinList _hv_supplies = null;

		public static PinList TRIGGERS
		{
			get
			{
				if (_triggers == null)
				{
					_triggers = TP.Session.PinManager.PinLists["TRIGGERS"];
				}
				return(_triggers);
			}
		}
		public static PinList _triggers = null;

		public static PinList SPI_PINS
		{
			get
			{
				if (_spi_pins == null)
				{
					_spi_pins = TP.Session.PinManager.PinLists["SPI_PINS"];
				}
				return(_spi_pins);
			}
		}
		public static PinList _spi_pins = null;

		public static PinList SINGLE_DRIVERS
		{
			get
			{
				if (_single_drivers == null)
				{
					_single_drivers = TP.Session.PinManager.PinLists["SINGLE_DRIVERS"];
				}
				return(_single_drivers);
			}
		}
		public static PinList _single_drivers = null;

		public static PinList DOUBLE_DRIVERS
		{
			get
			{
				if (_double_drivers == null)
				{
					_double_drivers = TP.Session.PinManager.PinLists["DOUBLE_DRIVERS"];
				}
				return(_double_drivers);
			}
		}
		public static PinList _double_drivers = null;

		public static PinList QUAD_DRIVERS
		{
			get
			{
				if (_quad_drivers == null)
				{
					_quad_drivers = TP.Session.PinManager.PinLists["QUAD_DRIVERS"];
				}
				return(_quad_drivers);
			}
		}
		public static PinList _quad_drivers = null;

		public static PinList MUX_EN_PINS
		{
			get
			{
				if (_mux_en_pins == null)
				{
					_mux_en_pins = TP.Session.PinManager.PinLists["MUX_EN_PINS"];
				}
				return(_mux_en_pins);
			}
		}
		public static PinList _mux_en_pins = null;

		public static PinList RLX01_RELAYS
		{
			get
			{
				if (_rlx01_relays == null)
				{
					_rlx01_relays = TP.Session.PinManager.PinLists["RLX01_RELAYS"];
				}
				return(_rlx01_relays);
			}
		}
		public static PinList _rlx01_relays = null;

		public static PinList RLX02_RELAYS
		{
			get
			{
				if (_rlx02_relays == null)
				{
					_rlx02_relays = TP.Session.PinManager.PinLists["RLX02_RELAYS"];
				}
				return(_rlx02_relays);
			}
		}
		public static PinList _rlx02_relays = null;

		public static PinList RLX05_RELAYS
		{
			get
			{
				if (_rlx05_relays == null)
				{
					_rlx05_relays = TP.Session.PinManager.PinLists["RLX05_RELAYS"];
				}
				return(_rlx05_relays);
			}
		}
		public static PinList _rlx05_relays = null;

		public static PinList RLX08_RELAYS
		{
			get
			{
				if (_rlx08_relays == null)
				{
					_rlx08_relays = TP.Session.PinManager.PinLists["RLX08_RELAYS"];
				}
				return(_rlx08_relays);
			}
		}
		public static PinList _rlx08_relays = null;

		public static PinList RLX10_RELAYS
		{
			get
			{
				if (_rlx10_relays == null)
				{
					_rlx10_relays = TP.Session.PinManager.PinLists["RLX10_RELAYS"];
				}
				return(_rlx10_relays);
			}
		}
		public static PinList _rlx10_relays = null;

		public static PinList RLX11_RELAYS
		{
			get
			{
				if (_rlx11_relays == null)
				{
					_rlx11_relays = TP.Session.PinManager.PinLists["RLX11_RELAYS"];
				}
				return(_rlx11_relays);
			}
		}
		public static PinList _rlx11_relays = null;

		public static PinList RLX13_RELAYS
		{
			get
			{
				if (_rlx13_relays == null)
				{
					_rlx13_relays = TP.Session.PinManager.PinLists["RLX13_RELAYS"];
				}
				return(_rlx13_relays);
			}
		}
		public static PinList _rlx13_relays = null;

		public static PinList RLX14_RELAYS
		{
			get
			{
				if (_rlx14_relays == null)
				{
					_rlx14_relays = TP.Session.PinManager.PinLists["RLX14_RELAYS"];
				}
				return(_rlx14_relays);
			}
		}
		public static PinList _rlx14_relays = null;

		public static PinList RLX16_RELAYS
		{
			get
			{
				if (_rlx16_relays == null)
				{
					_rlx16_relays = TP.Session.PinManager.PinLists["RLX16_RELAYS"];
				}
				return(_rlx16_relays);
			}
		}
		public static PinList _rlx16_relays = null;

		public static PinList RLX17_RELAYS
		{
			get
			{
				if (_rlx17_relays == null)
				{
					_rlx17_relays = TP.Session.PinManager.PinLists["RLX17_RELAYS"];
				}
				return(_rlx17_relays);
			}
		}
		public static PinList _rlx17_relays = null;

		public static PinList RLX18_RELAYS
		{
			get
			{
				if (_rlx18_relays == null)
				{
					_rlx18_relays = TP.Session.PinManager.PinLists["RLX18_RELAYS"];
				}
				return(_rlx18_relays);
			}
		}
		public static PinList _rlx18_relays = null;

		public static PinList RLX21_RELAYS
		{
			get
			{
				if (_rlx21_relays == null)
				{
					_rlx21_relays = TP.Session.PinManager.PinLists["RLX21_RELAYS"];
				}
				return(_rlx21_relays);
			}
		}
		public static PinList _rlx21_relays = null;

		public static PinList RLX20_RELAYS
		{
			get
			{
				if (_rlx20_relays == null)
				{
					_rlx20_relays = TP.Session.PinManager.PinLists["RLX20_RELAYS"];
				}
				return(_rlx20_relays);
			}
		}
		public static PinList _rlx20_relays = null;

		public static PinList CONT_RELAYS_OPEN
		{
			get
			{
				if (_cont_relays_open == null)
				{
					_cont_relays_open = TP.Session.PinManager.PinLists["CONT_RELAYS_OPEN"];
				}
				return(_cont_relays_open);
			}
		}
		public static PinList _cont_relays_open = null;

		public static PinList CONT_RELAYS_CLOSE
		{
			get
			{
				if (_cont_relays_close == null)
				{
					_cont_relays_close = TP.Session.PinManager.PinLists["CONT_RELAYS_CLOSE"];
				}
				return(_cont_relays_close);
			}
		}
		public static PinList _cont_relays_close = null;

		public static PinList EVEN_CONT_PINS
		{
			get
			{
				if (_even_cont_pins == null)
				{
					_even_cont_pins = TP.Session.PinManager.PinLists["EVEN_CONT_PINS"];
				}
				return(_even_cont_pins);
			}
		}
		public static PinList _even_cont_pins = null;

		public static PinList ODD_CONT_PINS
		{
			get
			{
				if (_odd_cont_pins == null)
				{
					_odd_cont_pins = TP.Session.PinManager.PinLists["ODD_CONT_PINS"];
				}
				return(_odd_cont_pins);
			}
		}
		public static PinList _odd_cont_pins = null;

		public static PinList LEAKAGE_PINS
		{
			get
			{
				if (_leakage_pins == null)
				{
					_leakage_pins = TP.Session.PinManager.PinLists["LEAKAGE_PINS"];
				}
				return(_leakage_pins);
			}
		}
		public static PinList _leakage_pins = null;

		public static PinList HW_FAULT_PINS
		{
			get
			{
				if (_hw_fault_pins == null)
				{
					_hw_fault_pins = TP.Session.PinManager.PinLists["HW_FAULT_PINS"];
				}
				return(_hw_fault_pins);
			}
		}
		public static PinList _hw_fault_pins = null;

		public static PinList ONE_DIODE_PINS
		{
			get
			{
				if (_one_diode_pins == null)
				{
					_one_diode_pins = TP.Session.PinManager.PinLists["ONE_DIODE_PINS"];
				}
				return(_one_diode_pins);
			}
		}
		public static PinList _one_diode_pins = null;

		public static PinList TWO_DIODE_PINS
		{
			get
			{
				if (_two_diode_pins == null)
				{
					_two_diode_pins = TP.Session.PinManager.PinLists["TWO_DIODE_PINS"];
				}
				return(_two_diode_pins);
			}
		}
		public static PinList _two_diode_pins = null;

		public static PinList THREE_DIODE_PINS
		{
			get
			{
				if (_three_diode_pins == null)
				{
					_three_diode_pins = TP.Session.PinManager.PinLists["THREE_DIODE_PINS"];
				}
				return(_three_diode_pins);
			}
		}
		public static PinList _three_diode_pins = null;

		public static PinList ODD_LKG_PINS
		{
			get
			{
				if (_odd_lkg_pins == null)
				{
					_odd_lkg_pins = TP.Session.PinManager.PinLists["ODD_LKG_PINS"];
				}
				return(_odd_lkg_pins);
			}
		}
		public static PinList _odd_lkg_pins = null;

		public static PinList EVEN_LKG_PINS
		{
			get
			{
				if (_even_lkg_pins == null)
				{
					_even_lkg_pins = TP.Session.PinManager.PinLists["EVEN_LKG_PINS"];
				}
				return(_even_lkg_pins);
			}
		}
		public static PinList _even_lkg_pins = null;

		public static PinList RLX19_RELAYS
		{
			get
			{
				if (_rlx19_relays == null)
				{
					_rlx19_relays = TP.Session.PinManager.PinLists["RLX19_RELAYS"];
				}
				return(_rlx19_relays);
			}
		}
		public static PinList _rlx19_relays = null;

		public static PinList SINGLE_DRIVERS_PROBE
		{
			get
			{
				if (_single_drivers_probe == null)
				{
					_single_drivers_probe = TP.Session.PinManager.PinLists["SINGLE_DRIVERS_PROBE"];
				}
				return(_single_drivers_probe);
			}
		}
		public static PinList _single_drivers_probe = null;

		public static PinList DOUBLE_DRIVERS_PROBE
		{
			get
			{
				if (_double_drivers_probe == null)
				{
					_double_drivers_probe = TP.Session.PinManager.PinLists["DOUBLE_DRIVERS_PROBE"];
				}
				return(_double_drivers_probe);
			}
		}
		public static PinList _double_drivers_probe = null;

	}
	#endregion

} // end of namespace Adi.Cts.TestProgram
