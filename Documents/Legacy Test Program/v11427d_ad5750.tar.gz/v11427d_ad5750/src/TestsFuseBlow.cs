//
// Contains all fuse blowing related tests.
//
// History:
// 11/29/05 - CTS - Template Created.
//
using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{

	//
	// Note: If your application does not need fuse blowing tests then
	// please remove this file from your project (right click on 
	// TestsFuseBlow.cs in the solution view and select 'Delete', click 
	// OK when prompted.
	//
	// Otherwise please remove this comment.
	//

}  // end of namespace Adi.Cts.TestProgram
