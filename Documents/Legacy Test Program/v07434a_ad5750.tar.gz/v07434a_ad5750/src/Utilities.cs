//
// Contains utility methods that are used throughout the application.
//
// History:
// 11/29/05 - CTS - Template Created.
//
using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{
	//
	// Utl - add custom utility methods used by this application to this class
	//
	#region Utl                             :
	/// <summary>
	/// User global utility methods.
	/// </summary>
	public class Utl
	{
		//
		// Cal - add custom calibration methods used by this application to this class
		//
		#region Cal                             :
		/// <summary>
		/// User global calibration methods.
		/// </summary>
		/// <remarks>
		/// This subclass demonstrates how you can create a hierarchy inside 
		/// Utl to group your methods to aid in intellisense navigation.
		/// </remarks>
		public class Cal
		{
			//
			// Note: If your application does not need calibration routines then
			// please remove this region from your project (close the region, 
			// highlight it and hit the 'delete' key.
			//
			// Otherwise please remove this comment.
			//

		} // end of class Cal
		#endregion

		//
		// Fuse - add custom fuse methods used by this application to this class
		//
		#region Fuse                            :
		/// <summary>
		/// User global fuse methods.
		/// </summary>
		/// <remarks>
		/// This subclass demonstrates how you can create a hierarchy inside 
		/// Utl to group your methods to aid in intellisense navigation.
		/// </remarks>
		public class Fuse
		{
			//
			// Note: If your application does not need fuse routines then
			// please remove this region from your project (close the region, 
			// highlight it and hit the 'delete' key.
			//
			// Otherwise please remove this comment.
			//

		} // end of class Fuse
		#endregion

		//
		// DisplaySiteDetails utility method
		//
		#region DisplaySiteDetails              :
		/// <summary>
		/// Display multisite details.
		/// </summary>
		/// <remarks>
		/// This is a sample utility method, please remove it if it is not needed.
		/// </remarks>
		public static void DisplaySiteDetails ( )
		{
			//
			// Note: This statement shows some of the new string formatting syntax in C#.
			// For details on how to create such strings and links to further details on 
			// string formatting hold down the CTRL key and click on the following link :
			// (the pertinent details are in the 'Remarks' section)
			// ms-help://MS.VSCC.2003/MS.MSDNQTR.2003FEB.1033/cpref/html/frlrfsystemstringclassformattopic1.htm
			//
			//TP.Console.WriteLine(
			//	"Site Details : \n\tNumber Test Sites = {0}.\n\tActive Site Mask  = 0x{1:X}.",
			//	TP.MS.TestSiteCount, (UInt32)TP.MS.ActiveSites);
		}
		#endregion

		//
		//Functions used at lot start or program start to setup test hardware etc
		//
		#region InitFunctions
		//
		// UserInit utility method
		//
		#region UserInit                        :
		/// <summary>
		/// User initialization routine called at the beginning of each lot
		/// </summary>
		public static void UserInit ( )
		{
			UserPowerOn();

			// Open all relays
			TP.Console.WriteLine("Open all Relays....");
			HW.Rdc.Reset(PM.ALL_RELAYS);
			
			// Reset the DMM
			// This function will reset the digital volt meter and put it into  a known state.
			TP.Console.WriteLine("Setting up the DMM....");
			HW.Dmm.Reset(PM.DMM);
			HW.Dmm.AutoZero(PM.DMM, OnOff.OFF);
			HW.Dmm.Function(PM.DMM, Dmm.Mode.DC_VOLT_MODE);
			HW.Dmm.Range(PM.DMM,10.0);
			HW.Dmm.Integration(PM.DMM, 0.002);
			HW.Mmx.Set(PM.MMX_PIN, new Mmx.RelaySet(Mmx.Relay.DMM_POGO), Mmx.NONE);

			VIInit();
			DCInit();
			DssInit();
			MuxInit();

			//Only connect HVS if AD5751 sequencer is selected
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
                HVInit();

		}
		#endregion

		//
		// UserPowerOn utility method
		//
		#region UserPowerOn                         :
		/// <summary>
		/// Power up the User Power Supplies.
		/// </summary>
		public static void UserPowerOn ( )
		{
			//
			// Turn on User Power 
			//
			TP.Console.WriteLine("Powering up the board....");
			SetupUpc(OpenClose.CLOSE);

		}
		#endregion

		//
		// UserPowerOff utility method
		//
		#region UserPowerOff                       :
		/// <summary> 
		/// Power down the User Power Supplies.
		/// </summary>
		public static void UserPowerOff ( )
		{
			//
			// Turn off User Power
			//
			TP.Console.WriteLine("Powering down the board....");
			SetupUpc(OpenClose.OPEN);
		}
		#endregion

		//
		// VIInit utility method
		//
		#region VIInit                          :

		/// <summary>
		/// Initialises all VIFs and VIEs in use.
		/// </summary>
		public static void VIInit( )
		{
			double zeroV = 0.00;
			double dvccClamp = App.TC.DVcc + 0.1*App.TC.DVcc;
			double posAvddClamp = App.TC.AVdd + 0.2*App.TC.AVdd;
			double negAvddClamp = -0.1;
			double negAvssClamp = App.TC.AVss + 0.2*App.TC.AVss;
			double posAvssClamp = 0.1;
			double genVoltClamp = 20.0;
			double genCurrClamp = 0.010; //***set to 10mA for now, but need to check this***

			MsDouble maxCapLoad = 10.0e-6; // load expected on VI's in units of uF

			TP.Console.WriteLine("Setting up VIF's and VIE's...");
			
			// ************Setup VIF's************

			// Setup VIF for DVcc
			HW.Dvi.Mode(PM.DVCC, Dvi.FMMode.FVMI);
			HW.Dvi.VRange(PM.DVCC, Dvi.VRanges.V_20_V);
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);
			HW.Dvi.Bandwidth(PM.DVCC, Dvi.Band.LOW);
			HW.Dvi.VClamp(PM.DVCC, dvccClamp);
			HW.Dvi.WriteV(PM.DVCC, zeroV);
			//HW.Dvi.Gate(PM.DVCC, OpenClose.CLOSE);
            
			// set capacitive load compensation so that power is supplied/removed smoothly
            HW.Dvi.CapacitiveLoad(PM.DVCC, maxCapLoad[Site.S1]);

			// Setup VIFs for "Board Sources":
			// VIFs for pinchecker, resistor measurements & HV Comparator input
			HW.Dvi.Mode(PM.IOUT_RES_MEAS, Dvi.FMMode.FVMI);
			HW.Dvi.IRange(PM.IOUT_RES_MEAS, Dvi.IRanges.I_10_MA);
			HW.Dvi.VRange(PM.IOUT_RES_MEAS, Dvi.VRanges.V_20_V);
			HW.Dvi.Bandwidth(PM.IOUT_RES_MEAS, Dvi.Band.LOW);
			HW.Dvi.IClamp(PM.IOUT_RES_MEAS, genCurrClamp);
			HW.Dvi.WriteV(PM.IOUT_RES_MEAS, zeroV);
			HW.Dvi.Gate(PM.IOUT_RES_MEAS, OpenClose.CLOSE);

			HW.Dvi.Mode(PM.VOUT_RES_MEAS, Dvi.FMMode.FVMI);
			HW.Dvi.IRange(PM.VOUT_RES_MEAS, Dvi.IRanges.I_250_MA);
			HW.Dvi.VRange(PM.VOUT_RES_MEAS, Dvi.VRanges.V_20_V);
			HW.Dvi.Bandwidth(PM.VOUT_RES_MEAS, Dvi.Band.LOW);
			HW.Dvi.VClamp(PM.VOUT_RES_MEAS, genVoltClamp);
			HW.Dvi.WriteV(PM.VOUT_RES_MEAS, zeroV);
			HW.Dvi.Gate(PM.VOUT_RES_MEAS, OpenClose.CLOSE);

			HW.Dvi.Mode(PM.V_PINCHECK, Dvi.FMMode.FIMV);
			HW.Dvi.IRange(PM.V_PINCHECK, Dvi.IRanges.I_10_MA);
			HW.Dvi.VRange(PM.V_PINCHECK, Dvi.VRanges.V_20_V);
			HW.Dvi.Bandwidth(PM.V_PINCHECK, Dvi.Band.LOW);
			HW.Dvi.IClamp(PM.V_PINCHECK, genCurrClamp);
			HW.Dvi.NumAverages(PM.V_PINCHECK, 1000);
			HW.Dvi.Timeout(PM.V_PINCHECK, 20, 20);
			HW.Dvi.WriteI(PM.V_PINCHECK, zeroV);
			HW.Dvi.Gate(PM.V_PINCHECK, OpenClose.CLOSE);

			HW.Dvi.Mode(PM.REXT1_RES_MEAS, Dvi.FMMode.FIMV);
			HW.Dvi.IRange(PM.REXT1_RES_MEAS, Dvi.IRanges.I_10_MA);
			HW.Dvi.VRange(PM.REXT1_RES_MEAS, Dvi.VRanges.V_20_V);
			HW.Dvi.Bandwidth(PM.REXT1_RES_MEAS, Dvi.Band.LOW);
			HW.Dvi.IClamp(PM.REXT1_RES_MEAS, genCurrClamp);
			HW.Dvi.WriteI(PM.REXT1_RES_MEAS, zeroV);
			HW.Dvi.Gate(PM.REXT1_RES_MEAS, OpenClose.CLOSE);

			HW.Dvi.Mode(PM.HV_COMP_INPUT, Dvi.FMMode.FVMI);
			HW.Dvi.VRange(PM.HV_COMP_INPUT, Dvi.VRanges.V_20_V);
			HW.Dvi.IRange(PM.HV_COMP_INPUT, Dvi.IRanges.I_10_MA);
			HW.Dvi.Bandwidth(PM.HV_COMP_INPUT, Dvi.Band.LOW);
			HW.Dvi.VClamp(PM.HV_COMP_INPUT, genVoltClamp);
			HW.Dvi.WriteV(PM.HV_COMP_INPUT, App.TC.CompInput);
			HW.Dvi.Gate(PM.HV_COMP_INPUT, OpenClose.CLOSE);


			// Setup VIFs for VSENSEN input
			HW.Dvi.Mode(PM.VSENSEN, Dvi.FMMode.FVMI);
			HW.Dvi.VRange(PM.VSENSEN, Dvi.VRanges.V_20_V);
			HW.Dvi.IRange(PM.VSENSEN, Dvi.IRanges.I_10_MA);
			HW.Dvi.Bandwidth(PM.VSENSEN, Dvi.Band.HIGH);
			HW.Dvi.VClamp(PM.VSENSEN, genVoltClamp);
			HW.Dvi.WriteV(PM.VSENSEN, zeroV);
			HW.Dvi.Gate(PM.VSENSEN, OpenClose.CLOSE);


			// Setup VIFs for IOUT offset
			//HW.Dvi.Mode(PM.IOUT, Dvi.FMMode.FVMI);
			//HW.Dvi.VRange(PM.IOUT, Dvi.VRanges.V_20_V);
			//HW.Dvi.IRange(PM.IOUT, Dvi.IRanges.I_250_MA);
			//HW.Dvi.Bandwidth(PM.IOUT, Dvi.Band.LOW);
			//HW.Dvi.VClamp(PM.IOUT, genVoltClamp);
			//HW.Dvi.WriteV(PM.IOUT, zeroV);
			//HW.Dvi.Gate(PM.IOUT, OpenClose.CLOSE);

			//Setup VIFs for -12V supply on HFDIG circuit
			HW.Dvi.Mode(PM.AD861_NEG_SUPPLY, Dvi.FMMode.FVMI);
			HW.Dvi.VRange(PM.AD861_NEG_SUPPLY, Dvi.VRanges.V_20_V);
			HW.Dvi.IRange(PM.AD861_NEG_SUPPLY, Dvi.IRanges.I_10_MA);
			HW.Dvi.Bandwidth(PM.AD861_NEG_SUPPLY, Dvi.Band.LOW);
			HW.Dvi.VClamp(PM.AD861_NEG_SUPPLY, genVoltClamp);
			HW.Dvi.WriteV(PM.AD861_NEG_SUPPLY, -12.0);
			HW.Dvi.Gate(PM.AD861_NEG_SUPPLY, OpenClose.CLOSE);

			// ************Setup VIE's************

			// Setup VIEs for AVdd/AVss
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				HW.Vi.Mode(PM.VIES, Vi.FMMode.FVMI);
				HW.Vi.VRange(PM.VIES, Vi.VRanges.V_40_V);
				HW.Vi.IRange(PM.VIES, Vi.IRanges.I_100_MA);
				HW.Vi.Bandwidth(PM.VIES, Vi.Band.LOW);
				HW.Vi.VClamp(PM.AVDD, posAvddClamp, negAvddClamp);
				HW.Vi.VClamp(PM.AVSS, posAvssClamp, negAvssClamp);
				HW.Vi.WriteV(PM.VIES, 0);
				//HW.Vi.Gate(PM.VIES, OpenClose.CLOSE);
			}
			//AVss grounded for AD5751 part
		/*	else
			{
				HW.Vi.Mode(PM.AVSS, Vi.FMMode.FVMI);
				HW.Vi.VRange(PM.AVSS, Vi.VRanges.V_40_V);
				HW.Vi.IRange(PM.AVSS, Vi.IRanges.I_100_MA);
				HW.Vi.Bandwidth(PM.AVSS, Vi.Band.LOW);
				HW.Vi.VClamp(PM.AVSS, posAvssClamp, negAvssClamp);
				HW.Vi.WriteV(PM.AVSS, 0);
				//HW.Vi.Gate(PM.AVSS, OpenClose.CLOSE);
			}*/

			// Connect VIEs from rack to testhead through MMX card.
			HW.Mmx.Set(PM.MMX_PIN, 
				new Mmx.RelaySet(Mmx.Relay.VI1_EN_F, 
				Mmx.Relay.VI1_EN_S, 
				Mmx.Relay.VI1_POGO_F, 
				Mmx.Relay.VI1_POGO_S), Mmx.NONE);
			HW.Mmx.Set(PM.MMX_PIN,
				new Mmx.RelaySet(Mmx.Relay.VI2_EN_F ,
				Mmx.Relay.VI2_EN_S ,
				Mmx.Relay.VI2_POGO_F ,
				Mmx.Relay.VI2_POGO_S), Mmx.NONE);
			HW.Mmx.Set(PM.MMX_PIN,
				new Mmx.RelaySet(Mmx.Relay.VI3_EN_F ,
				Mmx.Relay.VI3_EN_S ,
				Mmx.Relay.VI3_POGO_F ,
				Mmx.Relay.VI3_POGO_S), Mmx.NONE);
			HW.Mmx.Set(PM.MMX_PIN,
				new Mmx.RelaySet(Mmx.Relay.VI4_EN_F ,
				Mmx.Relay.VI4_EN_S ,
				Mmx.Relay.VI4_POGO_F ,
				Mmx.Relay.VI4_POGO_S), Mmx.NONE);
			HW.Mmx.Set(PM.MMX_PIN,
				new Mmx.RelaySet(Mmx.Relay.VI5_EN_F ,
				Mmx.Relay.VI5_EN_S ,
				Mmx.Relay.VI5_POGO_F ,
				Mmx.Relay.VI5_POGO_S), Mmx.NONE);
			HW.Mmx.Set(PM.MMX_PIN,
				new Mmx.RelaySet(Mmx.Relay.VI6_EN_F ,
				Mmx.Relay.VI6_EN_S ,
				Mmx.Relay.VI6_POGO_F ,
				Mmx.Relay.VI6_POGO_S), Mmx.NONE);
			HW.Mmx.Set(PM.MMX_PIN,
				new Mmx.RelaySet(Mmx.Relay.VI7_EN_F ,
				Mmx.Relay.VI7_EN_S ,
				Mmx.Relay.VI7_POGO_F ,
				Mmx.Relay.VI7_POGO_S), Mmx.NONE);
			HW.Mmx.Set(PM.MMX_PIN,
				new Mmx.RelaySet(Mmx.Relay.VI8_EN_F ,
				Mmx.Relay.VI8_EN_S ,
				Mmx.Relay.VI8_POGO_F ,
				Mmx.Relay.VI8_POGO_S), Mmx.NONE);
		}
		#endregion

		//
		// DCInit utility method
		//
		#region DCInit                          :

		/// <summary>
		/// Initialises DC Source...
		/// </summary>
		public static void DCInit ( )
		{
			double zeroVolts = 0.0;
		
			// ************Setup DCS ************
			
			TP.Console.WriteLine("Setting up DC Sources...");

			HW.Dcs.Reset(PM.DC_SOURCES);
			HW.Dcs.Band(PM.DC_SOURCES, Dcs.Bands.LO);
			HW.Dcs.VRange(PM.DC_SOURCES, Dcs.Ranges.V_5_V);
			HW.Dcs.VOut(PM.DC_SOURCES, zeroVolts);
			HW.Dcs.OutputConnect(PM.DC_SOURCES, Dcs.Connections.CONNECT_CH_TO_POGO);

		}
		#endregion

		//
		// DssInit utility method
		//
		#region DssInit                          :

		/// <summary>
		/// Initialises Dss Conditions...
		/// </summary>
		public static void DssInit ( )
		{
			double zeroVolts = 0.0;
			//vih and vil values from the cts trigger spec
			double vih = 4.8;
			double vil = 2.6;
		
			// ************Setup DSS ************
			
			TP.Console.WriteLine("Setting up DSS Conditions...");

			// Disconnect and Inhibit all DUT pins until they are required in the program
			HW.Dss.Reset(PM.EVERY_PIN);
			HW.Dss.ConnectionSet(PM.EVERY_PIN, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.DriverInputSelect(PM.EVERY_PIN, Dss.DriveData.FORCE_INHIBIT);
			HW.Dss.DriverTermMode(PM.EVERY_PIN, Dss.TermMode.INHIBIT);
			HW.Dss.PmuConnectMode(PM.EVERY_PIN, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.PmuModeValue(PM.EVERY_PIN, Dss.PmuMode.FVMI_200_UA, zeroVolts);


			// Set up the trigger pins
			HW.Dss.ControlValue(PM.TRIGGERS, Dss.Control.VIH, vih);
			HW.Dss.ControlValue(PM.TRIGGERS, Dss.Control.VIL, vil);

			// Setup strobe/lead/trail values on all pins
			HW.Dss.SeqStop();
			//Setup timing conditions
			SetInterfaceTiming(App.TC.Frequency);
		}
		#endregion

		//
		// MuxInit utility method
		//
		#region MuxInit                          :

		/// <summary>
		/// Initialises Mux's...
		/// </summary>
		public static void MuxInit ( )
		{
			// ************Setup mux control pins ************
			
			TP.Console.WriteLine("Setting up MUX controls...");

			HW.Dss.ControlValue(PM.MUX_PINS, Dss.Control.VIH, 5.0);
			HW.Dss.ControlValue(PM.MUX_PINS, Dss.Control.VIL, 0.0);
			HW.Dss.DriverInputSelect(PM.MUX_PINS, Dss.DriveData.FORCE_LOW);
			HW.Dss.ConnectionSet(PM.MUX_PINS, Dss.ConnectionMode.OUTPUT);
		}
		#endregion

		//
		// HVInit utility method
		//
		#region HVInit                          :

		/// <summary>
		/// Initialises High Voltage Sources...
		/// </summary>
		public static void HVInit ( )
		{
			double zeroVolts = 0.0;

			// ************Setup mux control pins ************
			
			TP.Console.WriteLine("Setting up HVS...");

			//NEED TO CHECK THIS......................
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{																											   
				HW.Upc.Gate(PM.HV_SUPPLIES, OpenClose.OPEN, zeroVolts, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
				HW.Upc.Gate(PM.HV_SUPPLIES, OpenClose.CLOSE, zeroVolts, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
			}
		}
		#endregion

		//
		// SetupUpc local method
		//
		#region SetupUpc                        :
		/// <summary>
		/// Setup the gates on the upc
		/// </summary>
		/// <param name="openClose">specifies whether to open or close the gates</param>
		/// <remarks>
		/// This method is marked private thus making it only available to other methods
		/// in this class - effectively restricting the method to local scope. 
		/// </remarks>
		private static void SetupUpc (OpenClose openClose)
		{
			//
			// The value of this method is to ensure that UserPowerOff and UserPowerOn always
			// work on the same set of supplies.
			//
			HW.Upc.Gate(Upc.A20UPC_V_P24_V, openClose);
			HW.Upc.Gate(Upc.A20UPC_V_N24_V, openClose);
			HW.Upc.Gate(Upc.A20UPC_V_P12_V, openClose);
		}
		#endregion

		//
		//ResetResources method
		//
		#region ResetResources  				:
		/// <summary>
		/// Resets all VIs/sources to 0V and opens all relays
		/// </summary>
		public static void ResetResources ( )
		{
			MsDouble zeroV = 0.0;

			// ************Setup VIF's************
			HW.Dvi.CapacitiveLoad(PM.DVCC, zeroV[Site.S1]);
			HW.Dvi.WriteV(PM.DVCC, zeroV);
			HW.Dvi.WriteV(PM.IOUT_RES_MEAS, zeroV);
			HW.Dvi.WriteV(PM.VOUT_RES_MEAS, zeroV);
			HW.Dvi.WriteI(PM.V_PINCHECK, zeroV);
			HW.Dvi.WriteI(PM.REXT1_RES_MEAS, zeroV);
			HW.Dvi.WriteV(PM.HV_COMP_INPUT, App.TC.CompInput);
			HW.Dvi.WriteV(PM.VSENSEN, zeroV);
			//HW.Dvi.WriteV(PM.IOUT, zeroV);
			HW.Dvi.WriteV(PM.AD861_NEG_SUPPLY, -12.0);
			// ************Setup VIE's************
			HW.Vi.WriteV(PM.VIES, zeroV);
			// ************Setup DC Sources************
			HW.Dcs.VOut(PM.DC_SOURCES, zeroV);
			// ************Setup Pincards************
			HW.Dss.PmuModeValue(PM.EVERY_PIN, Dss.PmuMode.FVMI_200_UA, zeroV);
			HW.Dss.PmuConnectMode(PM.EVERY_PIN, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.ConnectionSet(PM.EVERY_PIN, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.DriverInputSelect(PM.MUX_PINS, Dss.DriveData.FORCE_LOW);
			// ************Open all Relays************
			HW.Rdc.Set(PM.ALL_RELAYS, OpenClose.OPEN);

		}
		#endregion

		#endregion

		//
		//Functions relating to dmm, muxes, digitiser etc
		//
		#region MeasureFunctions

		//
		// MeasureNode method
		//
		#region MeasureNode                    :
		/// <summary>
		/// Measures voltage on given node on either DMM or digitiser, depending 
		/// on parameter passed in.
		/// </summary>
		/// <param name="measPoint"></param>
		/// <param name="resourceSelect"></param>
		/// <returns></returns>
		public static MsDouble MeasureNode (App.MuxNodes measPoint, App.MeasOptions resourceSelect) 
		{
			MsDouble voltageMeas = 0.0;

			if(resourceSelect == App.MeasOptions.DMM)
				voltageMeas = Utl.DmmMeas(measPoint);
			else
				voltageMeas = Utl.DigitiserMeas(measPoint);

			return voltageMeas;
		}
		#endregion
		
		//
		// DmmMeas method
		//
		#region DmmMeas                    :
		/// <summary>
		/// Switches the correct node through the correct mux for measuring
		/// on the dmm. Measures voltage on that node.
		/// </summary>
		/// <param name="measPoint"></param>
		/// <returns></returns>
		/// 

		public static MsDouble DmmMeas (App.MuxNodes measPoint) 
		{
			MsDouble dmmRead = 0.0;
			int nodeSelect, siteIncr = 0,
				currSite = 0, lastSite = 0;


			if(TP.MS.ActiveSites.FirstActiveSite == Site.S1)
				siteIncr = 0;
			else if(TP.MS.ActiveSites.FirstActiveSite == Site.S2)
				siteIncr = 1;
			else if(TP.MS.ActiveSites.FirstActiveSite == Site.S3)
				siteIncr = 2;
			else if(TP.MS.ActiveSites.FirstActiveSite == Site.S4)
				siteIncr = 3;

			nodeSelect = (int)measPoint + siteIncr;

			foreach (Site site in TP.MS.SerialLoop)
			{
				if(lastSite != 0)
				{
					if(site == Site.S1)
						currSite = 1;
					else if(site == Site.S2)
						currSite = 2;
					else if(site == Site.S3)
						currSite = 3;
					else if(site == Site.S4)
						currSite = 4;    
				
				if((currSite - lastSite) == 2)
					nodeSelect++;
				else if((currSite - lastSite) == 3)
					nodeSelect +=2;
				}

				SetMeasMux((App.MuxPerSiteNodes)nodeSelect);
				dmmRead[site] = HW.Dmm.Read(PM.DMM);
				nodeSelect++;

				if(site == Site.S1)
					lastSite = 1;
				else if(site == Site.S2)
					lastSite = 2;
				else if(site == Site.S3)
					lastSite = 3;
				else if(site == Site.S4)
					lastSite = 4;    
			}
			return dmmRead;
		}
		#endregion

		//
		// DigitiserMeas method
		//
		#region DigitiserMeas                    :
		/// <summary>
		/// Switches the correct node through the correct mux for measuring
		/// on the digitiser. Measures voltage on that node.
		/// </summary>
		/// <param name="measPoint"></param>
		/// <returns></returns>
		/// 

		public static MsDouble DigitiserMeas (App.MuxNodes measPoint) 
		{
			MsDouble digMeas = 0.0;
			MsDouble digOffset = 0, digGain = 1;
			
			ConnectDigChan(measPoint, out digOffset, out digGain);
			
			if((measPoint == App.MuxNodes.IOUT_MEAS) || (measPoint == App.MuxNodes.VSENSEN_MEAS))
                digMeas = HW.Lfd.DirectRead(PM.DIG14, (int)App.TC.NumDigAvgs);
				//digMeas = HW.Lfd.VoltmeterRead(PM.DIG14);
			else if((measPoint == App.MuxNodes.VOUT_MEAS) || (measPoint == App.MuxNodes.VOUT_SCALE_MEAS))
				digMeas = HW.Lfd.DirectRead(PM.DIG15, (int)App.TC.NumDigAvgs);
			else
				TP.Console.WriteLine("Can't measure this node using digitiser");

			//Adjust measurement with digitiser offset and gain errors
			digMeas = (digMeas - digOffset) / digGain;

			//Cleanup 

			return digMeas;
		}
		#endregion

		//
		// SetMeasMux method
		//
		#region SetMeasMux                    :
		/// <summary>
		/// Switches the correct node through the correct mux
		/// </summary>
		/// <param name="measPoint"></param>
		/// 

		public static void SetMeasMux (App.MuxPerSiteNodes measPoint) 
		{
			if((measPoint >= App.MuxPerSiteNodes.VREF_MEAS_0) && (measPoint < App.MuxPerSiteNodes.IFAULT_MEAS_0))
				SetMuxA(measPoint);
			else if((measPoint >= App.MuxPerSiteNodes.IFAULT_MEAS_0) && (measPoint < App.MuxPerSiteNodes.V_GAIN_CHECK_0))
				SetMuxB(measPoint);
			else if((measPoint >= App.MuxPerSiteNodes.V_GAIN_CHECK_0) && (measPoint <= App.MuxPerSiteNodes.V_GAIN_CHECK_3))
				SetMuxC(measPoint);
			else
				TP.Console.WriteLine("Invalid entry for SetMeasMux method...");
		}
		#endregion

		//
		// SetMuxA method
		//
		#region SetMuxA                  :
		/// <summary>
		/// Switches the correct node through MuxA to the dmm.
		/// </summary>
		/// <param name="measPoint"></param>
		public static void SetMuxA (App.MuxPerSiteNodes measPoint) 
		{
			int mod;

			//Disable all muxes
			HW.Dss.DriverInputSelect(PM.MUX_EN_PINS, Dss.DriveData.FORCE_LOW);

			switch (measPoint)
			{
				case App.MuxPerSiteNodes.VREF_MEAS_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VREF_MEAS_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VREF_MEAS_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VREF_MEAS_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VIN_MEAS_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VIN_MEAS_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VIN_MEAS_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VIN_MEAS_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VOUT_MEAS_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.VOUT_MEAS_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.VOUT_MEAS_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.VOUT_MEAS_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.IOUT_MEAS_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.IOUT_MEAS_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.IOUT_MEAS_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.IOUT_MEAS_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				default:
					TP.Console.WriteLine("Invalid entry for SetMuxA method");
					break;
			}

			//Select which DUTGND to switch to DmmLow
			mod = (int)measPoint % 4;

			if(mod == 0)
			{
				HW.Rdc.Set(PM.D63, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D64, OpenClose.CLOSE);
			}
			else if(mod == 1)
			{
				HW.Rdc.Set(PM.D63, OpenClose.OPEN);
				HW.Rdc.Set(PM.D64, OpenClose.CLOSE);
			}
			else if(mod == 2)
			{
				HW.Rdc.Set(PM.D63, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D64, OpenClose.OPEN);
			}
			else if(mod == 3)
			{
				HW.Rdc.Set(PM.D63, OpenClose.OPEN);
				HW.Rdc.Set(PM.D64, OpenClose.OPEN);
			}

			//Drive enable pin for Mux A high
			HW.Dss.DriverInputSelect(PM.MUXA_EN, Dss.DriveData.FORCE_HIGH);

			// added on Friday
			HW.Dss.ConnectionSet(PM.MUX_A0, Dss.ConnectionMode.OUTPUT);
			HW.Dss.ConnectionSet(PM.MUX_A1, Dss.ConnectionMode.OUTPUT);
			HW.Dss.ConnectionSet(PM.MUX_A2, Dss.ConnectionMode.OUTPUT);
			HW.Dss.ConnectionSet(PM.MUX_A3, Dss.ConnectionMode.OUTPUT);


			
			App.Time.MsDelay(App.TC.RelaySettle);
			
		}

		#endregion

		//
		// SetMuxB method
		//
		#region SetMuxB                  :	
		/// <summary>
		/// Switches the correct node through MuxB to the dmm.
		/// </summary>
		/// <param name="measPoint"></param>
		/// 

		public static void SetMuxB (App.MuxPerSiteNodes measPoint) 
		{
			int mod;

			//Disable all muxes
			HW.Dss.DriverInputSelect(PM.MUX_EN_PINS, Dss.DriveData.FORCE_LOW);

			switch (measPoint)
			{
				case App.MuxPerSiteNodes.IFAULT_MEAS_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.IFAULT_MEAS_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.IFAULT_MEAS_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.IFAULT_MEAS_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VSENSEN_MEAS_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VSENSEN_MEAS_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VSENSEN_MEAS_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VSENSEN_MEAS_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.VOUT_SCALE_MEAS_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.VOUT_SCALE_MEAS_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.VOUT_SCALE_MEAS_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.VOUT_SCALE_MEAS_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.DUTGND_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.DUTGND_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.DUTGND_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				case App.MuxPerSiteNodes.DUTGND_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A3, Dss.DriveData.FORCE_HIGH);
					break;
				default:
					TP.Console.WriteLine("Invalid entry for SetMuxB method");
					break;
			}

			//Select which DUTGND to switch to DmmLow
			mod = (int)measPoint % 4;

			if(mod == 0)
			{
				HW.Rdc.Set(PM.D63, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D64, OpenClose.CLOSE);
			}
			else if(mod == 1)
			{
				HW.Rdc.Set(PM.D63, OpenClose.OPEN);
				HW.Rdc.Set(PM.D64, OpenClose.CLOSE);
			}
			else if(mod == 2)
			{
				HW.Rdc.Set(PM.D63, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D64, OpenClose.OPEN);
			}
			else if(mod == 3)
			{
				HW.Rdc.Set(PM.D63, OpenClose.OPEN);
				HW.Rdc.Set(PM.D64, OpenClose.OPEN);
			}

			App.Time.MsDelay(App.TC.RelaySettle);

			//Drive enable pin for Mux B high
			HW.Dss.DriverInputSelect(PM.MUXB_EN, Dss.DriveData.FORCE_HIGH);

			// missing code - Michal Added
			HW.Dss.ConnectionSet(PM.MUX_A0, Dss.ConnectionMode.OUTPUT);
			HW.Dss.ConnectionSet(PM.MUX_A1, Dss.ConnectionMode.OUTPUT);
			HW.Dss.ConnectionSet(PM.MUX_A2, Dss.ConnectionMode.OUTPUT);
			HW.Dss.ConnectionSet(PM.MUX_A3, Dss.ConnectionMode.OUTPUT);

			App.Time.MsDelay(App.TC.RelaySettle);
		}

		#endregion

		//
		// SetMuxC method
		//
		#region SetMuxC                  :
		/// <summary>
		/// Switches the correct node through MuxC to the dmm.
		/// </summary>
		/// <param name="measPoint"></param>
		public static void SetMuxC (App.MuxPerSiteNodes measPoint) 
		{
			int mod;

			//Disable all muxes
			HW.Dss.DriverInputSelect(PM.MUX_EN_PINS, Dss.DriveData.FORCE_LOW);

			switch (measPoint)
			{
				case App.MuxPerSiteNodes.V_GAIN_CHECK_0:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.V_GAIN_CHECK_1:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.V_GAIN_CHECK_2:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					break;
				case App.MuxPerSiteNodes.V_GAIN_CHECK_3:
					HW.Dss.DriverInputSelect(PM.MUX_A0, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.MUX_A2, Dss.DriveData.FORCE_LOW);
					break;
				default:
					TP.Console.WriteLine("Invalid entry for SetMuxC method");
					break;
			}

			//Select which DUTGND to switch to DmmLow
			mod = (int)measPoint % 4;

			if(mod == 0)
			{
				HW.Rdc.Set(PM.D63, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D64, OpenClose.CLOSE);
			}
			else if(mod == 1)
			{
				HW.Rdc.Set(PM.D63, OpenClose.OPEN);
				HW.Rdc.Set(PM.D64, OpenClose.CLOSE);
			}
			else if(mod == 2)
			{
				HW.Rdc.Set(PM.D63, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D64, OpenClose.OPEN);
			}
			else if(mod == 3)
			{
				HW.Rdc.Set(PM.D63, OpenClose.OPEN);
				HW.Rdc.Set(PM.D64, OpenClose.OPEN);
			}

			//Drive enable pin for Mux C high
			HW.Dss.DriverInputSelect(PM.MUXC_EN, Dss.DriveData.FORCE_HIGH);
			App.Time.MsDelay(App.TC.RelaySettle);
		}

		#endregion

		//
		// ConnectDigChan method
		//
		#region ConnectDigChan                  :
		/// <summary>
		/// Connects up correct digitiser channel depending on selected measure point.
		/// </summary>
		/// <param name="measPoint"></param>
		public static void ConnectDigChan (App.MuxNodes measPoint, out MsDouble digOffset, out MsDouble digGain) 
		{
			HW.Lfd.Reset(PM.DIG14);
			HW.Lfd.Reset(PM.DIG15);
			HW.Lfd.GroundSense(PM.DIG14, EnableDisable.ENABLE);
			HW.Lfd.GroundSense(PM.DIG15, EnableDisable.ENABLE);

			//Default offset/gain values
			digOffset = 0;
			digGain = 1;

			switch (measPoint)
			{
				case App.MuxNodes.VREF_MEAS:
					TP.Console.WriteLine("No valid digitiser connection for VREF");
                    break;
				case App.MuxNodes.VIN_MEAS:
					TP.Console.WriteLine("No valid digitiser connection for VIN");
					break;
				case App.MuxNodes.VOUT_MEAS:
					HW.Lfd.DirectMode(PM.DIG15, Lfd.PosInput.DUT1, Lfd.NegInput.DUT1, Lfd.NmRange.V_11_V, Lfd.CmRange.BIP_11_V, 0, Lfd.Filter.LP_200_KHZ, Lfd.Trigger.SOFT_TRIG, 500000, EnableDisable.ENABLE);
					digOffset = App.TC.BoardVars.dig15offset1;
					digGain = App.TC.BoardVars.dig15gain1;
					break;
				case App.MuxNodes.IOUT_MEAS:
					//HW.Lfd.VoltmeterMode(PM.DIG14, Lfd.PosInput.DUT1, Lfd.NegInput.DUT1, Lfd.NmRange.V_11_V, Lfd.CmRange.BIP_11_V, (int)App.TC.NumDigAvgs);
					HW.Lfd.DirectMode(PM.DIG14, Lfd.PosInput.DUT1, Lfd.NegInput.DUT1, Lfd.NmRange.V_11_V, Lfd.CmRange.BIP_11_V, 0, Lfd.Filter.LP_200_KHZ, Lfd.Trigger.SOFT_TRIG, 500000, EnableDisable.ENABLE);
					digOffset = App.TC.BoardVars.dig14offset1;
					digGain = App.TC.BoardVars.dig14gain1;
					break;
				case App.MuxNodes.IFAULT_MEAS:
					TP.Console.WriteLine("No valid digitiser connection for IFAULT");
					break;
				case App.MuxNodes.VSENSEN_MEAS:
					HW.Lfd.DirectMode(PM.DIG14, Lfd.PosInput.DUT2, Lfd.NegInput.DUT1, Lfd.NmRange.V_11_V, Lfd.CmRange.BIP_11_V, 0, Lfd.Filter.LP_200_KHZ, Lfd.Trigger.SOFT_TRIG, 500000, EnableDisable.ENABLE);
					digOffset = App.TC.BoardVars.dig14offset2;
					digGain = App.TC.BoardVars.dig14gain2;
					break;
				case App.MuxNodes.VOUT_SCALE_MEAS:
					HW.Lfd.DirectMode(PM.DIG15, Lfd.PosInput.DUT2, Lfd.NegInput.DUT1, Lfd.NmRange.V_11_V, Lfd.CmRange.BIP_11_V, 0, Lfd.Filter.LP_200_KHZ, Lfd.Trigger.SOFT_TRIG, 500000, EnableDisable.ENABLE);
					digOffset = App.TC.BoardVars.dig15offset2;
					digGain = App.TC.BoardVars.dig15gain2;
					break;
				case App.MuxNodes.DUTGND:
					TP.Console.WriteLine("No valid digitiser connection for DUTGND");
					break;
				case App.MuxNodes.V_GAIN_CHECK:
					TP.Console.WriteLine("No valid digitiser connection for V_GAIN_CHECK");
					break;
				default:
					TP.Console.WriteLine("Invalid entry for ConnectDigChan method");
					break;
			}
		}

		#endregion
		#endregion

		//
		//DUT specific setups
		//
		#region DeviceSetupFunctions
		//
		// SetInterfaceTiming utility method
		//
		#region SetInterfaceTiming                         :
		/// <summary>
		/// Sets up timing conditions for normal SPI operation
		/// </summary>
		/// <param name="freq"></param>
		/// 
		public static void SetInterfaceTiming (double freq) 
		{
			double vectorPeriod = 1.0/freq;

			App.TC.TimingData.SyncLead = vectorPeriod/11.0;
			App.TC.TimingData.SyncTrail = vectorPeriod/2.0;
			App.TC.TimingData.SclkLead = vectorPeriod/10.0;
			App.TC.TimingData.SclkTrail = vectorPeriod/10.0 + vectorPeriod/2.0;
			App.TC.TimingData.SdinLead = vectorPeriod/4.0;
			App.TC.TimingData.SdinTrail = 3.0*vectorPeriod/4.0;
			App.TC.TimingData.SdoStrobe = 9.0*vectorPeriod/10.0;
			App.TC.TimingData.ResetLead = vectorPeriod/33.0;
			App.TC.TimingData.ResetTrail = 32.0*(vectorPeriod/33.0);
			App.TC.TimingData.ClearLead = vectorPeriod/10.0;


			if(App.Globals.DebugEnable)
			{
				App.TC.TimingData.SyncLead = vectorPeriod/33.0;
				App.TC.TimingData.SyncTrail = 32*vectorPeriod/33.0;
				App.TC.TimingData.SclkLead = vectorPeriod/15.0;
				App.TC.TimingData.SclkTrail = vectorPeriod/15.0 + vectorPeriod/2.0;
				App.TC.TimingData.SdinLead = vectorPeriod/4.0;
				App.TC.TimingData.SdinTrail = 3.0*vectorPeriod/4.0;
				App.TC.TimingData.SdoStrobe = 32*vectorPeriod/33.0;
				App.TC.TimingData.ResetLead = vectorPeriod/10.0;
				App.TC.TimingData.ClearLead = vectorPeriod/10.0;
			}

			//For safety, stop the formatters first
			HW.Dss.SeqStop(); 
			HW.Dss.Freq(PM.EVERY_PIN,freq);
			//Set up valid conditions for each pin to avoid alarms.
			HW.Dss.Strobe(PM.EVERY_PIN, vectorPeriod - 1.0e-9);
			HW.Dss.Lead(PM.EVERY_PIN, 1.0e-9);
			HW.Dss.Trail(PM.EVERY_PIN, vectorPeriod - 5.0e-9);

			//Set up correct timing data on SPI pins
			HW.Dss.Lead(PM.SYNC_RSEL, App.TC.TimingData.SyncLead);
			HW.Dss.Trail(PM.SYNC_RSEL, App.TC.TimingData.SyncTrail);
			HW.Dss.Lead(PM.SCLK_OUTEN, App.TC.TimingData.SclkLead);
			HW.Dss.Trail(PM.SCLK_OUTEN, App.TC.TimingData.SclkTrail);
			HW.Dss.Lead(PM.SDIN_R0,App.TC.TimingData.SdinLead);
			HW.Dss.Trail(PM.SDIN_R0, App.TC.TimingData.SdinTrail);
			HW.Dss.Strobe(PM.SDO_VFAULT, App.TC.TimingData.SdoStrobe);
			HW.Dss.Lead(PM.RESET, App.TC.TimingData.ResetLead);
			HW.Dss.Trail(PM.RESET, App.TC.TimingData.ResetTrail);
			HW.Dss.Lead(PM.CLEAR, App.TC.TimingData.ClearLead);
		}
		#endregion

		//
		// t5SetInterfaceTiming utility method
		//
		#region t5SetInterfaceTiming                         :
		/// <summary>
		/// Sets up timing conditions for normal SPI operation
		/// </summary>
		/// <param name="freq"></param>
		/// 
		public static void t5SetInterfaceTiming (double freq) 
		{
			double vectorPeriod = 1.0/freq;


			//App.TC.TimingData.SyncLead = vectorPeriod/11.0;
			//App.TC.TimingData.SyncTrail = vectorPeriod/2.0;
			//App.TC.TimingData.SclkLead = vectorPeriod/10.0;
			//App.TC.TimingData.SclkTrail = vectorPeriod/10.0 + vectorPeriod/2.0;
			//App.TC.TimingData.SdinLead = vectorPeriod/4.0;
			//App.TC.TimingData.SdinTrail = 3.0*vectorPeriod/4.0;
			//App.TC.TimingData.SdoStrobe = 9.0*vectorPeriod/10.0;
			//App.TC.TimingData.ResetLead = vectorPeriod/10.0;
			//App.TC.TimingData.ClearLead = vectorPeriod/10.0;

			App.TC.TimingData.SyncLead = vectorPeriod/33.0;
			App.TC.TimingData.SyncTrail = 32*vectorPeriod/33.0;
			App.TC.TimingData.SclkLead = vectorPeriod/15.0;
			App.TC.TimingData.SclkTrail = vectorPeriod/15.0 + vectorPeriod/2.0;
			App.TC.TimingData.SdinLead = vectorPeriod/4.0;
			App.TC.TimingData.SdinTrail = 3.0*vectorPeriod/4.0;
			App.TC.TimingData.SdoStrobe = 32*vectorPeriod/33.0;
			App.TC.TimingData.ResetLead = vectorPeriod/10.0;
			App.TC.TimingData.ClearLead = vectorPeriod/10.0;

			//For safety, stop the formatters first
			HW.Dss.SeqStop(); 
			HW.Dss.Freq(PM.EVERY_PIN,freq);
			//Set up valid conditions for each pin to avoid alarms.
			HW.Dss.Strobe(PM.EVERY_PIN, vectorPeriod - 1.0e-9);
			HW.Dss.Lead(PM.EVERY_PIN, 1.0e-9);
			HW.Dss.Trail(PM.EVERY_PIN, vectorPeriod - 5.0e-9);

			//Set up correct timing data on SPI pins
			HW.Dss.Lead(PM.SYNC_RSEL, App.TC.TimingData.SyncLead);
			HW.Dss.Trail(PM.SYNC_RSEL, App.TC.TimingData.SyncTrail);
			HW.Dss.Lead(PM.SCLK_OUTEN, App.TC.TimingData.SclkLead);
			HW.Dss.Trail(PM.SCLK_OUTEN, App.TC.TimingData.SclkTrail);
			HW.Dss.Lead(PM.SDIN_R0,App.TC.TimingData.SdinLead);
			HW.Dss.Trail(PM.SDIN_R0, App.TC.TimingData.SdinTrail);
			HW.Dss.Strobe(PM.SDO_VFAULT, App.TC.TimingData.SdoStrobe);
			HW.Dss.Lead(PM.RESET, App.TC.TimingData.ResetLead);
			HW.Dss.Lead(PM.CLEAR, App.TC.TimingData.ClearLead);
		}
		#endregion

		//
		// PowerUpDevice method
		//
		#region PowerUpDevice                  :
		/// <summary>
		/// Function to power up the DUT
		/// </summary>
		/// 
		public static void PowerUpDevice ( ) 
		{
			MsDouble dvccValue = 0.0;
			double pullupVoltage;

			//TP.Console.WriteLine("Powering Up the DUT!!!");

			HW.Dvi.Gate(PM.DVCC, OpenClose.CLOSE);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                HW.Vi.Gate(PM.VIES, OpenClose.CLOSE);				

			//Ensure decoupling caps are switched in
			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN);
			//Tie VsenseN to DUTGND & Vout to VsenseP
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Setup AVdd using VIE
				HW.Rdc.Set(PM.RLX08_RELAYS, OpenClose.OPEN);
				Utl.StepSupplyVoltageTo(PM.AVDD, App.TC.AVdd, App.TC.CurrentVdd);
				App.Time.UsDelay(100);
				//No need for high voltage protection circuit if AD5750 is being tested.
				HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);

				//Set up AVss - For AD5751, AVss grounded.
				Utl.StepSupplyVoltageTo(PM.AVSS, App.TC.AVss, App.TC.CurrentVss);
			}

			//Set up DVcc
			foreach(Site site in TP.MS.ActiveSites)
			{
				//If testing AD5751, need to take diode drop on DVcc into account.
				if(App.Globals.GenericType == App.GenericType.HV_GEN)
					dvccValue[site] = App.TC.DVcc + App.TC.BoardVars.DvccDiodeVoltage[site];
				else
					dvccValue[site] = App.TC.DVcc;
			}

			HW.Dvi.VClamp(PM.DVCC, (dvccValue + dvccValue* (MsDouble)(0.1)));
			HW.Dvi.WriteV(PM.DVCC, dvccValue);
			App.Time.UsDelay(100);

			//Set up Vref
			HW.Dcs.VOut(PM.VREF, App.TC.VRef);
			App.Time.UsDelay(100);

			//Force 0V on Vin initially
			HW.Dcs.VOut(PM.VIN, 0.0);
			App.Time.UsDelay(100);

			//Connect Digital Pins & set up logic levels
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, App.TC.Voh);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, App.TC.Vol);
			HW.Dss.DriverInputSelect(PM.DIG_PINS, Dss.DriveData.DRIVE_PATTERN);
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.OUTPUT);


			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);

			//Set up AVdd
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				//Switch out HVS 
				HW.Rdc.Set(PM.RLX08_RELAYS, OpenClose.CLOSE);
				HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.OPEN);
				HW.Dvi.WriteV(PM.HV_COMP_INPUT, 100.0e-3);
				
				HW.Upc.Gate(PM.HV_SUPPLIES, OpenClose.CLOSE, App.TC.AVdd/(MsDouble)2.0, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
				App.Time.MsDelay(100);

				//Close RLX18 so that if Vout is loaded, that it is always loaded with 5k
				//and not 1k, which will cause the short cct current to kick in at higher supplies
				HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);
			}

			//AD57571 Note: AVss disconnected as it's internally tied to VsenseN which is tied to DUTGND for the whole test run
			App.TC.CurrentVdd = App.TC.AVdd;
			App.TC.CurrentVss = App.TC.AVss;

			App.TC.CurrentVcc[Site.S1] = App.TC.DVcc;
			App.TC.CurrentVcc[Site.S2] = App.TC.DVcc;
			App.TC.CurrentVcc[Site.S3] = App.TC.DVcc;
			App.TC.CurrentVcc[Site.S4] = App.TC.DVcc;

			//Setup correct timing
			SetInterfaceTiming(App.TC.Frequency);

		}
		#endregion


		//
		// PowerUpDeviceForVoutLkg method
		//
		#region PowerUpDeviceForVoutLkg                 :
		/// <summary>
		/// Function to power up the DUT
		/// </summary>
		/// 
		public static void PowerUpDeviceForVoutLkg ( ) 
		{
			MsDouble dvccValue = 0.0;
			double pullupVoltage;
			MsDouble lkgAvdd = 44.0, 
				lkgAvss = 0.0;
			MsDouble compInput = 0.3;

			//TP.Console.WriteLine("Powering Up the DUT!!!");

			HW.Dvi.WriteV(PM.HV_COMP_INPUT, compInput);
			HW.Dvi.Gate(PM.DVCC, OpenClose.CLOSE);			

			//Setup relays correctly
			HW.Rdc.Set(PM.D3, OpenClose.OPEN);
			HW.Rdc.Set(PM.D7, OpenClose.OPEN);
			HW.Rdc.Set(PM.D6, OpenClose.OPEN);

			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);

			//Set up DVcc
			foreach(Site site in TP.MS.ActiveSites)
			{
				//If testing AD5751, need to take diode drop on DVcc into account.
				if(App.Globals.GenericType == App.GenericType.HV_GEN)
					dvccValue[site] = App.TC.DVcc + App.TC.BoardVars.DvccDiodeVoltage[site];
				else
					dvccValue[site] = App.TC.DVcc;
			}

			HW.Dvi.WriteV(PM.DVCC, dvccValue);
			App.Time.UsDelay(100);

			//Set up AVss
			HW.Vi.Gate(PM.AVSS, OpenClose.CLOSE);
			Utl.StepSupplyVoltageTo(PM.AVSS, lkgAvss, App.TC.CurrentVss);

			//Set up AVdd
			//Switch out HVS 
			HW.Rdc.Set(PM.RLX08_RELAYS, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.OPEN);
			//HW.Upc.Gate(PM.HV_SUPPLIES, OpenClose.CLOSE, lkgAvdd/(MsDouble)4.0, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
			HW.Upc.Gate(PM.HV_SUPPLIES, OpenClose.CLOSE, lkgAvdd/(MsDouble)2.0, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
			App.Time.MsDelay(100);

			//Close RLX18 so that if Vout is loaded, that it is always loaded with 5k
			//and not 1k, which will cause the short cct current to kick in at higher supplies
			HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			App.TC.CurrentVdd = lkgAvdd;
			App.TC.CurrentVss = lkgAvss;

			App.TC.CurrentVcc[Site.S1] = App.TC.DVcc;
			App.TC.CurrentVcc[Site.S2] = App.TC.DVcc;
			App.TC.CurrentVcc[Site.S3] = App.TC.DVcc;
			App.TC.CurrentVcc[Site.S4] = App.TC.DVcc;

			//Set up Vref
			HW.Dcs.VOut(PM.VREF, App.TC.VRef);
			App.Time.UsDelay(100);

			//Force 0V on Vin initially
			HW.Dcs.VOut(PM.VIN, 0.0);
			App.Time.UsDelay(100);

			//Connect Digital Pins & set up logic levels
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, 4.0);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, 0.0);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, App.TC.Voh);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, App.TC.Vol);
			HW.Dss.DriverInputSelect(PM.DIG_PINS, Dss.DriveData.DRIVE_PATTERN);
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.OUTPUT);


			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);

			//Setup correct timing
			SetInterfaceTiming(App.TC.Frequency);

		}
		#endregion

		//
		// ModifySupplies method
		//
		#region ModifySupplies                  :
		/// <summary>
		/// Function to modify DUT supplies
		/// </summary>
		/// <param name="aVdd"></param>
		/// <param name="aVss"></param>
		/// <param name="dVcc"></param>
		public static void ModifySupplies (MsDouble aVdd, MsDouble aVss, MsDouble dVcc ) 
		{
			double vddDelay = 0.0;
			MsDouble posAvddClamp = 0.0, negAvddClamp = -0.1, posAvssClamp = 0.1, negAvssClamp = 0.0;

			//TP.Console.WriteLine("Modifiying supplies to AVdd: {0}V, AVss: {1}V, DVcc: {2}", aVdd, aVss, dVcc);

			foreach(Site site in TP.MS.SerialLoop)
			{
				//Set up AVdd
				if(aVdd[site] != App.TC.CurrentVdd[site])
				{
					if(App.TC.CurrentVdd[site] < aVdd[site])
					{
						//Set clamps according to required AVdd
						posAvddClamp[site] = aVdd[site] + aVdd[site]*0.2;
						HW.Vi.VClamp(PM.AVDD, posAvddClamp, negAvddClamp);
					}
					vddDelay = ((Math.Abs(App.TC.CurrentVdd[site] - aVdd[site])) / App.TC.AvddSlewRate) * 1000;
					if(App.Globals.GenericType == App.GenericType.LV_GEN)
					{ 
						Utl.StepSupplyVoltageTo(PM.AVDD, aVdd[site], App.TC.CurrentVdd[site]);
					}
					else if(App.Globals.GenericType == App.GenericType.HV_GEN)
					{
						HW.Upc.Gate(PM.HV_SUPPLY1_LO, OpenClose.CLOSE, aVdd[site]/2.0, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
						HW.Upc.Gate(PM.HV_SUPPLY1_HI, OpenClose.CLOSE, aVdd[site]/2.0, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
					}
					App.Time.MsDelay(vddDelay);
					if(App.TC.CurrentVdd[site] > aVdd[site])
					{
						//Set clamps according to required AVdd
						posAvddClamp[site] = aVdd[site] + aVdd[site]*0.2;
						HW.Vi.VClamp(PM.AVDD, posAvddClamp, negAvddClamp);
					}
					//App.Time.MsDelay(App.TC.OutputSettle);
					App.TC.CurrentVdd[site] = aVdd[site];
				}

				//Set up AVss
				if(aVss[site] != App.TC.CurrentVss[site])
				{
					if(App.Globals.GenericType == App.GenericType.HV_GEN)
					{
						if(aVss[site] != 0)
						{
							TP.Console.WriteLine("Can't set non-zero AVss value on AD5751!");
						}
						else
						{
							if(App.TC.CurrentVss > aVss)
							{
								//Set clamps according to required AVdd
								negAvssClamp[site] = aVss[site] + aVss[site]*0.2;
								HW.Vi.VClamp(PM.AVSS, posAvssClamp, negAvssClamp);
							}
							Utl.StepSupplyVoltageTo(PM.AVSS, aVss[site], App.TC.CurrentVss[site]);
							App.Time.MsDelay(App.TC.OutputSettle);
						}
					}
					else
					{
						if(App.TC.CurrentVss > aVss)
						{
							//Set clamps according to required AVdd
							negAvssClamp[site] = aVss[site] + aVss[site]*0.2;
							HW.Vi.VClamp(PM.AVSS, posAvssClamp, negAvssClamp);
						}
						Utl.StepSupplyVoltageTo(PM.AVSS, aVss[site], App.TC.CurrentVss[site]);
						App.Time.MsDelay(App.TC.OutputSettle);
						if(App.TC.CurrentVss < aVss)
						{
							//Set clamps according to required AVdd
							negAvssClamp[site] = aVss[site] + aVss[site]*0.2;
							HW.Vi.VClamp(PM.AVSS, posAvssClamp, negAvssClamp);
						}
					}
					App.TC.CurrentVss[site] = aVss[site];
				}

				//Set up DVcc
				if(dVcc != App.TC.CurrentVcc)
				{
					//App.TC.CurrentVcc = dVcc;

					if(dVcc[site] > App.TC.CurrentVcc[site])
					{

						//If testing AD5751, need to take diode drop on DVcc into account.
						if(App.Globals.GenericType == App.GenericType.HV_GEN)
							dVcc = dVcc[site] + App.TC.BoardVars.DvccDiodeVoltage[site];

						HW.Dvi.VClamp(PM.DVCC, (dVcc[site] + dVcc[site]*0.1));
						HW.Dvi.WriteV(PM.DVCC, dVcc);

						HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, dVcc[site]);
						HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, dVcc[site] - 0.4);
					}
					else
					{
						//If testing AD5751, need to take diode drop on DVcc into account.
						if(App.Globals.GenericType == App.GenericType.HV_GEN)
							dVcc[site] = App.TC.CurrentVcc[site] + App.TC.BoardVars.DvccDiodeVoltage[site];

						HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, dVcc[site]);
						HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, dVcc[site] - 0.4);

						HW.Dvi.WriteV(PM.DVCC, dVcc[site]);
						HW.Dvi.VClamp(PM.DVCC, (dVcc[site] + dVcc[site]*0.1));
					}
				
					App.Time.MsDelay(App.TC.OutputSettle);
					App.TC.CurrentVcc[site] = dVcc[site];
				}
			}
		}
		#endregion

		//
		// StepSupplyVoltageTo method
		//
		#region StepSupplyVoltageTo                  :
		/// <summary>
		/// When using VIEs, it's important to step the voltage gradually
		/// Otherwise, over/under shoots damage the DUT
		/// </summary>
		/// <param name="pin"></param>
		/// <param name="targetVoltage"></param>
		/// <param name="currentVoltage"></param>
		public static void StepSupplyVoltageTo (PinList pin, MsDouble targetVoltage, MsDouble currentVoltage) 
		{
			MsInt numSteps = 0;
			MsDouble stepSize = 0.0;

			if((pin == PM.AVDD) || (pin == PM.AVSS))
			{
				foreach(Site site in TP.MS.ActiveSites)
				{
					numSteps[site] = Math.Abs((int)(currentVoltage[site] - targetVoltage[site]));
					if(targetVoltage[site] > currentVoltage[site])
						stepSize[site] = 1;
					else
						stepSize[site] = -1;
				}

				foreach (Site site in TP.MS.SerialLoop)
				{
					for(int i = 0; i < numSteps[site]; i++)
					{
						HW.Vi.WriteV(pin, (currentVoltage[site] + (i+1)*stepSize[site]));
						App.Time.MsDelay(App.TC.VieDelay);
					}
					HW.Vi.WriteV(pin, targetVoltage[site]);
				}
			}
			else
				TP.Console.WriteLine("Invalid supply pin selection for 'StepSupplyVoltageTo' function");

		}
		#endregion

		//
		// StepSupplyVoltageTo method
		//
		#region StepSupplyVoltageToAvss                  :
		/// <summary>
		/// When using VIEs, it's important to step the voltage gradually
		/// Otherwise, over/under shoots damage the DUT
		/// </summary>
		/// <param name="pin"></param>
		/// <param name="targetVoltage"></param>
		/// <param name="currentVoltage"></param>
		public static void StepSupplyVoltageToAvss (double targetAvssVoltage, double CurrentAvssVoltage) 
		{
			int numSteps = 0;
			double stepSize = 0.0;

			numSteps = Math.Abs((int)(CurrentAvssVoltage - targetAvssVoltage));
			if(targetAvssVoltage > CurrentAvssVoltage)
				stepSize = 1;
			else
				stepSize = -1;
			
			for(int i = 0; i < numSteps; i++)
			{
				HW.Vi.WriteV(Vi.V02VIB, (CurrentAvssVoltage + (i+1)*stepSize));
				App.Time.MsDelay(App.TC.VieDelay);
			}
			HW.Vi.WriteV(Vi.V02VIB, targetAvssVoltage);

		}
		#endregion


		//
		// PowerDownDevice method
		//
		#region PowerDownDevice                  :
		/// <summary>
		/// Function to power down the DUT
		/// </summary>

		public static void PowerDownDevice ( ) 
		{
			MsDouble zeroVolts = 0.0;
			
			//Force 0V on Vin
			HW.Dcs.VOut(PM.VIN, zeroVolts);
			App.Time.UsDelay(100);

			//Set Vref to 0V
			HW.Dcs.VOut(PM.VREF, zeroVolts);
			App.Time.UsDelay(100);

			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				//Force HVS to 0V
				HW.Upc.Gate(PM.HV_SUPPLY1_HI, OpenClose.CLOSE, zeroVolts, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
				HW.Upc.Gate(PM.HV_SUPPLY1_LO, OpenClose.CLOSE, zeroVolts, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
				HW.Rdc.Set(PM.RLX08_RELAYS, OpenClose.OPEN);
				App.Time.UsDelay(100);
			}

			//Set DVcc to 0V
			foreach(Site site in TP.MS.SerialLoop)
			{
				if(App.TC.CurrentVcc[site] != 0.0)
				{
					HW.Dvi.WriteV(PM.DVCC, App.TC.DVcc/2.0);
					App.Time.UsDelay(100);
				}
			}
			HW.Dvi.WriteV(PM.DVCC, zeroVolts);
			App.Time.UsDelay(100);


			//Set AVss to 0v
			Utl.StepSupplyVoltageTo(PM.AVSS, zeroVolts, App.TC.CurrentVss);
			App.Time.UsDelay(100);
			
			
			
			//Set up AVdd
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Setup AVdd using VIE
				Utl.StepSupplyVoltageTo(PM.AVDD, zeroVolts, App.TC.CurrentVdd);
				App.Time.UsDelay(100);
			}

			// reset all relays
			HW.Rdc.Reset(PM.ALL_RELAYS);

			App.TC.CurrentVdd[Site.S1] = (double)zeroVolts;
			App.TC.CurrentVdd[Site.S2] = (double)zeroVolts;
			App.TC.CurrentVdd[Site.S3] = (double)zeroVolts;
			App.TC.CurrentVdd[Site.S4] = (double)zeroVolts;

			App.TC.CurrentVss[Site.S1] = (double)zeroVolts;
			App.TC.CurrentVss[Site.S2] = (double)zeroVolts;
			App.TC.CurrentVss[Site.S3] = (double)zeroVolts;
			App.TC.CurrentVss[Site.S4] = (double)zeroVolts;

			App.TC.CurrentVcc[Site.S1] = (double)zeroVolts;
			App.TC.CurrentVcc[Site.S2] = (double)zeroVolts;
			App.TC.CurrentVcc[Site.S3] = (double)zeroVolts;
			App.TC.CurrentVcc[Site.S4] = (double)zeroVolts;

			
			// Force RESET LOW and Disconnect
			HW.Dss.DriverInputSelect(PM.RESET, Dss.DriveData.FORCE_LOW);
			HW.Dss.ConnectionSet(PM.RESET, Dss.ConnectionMode.DISCONNECT);

			// Disconnect all Dig pins
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.DISCONNECT);

			//Open VI gates
			HW.Dvi.Gate(PM.DVCC, OpenClose.OPEN);
			HW.Vi.Gate(PM.AVDD, OpenClose.OPEN);
			HW.Vi.Gate(PM.AVSS, OpenClose.OPEN);




		}
		#endregion


		//
		// PowerDownDeviceForVoutLkg method
		//
		#region PowerDownDeviceForVoutLkg                  :
		/// <summary>
		/// Function to power down the DUT in Vout Lkg Test for AD5750 only
		/// </summary>

		public static void PowerDownDeviceForVoutLkg ( ) 
		{
			MsDouble zeroVolts = 0.0, lkgAVdd = 44.0;

			//TP.Console.WriteLine("Powering Down the DUT!!!");

			//Connect Digital Pins & set up logic levels
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.DISCONNECT);

			//Force 0V on Vin
			HW.Dcs.VOut(PM.VIN, zeroVolts);
			App.Time.UsDelay(100);

			//Set Vref to 0V
			HW.Dcs.VOut(PM.VREF, zeroVolts);
			App.Time.UsDelay(100);

			//Force HVS to 0V
			//HW.Upc.Gate(PM.HV_SUPPLIES, OpenClose.CLOSE, lkgAVdd/(MsDouble)4, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
			HW.Upc.Gate(PM.HV_SUPPLIES, OpenClose.CLOSE, zeroVolts, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);

			HW.Rdc.Set(PM.RLX08_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.CLOSE);
			HW.Dvi.WriteV(PM.HV_COMP_INPUT, App.TC.CompInput);
			App.Time.UsDelay(100);


			//Set DVcc to 0V
			foreach(Site site in TP.MS.SerialLoop)
			{
				if(App.TC.CurrentVcc[site] != 0.0)
				{
					HW.Dvi.WriteV(PM.DVCC, App.TC.DVcc/2.0);
					App.Time.UsDelay(100);
				}
			}
			HW.Dvi.WriteV(PM.DVCC, zeroVolts);
			App.Time.UsDelay(100);

			//Set AVss to 0v
			Utl.StepSupplyVoltageTo(PM.AVSS, zeroVolts, App.TC.CurrentVss);
			App.Time.UsDelay(100);

			App.TC.CurrentVdd = (double)zeroVolts;
			App.TC.CurrentVss = (double)zeroVolts;
			App.TC.CurrentVcc = (double)zeroVolts;

			//Setup relays correctly
			HW.Rdc.Set(PM.D3, OpenClose.OPEN);
			HW.Rdc.Set(PM.D7, OpenClose.OPEN);
			HW.Rdc.Set(PM.D6, OpenClose.OPEN);

			//Open VI gates
			HW.Dvi.Gate(PM.DVCC, OpenClose.OPEN);
			HW.Vi.Gate(PM.AVDD, OpenClose.OPEN);
			HW.Vi.Gate(PM.AVSS, OpenClose.OPEN);

		}
		#endregion

		//
		// SetDeviceMode method
		//
		#region SetDeviceMode                  :
		/// <summary>
		/// Sets HW SELECT pin depending on Software/Hardware mode
		/// </summary>
		/// <param name="operationMode"></param>
		/// 
		public static void SetDeviceMode ( App.OpMode operationMode ) 
		{
			double pullupVoltage;
			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			//If hardware mode is required, need to force HW_SELECT pin high
			//& vice versa
			if(operationMode == App.OpMode.HARDWARE)
			{
				HW.Dss.DriverInputSelect(PM.HW_SELECT, Dss.DriveData.FORCE_HIGH);
				HW.Dss.DriverInputSelect(PM.CLRSEL, Dss.DriveData.FORCE_LOW);
				HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.FORCE_LOW);
				//Pull up Fault pins
				HW.Dss.ConnectionSet(PM.HW_FAULT_PINS, Dss.ConnectionMode.OUTPUT_LOAD);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, 0.0002);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, 0.0002);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VTH, pullupVoltage);

			}
			else if(operationMode == App.OpMode.SOFTWARE)
			{
				HW.Dss.DriverInputSelect(PM.HW_SELECT, Dss.DriveData.FORCE_LOW);
				HW.Dss.DriverInputSelect(PM.CLRSEL, Dss.DriveData.FORCE_LOW);
				HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.FORCE_LOW);

				HW.Dss.DriverInputSelect(PM.SPI_PINS, Dss.DriveData.DRIVE_PATTERN);

				//Pull up Fault pins
				HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);
			}
			else
				TP.Console.WriteLine("Invalid Entry for DUT mode selection!");
		}
		#endregion

		//
		// HWOutputEn method
		//
		#region HWOutputEn                  :
		/// <summary>
		/// Sets OUTEN pin high/low depending on whether output should be enabled/disabled.
		/// </summary>
		/// <param name="outputSel"></param>
		public static void HWOutputEn ( App.OutputEn outputSel ) 
		{
			//If output enable is required, need to force SCLK_OUTEN pin high
			//& vice versa

			if(outputSel == App.OutputEn.OP_ENABLE)
			{
				HW.Dss.DriverInputSelect(PM.SCLK_OUTEN, Dss.DriveData.FORCE_HIGH);
			}
			else if(outputSel == App.OutputEn.OP_DISABLE)
			{
				HW.Dss.DriverInputSelect(PM.SCLK_OUTEN, Dss.DriveData.FORCE_LOW);
			}
			else
				TP.Console.WriteLine("Invalid Entry for output mode selection!");
		}
		#endregion

		//
		//SetAddressPins method
		//
		#region SetAddressPins					:
		/// <summary>
		/// Sets AD2, AD1, AD0 according to required address
		/// </summary>
		/// <param name="address"></param>
		/// 
		public static void SetAddressPins ( int address )
		{
			switch((int)address)
			{
				case 0:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					break;
				case 1:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
                    break;
				case 2:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					break;
				case 3:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					break;
				case 4:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					break;
				case 5:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					break;
				case 6:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					break;
				case 7:
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					break;
			}


		}
		#endregion

		//
		//SetHwRange method
		//
		#region SetHwRange					:
		/// <summary>
		/// Sets R0, R1, R2, R3 according to required range
		/// </summary>
		/// <param name="address"></param>
		/// 
		public static void SetHwRange ( App.RangeOptions range, App.ResSel rSel )
		{
			int rangeInt;

			rangeInt = App.TC.RangeData[(int)range].ProgBits;

			//Set Range Select Pin
			if(rSel == App.ResSel.R_INT)
			{
				HW.Dss.DriverInputSelect(PM.SYNC_RSEL, Dss.DriveData.FORCE_HIGH);
				//Switch in external resistor
				HW.Rdc.Set(PM.D4, OpenClose.OPEN);
			}
			else if (rSel == App.ResSel.R_EXT)
			{
				HW.Dss.DriverInputSelect(PM.SYNC_RSEL, Dss.DriveData.FORCE_LOW);
				//Switch in external resistor
				HW.Rdc.Set(PM.D4, OpenClose.CLOSE);
			}

			switch(rangeInt)
			{
				case 0:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 1:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
				case 2:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 3:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
				case 4:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 5:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
				case 6:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 7:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
				case 8:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 9:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
				case 10:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 11:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
				case 12:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 13:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_LOW);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
				case 14:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_LOW);
					break;
				case 15:
					HW.Dss.DriverInputSelect(PM.AD0_R3, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD1_R2, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.AD2_R1, Dss.DriveData.FORCE_HIGH);
					HW.Dss.DriverInputSelect(PM.SDIN_R0, Dss.DriveData.FORCE_HIGH);
					break;
			}


		}
		#endregion

		#endregion

		//
		//Various functions to interface with DUT
		//
		#region DutInterfaceFunctions
		//
		//ShortWrite Method
		//
		#region ShortWrite
		/// <summary>
		/// Modifies and executes 16 bit write to the DUT
		/// "Short" indicates 16 bit write, as opposed to the longer 24bit write
		/// </summary>
		/// <param name="address"></param>
		/// <param name="range"></param>
		/// <param name="clearMode"></param>
		/// <param name="outputEn"></param>
		/// <param name="clearEn"></param>
		/// <param name="rSel"></param>
		/// <param name="resetEn"></param>
		/// 

		public static void ShortWrite ( int address, int range, App.ClearMode clearMode, App.OutputEn outputEn, 
			App.ClearEn clearEn, App.ResSel rSel, App.SoftResetEn resetEn)
		{
			MsInt writeWord = 0;
			MsUInt64 [] writeArray = MsUInt64.CreateArray(16,0);
			int i, dataMask;

			foreach (Site site in TP.MS.ActiveSites)
			{		
				writeWord[site] = (address << 13 ) + (range << 7) + ((int)clearMode << 6) + ((int)outputEn << 5) + 
					((int)clearEn << 4) + ((int)rSel << 3) + ((int)resetEn << 2);

				for(i = 0; i < 16; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					UInt64 variable = (UInt64)((writeWord[site] & dataMask) >> i);
					writeArray[15 - i][site] = (UInt64)((writeWord[site] & dataMask) >> i);
				}
			}

			if(App.TC.Current16bitWord != writeWord)
			{
				//Modify, load and run pattern
				HW.Dss.PatSetBits(PM.SDIN_R0, DP.write_16bits, 2, 16, Dss.PatControl.DRV_DRIVE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, writeArray, null);
				App.TC.Current16bitWord = writeWord;
				HW.Dss.PatLoad(DP.write_16bits);
				App.TC.CurrentLoadedPat = DP.write_16bits;
			}
			else if(App.TC.CurrentLoadedPat != DP.write_16bits)
			{
				HW.Dss.PatLoad(DP.write_16bits);
				App.TC.CurrentLoadedPat = DP.write_16bits;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.write_16bits.Name);
			}
		}
		#endregion

		//
		//t5ShortWrite Method
		//
		#region t5ShortWrite
		/// <summary>
		/// Modifies and executes 16 bit write to the DUT
		/// "Short" indicates 16 bit write, as opposed to the longer 24bit write
		/// </summary>
		/// <param name="address"></param>
		/// <param name="range"></param>
		/// <param name="clearMode"></param>
		/// <param name="outputEn"></param>
		/// <param name="clearEn"></param>
		/// <param name="rSel"></param>
		/// <param name="resetEn"></param>
		/// 

		public static void t5ShortWrite ( int address, int range, App.ClearMode clearMode, App.OutputEn outputEn, 
			App.ClearEn clearEn, App.ResSel rSel, App.SoftResetEn resetEn)
		{
			MsInt writeWord = 0;
			MsUInt64 [] writeArray = MsUInt64.CreateArray(16,0);
			int i, dataMask;

			foreach (Site site in TP.MS.ActiveSites)
			{		
				writeWord[site] = (address << 13 ) + (range << 7) + ((int)clearMode << 6) + ((int)outputEn << 5) + 
					((int)clearEn << 4) + ((int)rSel << 3) + ((int)resetEn << 2);

				for(i = 0; i < 16; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					UInt64 variable = (UInt64)((writeWord[site] & dataMask) >> i);
					writeArray[15 - i][site] = (UInt64)((writeWord[site] & dataMask) >> i);
				}
			}

			//Modify, load and run pattern
			HW.Dss.PatSetBits(PM.SDIN_R0, DP.t5_write_16bits, 2, 16, Dss.PatControl.DRV_DRIVE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, writeArray, null);
			HW.Dss.PatLoad(DP.t5_write_16bits);
			App.TC.CurrentLoadedPat = DP.t5_write_16bits;
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.t5_write_16bits.Name);
			}
		}
		#endregion

		//
		//write24Bits - A Method
		//
		#region write24Bits
		/// <summary>
		/// Modifies and executes 24 bit write to the DUT
		/// Mostly used for testmode writes
		/// </summary>
		/// <param name="writeWord"></param>
		public static void write24Bits ( MsInt writeWord )
		{
			MsUInt64 [] writeArray = MsUInt64.CreateArray(24,0);
			int i, dataMask;

			foreach (Site site in TP.MS.ActiveSites)
			{		
				for(i = 0; i < 24; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					UInt64 variable = (UInt64)((writeWord[site] & dataMask) >> i);
					writeArray[23 - i][site] = (UInt64)((writeWord[site] & dataMask) >> i);
				}
			}

			if(App.TC.Current24bitWord != writeWord)
			{
				//Modify, load and run pattern
				HW.Dss.PatSetBits(PM.SDIN_R0, DP.write_24bits, 2, 24, Dss.PatControl.DRV_PULSE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RO, writeArray, null);
				App.TC.Current24bitWord = writeWord;
				HW.Dss.PatLoad(DP.write_24bits);
				App.TC.CurrentLoadedPat = DP.write_24bits;
			}
			else if(App.TC.CurrentLoadedPat != DP.write_24bits)
			{
				HW.Dss.PatLoad(DP.write_24bits);
				App.TC.CurrentLoadedPat = DP.write_24bits;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.write_24bits.Name);
			}
		}
		#endregion

		//
		//write24Bits - B Method
		//
		#region write24Bits
		/// <summary>
		/// Modifies and executes 24 bit write to the DUT
		/// This function also calculates PEC code to be appended to the end of the write
		/// </summary>
		/// <param name="address"></param>
		/// <param name="range"></param>
		/// <param name="clearMode"></param>
		/// <param name="outputEn"></param>
		/// <param name="clearEn"></param>
		/// <param name="rSel"></param>
		/// <param name="resetEn"></param>
		/// 

		public static void write24Bits ( int address, int range, App.ClearMode clearMode, App.OutputEn outputEn, 
			App.ClearEn clearEn, App.ResSel rSel, App.SoftResetEn resetEn)
		{
			MsInt writeWord = 0, pecWord = 0, wordWithPec = 0;
			MsUInt64 [] writeArray = MsUInt64.CreateArray(24,0);
			int i, dataMask;

			foreach (Site site in TP.MS.ActiveSites)
			{		
				writeWord[site] = (address << 13 ) + (range << 7) + ((int)clearMode << 6) + ((int)outputEn << 5) + 
					((int)clearEn << 4) + ((int)rSel << 3) + ((int)resetEn << 2);
                
				pecWord[site] = Utl.CalculatePecWord(writeWord[site]);
				wordWithPec[site] = (writeWord[site] << 8) + pecWord[site];

				for(i = 0; i < 24; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					writeArray[23 - i][site] = (UInt64)((wordWithPec[site] & dataMask) >> i);
				}
			}

			if(App.TC.Current24bitWord != writeWord)
			{
				//Modify, load and run pattern
				HW.Dss.PatSetBits(PM.SDIN_R0, DP.write_24bits, 2, 24, Dss.PatControl.DRV_DRIVE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, writeArray, null);
				App.TC.Current24bitWord = writeWord;
				HW.Dss.PatLoad(DP.write_24bits);
				App.TC.CurrentLoadedPat = DP.write_24bits;
			}
			else if(App.TC.CurrentLoadedPat != DP.write_24bits)
			{
				HW.Dss.PatLoad(DP.write_24bits);
				App.TC.CurrentLoadedPat = DP.write_24bits;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.write_24bits.Name);
			}
		}
		#endregion

		//
		//t5Write24Bits - Used for T5 Timing Char Only
		//
		#region t5Write24Bits
		/// <summary>
		/// Modifies and executes 24 bit write to the DUT
		/// This function also calculates PEC code to be appended to the end of the write
		/// </summary>
		/// <param name="address"></param>
		/// <param name="range"></param>
		/// <param name="clearMode"></param>
		/// <param name="outputEn"></param>
		/// <param name="clearEn"></param>
		/// <param name="rSel"></param>
		/// <param name="resetEn"></param>
		/// 

		public static void t5Write24Bits ( int address, int range, App.ClearMode clearMode, App.OutputEn outputEn, 
			App.ClearEn clearEn, App.ResSel rSel, App.SoftResetEn resetEn)
		{
			MsInt writeWord = 0, pecWord = 0, wordWithPec = 0;
			MsUInt64 [] writeArray = MsUInt64.CreateArray(24,0);
			int i, dataMask;

			foreach (Site site in TP.MS.ActiveSites)
			{		
				writeWord[site] = (address << 13 ) + (range << 7) + ((int)clearMode << 6) + ((int)outputEn << 5) + 
					((int)clearEn << 4) + ((int)rSel << 3) + ((int)resetEn << 2);
                
				pecWord[site] = Utl.CalculatePecWord(writeWord[site]);
				wordWithPec[site] = (writeWord[site] << 8) + pecWord[site];

				for(i = 0; i < 24; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					writeArray[23 - i][site] = (UInt64)((wordWithPec[site] & dataMask) >> i);
				}
			}

			//Modify, load and run pattern
			HW.Dss.PatSetBits(PM.SDIN_R0, DP.t5_write_24bits, 2, 24, Dss.PatControl.DRV_DRIVE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, writeArray, null);
			HW.Dss.PatLoad(DP.t5_write_24bits);
			App.TC.CurrentLoadedPat = DP.t5_write_24bits;
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.t5_write_24bits.Name);
			}
		}
		#endregion

		//
		//t7and8write24Bits - Used for setup & hold tests only.
		//
		#region t7and8write24Bits
		/// <summary>
		/// Modifies and executes 24 bit write to the DUT
		/// This function also calculates PEC code to be appended to the end of the write
		/// </summary>
		/// <param name="address"></param>
		/// <param name="range"></param>
		/// <param name="clearMode"></param>
		/// <param name="outputEn"></param>
		/// <param name="clearEn"></param>
		/// <param name="rSel"></param>
		/// <param name="resetEn"></param>
		/// 

		public static void t7and8write24Bits ( int address, int range, App.ClearMode clearMode, App.OutputEn outputEn, 
			App.ClearEn clearEn, App.ResSel rSel, App.SoftResetEn resetEn)
		{
			MsInt writeWord = 0, pecWord = 0, wordWithPec = 0;
			MsUInt64 [] writeArray = MsUInt64.CreateArray(24,0);
			int i, dataMask;

			foreach (Site site in TP.MS.ActiveSites)
			{		
				writeWord[site] = (address << 13 ) + (range << 7) + ((int)clearMode << 6) + ((int)outputEn << 5) + 
					((int)clearEn << 4) + ((int)rSel << 3) + ((int)resetEn << 2);
                
				pecWord[site] = Utl.CalculatePecWord(writeWord[site]);
				wordWithPec[site] = (writeWord[site] << 8) + pecWord[site];

				for(i = 0; i < 24; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					writeArray[23 - i][site] = (UInt64)((wordWithPec[site] & dataMask) >> i);
				}
			}

			if(App.TC.Current24bitWord != writeWord)
			{
				//Modify, load and run pattern
				HW.Dss.PatSetBits(PM.SDIN_R0, DP.write_24bits, 2, 24, Dss.PatControl.DRV_PULSE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, writeArray, null);
				App.TC.Current24bitWord = writeWord;
				HW.Dss.PatLoad(DP.write_24bits);
				App.TC.CurrentLoadedPat = DP.write_24bits;
			}
			else if(App.TC.CurrentLoadedPat != DP.write_24bits)
			{
				HW.Dss.PatLoad(DP.write_24bits);
				App.TC.CurrentLoadedPat = DP.write_24bits;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.write_24bits.Name);
			}
		}
		#endregion


		//
		//CalculatePecWord method
		//
		#region CalculatePecWord					:
		/// <summary>
		/// This function takes 16bit input word and appends 8bit checksum word to the end.
		/// Checksum is calculated using CRC-8 polynomial.
		/// </summary>
		/// <param name="inputWord"></param>
		public static int CalculatePecWord ( int inputWord )
		{
			int modifiedWord;
			int polySize = 9;
			int checksumSize = polySize - 1;
			int inputWordSize = 16;
			int pecWordSize = inputWordSize + checksumSize;
			int polyWord = 0x107;
			int i; 
			int msb;
			int xorWord;

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "PEC write:");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Initial 16bit word: {0}", inputWord);

			modifiedWord = (inputWord << checksumSize) & 0xFFFF00;

			for(i = 0; i < inputWordSize; i++)
			{
				msb = (modifiedWord >> (pecWordSize - 1 - i)) & 0x1;

				if(msb == 1)
				{
					xorWord = polyWord << (pecWordSize - polySize - i);
					modifiedWord = modifiedWord ^ xorWord;
				}
			}

			modifiedWord = modifiedWord & 0x0000FF;
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "8bit code: {0}", modifiedWord);

			return modifiedWord;
		}
		#endregion

		//
		//ReadAddr Method
		//
		#region ReadAddr
		/// <summary>
		/// Reads from address provided and returns readback word
		/// </summary>
		/// <param name="address"></param>
		/// <returns></returns>
		public static MsInt ReadAddr ( int address )
		{
			MsInt readback = 0;
			MsUInt64 [] addrArray = MsUInt64.CreateArray(3,0);
			MsUInt64 [] readArray = MsUInt64.CreateArray(11,0);
			int i, dataMask;

			//Reset timing back to slow 10Mhz for readback.
			Utl.SetInterfaceTiming(10.0e6);

			if(App.TC.CurrentReadAddr != address)
			{
				//Modify Address bits for readback
				foreach (Site site in TP.MS.ActiveSites)
				{		
					for(i = 0; i < 3; i++)
					{
						dataMask = (int)Math.Pow(2.0, (double)i);
						addrArray[2 - i][site] = (UInt64)((address & dataMask) >> i);
					}
				}
				HW.Dss.PatSetBits(PM.SDIN_R0, DP.read_data, 2, 3, Dss.PatControl.DRV_DRIVE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, addrArray, null);
				App.TC.CurrentReadAddr = address;
				//Load and Run pattern
				HW.Dss.PatLoad(DP.read_data);
				App.TC.CurrentLoadedPat = DP.read_data;
			}
			else if(App.TC.CurrentLoadedPat != DP.read_data)
			{
				//Load and Run pattern
				HW.Dss.PatLoad(DP.read_data);
				App.TC.CurrentLoadedPat = DP.read_data;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDO_VFAULT,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.read_data.Name);
			}
			App.Time.MsDelay(1);


			readArray = HW.Dss.CapRead(PM.SDO_VFAULT,11,0,Dss.CapReadFormat.DATA);

			foreach (Site site in TP.MS.ActiveSites)
			{			
				for(i = 0; i < 11; i++)
				{
					readback[site] += ( ((int)readArray[i][site]) * (int)Math.Pow(2,(Double)(10-i)));
				}
			}

			//Cleanup
			Utl.SetInterfaceTiming(App.TC.Frequency);

			return readback;
		}
		#endregion

		//
		//t11ReadAddr Method
		//
		#region t11ReadAddr
		/// <summary>
		/// Reads from address provided and returns readback word
		/// </summary>
		/// <param name="address"></param>
		/// <returns></returns>
		public static MsInt t11ReadAddr ( )
		{
			MsInt readback = 0;
			MsUInt64 [] readArray = MsUInt64.CreateArray(11,0);
			int i;

			if(App.TC.CurrentLoadedPat != DP.t11_read_data)
			{
				//Load and Run pattern
				HW.Dss.PatLoad(DP.t11_read_data);
				App.TC.CurrentLoadedPat = DP.t11_read_data;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDO_VFAULT,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.t11_read_data.Name);
			}
			App.Time.MsDelay(1);


			readArray = HW.Dss.CapRead(PM.SDO_VFAULT,11,0,Dss.CapReadFormat.DATA);

			foreach (Site site in TP.MS.ActiveSites)
			{			
				for(i = 0; i < 11; i++)
				{
					readback[site] += ( ((int)readArray[i][site]) * (int)Math.Pow(2,(Double)(10-i)));
				}
			}

			return readback;
		}
		#endregion

		//
		//BlowFuseMem method
		//
		#region BlowFuseMem  				:
		/// <summary>
		/// Assembles blow fuse word based on parameters passed in. "blow_fuse" pattern is then modified,loaded and run.
		/// </summary>
		/// <param name="rSel"></param>
		/// <param name="range"></param>
		/// <param name="block"></param>
		public static void BlowFuseMem ( App.ResSel rSel, App.RangeOptions range, App.BlowBlockBits block, MsInt trimCode)
		{
			MsInt blowWord = 0;
			int i, dataMask;
			MsUInt64 [] writeArray = MsUInt64.CreateArray(24,0);

			//**Should be in test mode when running this function!!**
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

			blowWord = ((int)App.TestModes.TM_BLOW_FUSE << 20) + ((int)rSel << 19) + 
				(App.TC.RangeData[(int)range].ProgBits << 15) + ((int)block << 13) + trimCode;

			foreach( Site site in TP.MS.ActiveSites)
			{
				for(i = 0; i < 24; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					writeArray[23 - i][site] = (UInt64)((blowWord[site] & dataMask) >> i);
				}
			}

			//Release Clear Pin so that it can be pulsed during pattern run
			HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.DRIVE_PATTERN);

			if(App.TC.CurrentBlowWord != blowWord)
			{
				//Modify, load and run pattern
				HW.Dss.PatSetBits(PM.SDIN_R0, DP.blow_fuse, 2, 24, Dss.PatControl.DRV_DRIVE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, writeArray, null);
				App.TC.CurrentBlowWord = blowWord;
				HW.Dss.PatLoad(DP.blow_fuse);
				App.TC.CurrentLoadedPat = DP.blow_fuse;
			}
			else if(App.TC.CurrentLoadedPat != DP.blow_fuse)
			{
				HW.Dss.PatLoad(DP.blow_fuse);
				App.TC.CurrentLoadedPat = DP.blow_fuse;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.blow_fuse.Name);
			}

			//Cleanup
			HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.FORCE_LOW);
		}
		#endregion

		//
		//BlowMasterFuse method
		//
		#region BlowMasterFuse  				:
		/// <summary>
		/// Assembles blow fuse word based on parameters passed in. "blow_fuse" pattern is then modified,loaded and run.
		/// </summary>
		/// <param name="rSel"></param>
		/// <param name="range"></param>
		/// <param name="block"></param>
		public static void BlowMasterFuse ( )
		{
			App.RangeOptions range = App.RangeOptions.FIVE_V;

			//Enter Test Mode 
			Utl.EnterTM();
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			//Release Clear Pin so that it can be pulsed during pattern run
			HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.DRIVE_PATTERN);

			//Increase DVcc to blow voltage level
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
			App.Time.MsDelay(10);

			if(App.TC.CurrentLoadedPat != DP.blowMasterFuse)
			{
				HW.Dss.PatLoad(DP.blowMasterFuse);
				App.TC.CurrentLoadedPat = DP.blowMasterFuse;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDIN_R0,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.blow_fuse.Name);
			}

			//Cleanup
			HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.FORCE_LOW);
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);
		}
		#endregion

		//
		//ReadFuseMem method
		//
		#region ReadFuseMem  				:
		/// <summary>
		/// Assembles fuse addressing word based on parameters passed in. "read_fuse" pattern is then modified,loaded and run.
		/// Readback word is returned as an MsInt
		/// </summary>
		/// <param name="rSel"></param>
		/// <param name="range"></param>
		/// <param name="block"></param>
		public static MsInt ReadFuseMem ( App.ResSel rSel, App.RangeOptions range, App.BlockBits block)
		{
			int addressWord = 0;
			MsInt readback = 0;
			int i, dataMask;
			MsUInt64 [] readArray = MsUInt64.CreateArray(13,0);
			MsUInt64 [] addrArray = MsUInt64.CreateArray(11,0);
			double fuseReadbackFreq = 10.0e6;

			//Enter Test Mode 
			Utl.EnterTM();
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

			addressWord = ((int)App.TestModes.TM_FUSE_READ << 7) + ((int)rSel << 6) + (App.TC.RangeData[(int)range].ProgBits << 2) + (int)block;

			//Modify Address bits for readback
			foreach (Site site in TP.MS.ActiveSites)
			{		
				for(i = 0; i < 11; i++)
				{
					dataMask = (int)Math.Pow(2.0, (double)i);
					addrArray[10 - i][site] = (UInt64)((addressWord & dataMask) >> i);
				}
			}

			//Reduce interface speed to correctly readback the fuses
			Utl.SetInterfaceTiming(fuseReadbackFreq);

			if((App.TC.CurrentFuseReadWord != addressWord) || (App.TC.CurrentActiveSites != TP.MS.ActiveSites))
			{
				HW.Dss.PatSetBits(PM.SDIN_R0, DP.read_fuse, 2, 11, Dss.PatControl.DRV_DRIVE|Dss.PatControl.CAP_DISABLE, Dss.PatDriveFormat.RZ, addrArray, null);
				App.TC.CurrentFuseReadWord = addressWord;

				//Load and Run pattern
				HW.Dss.PatLoad(DP.read_fuse);
				App.TC.CurrentLoadedPat = DP.read_fuse;
				App.TC.CurrentActiveSites = TP.MS.ActiveSites;
			}
			else if(App.TC.CurrentLoadedPat != DP.read_fuse)
			{
				HW.Dss.PatLoad(DP.read_fuse);
				App.TC.CurrentLoadedPat = DP.read_fuse;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			if(HW.Dss.PatWaitEnd(PM.SDO_VFAULT,0,1,1000)!= (MsBool)false)
			{
				TP.Console.Warn("The pattern {0} never stopped.", DP.read_fuse.Name);
			}

			readArray = HW.Dss.CapRead(PM.SDO_VFAULT,13,0,Dss.CapReadFormat.DATA);

			foreach (Site site in TP.MS.ActiveSites)
			{			
				for(i = 0; i < 13; i++)
				{
					readback[site] += ( ((int)readArray[i][site]) * (int)Math.Pow(2,(Double)(12-i)));
				}
			}

			//Cleanup
			Utl.SetInterfaceTiming(App.TC.Frequency);

			return readback;
		}
		#endregion

		//
		//HwClearMode method
		//
		#region HwClearMode					:
		/// <summary>
		/// Forces CLRSEL pin high for CLR_TO_MID, 
		/// Forces CLRSEL pin low for CLR_TO_ZERO
		/// </summary>
		/// <param name="clearMode"></param>
		public static void HwClearMode ( App.ClearMode clearMode)
		{
			if(clearMode == App.ClearMode.CLR_TO_ZERO)
			{
				HW.Dss.DriverInputSelect(PM.CLRSEL, Dss.DriveData.FORCE_LOW);
			}
			else if(clearMode == App.ClearMode.CLR_TO_MID)
			{
				HW.Dss.DriverInputSelect(PM.CLRSEL, Dss.DriveData.FORCE_HIGH);
			}
			else
			{
				TP.Console.WriteLine("Invalid Option for HwClearMode");
			}
		}
		#endregion

		//
		//HwClearEn method
		//
		#region HwClearEn  				:
		/// <summary>
		/// Forces CLEAR pin high for CLEAR, 
		/// Forces CLEAR pin low for NO_CLEAR
		/// </summary>
		/// <param name="clearEn"></param>
		/// 
		public static void HwClearEn ( App.ClearEn clearEn)
		{
			if(clearEn == App.ClearEn.NO_CLEAR)
			{
				HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.FORCE_LOW);
			}
			else if(clearEn == App.ClearEn.CLEAR)
			{
				HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.FORCE_HIGH);
			}
			else
			{
				TP.Console.WriteLine("Invalid Option for HwClearEn");
			}
		}
		#endregion

		//
		//EnterTM method
		//
		#region EnterTM  				:
		/// <summary>
		/// Function runs correct sequence to enter test mode
		/// </summary>

		public static void EnterTM ( )
		{
			int tmEntryWord = 0xF5CB31;
			int tmAddress = 0x7;

			SetAddressPins(tmAddress);
			Utl.write24Bits(tmEntryWord);
			App.Time.UsDelay(20);

			SetAddressPins(App.TC.DutAddress);
		}
		#endregion

		//
		//ExitTM method
		//
		#region ExitTM  				:
		/// <summary>
		/// Function runs correct sequence to exit test mode
		/// </summary>

		public static void ExitTM ( )
		{
			int tmEntryWord = 0xF5CB31;
			int tmAddress = 0x0;

			SetAddressPins(tmAddress);
			Utl.write24Bits(tmEntryWord);
			App.Time.UsDelay(20);
	
		}
		#endregion

		//
		//TmWrite method
		//
		#region TmWrite  				:
		/// <summary>
		/// Function takes all test mode variables and constructs 24bit word.
		/// 24bit write pattern is modified with this word and executed
		/// </summary>
		/// <param name="mode"></param>
		/// <param name="range"></param>
		/// <param name="rSel"></param>
		/// <param name="block"></param>
		/// <param name="data"></param>
		public static void TmWrite ( App.TestModes mode, int range, App.ResSel rSel, int block, MsInt data)
		{
			MsInt writeWord = 0;
			foreach(Site site in TP.MS.ActiveSites)
			{
				writeWord[site] = ((int)mode << 20) + ((int)rSel << 19) + (range << 15) + (block << 13) + data[site];
			}
			write24Bits(writeWord);
			App.Time.UsDelay(20);
		}
		#endregion
		#endregion

		//
		//RunPattern method
		//
		#region RunPattern  				:
		/// <summary>
		/// Loads & Runs requested pattern
		/// </summary>

		public static void RunPattern ( TestPattern patToRun)
		{
			MsBool status = true;

			if(App.TC.CurrentLoadedPat != patToRun)
			{
				HW.Dss.PatLoad(patToRun);
				App.TC.CurrentLoadedPat = patToRun;
			}
			HW.Dss.SeqRun();
			//Wait for pattern to stop.
			while (status == (MsBool)true)
			{
				status = HW.Dss.PatStatus(PM.DIG_PINS,Dss.Status.RUNNING);
			}
	
		}
		#endregion

		//
		//TestVout method
		//
		#region TestVout  				:
		/// <summary>
		/// This function measures Vout on either DMM or DIG and checks Vs an expected voltage
		/// </summary>
		/// <param name="expectedVoltage"></param>
		/// <param name="resourceSelect"></param>
		/// <returns></returns>
		public static MsInt TestVout ( double expectedVoltage, App.MeasOptions resourceSelect )
		{
			MsInt passFail = 0;
			double limitMargin = 0.030;
			MsDouble voutMeas;

			if((expectedVoltage == 0.0) && (App.Globals.GenericType == App.GenericType.LV_GEN))
				limitMargin = 20.0e-3;
			else if((expectedVoltage == 0.0) && (App.Globals.GenericType == App.GenericType.HV_GEN))
				limitMargin = 50.0e-3;
			else
                limitMargin = Math.Abs(expectedVoltage * 0.01);

			voutMeas = VoutMeas(expectedVoltage, resourceSelect);

			if(App.Globals.OfflineDev)
			{
				voutMeas = expectedVoltage;
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				if((voutMeas[site] > (expectedVoltage + limitMargin)) || (voutMeas[site] < (expectedVoltage - limitMargin)))
				{
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "FAIL: Vout voltage: {0}", voutMeas[site]);
					passFail[site]++;
				}
				else
				{
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "PASS: Vout voltage: {0}", voutMeas[site]);
				}
			}

			return passFail;
		}
		#endregion

		//
		//TestIout method
		//
		#region TestIout  				: 
		/// <summary>
		/// This function measures Iout (on either DMM or DIG) and checks Vs an expected current
		/// </summary>
		/// <param name="expectedCurrent"></param>
		/// <param name="resourseSelect"></param>
		/// <returns></returns>
		public static MsInt TestIout ( double expectedCurrent, App.MeasOptions resourseSelect )
		{
			MsInt passFail = 0;
			double limitMargin = 0.005;
			MsDouble ioutMeas;

			if(expectedCurrent == 0)
				limitMargin = 48.0e-6;
			else
				limitMargin = Math.Abs(expectedCurrent * 0.04);

			ioutMeas = Utl.IoutMeas(resourseSelect);

			if(App.Globals.OfflineDev)
			{
				ioutMeas = expectedCurrent;
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				if((ioutMeas[site] > (expectedCurrent + limitMargin)) || (ioutMeas[site] < (expectedCurrent - limitMargin)))
				{
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "FAIL: Iout current: {0}", ioutMeas[site]);
					passFail++;
				}
				else
				{
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "PASS: Iout current: {0}", ioutMeas[site]);
				}
			}

			return passFail;
		}
		#endregion

		//
		//TestOutput method
		//
		#region TestOutput  				:
		/// <summary>
		/// This function measures selected output on either DMM or DIG and checks Vs an expected output
		/// </summary>
		/// <param name="range"></param>
		/// <param name="expectedOutput"></param>
		/// <param name="resourceSelect"></param>
		/// <returns></returns>
		public static MsInt TestOutput ( App.RangeOptions range, double expectedOutput, App.MeasOptions resourceSelect )
		{
			MsInt passFail = 0;
			double limitMargin = 0.005;
			MsDouble output = 0.0;

			//Set limit margin to 1% of fullscale range of selected range
			if((range == App.RangeOptions.THREE_TWENTY_MA) || 
				(range == App.RangeOptions.TWENTY_P_FOUR_MA) || 
				(range == App.RangeOptions.TWENTY_FOUR_P_FIVE_MA) ||
				(range == App.RangeOptions.SIX_V) ||
				(range == App.RangeOptions.SIX_V_BIP) ||
				(range == App.RangeOptions.TWELVE_V) ||
				(range == App.RangeOptions.TWELVE_V_BIP) )
			{
				limitMargin = (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue) * 0.1;
			}
			else
				limitMargin = (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue) * 0.01;

															  

			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				output = Utl.VoutMeas(expectedOutput, resourceSelect);
			}
			else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
			{
				output = Utl.IoutMeas(resourceSelect);
			}


			if(App.Globals.OfflineDev)
			{
				output = expectedOutput;
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				if((output[site] > (expectedOutput + limitMargin)) || (output[site] < (expectedOutput - limitMargin)))
				{
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "FAIL: Output: {0}", output[site]);
					passFail++;
				}
				else
				{
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "PASS: Output: {0}", output[site]);
				}
			}

			return passFail;
		}
		#endregion

		//
		//IoutMeas method
		//
		#region IoutMeas  				:
		/// <summary>
		/// Measures voltage on IoutMeas node (top of 300ohm resistor) using either DMM or DIG
		/// </summary>
		/// <param name="resourceSelect"></param>
		/// <returns></returns>
		public static MsDouble IoutMeas ( App.MeasOptions resourceSelect )
		{
			MsDouble resLoad = App.TC.BoardVars.IoutLowRes;
			MsDouble ioutMeas = 0.0;
			MsDouble vMeas = 0.0;

			MsDouble i_meas_neg = 0.0;
			MsDouble [] iMeas_array = MsDouble.CreateArray(64, 0);

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{

				vMeas = Utl.MeasureNode(App.MuxNodes.IOUT_MEAS, resourceSelect);

				//Measured voltage is expressed as current
				foreach(Site site in TP.MS.ActiveSites)
				{
					ioutMeas[site] = vMeas[site]/resLoad[site];
				}
			}
			else
			{

				HW.Dss.ConnectionSet(PM.IOUT_PINCARD, Dss.ConnectionMode.PMU_TO_PIN);

				if(App.Globals.Pincard100mA)
				{
					HW.Dss.PmuConnectMode(PM.IOUT_PINCARD, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_100_MA);
					HW.Dss.PmuModeValue(PM.IOUT_PINCARD, Dss.PmuMode.FVMI_100_MA, 0);
				}

				
				else if(App.Globals.Pincard2mA)
				{
					HW.Dss.PmuConnectMode(PM.IOUT_PINCARD, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_2_MA);
					HW.Dss.PmuModeValue(PM.IOUT_PINCARD, Dss.PmuMode.FVMI_2_MA, 0);
				}
				else
				{
					HW.Dss.PmuConnectMode(PM.IOUT_PINCARD, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_200_UA);
					HW.Dss.PmuModeValue(PM.IOUT_PINCARD, Dss.PmuMode.FVMI_200_UA, 0);
				}
				

				App.Time.MsDelay(App.TC.Pmu_read_delay);

				int num_avg = 20;
				i_meas_neg = HW.Dss.PmuRead(PM.IOUT_PINCARD, num_avg);
				ioutMeas = (-1)*i_meas_neg;
			}
			
			return ioutMeas;
		}
		#endregion

		//
		//VoutMeas method
		//
		#region VoutMeas  				:
		/// <summary>
		/// Function to measure Vout. Depending on expected voltage, the scale circuit may be used.
		/// DMM or digitiser option also available.
		/// </summary>
		/// <param name="expVoltage"></param>
		/// <param name="resourceSelect"></param>
		/// <returns></returns>
		public static MsDouble VoutMeas ( double expVoltage, App.MeasOptions resourceSelect )
		{
			MsDouble scalar, vMeas, voutMeas = 0.0;


			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				App.MuxNodes muxNode;
			
				if(Math.Abs(expVoltage) > 14.0)
				{
					//Need to ensure that no external relay is in place.
					//Scale down circuit is equivalent to 5k load
					HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

					HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.CLOSE);
					HW.Rdc.Set(PM.RLX19_RELAYS, OpenClose.CLOSE);
					HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.OPEN);
					muxNode = App.MuxNodes.VOUT_SCALE_MEAS;
					scalar = App.TC.BoardVars.VoutScaleHighGain;
				}
				else if((Math.Abs(expVoltage) < 15.0) && (Math.Abs(expVoltage) > 11.0))
				{
					//Need to ensure that no external relay is in place.
					//Scale down circuit is equivalent to 1k load
					HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

					HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.CLOSE);
					HW.Rdc.Set(PM.RLX19_RELAYS, OpenClose.CLOSE);
					HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.CLOSE);
					muxNode = App.MuxNodes.VOUT_SCALE_MEAS;
					scalar = App.TC.BoardVars.VoutScaleLowGain;
				}
				else
				{
					//use regular voltage measure
					HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);
					//RLY18 should always be open when measuring lower voltage ranges
					//1kohm load required for lower ranges. 
					HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.OPEN);
					muxNode = App.MuxNodes.VOUT_MEAS;
					scalar = 1;
				}

				App.Time.MsDelay(App.TC.RelaySettle);

				vMeas = Utl.MeasureNode(muxNode, resourceSelect);

				//Measured voltage is expressed as current
				foreach(Site site in TP.MS.ActiveSites)
				{
					voutMeas[site] = vMeas[site] / scalar[site];
				}

				//Cleanup
				HW.Rdc.Set(PM.RLX19_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX20_RELAYS, OpenClose.OPEN);
			}
			
			else
			{
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FIMV_2_MA);
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FIMV_2_MA, 0);

				App.Time.MsDelay(App.TC.Pmu_read_delay);

				//App.Globals.NumPmuAverages
				voutMeas = HW.Dss.PmuRead(PM.VOUT, 10);
			}

			return voutMeas;
	
		}
		#endregion

		//
		//MeasureRangeGainError method
		//
		#region MeasureRangeGainError  				:
		/// <summary>
		/// Function calculates a Gain Error figure for the given range (based on 1Q and 3Q inputs) 
		/// Outputs measured on either digitiser or DMM.
		/// </summary>
		/// <param name="range"></param>
		/// <param name="resourceSelect"></param>
		/// <returns></returns>
		public static MsDouble MeasureRangeGainError ( App.RangeOptions range, App.MeasOptions resourceSelect )
		{
			double vinO1 = App.TC.MaxInputVoltage / 8.0,
                vinO7 = 7*vinO1;
			MsDouble outputO1 = 0.0, 
				outputO7 = 0.0;
			MsDouble gainError = 0, 
				gain = 0;
			double idealOutputO1, idealOutputO7, idealGain, expectedOutput;
			double [] outputO1Array = new double[1000];
			double [] outputO7Array = new double[1000];
			double [] gainArray = new double[1000];
			double [] gainErrorArray = new double[1000];

			idealOutputO1 = App.TC.RangeData[(int)range].MinValue + ((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/8.0);
			idealOutputO7 = App.TC.RangeData[(int)range].MinValue + 7.0*((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/8.0);
			idealGain = (idealOutputO7 - idealOutputO1)/(vinO7 - vinO1);

			//Set Input Voltage to 0.512V and measure corresponding Vout
			HW.Dcs.VOut(PM.VIN, vinO1);
			App.Time.MsDelay(App.TC.OutputSettle);

			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				expectedOutput = idealOutputO1;
				if(range == App.RangeOptions.FORTY_V)
					expectedOutput = 40.0;
				outputO1 = Utl.VoutMeas(expectedOutput, resourceSelect);
			}
			else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
			{
				outputO1 = Utl.IoutMeas(resourceSelect);
			}

			//Set Input Voltage to 3.584V and measure corresponding Iout current
			HW.Dcs.VOut(PM.VIN, vinO7);
			App.Time.MsDelay(App.TC.OutputSettle);
			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				expectedOutput = idealOutputO7;
				if(range == App.RangeOptions.FORTY_V)
					expectedOutput = 40.0;
				outputO7 = Utl.VoutMeas(expectedOutput, resourceSelect);
			}
			else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
			{
				outputO7 = Utl.IoutMeas(resourceSelect);
			}

			HW.Dcs.VOut(PM.VIN, 0.0);

			foreach(Site site in TP.MS.ActiveSites)
			{
				gain[site] = (outputO7[site] - outputO1[site]) / (vinO7 - vinO1);
				gainError[site] = ((gain[site] - idealGain) / idealGain) * 100;
			}

			return gainError;
	
		}
		#endregion

		//
		//MeasureRangeOffsetError method
		//
		#region MeasureRangeOffsetError  				:
		/// <summary>
		/// Function calculates an Offset Error figure for the given range (based on input vin)
		/// Measured on either DMM or DIG
		/// </summary>
		/// <param name="range"></param>
		/// 

		public static MsDouble MeasureRangeOffsetError ( App.RangeOptions range, double vin, App.MeasOptions resourceSelect )
		{
			MsDouble offsetError = 0,
				output1 = 0;
			double targetValue;

			targetValue = (vin/App.TC.MaxInputVoltage) * (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue);

			HW.Dcs.VOut(PM.VIN, vin);
			App.Time.MsDelay(App.TC.OutputSettle);

			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				output1 = Utl.VoutMeas((targetValue + App.TC.RangeData[(int)range].MinValue), resourceSelect);
			}
			else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
			{
				output1 = Utl.IoutMeas(resourceSelect);
			}

			HW.Dcs.VOut(PM.VIN, 0.0);

			foreach(Site site in TP.MS.ActiveSites)
			{
				offsetError[site] = output1[site] - (targetValue + App.TC.RangeData[(int)range].MinValue);
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Offset Error: {0}", offsetError[site]);
			}

			return offsetError;
		}
		#endregion

		//
		//MeasureOutput method
		//
		#region MeasureOutput  				:
		/// <summary>
		/// Function measures either Iout/Vout (on DMM or DIG) depending on selected range
		/// </summary>
		/// <param name="range"></param>
		/// <param name="expectedOutput"></param>
		/// <param name="resourceSelect"></param>
		/// <returns></returns>
		public static MsDouble MeasureOutput ( App.RangeOptions range, double expectedOutput, App.MeasOptions resourceSelect )
		{
			MsDouble output = 0.0;

			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				output = Utl.VoutMeas(expectedOutput, resourceSelect);
			}
			else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
			{
				output = Utl.IoutMeas(resourceSelect);
			}

			return output;
	
		}
		#endregion

		//
		//FineTuneGainError method
		//
		#region FineTuneGainError  				:
		/// <summary>
		/// Function takes calculated gain trim code and fine tunes to find ideal trim code to reach ideal gain error target
		/// </summary>
		/// <param name="gainTrimCode"></param>
		/// <param name="fsCode"></param>
		/// <param name="idealGainError"></param>
		/// <param name="range"></param>
		/// <param name="rSel"></param>
		/// <returns></returns>
		public static MsInt FineTuneGainError ( MsInt gainTrimCode, int fsCode, double idealGainError, App.RangeOptions range, App.ResSel rSel)
		{
			MsDouble gainError = 0;
			int count = 0; 
			int maxLoops = 5;
			App.MeasOptions resourceSelect = App.MeasOptions.DMM;

			gainError = Utl.MeasureRangeGainError(range, resourceSelect);

			foreach(Site site in TP.MS.ActiveSites)
			{
				count = 0;

				if((Math.Abs(gainError[site]) > idealGainError))
				{
					while((Math.Abs(gainError[site]) > idealGainError) && (count < maxLoops))
					{
						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "New gain error: {0}", gainError[site]);

						if(gainError[site] > 0.0)
							gainTrimCode[site]--;
						else
							gainTrimCode[site]++;

						if(gainTrimCode[site] > fsCode)
							gainTrimCode[site] = fsCode;
						else if(gainTrimCode[site] < 0)
							gainTrimCode[site] = 0;

						Utl.TmWrite(App.TestModes.TM_GAIN_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, gainTrimCode);
						//Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.IbiasTrimCode[site]);
						//Utl.TmWrite(App.TestModes.TM_TC_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.TcTrimCode);

						gainError = Utl.MeasureRangeGainError(range, resourceSelect);
						count++;
					}
				}
			}

			return gainTrimCode;
		}
		#endregion

		//
		//FineTuneOffsetError method
		//
		#region FineTuneOffsetError  				:
		/// <summary>
		/// Function takes calculated offset trim code and fine tunes to find ideal trim code to reach ideal offset error target
		/// </summary>
		/// <param name="offsetTrimCode"></param>
		/// <param name="vin"></param>
		/// <param name="targetValue"></param>
		/// <param name="idealOffsetError"></param>
		/// <param name="range"></param>
		/// <param name="rSel"></param>
		/// <returns></returns>
		public static MsInt FineTuneOffsetError ( MsInt offsetTrimCode, double vin, double targetValue, double idealOffsetError, App.RangeOptions range, App.ResSel rSel)
		{
			MsDouble offsetError = 0.0;
			int count = 0;
			MsDouble output1 = 0.0;
			App.MeasOptions resourceSelect = App.MeasOptions.DMM;

			offsetError = Utl.MeasureRangeOffsetError( range, vin, resourceSelect);

			foreach(Site site in TP.MS.ActiveSites)
			{
				count = 0;
				if((Math.Abs(offsetError[site]) > idealOffsetError))
				{
					while((Math.Abs(offsetError[site]) > idealOffsetError) && (count < 10))
					{
						if((range == App.RangeOptions.TWENTY_MA_BIP) || (range == App.RangeOptions.TWENTY_FOUR_MA_BIP))
						{
							if((offsetError[site] > 0) && (offsetTrimCode[site] < 8192))
								offsetTrimCode[site]++;
							else if((offsetError[site] < 0) && (offsetTrimCode[site] > 0))
								offsetTrimCode[site]--;
						}
						else
						{
							if((offsetError[site] > 0) && (offsetTrimCode[site] > 0))
								offsetTrimCode[site]--;
							else if((offsetError[site] < 0) && (offsetTrimCode[site] < 8192))
								offsetTrimCode[site]++;
						}

						Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetTrimCode);
						//Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.IbiasTrimCode[site]);
						//Utl.TmWrite(App.TestModes.TM_TC_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.TcTrimCode);
						
						offsetError = Utl.MeasureRangeOffsetError( range, vin, resourceSelect);
						count++;
					}
				}
			}

			return offsetTrimCode;
	
		}
		#endregion

		//
		//Pinchecker Functions
		//
		#region PincheckFunctions

		//
		//MeasPinVoltage method
		//
		#region MeasPinVoltage  				:
		/// <summary>
		/// Pincheck function to measure voltage on selected pin for given test
		/// </summary>
		/// <param name="testName"></param>
		public static void MeasPinVoltage ( string testName )
		{
			App.TC.PincheckCount++;

			App.TC.PincheckMeas[App.TC.PincheckCount] = HW.Dvi.ReadV(PM.V_PINCHECK);
			App.TC.TestName[App.TC.PincheckCount] = testName;
		}
		#endregion


		//
		//WritePincheckFile method
		//
		#region WritePincheckFile  				:
		/// <summary>
		/// Writes all pincheck/testname data to a file 
		/// </summary>
		/// <param name="testName"></param>
		public static void WritePincheckFile ( )
		{
			string pinName = PM.EVERY_PIN[App.TC.PinCount].Name;
			App.TC.PinCount++;

			String fileName = @String.Format("{0}_pincheck_data.txt", pinName);

			using (System.IO.StreamWriter dataFileOut = 
					   new System.IO.StreamWriter(fileName))
			{
				dataFileOut.WriteLine("Pincheck data for {0} pin", pinName);
				for (int i=0; i < App.TC.NumPinChecks; i++)
				{
					dataFileOut.WriteLine("Test: {0},		Vmeas: {1}", App.TC.TestName[i], App.TC.PincheckMeas[i]);
				}
			}

			App.TC.PincheckCount = 0;

			//close file???
		}
		#endregion

		#endregion

		//
		//WriteFile method
		//
		#region WriteFile  				:
		/// <summary>
		/// Writes data from a given array to a file 
		/// </summary>
		/// <param name="testName"></param>
		public static void WriteFile ( double [] data, int numDataBits, String fileName )
		{
			using (System.IO.StreamWriter dataFileOut = 
					   new System.IO.StreamWriter(fileName))
			{
				for (int i=0; i < numDataBits; i++)
				{
					dataFileOut.WriteLine("Result: {0}", data[i]);
				}
			}
		}
		#endregion

		//
		//SetDigitalLevels method
		//
		#region SetDigitalLevels  				:
		/// <summary>
		/// Sets digital levels on digital pins according to option chosen.
		/// </summary>
		/// <param name="levelSelect"></param>
		public static void SetDigitalLevels ( App.DigLevelsOpts levelSelect)
		{
			double vih = App.TC.DVcc*0.9,
				vil = App.TC.DVcc*0.1,
				voh = App.TC.DVcc - 0.4,
				vol = 0.4,
				loadCurrent = 200.0e-6,
				vth = (voh - vol)/2.0;


			switch(levelSelect)
			{
				case App.DigLevelsOpts.DEFAULT:
					vih = App.TC.Vih;
					vil = App.TC.Vil;
					voh = App.TC.Voh;
					vol = App.TC.Vol;
					break;
				case App.DigLevelsOpts.JEDEC:
					vih = 2.0;
					vil = 0.8;
					voh = App.TC.DVcc - 0.4;
					vol = 0.4;
					break;
				case App.DigLevelsOpts.TIMING:
					vih = App.TC.DVcc*0.9;
					vil = App.TC.DVcc*0.1;
					voh = App.TC.DVcc - 0.4;
					vol = 0.4;
					loadCurrent = 200.0e-6;
					vth = (voh - vol)/2.0;
					break;
				default:
					TP.Console.WriteLine("Invalid selection for digital levels!");
					break;
			}

			//Set logic levels, active load on all digital pins
			HW.Dss.DriverInputSelect(PM.SPI_PINS, Dss.DriveData.DRIVE_PATTERN);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, vih);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, vil);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, voh);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, vol);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VTH, vth);
			HW.Dss.ControlValue(PM.SDO_VFAULT, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.SDO_VFAULT, Dss.Control.IOL, loadCurrent);
			
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.OUTPUT);
			if(levelSelect == App.DigLevelsOpts.TIMING)
                HW.Dss.ConnectionSet(PM.SDO_VFAULT, Dss.ConnectionMode.OUTPUT_LOAD);

		}
		#endregion

		//
		//SetLVTestConditions method
		//
		#region SetLVTestConditions  				:
		/// <summary>
		/// Sets supply voltage variables dependant on current test cycle
		/// </summary>
		public static void SetLVTestConditions ( )
		{
			double dvccClamp, posAvddClamp, negAvddClamp, negAvssClamp, posAvssClamp;
			string waferNum;

			switch(TP.Part.CurrentTestCycle)
			{
				case 1:
					//At start of cycle, ask for wafer number
					TP.Console.AskUser("Please Enter Wafer Number: ", "0", out waferNum);

					if(waferNum == "1")
						App.TC.WaferNum = 1;
					else if (waferNum == "3")
						App.TC.WaferNum = 3;
					else if(waferNum == "6")
						App.TC.WaferNum = 6;
					else if(waferNum == "10")
						App.TC.WaferNum = 10;
					else
						TP.Console.AskConfirm("Invalid Wafer Number");

					App.TC.AVdd.Value = App.Globals.CharLVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharLVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					if (App.Globals.TemptronicsEnable)
					{
						TX.TemptronicThermoStream.HeadDown();
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 2:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharLVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					break;
				case 3:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharLVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					break;
				case 4:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharLVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					break;
				case 5:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharLVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 6:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharLVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					break;
				case 7:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharLVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					break;
				case 8:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharLVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					break;
				case 9:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharLVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 10:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharLVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					break;
				case 11:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharLVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					break;
				case 12:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharLVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					break;
				case 13:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharLVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 14:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharLVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					break;
				case 15:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharLVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					break;
				case 16:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharLVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					break;
				case 17:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharLVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 18:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharLVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					break;
				case 19:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharLVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					break;
				case 20:
					App.TC.AVdd.Value = App.Globals.CharLVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharLVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					break;
				default:
					TP.Console.WriteLine("No conditions option for current test cycle!");
					break;
			}
			App.TC.Vih.Value = App.TC.DVcc;
			App.TC.Vil.Value = 0.0;
			App.TC.Voh.Value = App.TC.DVcc - 0.4;
			App.TC.Vol.Value = 0.4;

			dvccClamp = App.TC.DVcc + 0.1*App.TC.DVcc;
			posAvddClamp = App.TC.AVdd + 0.2*App.TC.AVdd;
			negAvddClamp = -0.1;
			negAvssClamp = App.TC.AVss + 0.2*App.TC.AVss;
			posAvssClamp = 0.1;

			HW.Dvi.VClamp(PM.DVCC, dvccClamp);
			HW.Vi.VClamp(PM.AVDD, posAvddClamp, negAvddClamp);
			HW.Vi.VClamp(PM.AVSS, posAvssClamp, negAvssClamp);
		}
		#endregion

		//
		//SetHVTestConditions method
		//
		#region SetHVTestConditions  				:
		/// <summary>
		/// Sets supply voltage variables dependant on current test cycle
		/// </summary>
		public static void SetHVTestConditions ( )
		{
			double dvccClamp, posAvddClamp, negAvddClamp, negAvssClamp, posAvssClamp;
			string waferNum;

			switch(TP.Part.CurrentTestCycle)
			{
				case 1:
					//At start of cycle, ask for wafer number
					TP.Console.AskUser("Please Enter Wafer Number: ", "0", out waferNum);

					if(waferNum == "1")
						App.TC.WaferNum = 1;
					else if (waferNum == "3")
						App.TC.WaferNum = 3;
					else if(waferNum == "6")
						App.TC.WaferNum = 6;
					else if(waferNum == "10")
						App.TC.WaferNum = 10;
					else
						TP.Console.AskConfirm("Invalid Wafer Number");


					App.TC.AVdd.Value = App.Globals.CharHVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharHVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					if (App.Globals.TemptronicsEnable)
					{
						TX.TemptronicThermoStream.HeadDown();
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 2:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharHVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					break;
				case 3:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharHVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					break;
				case 4:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharHVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[0];
					break;
				case 5:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharHVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 6:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharHVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					break;
				case 7:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharHVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					break;
				case 8:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharHVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[1];
					break;
				case 9:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharHVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 10:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharHVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					break;
				case 11:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharHVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					break;
				case 12:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharHVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					break;
				case 13:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharHVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 14:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharHVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					break;
				case 15:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharHVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					break;
				case 16:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharHVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[3];
					break;
				case 17:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[0];
					App.TC.AVss.Value = App.Globals.CharHVAvss[0];
					App.TC.DVcc.Value = App.Globals.CharDvcc[0];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 18:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[1];
					App.TC.AVss.Value = App.Globals.CharHVAvss[1];
					App.TC.DVcc.Value = App.Globals.CharDvcc[1];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					break;
				case 19:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[2];
					App.TC.AVss.Value = App.Globals.CharHVAvss[2];
					App.TC.DVcc.Value = App.Globals.CharDvcc[2];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					break;
				case 20:
					App.TC.AVdd.Value = App.Globals.CharHVAvdd[3];
					App.TC.AVss.Value = App.Globals.CharHVAvss[3];
					App.TC.DVcc.Value = App.Globals.CharDvcc[3];
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					break;
				default:
					TP.Console.WriteLine("No conditions option for current test cycle!");
					break;
			}
			App.TC.Vih.Value = App.TC.DVcc;
			App.TC.Vil.Value = 0.0;
			App.TC.Voh.Value = App.TC.DVcc - 0.4;
			App.TC.Vol.Value = 0.4;

			dvccClamp = App.TC.DVcc + 0.1*App.TC.DVcc;
			posAvddClamp = App.TC.AVdd + 0.2*App.TC.AVdd;
			negAvddClamp = -0.1;
			negAvssClamp = App.TC.AVss + 0.2*App.TC.AVss;
			posAvssClamp = 0.1;

			HW.Dvi.VClamp(PM.DVCC, dvccClamp);
			HW.Vi.VClamp(PM.AVDD, posAvddClamp, negAvddClamp);
			HW.Vi.VClamp(PM.AVSS, posAvssClamp, negAvssClamp);
		}
		#endregion

		//
		//SetYaConditions method
		//
		#region SetYaConditions  				:
		/// <summary>
		/// Sets supply voltage variables dependant on current test cycle
		/// </summary>
		public static void SetYaConditions ( )
		{
			//string waferNum;

			switch(TP.Part.CurrentTestCycle)
			{
				case 1:
					//At start of cycle, ask for wafer number
					/*TP.Console.AskUser("Please Enter Wafer Number: ", "0", out waferNum);

					if(waferNum == "1")
						App.TC.WaferNum = 1;
					else if (waferNum == "3")
						App.TC.WaferNum = 3;
					else if(waferNum == "6")
						App.TC.WaferNum = 6;
					else if(waferNum == "10")
						App.TC.WaferNum = 10;
					else
						TP.Console.AskConfirm("Invalid Wafer Number");
*/
					App.TC.WaferNum = 6;

					App.TC.Temp.Value = App.Globals.CharTemp[0];
					if (App.Globals.TemptronicsEnable)
					{
						TX.TemptronicThermoStream.HeadDown();
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 2:
					App.TC.Temp.Value = App.Globals.CharTemp[2];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				case 3:
					App.TC.Temp.Value = App.Globals.CharTemp[4];
					if (App.Globals.TemptronicsEnable)
					{
						TP.Console.WriteLine("Setting temperature to {0}C", App.TC.Temp);
						TX.TemptronicThermoStream.SetAndWaitTemperature(App.TC.Temp, App.Globals.SoakTime);
						App.Time.MsDelay(5000);
					}
					break;
				default:
					TP.Console.WriteLine("No conditions option for current test cycle!");
					break;
			}
		}
		#endregion

		//
		//FindUnipolarDeadband method
		//
		#region FindUnipolarDeadband  				:
		/// <summary>
		/// Function to zoom in on deadband of a unipolar range using linearity as an indicator.
		/// Function using binary search to come within "measRes" (measurement resolution) of deadband.
		/// </summary>
		public static MsDouble FindUnipolarDeadband ( MsDouble idealTUE, MsDouble passingVin, App.RangeOptions range, App.MeasOptions resourceSelect)
		{
			MsDouble deadband = 0.0, 
				testPoint = 0.0,
				highDataPoint = 0.0, 
				lowDataPoint = 0.0,
				idealOut = 0.0,
				outputMeas = 0.0,
				tueError = 0.0;
			double measRes = 0.0010;
			MsBool passFail =  false;

			highDataPoint = passingVin;
			lowDataPoint = 0.0;
			testPoint = 0.0;

			foreach(Site site in TP.MS.ActiveSites)
			{
				for(int i = 0; i < 100; i++)
				{
					//Check TUE error with new testPoint

					//Calculate ideal output for new testPoint
					idealOut[site] = App.TC.RangeData[(int)range].MinValue + 
						((testPoint[site]/App.TC.MaxInputVoltage) * (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));

					//Load testPoint value to Vin & measure o/p
					HW.Dcs.VOut(PM.VIN, testPoint);
					App.Time.MsDelay(App.TC.OutputSettle);
					outputMeas = Utl.MeasureOutput(range, idealOut[site], resourceSelect);

					tueError[site] = ((outputMeas[site] - idealOut[site]) / (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;
					if((Math.Abs(tueError[site]) - Math.Abs(idealTUE[site])) > 0.015)
						passFail = false;
					else
						passFail = true;			

					if(passFail[site] == true)
					{
						//=> deadband < testpoint
						highDataPoint[site] = testPoint[site];
					}
					else if(passFail[site] == false)
					{
						//=> deadband > testpoint
						lowDataPoint[site] = testPoint[site];
					}

					testPoint[site] = lowDataPoint[site] + (highDataPoint[site] - lowDataPoint[site])/2;
					if((highDataPoint[site] - lowDataPoint[site]) < measRes)
					{
						deadband[site] = highDataPoint[site];
						break;
					}
				}
			}
			HW.Dcs.VOut(PM.VIN, 0.0);

			return deadband;

		}
		#endregion

		//
		//MeasIntNodes method
		//
		#region MeasIntNodes  				:
		/// <summary>
		/// Function to be called in debug mode to measure internal nodesl
		/// </summary>
		public static void MeasIntNodes ( App.RangeOptions range, App.ResSel rSel, App.VLoadOptions vLoad)
		{
			int numPoints = 30;
			double vin;
			MsDouble [] vMeas = MsDouble.CreateArray(numPoints, 0);
			double [] vinArray = new double[numPoints];
			double [] vinBufOutArray = new double[numPoints];

			//Enter test mode
			Utl.EnterTM();
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE,
				App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, (int)App.TmuxBits.VIN_OUT);

			//Switch out NC/IFault pin
			HW.Rdc.Set(PM.RLX21_RELAYS, OpenClose.CLOSE);

			for(int i = 0; i < numPoints; i++)
			{
				vin = i*0.001;
				HW.Dcs.VOut(PM.VIN, vin);
				vMeas[i] = Utl.MeasureNode(App.MuxNodes.VIN_MEAS, App.MeasOptions.DMM);
				vinArray[i] = (double)vMeas[i];

				vMeas[i] = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);
				vinBufOutArray[i] = (double)vMeas[i];
			}

			String fileName = @String.Format("{0}_{1}_{2}_vin_data.txt", range, rSel, vLoad);
			Utl.WriteFile(vinArray, numPoints, fileName);

			String newFileName = @String.Format("{0}_{1}_{2}_vinBufOut_data.txt", range, rSel, vLoad);
			Utl.WriteFile(vinBufOutArray, numPoints, newFileName);

			HW.Dcs.VOut(PM.VIN, 0.0);
		}
		#endregion


		//
		// TrackBin8Failures utility method
		//
		#region TrackBin8Failures              :
		/// <summary>
		/// Track the number of Bin8's in the lot and stop testing if there is any discrepancy.
		/// </summary>
		/// <remarks>
		/// </remarks>
		public static void TrackBin8Failures ( )
		{
			int		Bin8Failures = 8;
			double  NumBin8Parts = 0;
			double	CurrentBin8Percentage = 0;

			//Put in the allowable Percentage of Bin8 failures. This figure changes depending on the lot size.
			double	AllowableBin8Percentage = 30.0;
			if		(App.Globals.PartCounter>=30 && App.Globals.PartCounter<60)		AllowableBin8Percentage = 25.0;
			else if	(App.Globals.PartCounter>=60 && App.Globals.PartCounter<100)	AllowableBin8Percentage = 20.0;
			else if	(App.Globals.PartCounter>=100)									AllowableBin8Percentage = 10.0;
			else																	AllowableBin8Percentage = 30.0;
			
			//Calculate the percentage of the Bin8 failures with respect to the number of parts tested.
			foreach (Site site in TP.Part.TestSites) NumBin8Parts	+= TP.Part[site].BinningDetails[Bin8Failures];
			
			CurrentBin8Percentage = NumBin8Parts/App.Globals.PartCounter*100;
			
			//Display a pop-up message on the screen if the number of Bin8's exceeds the allowable percentage.
			if (CurrentBin8Percentage > AllowableBin8Percentage)		
				TP.Console.AskConfirm("Too many parts have FAILED Continuity!!! Please end the lot and have the setup checked.");	
			
		}
		#endregion

	} // end of class Utl
	#endregion



} // end of namespace Adi.Cts.TestProgram
