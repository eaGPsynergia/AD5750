//
// Contains all sequencers used in this application and test limits definitions.
//
// History:
// 11/29/05 - CTS - Template Created.
//
using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{
	//
	// Test application names and numbers
	//
	#region IDs                             :
	/// <summary>
	/// Encapsulates all the test names and numbers used in this test program.
	/// </summary>
	public class IDs
	{

		#region Normal ID Declarations
		public static TestID SiteNumber;

		public static TestID DVccTC;
		public static TestID AVddTC;
		public static TestID AVssTC;
		public static TestID VrefTC;
		public static TestID TempTC;
		public static TestID WaferTC;
		public static TestID BlowFusesTC;
		public static TestID FuseVTC;
		public static TestID Idd15Stby;
		public static TestID IddRefStby;
		public static TestID IddDigStby;


		public static TestID NCcheck;

		#region continuityResCheck
		public static TestID GndSnsRes50mv;
		public static TestID GndSnsRes100mv;

		public static TestID ContHighNcIfault;
		public static TestID ContHighFault;
		public static TestID ContHighReset;
		public static TestID ContHighHwsel;
		public static TestID ContHighVsensep;
		public static TestID ContHighVout;
		public static TestID ContHighVsensen;
		public static TestID ContHighComp2;
		public static TestID ContHighComp1;
		public static TestID ContHighIout;
		public static TestID ContHighVin;
		public static TestID ContHighVref;
		public static TestID ContHighRext2;
		public static TestID ContHighRext1;
		public static TestID ContHighAD0;
		public static TestID ContHighAD1;
		public static TestID ContHighAD2;
		public static TestID ContHighSdin;
		public static TestID ContHighSclk;
		public static TestID ContHighSync;
		public static TestID ContHighClr;
		public static TestID ContHighClrsel;
		public static TestID ContHighSD0;

		public static TestID ContLowNcIfault;
		public static TestID ContLowFault;
		public static TestID ContLowReset;
		public static TestID ContLowHwsel;
		public static TestID ContLowVsensep;
		public static TestID ContLowVout;
		public static TestID ContLowVsensen;
		public static TestID ContLowComp2;
		public static TestID ContLowComp1;
		public static TestID ContLowIout;
		public static TestID ContLowVin;
		public static TestID ContLowVref;
		public static TestID ContLowRext2;
		public static TestID ContLowRext1;
		public static TestID ContLowAD0;
		public static TestID ContLowAD1;
		public static TestID ContLowAD2;
		public static TestID ContLowSdin;
		public static TestID ContLowSclk;
		public static TestID ContLowSync;
		public static TestID ContLowClr;
		public static TestID ContLowClrsel;
		public static TestID ContLowSD0;

		public static TestID VoutHiRes;

		public static TestID NcIfaultLoRes;
		public static TestID FaultLoRes;
		public static TestID ResetLoRes;
		public static TestID HwselLoRes;
		public static TestID VsensepLoRes;
		public static TestID VoutLoRes;
		public static TestID VsensenLoRes;
		public static TestID Comp2LoRes;
		public static TestID Comp1LoRes;
		public static TestID IoutLoRes;
		public static TestID VinLoRes;
		public static TestID VrefLoRes;
		public static TestID Rext2LoRes;
		public static TestID Rext1LoRes;
		public static TestID AD0LoRes;
		public static TestID AD1LoRes;
		public static TestID AD2LoRes;
		public static TestID SdinLoRes;
		public static TestID SclkLoRes;
		public static TestID SyncLoRes;
		public static TestID ClrLoRes;
		public static TestID ClrselLoRes;
		public static TestID SD0LoRes;
		#endregion

		public static TestID Continuity;

		public static TestID PowerupToZero;
		public static TestID PowerupToMid;
		public static TestID PowerupTristate;

		#region leakage
		public static TestID ResetLeakage0V;
		public static TestID HwselLeakage0V;
		public static TestID Ad0Leakage0V;
		public static TestID Ad1Leakage0V;
		public static TestID Ad2Leakage0V;
		public static TestID SdinLeakage0V;
		public static TestID SclkLeakage0V;
		public static TestID SyncLeakage0V;
		public static TestID ClearLeakage0V;
		public static TestID ClrselLeakage0V;
		public static TestID SdoLeakage0V;
		public static TestID FaultLeakage0V;
		public static TestID IfaultLeakage0V;

		public static TestID ResetLeakageDvcc;
		public static TestID HwselLeakageDvcc;
		public static TestID Ad0LeakageDvcc;
		public static TestID Ad1LeakageDvcc;
		public static TestID Ad2LeakageDvcc;
		public static TestID SdinLeakageDvcc;
		public static TestID SclkLeakageDvcc;
		public static TestID SyncLeakageDvcc;
		public static TestID ClearLeakageDvcc;
		public static TestID ClrselLeakageDvcc;
		public static TestID SdoLeakageDvcc;
		public static TestID FaultLeakageDvcc;
		public static TestID IfaultLeakageDvcc;

		public static TestID IoutTristateLkg;
		public static TestID VoutTristateLkg;
		public static TestID vsensenLkg;
		#endregion

		public static TestID AIdd;
		public static TestID AIss;
		public static TestID DIcc;

		public static TestID PostTestAIdd;
		public static TestID PostTestAIss;
		public static TestID PostTestDIcc;

		public static TestID IloadHighMeas;
		public static TestID IloadLowMeas;
		public static TestID VinLowMeas;
		public static TestID VinHighMeas;
		public static TestID VrefMeas;
		public static TestID VscaleHighRatio;
		public static TestID VscaleHighLoad;
		public static TestID VscaleHighM;
		public static TestID VscaleHighC;
		public static TestID VscaleLowRatio;
		public static TestID VscaleLowLoad;

		public static TestID VrefCurrent;
		public static TestID VinCurrent;
		public static TestID VrefCurrentHi;
		public static TestID VinCurrentHi;

		public static TestID readMasterFuse;
		public static TestID DeviceID;

		public static TestID Vgen7V;
		public static TestID Vgen5V;

		public static TestID IbiasTrimCode;
		public static TestID IbiasPostTrim;
		public static TestID TempcoTrimCode;

		#region PreTrim
		public static TestID OffsetError5V;
		public static TestID OffsetTrimCode5V;
		public static TestID GainError5V;
		public static TestID GainTrimCode5V;

		public static TestID OffsetError10V;
		public static TestID OffsetTrimCode10V;
		public static TestID GainError10V;
		public static TestID GainTrimCode10V;

		public static TestID OffsetError5Vbip;
		public static TestID OffsetTrimCode5Vbip;
		public static TestID GainError5Vbip;
		public static TestID GainTrimCode5Vbip;

		public static TestID OffsetError10Vbip;
		public static TestID OffsetTrimCode10Vbip;
		public static TestID GainError10Vbip;
		public static TestID GainTrimCode10Vbip;

		public static TestID OffsetError40V;
		public static TestID OffsetTrimCode40V;
		public static TestID GainError40V;
		public static TestID GainTrimCode40V;

		public static TestID OffsetError4to20m;
		public static TestID OffsetTrimCode4to20m;
		public static TestID GainError4to20m;
		public static TestID GainTrimCode4to20m;

		public static TestID OffsetError20m;
		public static TestID OffsetTrimCode20m;
		public static TestID GainError20m;
		public static TestID GainTrimCode20m;

		public static TestID OffsetError24m;
		public static TestID OffsetTrimCode24m;
		public static TestID GainError24m;
		public static TestID GainTrimCode24m;

		public static TestID OffsetError20mBip;
		public static TestID OffsetTrimCode20mBip;
		public static TestID GainError20mBip;
		public static TestID GainTrimCode20mBip;

		public static TestID OffsetError24mBip;
		public static TestID OffsetTrimCode24mBip;
		public static TestID GainError24mBip;
		public static TestID GainTrimCode24mBip;

		public static TestID OffsetError4to20mInt;
		public static TestID OffsetTrimCode4to20mInt;
		public static TestID GainError4to20mInt;
		public static TestID GainTrimCode4to20mInt;

		public static TestID OffsetError20mInt;
		public static TestID OffsetTrimCode20mInt;
		public static TestID GainError20mInt;
		public static TestID GainTrimCode20mInt;

		public static TestID OffsetError24mInt;
		public static TestID OffsetTrimCode24mInt;
		public static TestID GainError24mInt;
		public static TestID GainTrimCode24mInt;

		public static TestID OffsetError20mBipInt;
		public static TestID OffsetTrimCode20mBipInt;
		public static TestID GainError20mBipInt;
		public static TestID GainTrimCode20mBipInt;

		public static TestID OffsetError24mBipInt;
		public static TestID OffsetTrimCode24mBipInt;
		public static TestID GainError24mBipInt;
		public static TestID GainTrimCode24mBipInt;
		#endregion

		public static TestID Read_X_Coordinate;
		public static TestID Read_Y_Coordinate;
		public static TestID Read_Wafer_number;

		public static TestID BlowHighVoltage;
		public static TestID BlowFuseMem;

		#region PostTrim
		public static TestID[] vPostTrimPosTueReal	= new TestID[App.Globals.NumTrimVRanges];		
		public static TestID[] vPostTrimNegTueReal	= new TestID[App.Globals.NumTrimVRanges];		
		public static TestID[] vPostTrimLin			= new TestID[App.Globals.NumTrimVRanges];		
		public static TestID[] vPostTrimGain		= new TestID[App.Globals.NumTrimVRanges];		
		public static TestID[] vPostTrimOffset		= new TestID[App.Globals.NumTrimVRanges];		
		public static TestID[] vPostTrimZSError		= new TestID[App.Globals.NumTrimVRanges];		
		public static TestID[] vPostTrimFSError		= new TestID[App.Globals.NumTrimVRanges];		
		//public static TestID[,] vPostTrimDeadband	= new TestID[App.Globals.NumTrimVRanges];		
		public static TestID[] vPostTrimDBcalc		= new TestID[App.Globals.NumTrimVRanges];		

		public static TestID[] vPostTrimMSOffset	= new TestID[App.Globals.NumBipVRanges];
		public static TestID[,] iPostTrimMSOffset	= new TestID[App.Globals.NumBipIRanges, App.Consts.NUM_RES_MODES];

		public static TestID[,] iPostTrimPosTueReal	= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		public static TestID[,] iPostTrimNegTueReal	= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		public static TestID[,] iPostTrimLin		= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		public static TestID[,] iPostTrimGain		= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		public static TestID[,] iPostTrimOffset		= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		public static TestID[,] iPostTrimZSError	= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		public static TestID[,] iPostTrimFSError	= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		//public static TestID[,] iPostTrimDeadband	= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		
		public static TestID[,] iPostTrimDBcalc		= new TestID[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];		

		//Overrange tests for Rockwell special
		public static TestID[] overRangeZS = new TestID[2];
		public static TestID[] overRangeFS = new TestID[2];
		public static TestID[] overRangeMS = new TestID[2];
		public static TestID[] overRangeGain = new TestID[2];
		public static TestID[] overRangeLin = new TestID[2];
		public static TestID[] overRangePosTue = new TestID[2];
		public static TestID[] overRangeNegTue = new TestID[2];
		#endregion

		public static TestID VsensenFunc;

		public static TestID IRangeDIcc;
		public static TestID IRangeAIss;
		public static TestID IRangeAIdd;
		public static TestID VRangeDIcc;
		public static TestID VRangeAIss;
		public static TestID VRangeAIdd;

		public static TestID DigLevelFunc;

		#region TestPoints
		public static TestID VtoIoBufOffs;
		public static TestID VtoItestpoint;
		public static TestID Vref_div2;
		public static TestID vDacImode;
		//public static TestID OpBufVofsIp;
		public static TestID opBufVinOffset;
		//public static TestID vinNeg;
		public static TestID vDacVmode;
		public static TestID vOfsBufOffset;
		public static TestID vOfsIp;
		public static TestID vOfsDac;
		public static TestID vrefBufOffset;
		public static TestID vrefBufOp;
		public static TestID vrefMeas;
		public static TestID vinBufOffset;
		public static TestID vinBufOp;
		public static TestID vinMeas;
		#endregion


		public static TestID AddrFunc;
		public static TestID ClrFunc;
		public static TestID ResetFunc;
		public static TestID PecFunc;
		public static TestID InvalidWrites;

		#region Alarms
		public static TestID VoutSwFaultPinFunc;
		public static TestID VoutSwFault2mA5Func;

		public static TestID VFaultFunc;
		public static TestID ShortCctCurPos;
		public static TestID ShortCctCurNeg;

		public static TestID SwFaultPinFunc;
		public static TestID SwFault2mA5Func;

		public static TestID IFaultFunc;
		public static TestID ComplFuncAvdd;
		public static TestID IdealIoutVdd;
		public static TestID ComplianceVvdd;
		public static TestID VddAlarmIout;
		public static TestID VddCurrAlrmDeltaFSR;
		public static TestID VddCurrComplDeltaFSR;
		public static TestID ComplFuncAvss;
		public static TestID AlarmVdd;
		public static TestID IdealIoutVss;
		public static TestID ComplianceVvss;
		public static TestID VssAlarmIout;
		public static TestID VssCurrAlrmDeltaFSR;
		public static TestID VssCurrComplDeltaFSR;
		public static TestID AlarmVss;

		public static TestID OverTempFaultFunc;
		public static TestID PecFaultFunc;
		#endregion

		#region HwRanges

		public static TestID HwTrimmedRangesFunc;

		public static TestID Hw6vGain;
		public static TestID Hw6vOffset;
		public static TestID Hw6vFSErr;
		public static TestID Hw12vGain;
		public static TestID Hw12vOffset;
		public static TestID Hw12vFSErr;
		public static TestID Hw6vBipGain;
		public static TestID Hw6vBipOffset;
		public static TestID Hw6vBipFSErr;
		public static TestID Hw12vBipGain;
		public static TestID Hw12vBipOffset;
		public static TestID Hw12vBipFSErr;


		public static TestID Hw3ma92Gain;
		public static TestID Hw3ma92Offset;
		public static TestID Hw3ma92FSErr;
		public static TestID Hw20ma4Gain;
		public static TestID Hw20ma4Offset;
		public static TestID Hw20ma4FSErr;
		public static TestID Hw24ma5Gain;
		public static TestID Hw24ma5Offset;
		public static TestID Hw24ma5FSErr;

		public static TestID Hw6vGainExtR;
		public static TestID Hw6vOffsetExtR;
		public static TestID Hw6vFSErrExtR;
		public static TestID Hw12vGainExtR;
		public static TestID Hw12vOffsetExtR;
		public static TestID Hw12vFSErrExtR;
		public static TestID Hw6vBipGainExtR;
		public static TestID Hw6vBipOffsetExtR;
		public static TestID Hw6vBipFSErrExtR;
		public static TestID Hw12vBipGainExtR;
		public static TestID Hw12vBipOffsetExtR;
		public static TestID Hw12vBipFSErrExtR;
		public static TestID Hw2v5BipGainExtR;
		public static TestID Hw2v5BipOffsetExtR;
		public static TestID Hw2v5BipFSErrExtR;
		public static TestID Hw44vGainExtR;
		public static TestID Hw44vOffsetExtR;
		public static TestID Hw44vFSErrExtR;
		#endregion

		public static TestID HwClearFunc;
		public static TestID HwReset;
		public static TestID HwIFaultFunc;
		public static TestID HwVFaultFunc;
		public static TestID HwVFault2mA5Func;
		public static TestID HwIFault2mA5Func;

		public static TestID BlowMasterFuse;

		public static TestID CoolOffset;
		public static TestID WarmOffset;
		public static TestID OffsetDelta;

		#endregion

		#region Char ID Declarations

		public static TestID IFaultFuncChar;
		public static TestID IdealIoutVddChar;
		public static TestID ComplianceVvddChar;
		public static TestID VddAlarmIoutChar;
		public static TestID VddCurrAlrmDeltaFSRChar;	
		public static TestID IdealIoutVssChar;
		public static TestID ComplianceVvssChar;
		public static TestID VssAlarmIoutChar;
		public static TestID VssCurrAlrmDeltaFSRChar;
		public static TestID SwFaultPinFuncChar;
		public static TestID SwFault2mA5FuncChar;

		public static TestID[] vRangeVssPsrrSource = new TestID[2];		
		public static TestID[] vRangeVddPsrrSource = new TestID[2];
		public static TestID[] vRangeVssPsrrSink = new TestID[2];
		public static TestID[] vRangeVddPsrrSink = new TestID[2];

		public static TestID iRangeVssPsrrSource;
		public static TestID iRangeVddPsrrSource;
		public static TestID iRangeVssPsrrSink;
		public static TestID iRangeVddPsrrSink;

		public static TestID[] VddHeadroom = new TestID[2];
		public static TestID[] VssHeadroom = new TestID[2];	
		public static TestID VssHeadroomPass;
		public static TestID VddHeadroomPass;
	
		public static TestID t13Timing;
		public static TestID t11Timing;
		public static TestID t10Timing;
		public static TestID t9Timing;
		public static TestID t8Timing;
		public static TestID t7Timing;
		public static TestID t6Timing;
		public static TestID t5Timing;
		public static TestID t5aTiming;
		public static TestID t4Timing;
		public static TestID t3Timing;
		public static TestID t2Timing;
		public static TestID t1Timing;

		public static TestID vih;
		public static TestID vil;
		public static TestID voh;
		public static TestID vol;
		#endregion

		#region Board Checker ID Declarations
		public static TestID TwelveVoltSupply;
		public static TestID DiodeDrop;

		public static TestID RL101;
		public static TestID RL105;
		public static TestID RL108;
		public static TestID RL110;
		public static TestID RL111;
		public static TestID RL113;
		public static TestID RL114;
		public static TestID RL116;
		public static TestID RL117;
		public static TestID RL118;
		public static TestID RL119;
		public static TestID RL121;

		public static TestID RL201;
		public static TestID RL205;
		public static TestID RL208;
		public static TestID RL210;
		public static TestID RL211;
		public static TestID RL213;
		public static TestID RL214;
		public static TestID RL216;
		public static TestID RL217;
		public static TestID RL218;
		public static TestID RL221;

		public static TestID RL301;
		public static TestID RL305;
		public static TestID RL308;
		public static TestID RL310;
		public static TestID RL311;
		public static TestID RL313;
		public static TestID RL314;
		public static TestID RL316;
		public static TestID RL317;
		public static TestID RL318;
		public static TestID RL319;
		public static TestID RL321;

		public static TestID RL401;
		public static TestID RL405;
		public static TestID RL408;
		public static TestID RL410;
		public static TestID RL411;
		public static TestID RL413;
		public static TestID RL414;
		public static TestID RL416;
		public static TestID RL417;
		public static TestID RL418;
		public static TestID RL421;

		public static TestID RL63;
		public static TestID RL64;

		public static TestID RL102x;
		public static TestID RL120x;
		public static TestID RL202x;
		public static TestID RL302x;
		public static TestID RL320x;
		public static TestID RL402x;

		public static TestID RLx03;
		public static TestID RLx04;
		public static TestID RLx06;
		public static TestID RLx07;
		public static TestID RLx09;
		public static TestID RLx12;
		public static TestID RLx15;
		public static TestID RLx22;

		public static TestID HighVoltageRelays;

		public static TestID MuxAVref;
		public static TestID MuxAVin;
		public static TestID MuxAIout;
		public static TestID MuxBDutgnd;
		public static TestID MuxBVoutScale;
		public static TestID MuxBVsenseN;
		public static TestID MuxCVgaincheck;

		public static TestID IoutLoadResRatio;
		public static TestID IoutLoadResHigh;
		public static TestID IoutLoadResLow;
		public static TestID VoutScale2;
		public static TestID VoutScale1;
		public static TestID RextRes;
		#endregion

		#region Load
		/// <summary>
		/// Initialize ids.
		/// </summary>
		public static void Load ( )		
		{
			String testName;
			#region Normal ID Init
			ulong i = 1;
			string TCTestsPrefix = "_";

			// ID Name                [Selector]         Test #    Test Name
			SiteNumber        = TP.Program.CreateTestID(       i++,  "Site Number");

			BlowFusesTC			= TP.Program.CreateTestID(     104,  TCTestsPrefix + "BlowFuses");
			FuseVTC           = TP.Program.CreateTestID(     105,  TCTestsPrefix + "FuseV");

			Idd15Stby         = TP.Program.CreateTestID(     121,  "Idd 15V Standby");
			IddRefStby        = TP.Program.CreateTestID(     122,  "Idd Ref Standby");
			IddDigStby        = TP.Program.CreateTestID(     123,  "Idd Dig Standby");

			DVccTC				= TP.Program.CreateTestID(i++,  TCTestsPrefix + "DVcc");
			AVddTC				= TP.Program.CreateTestID(i++,  TCTestsPrefix + "AVdd");
			AVssTC				= TP.Program.CreateTestID(i++,  TCTestsPrefix + "AVss");
			VrefTC				= TP.Program.CreateTestID(i++,  TCTestsPrefix + "VRef");
			TempTC				= TP.Program.CreateTestID(i++,  TCTestsPrefix + "Temp");
			WaferTC				= TP.Program.CreateTestID(i++,  TCTestsPrefix + "Wafer");

			VrefMeas			= TP.Program.CreateTestID(i++,		"Measured Vref");
			VinLowMeas			= TP.Program.CreateTestID(i++,		"Measured ZS Vin");
			VinHighMeas			= TP.Program.CreateTestID(i++,		"Measured FS Vin");
			IloadLowMeas		= TP.Program.CreateTestID(i++,		"Measured 300Ohm");
			IloadHighMeas		= TP.Program.CreateTestID(i++,		"Measured 1800Ohm");
			VscaleLowLoad		= TP.Program.CreateTestID(i++,		"Vout Scaled - Low Load");
			VscaleLowRatio		= TP.Program.CreateTestID(i++,		"Vout Scaled - Low Ratio");
			VscaleHighLoad		= TP.Program.CreateTestID(i++,		"Vout Scaled - High Load");
			VscaleHighRatio		= TP.Program.CreateTestID(i++,		"Vout Scaled - High Ratio");
			VscaleHighM			= TP.Program.CreateTestID(i++,		"Vout Scaled - Gain Factor");
			VscaleHighC			= TP.Program.CreateTestID(i++,		"Vout Scaled - Offset Factor");

			i=63;
			NCcheck           = TP.Program.CreateTestID(i++,		"NC Shorts");

			#region continuityResCheck
			GndSnsRes50mv	  = TP.Program.CreateTestID(2064,		"Gnd Pins Res @ 50mV");
			GndSnsRes100mv	  = TP.Program.CreateTestID(2065,		"Gnd Pins Res @ 100mV");

			ulong j = 6000;
			ContHighSD0       = TP.Program.CreateTestID(j++,		"SDO O/S High B");
			ContHighClrsel    = TP.Program.CreateTestID(j++,		"CLRSEL O/S High B");
			ContHighClr       = TP.Program.CreateTestID(j++,		"CLEAR O/S High B");
			ContHighSync      = TP.Program.CreateTestID(j++,		"SYNC O/S High B");
			ContHighSclk      = TP.Program.CreateTestID(j++,		"SCLK O/S High B");
			ContHighSdin      = TP.Program.CreateTestID(j++,		"SDIN O/S High B");
			ContHighAD2       = TP.Program.CreateTestID(j++,		"AD2 O/S High B");
			ContHighAD1       = TP.Program.CreateTestID(j++,		"AD1 O/S High B");
			ContHighAD0       = TP.Program.CreateTestID(j++,		"AD0 O/S High B");
			ContHighRext1     = TP.Program.CreateTestID(j++,		"REXT1 O/S High B");
			ContHighRext2     = TP.Program.CreateTestID(j++,		"REXT2 O/S High B");
			ContHighVref      = TP.Program.CreateTestID(j++,		"VREF O/S High B");
			ContHighVin       = TP.Program.CreateTestID(j++,		"VIN O/S High B");
			ContHighIout      = TP.Program.CreateTestID(j++,		"IOUT O/S High B");
			ContHighComp1     = TP.Program.CreateTestID(j++,		"COMP1 O/S High B");
			ContHighComp2     = TP.Program.CreateTestID(j++,		"COMP2 O/S High B");
			ContHighVsensen   = TP.Program.CreateTestID(j++,		"VSENSEN O/S High B");
			ContHighVout      = TP.Program.CreateTestID(j++,		"VOUT O/S High B");
			ContHighVsensep   = TP.Program.CreateTestID(j++,		"VSENSEP O/S High B");
			ContHighHwsel     = TP.Program.CreateTestID(j++,		"HWSEL O/S High B");
			ContHighReset     = TP.Program.CreateTestID(j++,		"RESET O/S High B");
			ContHighFault     = TP.Program.CreateTestID(j++,		"FAULT O/S High B");
			ContHighNcIfault  = TP.Program.CreateTestID(j++,		"NC/IFAULT O/S High B");

			ContLowSD0		  = TP.Program.CreateTestID(j++,		"SDO O/S Low");
			ContLowClrsel     = TP.Program.CreateTestID(j++,		"CLRSEL O/S Low B");
			ContLowClr        = TP.Program.CreateTestID(j++,		"CLEAR O/S Low B");
			ContLowSync       = TP.Program.CreateTestID(j++,		"SYNC O/S Low B");
			ContLowSclk       = TP.Program.CreateTestID(j++,		"SCLK O/S Low B");
			ContLowSdin       = TP.Program.CreateTestID(j++,		"SDIN O/S Low B");
			ContLowAD2        = TP.Program.CreateTestID(j++,		"AD2 O/S Low B");
			ContLowAD1        = TP.Program.CreateTestID(j++,		"AD1 O/S Low B");
			ContLowAD0        = TP.Program.CreateTestID(j++,		"AD0 O/S Low B");
			ContLowRext1      = TP.Program.CreateTestID(j++,		"REXT1 O/S Low B");
			ContLowRext2      = TP.Program.CreateTestID(j++,		"REXT2 O/S Low B");
			ContLowVref       = TP.Program.CreateTestID(j++,		"VREF O/S Low B");
			ContLowVin        = TP.Program.CreateTestID(j++,		"VIN O/S Low B");
			ContLowIout       = TP.Program.CreateTestID(j++,		"IOUT O/S Low B");
			ContLowComp1      = TP.Program.CreateTestID(j++,		"COMP1 O/S Low B");
			ContLowComp2      = TP.Program.CreateTestID(j++,		"COMP2 O/S Low B");
			ContLowVsensen    = TP.Program.CreateTestID(j++,		"VSENSEN O/S Low B");
			ContLowVout       = TP.Program.CreateTestID(j++,		"VOUT O/S Low B");
			ContLowVsensep    = TP.Program.CreateTestID(j++,		"VSENSEP O/S Low B");
			ContLowHwsel      = TP.Program.CreateTestID(j++,		"HWSEL O/S Low B");
			ContLowReset      = TP.Program.CreateTestID(j++,		"RESET O/S Low B");
			ContLowFault      = TP.Program.CreateTestID(j++,		"FAULT O/S Low B");
			ContLowNcIfault   = TP.Program.CreateTestID(j++,		"NC/IFAULT O/S Low B");

			VoutHiRes			= TP.Program.CreateTestID(j++,		"VOUT High Diode Res");


			Rext1LoRes			= TP.Program.CreateTestID(6056,		"REXT1 Low Diode Res");
			Rext2LoRes			= TP.Program.CreateTestID(6057,		"REXT2 Low Diode Res");
			VrefLoRes			= TP.Program.CreateTestID(6058,		"VREF Low Diode Res");
			VinLoRes			= TP.Program.CreateTestID(6059,		"VIN Low Diode Res");
			IoutLoRes			= TP.Program.CreateTestID(6060,		"IOUT Low Diode Res");
			VsensenLoRes		= TP.Program.CreateTestID(6063,		"VSENSEN Low Diode Res");
			VoutLoRes			= TP.Program.CreateTestID(6064,		"VOUT Low Diode Res");
			VsensepLoRes		= TP.Program.CreateTestID(6065,		"VSENSEP Low Diode Res");
			#endregion

			Continuity			= TP.Program.CreateTestID(i++,		"Continuity");

			#region LeakageIDs
			SdoLeakage0V		= TP.Program.CreateTestID(i++,		"SDO/VFAULT Leakage, 0V");
			ClrselLeakage0V		= TP.Program.CreateTestID(i++,		"CLRSEL Leakage, 0V");
			ClearLeakage0V		= TP.Program.CreateTestID(i++,		"CLEAR Leakage, 0V");
			SyncLeakage0V		= TP.Program.CreateTestID(i++,		"SYNC/RSEL Leakage, 0V");
			SclkLeakage0V		= TP.Program.CreateTestID(i++,		"SCLK/OUTEN Leakage, 0V");
			SdinLeakage0V		= TP.Program.CreateTestID(i++,		"SDIN/R0 Leakage, 0V");
			Ad2Leakage0V		= TP.Program.CreateTestID(i++,		"AD2/R1 Leakage, 0V");
			Ad1Leakage0V		= TP.Program.CreateTestID(i++,		"AD1/R2 Leakage, 0V");
			Ad0Leakage0V		= TP.Program.CreateTestID(i++,		"AD0/R3 Leakage, 0V");
			HwselLeakage0V		= TP.Program.CreateTestID(i++,		"HW SELECT Leakage, 0V");
			ResetLeakage0V		= TP.Program.CreateTestID(i++,		"RESET Leakage, 0V");
			FaultLeakage0V		= TP.Program.CreateTestID(i++,		"Fault/Temp Leakage, 0V");
			IfaultLeakage0V		= TP.Program.CreateTestID(i++,		"NC/IFault Leakage, 0V");

			SdoLeakageDvcc      = TP.Program.CreateTestID(i++,		"SDO/VFAULT Leakage, DVcc");
			ClrselLeakageDvcc   = TP.Program.CreateTestID(i++,		"CLRSEL Leakage, DVcc");
			ClearLeakageDvcc    = TP.Program.CreateTestID(i++,		"CLEAR Leakage, DVcc");
			SyncLeakageDvcc     = TP.Program.CreateTestID(i++,		"SYNC/RSEL Leakage, DVcc");
			SclkLeakageDvcc     = TP.Program.CreateTestID(i++,		"SCLK/OUTEN Leakage, DVcc");
			SdinLeakageDvcc     = TP.Program.CreateTestID(i++,		"SDIN/R0 Leakage, DVcc");
			Ad2LeakageDvcc      = TP.Program.CreateTestID(i++,		"AD2/R1 Leakage, DVcc");
			Ad1LeakageDvcc      = TP.Program.CreateTestID(i++,		"AD1/R2 Leakage, DVcc");
			Ad0LeakageDvcc      = TP.Program.CreateTestID(i++,		"AD0/R3 Leakage, DVcc");
			HwselLeakageDvcc    = TP.Program.CreateTestID(i++,		"HW SELECT Leakage, DVcc");
			ResetLeakageDvcc    = TP.Program.CreateTestID(i++,		"RESET Leakage, DVcc");
			FaultLeakageDvcc	= TP.Program.CreateTestID(i++,		"Fault/Temp Leakage, DVcc");
			IfaultLeakageDvcc	= TP.Program.CreateTestID(i++,		"NC/IFault Leakage, DVcc");
			#endregion

			i = 94;
			AIdd				= TP.Program.CreateTestID(i++,		"AIdd");
			AIss				= TP.Program.CreateTestID(i++,		"AIss");
			DIcc				= TP.Program.CreateTestID(i++,		"DIcc");

			VrefCurrent			= TP.Program.CreateTestID(i++,		"VRef lkg, 0V");
			VrefCurrentHi		= TP.Program.CreateTestID(i++,		"Vref lkg, DVcc");
			VinCurrent			= TP.Program.CreateTestID(i++,		"Vin lkg, 0V");
			VinCurrentHi		= TP.Program.CreateTestID(i++,		"Vin lkg, DVcc");

			readMasterFuse		= TP.Program.CreateTestID(i++,		"Master Fuse Read");
			Read_X_Coordinate	= TP.Program.CreateTestID(i++,	"Read_X_Coordinate");
			Read_Y_Coordinate	= TP.Program.CreateTestID(i++,	"Read_Y_Coordinate");
			Read_Wafer_number	= TP.Program.CreateTestID(i++,	"Read_Wafer_number");
			DeviceID			= TP.Program.CreateTestID(i++,		"Device ID");


			Vgen5V				= TP.Program.CreateTestID(i++,		"Vgen 5V");
			Vgen7V				= TP.Program.CreateTestID(i++,		"Vgen 7V");

			IbiasTrimCode		= TP.Program.CreateTestID(i++,		"Ibias Trim Code");
			IbiasPostTrim		= TP.Program.CreateTestID(i++,		"PostTrim Ibias");
			TempcoTrimCode		= TP.Program.CreateTestID(i++,		"Tempco Trim Code");

			BlowHighVoltage     = TP.Program.CreateTestID(i++,		"Blow 5751 bit");

			#region PreTrimIDs
			GainTrimCode5V			= TP.Program.CreateTestID(i++,	"5V: Gain Trim Code");
			GainError5V				= TP.Program.CreateTestID(i++,	"5V: Gain Error");
			OffsetTrimCode5V		= TP.Program.CreateTestID(i++,	"5V: Offset Trim Code");
			OffsetError5V			= TP.Program.CreateTestID(i++,	"5V: Offset Error");

			GainTrimCode10V			= TP.Program.CreateTestID(i++,	"10V: Gain Trim Code");
			GainError10V			= TP.Program.CreateTestID(i++,	"10V: Gain Error");
			OffsetTrimCode10V		= TP.Program.CreateTestID(i++,	"10V: Offset Trim Code");
			OffsetError10V			= TP.Program.CreateTestID(i++,	"10V: Offset Error");

			GainTrimCode5Vbip		= TP.Program.CreateTestID(i++,	"+/-5V: Gain Trim Code");
			GainError5Vbip			= TP.Program.CreateTestID(i++,	"+/-5V: Gain Error");
			OffsetTrimCode5Vbip		= TP.Program.CreateTestID(i++,	"+/-5V: Offset Trim Code");
			OffsetError5Vbip		= TP.Program.CreateTestID(i++,	"+/-5V: Offset Error");

			GainTrimCode10Vbip		= TP.Program.CreateTestID(i++,	"+/-10V: Gain Trim Code");
			GainError10Vbip			= TP.Program.CreateTestID(i++,	"+/-10V: Gain Error");
			OffsetTrimCode10Vbip	= TP.Program.CreateTestID(i++,	"+/-10V: Offset Trim Code");
			OffsetError10Vbip		= TP.Program.CreateTestID(i++,	"+/-10V: Offset Error");

			GainTrimCode40V			= TP.Program.CreateTestID(i++,	"40V: Gain Trim Code");
			GainError40V			= TP.Program.CreateTestID(i++,	"40V: Gain Error");
			OffsetTrimCode40V		= TP.Program.CreateTestID(i++,	"40V: Offset Trim Code");
			OffsetError40V			= TP.Program.CreateTestID(i++,	"40V: Offset Error");

			GainTrimCode4to20mInt	= TP.Program.CreateTestID(i++,	"4 - 20mA, Int Res: Gain Trim Code");
			GainError4to20mInt		= TP.Program.CreateTestID(i++,	"4 - 20mA, Int Res: Gain Error");
			OffsetTrimCode4to20mInt	= TP.Program.CreateTestID(i++,	"4 - 20mA, Int Res: Offset Trim Code");
			OffsetError4to20mInt	= TP.Program.CreateTestID(i++,	"4 - 20mA, Int Res: Offset Error");

			GainTrimCode20mInt		= TP.Program.CreateTestID(i++,	"20mA, Int Res: Gain Trim Code");
			GainError20mInt			= TP.Program.CreateTestID(i++,	"20mA, Int Res: Gain Error");
			OffsetTrimCode20mInt	= TP.Program.CreateTestID(i++,	"20mA, Int Res: Offset Trim Code");
			OffsetError20mInt		= TP.Program.CreateTestID(i++,	"20mA, Int Res: Offset Error");

			GainTrimCode24mInt		= TP.Program.CreateTestID(i++,	"24mA, Int Res: Gain Trim Code");
			GainError24mInt			= TP.Program.CreateTestID(i++,	"24mA, Int Res: Gain Error");
			OffsetTrimCode24mInt	= TP.Program.CreateTestID(i++,	"24mA, Int Res: Offset Trim Code");
			OffsetError24mInt		= TP.Program.CreateTestID(i++,	"24mA, Int Res: Offset Error");

			GainTrimCode20mBipInt	= TP.Program.CreateTestID(i++,	"+/-20mA, Int Res: Gain Trim Code");
			GainError20mBipInt		= TP.Program.CreateTestID(i++,	"+/-20mA, Int Res: Gain Error");
			OffsetTrimCode20mBipInt	= TP.Program.CreateTestID(i++,	"+/-20mA, Int Res: Offset Trim Code");
			OffsetError20mBipInt	= TP.Program.CreateTestID(i++,	"+/-20mA, Int Res: Offset Error");

			GainTrimCode24mBipInt	= TP.Program.CreateTestID(i++,	"+/-24mA, Int Res: Gain Trim Code");
			GainError24mBipInt		= TP.Program.CreateTestID(i++,	"+/-24mA, Int Res: Gain Error");
			OffsetTrimCode24mBipInt	= TP.Program.CreateTestID(i++,	"+/-24mA, Int Res: Offset Trim Code");
			OffsetError24mBipInt	= TP.Program.CreateTestID(i++,	"+/-24mA, Int Res: Offset Error");

			GainTrimCode4to20m		= TP.Program.CreateTestID(i++,	"4 - 20mA, Ext Res: Gain Trim Code");
			GainError4to20m			= TP.Program.CreateTestID(i++,	"4 - 20mA, Ext Res: Gain Error");
			OffsetTrimCode4to20m	= TP.Program.CreateTestID(i++,	"4 - 20mA, Ext Res: Offset Trim Code");
			OffsetError4to20m		= TP.Program.CreateTestID(i++,	"4 - 20mA, Ext Res: Offset Error");

			GainTrimCode20m			= TP.Program.CreateTestID(i++,	"20mA, Ext Res: Gain Trim Code");
			GainError20m			= TP.Program.CreateTestID(i++,	"20mA, Ext Res: Gain Error");
			OffsetTrimCode20m		= TP.Program.CreateTestID(i++,	"20mA, Ext Res: Offset Trim Code");
			OffsetError20m			= TP.Program.CreateTestID(i++,	"20mA, Ext Res: Offset Error");

			GainTrimCode24m			= TP.Program.CreateTestID(i++,	"24mA, Ext Res: Gain Trim Code");
			GainError24m			= TP.Program.CreateTestID(i++,	"24mA, Ext Res: Gain Error");
			OffsetTrimCode24m		= TP.Program.CreateTestID(i++,	"24mA, Ext Res: Offset Trim Code");
			OffsetError24m			= TP.Program.CreateTestID(i++,	"24mA, Ext Res: Offset Error");

			GainTrimCode20mBip		= TP.Program.CreateTestID(i++,	"+/-20mA, Ext Res: Gain Trim Code");
			GainError20mBip			= TP.Program.CreateTestID(i++,	"+/-20mA, Ext Res: Gain Error");
			OffsetTrimCode20mBip	= TP.Program.CreateTestID(i++,	"+/-20mA, Ext Res: Offset Trim Code");
			OffsetError20mBip		= TP.Program.CreateTestID(i++,	"+/-20mA, Ext Res: Offset Error");

			GainTrimCode24mBip		= TP.Program.CreateTestID(i++,	"+/-24mA, Ext Res: Gain Trim Code");
			GainError24mBip			= TP.Program.CreateTestID(i++,	"+/-24mA, Ext Res: Gain Error");
			OffsetTrimCode24mBip	= TP.Program.CreateTestID(i++,	"+/-24mA, Ext Res: Offset Trim Code");
			OffsetError24mBip		= TP.Program.CreateTestID(i++,	"+/-24mA, Ext Res: Offset Error");
			#endregion

			BlowFuseMem			= TP.Program.CreateTestID(i++,		"Memory Fuse Blow");
			BlowMasterFuse		= TP.Program.CreateTestID(i++,		"Master Fuse Blow");

			#region PostTrimIds

			int msIndex;
			int numOverranges = 2;

			App.VLoadOptions load = App.VLoadOptions.LOAD_OFF;
			msIndex = 0;

			#region VoltageRanges
			i=274;
			for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimVRanges; rangeIndex++)
			{
				//i++;
				App.RangeOptions range = App.TC.ActiveRanges[App.TC.NumActiveIRanges + rangeIndex];

				testName = String.Format("{0}, PostTrim ZS Err {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
				vPostTrimZSError[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

				testName = String.Format("{0}, PostTrim FS Err {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
				vPostTrimFSError[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

				if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751) ||
					(App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
				{
					testName = String.Format("{0}, PostTrim Offset {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					vPostTrimOffset[rangeIndex] = TP.Program.CreateTestID(i++,  testName);
				}

				if(App.TC.RangeData[(int)range].MidValue == 0.0)
				{
					testName = String.Format("{0}, PostTrim MS Err {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					vPostTrimMSOffset[msIndex] = TP.Program.CreateTestID(i++,  testName);
					msIndex++;
				}

				//i++;

				testName = String.Format("{0}, PostTrim Gain {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
				vPostTrimGain[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

				testName = String.Format("{0}, PostTrim Lin {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
				vPostTrimLin[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

				testName = String.Format("{0}, Pos TUE {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
				vPostTrimPosTueReal[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

				testName = String.Format("{0}, Neg TUE {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
				vPostTrimNegTueReal[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

				if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751)||
					(App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
				{
					//testName = String.Format("{0}, Calcul D'band {1},{2}", App.TC.RangeData[(int)range].RangeName, load, resourceSelect);
					//vPostTrimDeadband[rangeIndex,(int)load, (int)resourceSelect] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, Extrapol D'band {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					vPostTrimDBcalc[rangeIndex] = TP.Program.CreateTestID(i++,  testName);
				}
			}
			#endregion

			#region currentRanges
			i = 392;
			for(App.ResSel rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				msIndex = 0;
				for(App.RangeOptions range = 0; (int)range < App.Globals.NumTrimIRanges; range++)
				{
					if((rSel == App.ResSel.R_INT) && (range == App.RangeOptions.FOUR_TWENTY_MA))
					{
						i = 434;
					}
					//i++;
					
					testName = String.Format("{0}, PostTrim ZS Err {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
					iPostTrimZSError[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, PostTrim FS Err {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
					iPostTrimFSError[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);

					if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751)||
						(App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
					{
						testName = String.Format("{0}, PostTrim Offset {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
						iPostTrimOffset[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);
					}

					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						testName = String.Format("{0}, PostTrim MS Err {1},DIG", App.TC.RangeData[(int)range].RangeName, rSel);
						iPostTrimMSOffset[msIndex,(int)rSel] = TP.Program.CreateTestID(i++,  testName);
						msIndex++;
					}

					//i++;

					testName = String.Format("{0}, PostTrim Gain {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
					iPostTrimGain[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, PostTrim Lin {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
					iPostTrimLin[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, Pos TUE {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
					iPostTrimPosTueReal[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, Neg TUE {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
					iPostTrimNegTueReal[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);

					if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751)||
						(App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
					{
						//testName = String.Format("{0}, Calcul. D'band {1},{2}", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel, resourceSelect);
						//iPostTrimDeadband[(int)range, (int)rSel, (int)resourceSelect] = TP.Program.CreateTestID(i++,  testName);

						testName = String.Format("{0}, Extrapol. D'band {1},DIG", App.TC.RangeData[(int)App.TC.ActiveRanges[(int)range]].RangeName, rSel);
						iPostTrimDBcalc[(int)range, (int)rSel] = TP.Program.CreateTestID(i++,  testName);
					}
				}
			}
			#endregion

			#region overranges (RW only)
			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				App.RangeOptions range = App.RangeOptions.TWELVE_V;

				for(int rangeIndex = 0; rangeIndex < numOverranges; rangeIndex++)
				{
					testName = String.Format("{0}, PostTrim ZS Err {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					overRangeZS[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, PostTrim FS Err {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					overRangeFS[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						testName = String.Format("{0}, PostTrim MS Err {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
						overRangeMS[rangeIndex] = TP.Program.CreateTestID(i++,  testName);
					}

					testName = String.Format("{0}, PostTrim Gain {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					overRangeGain[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, PostTrim Lin {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					overRangeLin[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, Pos TUE {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					overRangePosTue[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

					testName = String.Format("{0}, Neg TUE {1},DIG", App.TC.RangeData[(int)range].RangeName, load);
					overRangeNegTue[rangeIndex] = TP.Program.CreateTestID(i++,  testName);

					range = range + 2;
				}
			}
			#endregion


			#endregion

			i = 491;
			PowerupToZero		= TP.Program.CreateTestID(i++,		"Powerup to 0V");
			PowerupToMid		= TP.Program.CreateTestID(i++,		"Powerup to Midscale");
			PowerupTristate		= TP.Program.CreateTestID(i++,		"Powerup Tristate");

			VsensenFunc			= TP.Program.CreateTestID(i++,		"VsenseN Functionality");

			VRangeAIdd			= TP.Program.CreateTestID(i++,		"Voltage Range AIdd");
			VRangeAIss			= TP.Program.CreateTestID(i++,		"Voltage Range AIss");
			VRangeDIcc			= TP.Program.CreateTestID(i++,		"Voltage Range DIcc");

			IRangeAIdd			= TP.Program.CreateTestID(i++,		"Current Range AIdd");
			IRangeAIss			= TP.Program.CreateTestID(i++,		"Current Range AIss");
			IRangeDIcc			= TP.Program.CreateTestID(i++,		"Current Range DIcc");

			DigLevelFunc		= TP.Program.CreateTestID(i++,		"Digital Levels Func");
			PecFunc				= TP.Program.CreateTestID(i++,		"PEC Func");

			#region TestPoints
			vinMeas           = TP.Program.CreateTestID(i++,		"Vin Meas");
			vinBufOp          = TP.Program.CreateTestID(i++,		"O/P of Vin Buffer");
			vinBufOffset      = TP.Program.CreateTestID(i++,		"Vin Buffer Offset");
			vrefMeas          = TP.Program.CreateTestID(i++,		"Vref Meas");
			vrefBufOp         = TP.Program.CreateTestID(i++,		"O/P of Vref Buffer");
			vrefBufOffset     = TP.Program.CreateTestID(i++,		"Vref Buffer Offset");
			vOfsDac           = TP.Program.CreateTestID(i++,		"Vofs DAC");
			vOfsIp            = TP.Program.CreateTestID(i++,		"Negative I/P of Vofs Buffer");
			vOfsBufOffset     = TP.Program.CreateTestID(i++,		"Vofs Buffer Offset");
			vDacVmode         = TP.Program.CreateTestID(i++,		"Vdac - gain trim DAC O/P (Vmode)");
			//vinNeg            = TP.Program.CreateTestID(i++,		"Vin 1V Neg");
			//opBufVinOffset    = TP.Program.CreateTestID(i++,		"Op Buf lVin Offset");
			//OpBufVofsIp       = TP.Program.CreateTestID(i++,		"Voff lv neg");
			vDacImode         = TP.Program.CreateTestID(i++,		"Vdac - gain trim DAC O/P (Imode)");
			Vref_div2         = TP.Program.CreateTestID(i++,		"Vref/2");
			VtoItestpoint     = TP.Program.CreateTestID(i++,		"VtoI testpoint1");
			VtoIoBufOffs      = TP.Program.CreateTestID(i++,		"VtoIo Buf Offset");
			#endregion

			AddrFunc			= TP.Program.CreateTestID(i++,		"Address Func");
			ClrFunc				= TP.Program.CreateTestID(i++,		"CLEAR Func");
			ResetFunc			= TP.Program.CreateTestID(i++,		"Reset Func");
			InvalidWrites		= TP.Program.CreateTestID(i++,		"Invalid Writes Check");

			#region Alarms
			PecFaultFunc		= TP.Program.CreateTestID(i++,		"PEC Fault Func");
			OverTempFaultFunc	= TP.Program.CreateTestID(i++,		"Temp Shutdown Func");


			IFaultFunc			= TP.Program.CreateTestID(i++,		"Iout Open Cct Fault Func");
			ComplFuncAvdd		= TP.Program.CreateTestID(i++,		"Iout Accuracy @ AVdd+2.5V");
			IdealIoutVdd		= TP.Program.CreateTestID(i++,		"Ideal Iout, Vdd Compl Test");
			ComplianceVvdd		= TP.Program.CreateTestID(i++,		"AVdd Compliance Voltage");
			VddAlarmIout		= TP.Program.CreateTestID(i++,		"Vdd Comp, Iout @ alarm enable");
			VddCurrAlrmDeltaFSR	= TP.Program.CreateTestID(i++,		"Vdd Iout FSR change @alarm");
			VddCurrComplDeltaFSR= TP.Program.CreateTestID(i++,		"Vdd Iout FSR change @compl");

			AlarmVdd			= TP.Program.CreateTestID(i++,		"Vdd voltage on Alarm");
			ComplFuncAvss		= TP.Program.CreateTestID(i++,		"Iout Accuracy @ AVss-2.5V");
			IdealIoutVss		= TP.Program.CreateTestID(i++,		"IdealIout, Vss Compl Test");
			ComplianceVvss		= TP.Program.CreateTestID(i++,		"AVss Compliance Voltage");
			VssAlarmIout		= TP.Program.CreateTestID(i++,		"Vss Comp, Iout @ alarm enable");
			VssCurrAlrmDeltaFSR	= TP.Program.CreateTestID(i++,		"Vss Iout FSR change @alarm");
			VssCurrComplDeltaFSR= TP.Program.CreateTestID(i++,		"Vss Iout FSR change @compl");
			AlarmVss			= TP.Program.CreateTestID(i++,		"Vss voltage on Alarm");

			SwFaultPinFunc		= TP.Program.CreateTestID(i++,		"S/W mode Fault Pin Func");
			SwFault2mA5Func		= TP.Program.CreateTestID(i++,		"S/W mode Fault Pin 2.5mA load");

			VFaultFunc			= TP.Program.CreateTestID(i++,		"Vout Short Cct Fault Func");
			ShortCctCurPos		= TP.Program.CreateTestID(i++,		"Vout Short Cct Curr +ve");
			ShortCctCurNeg		= TP.Program.CreateTestID(i++,		"Vout Short Cct Curr -ve");
			VoutSwFaultPinFunc	= TP.Program.CreateTestID(i++,		"S/W mode VFault (Pin) Func");
			VoutSwFault2mA5Func	= TP.Program.CreateTestID(i++,		"S/W mode VFault (Pin) 2.5mA load");
			#endregion

			#region HwRanges
			HwTrimmedRangesFunc = TP.Program.CreateTestID(i++,		"HW Trimmed Ranges Func");

			Hw6vGainExtR		= TP.Program.CreateTestID(i++,		"HW 6V ExtR Gain,DIG");
			Hw6vOffsetExtR		= TP.Program.CreateTestID(i++,		"HW 6V ExtR Offset,DIG");
			Hw6vFSErrExtR		= TP.Program.CreateTestID(i++,		"HW 6V ExtR FS Error,DIG");

			Hw12vGainExtR		= TP.Program.CreateTestID(i++,		"HW 12V ExtR Gain,DIG");
			Hw12vOffsetExtR		= TP.Program.CreateTestID(i++,		"HW 12V ExtR Offset,DIG");
			Hw12vFSErrExtR		= TP.Program.CreateTestID(i++,		"HW 12V ExtR FS Error,DIG");

			Hw6vBipGainExtR		= TP.Program.CreateTestID(i++,		"HW 6VBip ExtR Gain,DIG");
			Hw6vBipOffsetExtR	= TP.Program.CreateTestID(i++,		"HW 6VBip ExtR Offset,DIG");
			Hw6vBipFSErrExtR	= TP.Program.CreateTestID(i++,		"HW 6VBip ExtR FS Error,DIG");

			Hw12vBipGainExtR	= TP.Program.CreateTestID(i++,		"HW 12VBip ExtR Gain,DIG");
			Hw12vBipOffsetExtR	= TP.Program.CreateTestID(i++,		"HW 12VBip ExtR Offset,DIG");
			Hw12vBipFSErrExtR	= TP.Program.CreateTestID(i++,		"HW 12VBip ExtR FS Error,DIG");

			Hw2v5BipGainExtR	= TP.Program.CreateTestID(i++,		"HW 2.5VBip ExtR Gain,DIG");
			Hw2v5BipOffsetExtR	= TP.Program.CreateTestID(i++,		"HW 2.5VBip ExtR Offset,DIG");
			Hw2v5BipFSErrExtR	= TP.Program.CreateTestID(i++,		"HW 2.5VBip ExtR FS Error,DIG");

			Hw44vGainExtR		= TP.Program.CreateTestID(i++,		"HW 44V ExtR Gain,DIG");
			Hw44vOffsetExtR		= TP.Program.CreateTestID(i++,		"HW 44V ExtR Offset,DIG");
			Hw44vFSErrExtR		= TP.Program.CreateTestID(i++,		"HW 44V ExtR FS Error,DIG");


			Hw3ma92Gain			= TP.Program.CreateTestID(i++,		"HW 3.92-20.4mA IntR Gain");
			Hw3ma92Offset		= TP.Program.CreateTestID(i++,		"HW 3.92-20.4mA IntR Vin Offset");
			Hw3ma92FSErr		= TP.Program.CreateTestID(i++,		"HW 3.92-20.4mA IntR FS Error");

			Hw20ma4Gain			= TP.Program.CreateTestID(i++,		"HW 20.4mA IntR Gain");
			Hw20ma4Offset		= TP.Program.CreateTestID(i++,		"HW 20.4mA IntR Vin Offset");
			Hw20ma4FSErr		= TP.Program.CreateTestID(i++,		"HW 20.4mA IntR FS Error");

			Hw24ma5Gain			= TP.Program.CreateTestID(i++,		"HW 24.5mA IntR Gain");				
			Hw24ma5Offset		= TP.Program.CreateTestID(i++,		"HW 24.5mA IntR Vin Offset");
			Hw24ma5FSErr		= TP.Program.CreateTestID(i++,		"HW 24.5mA IntR FS Error");


			Hw6vGain			= TP.Program.CreateTestID(i++,		"HW 6V IntR Gain");
			Hw6vOffset			= TP.Program.CreateTestID(i++,		"HW 6V IntR Offset");
			Hw6vFSErr			= TP.Program.CreateTestID(i++,		"HW 6V IntR FS Error");

			Hw12vGain			= TP.Program.CreateTestID(i++,		"HW 12V IntR Gain");
			Hw12vOffset			= TP.Program.CreateTestID(i++,		"HW 12V IntR Offset");
			Hw12vFSErr			= TP.Program.CreateTestID(i++,		"HW 12V IntR FS Error");

			Hw6vBipGain			= TP.Program.CreateTestID(i++,		"HW 6VBip IntR Gain");
			Hw6vBipOffset		= TP.Program.CreateTestID(i++,		"HW 6VBip IntR Offset");
			Hw6vBipFSErr		= TP.Program.CreateTestID(i++,		"HW 6VBip IntR FS Error");

			Hw12vBipGain		= TP.Program.CreateTestID(i++,		"HW 12VBip IntR Gain");
			Hw12vBipOffset		= TP.Program.CreateTestID(i++,		"HW 12VBip IntR Offset");
			Hw12vBipFSErr		= TP.Program.CreateTestID(i++,		"HW 12VBip IntR FS Error");
			#endregion

			HwClearFunc			= TP.Program.CreateTestID(i++,		"HW Clear Functionality");
			HwReset				= TP.Program.CreateTestID(i++,		"HW Reset Func");
			HwVFaultFunc		= TP.Program.CreateTestID(i++,		"VFault Alarm Func");
			HwIFaultFunc		= TP.Program.CreateTestID(i++,		"IFault Alarm Func");
			HwVFault2mA5Func	= TP.Program.CreateTestID(i++,		"VFault Alarm Func, 2.5mA load");
			HwIFault2mA5Func	= TP.Program.CreateTestID(i++,		"IFault Alarm Func, 2.5mA load");

			IoutTristateLkg		= TP.Program.CreateTestID(5000,		"Iout Leakage2");
			vsensenLkg			= TP.Program.CreateTestID(5001,		"VsenseN Leakage2");
			VoutTristateLkg		= TP.Program.CreateTestID(5002,		"Vout Leakage2, PMU method");

			PostTestAIdd		= TP.Program.CreateTestID(i++,		"PostTest AIdd");
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				PostTestAIss				= TP.Program.CreateTestID(i++,		"PostTest AIss");
			PostTestDIcc				= TP.Program.CreateTestID(i++,		"PostTest DIcc");

			CoolOffset			= TP.Program.CreateTestID(i++,		"24mA offset");
			WarmOffset			= TP.Program.CreateTestID(i++,		"24mA offset after self heating");
			OffsetDelta			= TP.Program.CreateTestID(i++,		"SelfHeating Offset Delta");
			#endregion

			#region Char ID Init

			i = 2000;
			IFaultFuncChar			= TP.Program.CreateTestID(i++,		"Iout Open Cct Fault Func YA");
			IdealIoutVddChar		= TP.Program.CreateTestID(i++,		"Ideal Iout, Vdd Compl Test YA");
			ComplianceVvddChar		= TP.Program.CreateTestID(i++,		"AVdd Compliance Voltage YA");
			VddAlarmIoutChar		= TP.Program.CreateTestID(i++,		"Vdd Comp, Iout @ alarm enable YA");
			VddCurrAlrmDeltaFSRChar	= TP.Program.CreateTestID(i++,		"Vdd Iout FSR change @alarm YA");
			IdealIoutVssChar		= TP.Program.CreateTestID(i++,		"IdealIout, Vss Compl Test YA");
			ComplianceVvssChar		= TP.Program.CreateTestID(i++,		"AVss Compliance Voltage YA");
			VssAlarmIoutChar		= TP.Program.CreateTestID(i++,		"Vss Comp, Iout @ alarm enable YA");
			VssCurrAlrmDeltaFSRChar	= TP.Program.CreateTestID(i++,		"Vss Iout FSR change @alarm YA");
			SwFaultPinFuncChar		= TP.Program.CreateTestID(i++,		"S/W mode Fault Pin Func YA");
			SwFault2mA5FuncChar		= TP.Program.CreateTestID(i++,		"S/W mode Fault Pin 2.5mA load YA");

			i = 598;
			load = App.VLoadOptions.LOAD_OFF;

			for(load = App.VLoadOptions.LOAD_ON; load < (App.VLoadOptions.LOAD_OFF + 1); load++)
			{
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					testName = String.Format("5VBip Vss PSRR, Sinking {0}", load);
					vRangeVssPsrrSink[(int)load]      = TP.Program.CreateTestID(i++,  testName);
					testName = String.Format("5VBip Vdd PSRR, Sinking {0}", load);
					vRangeVddPsrrSink[(int)load]      = TP.Program.CreateTestID(i++,  testName);
					testName = String.Format("5VBip Vss PSRR, Sourcing {0}", load);
					vRangeVssPsrrSource[(int)load]      = TP.Program.CreateTestID(i++,  testName);
				}
				testName = String.Format("5VBip Vdd PSRR, Sourcing {0}", load);
				vRangeVddPsrrSource[(int)load]      = TP.Program.CreateTestID(i++,  testName);
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				iRangeVssPsrrSink   = TP.Program.CreateTestID(i++,  "20mABip Vss PSRR, Sinking");
				iRangeVddPsrrSink   = TP.Program.CreateTestID(i++,  "20mABip Vdd PSRR, Sinking");
				iRangeVssPsrrSource   = TP.Program.CreateTestID(i++,  "20mABip Vss PSRR, Sourcing");
			}
			iRangeVddPsrrSource   = TP.Program.CreateTestID(     i++,  "20mABip Vdd PSRR, Sourcing");

			for(load = App.VLoadOptions.LOAD_ON; load < (App.VLoadOptions.LOAD_OFF + 1); load++)
			{
				//i = 608;
				testName = String.Format("10VBip Vdd Headroom {0}", load);
				VddHeadroom[(int)load] = TP.Program.CreateTestID(i++,  testName);
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					testName = String.Format("10VBip Vss Headroom {0}", load);
					VssHeadroom[(int)load]      = TP.Program.CreateTestID(i++,  testName);
				}
			}
			VssHeadroomPass	  = TP.Program.CreateTestID(	 i++, "Vss 0.5V Headroom Check");
			VddHeadroomPass	  = TP.Program.CreateTestID(	 i++, "Vss 2.0V Headroom Check");

			t1Timing          = TP.Program.CreateTestID(     i++,  "T1 - SCLK Cycle Time");
			t2Timing          = TP.Program.CreateTestID(     i++,  "T2 - SCLK High Time");
			t3Timing          = TP.Program.CreateTestID(     i++,  "T3 - SCLK Low Time");
			t4Timing          = TP.Program.CreateTestID(     i++,  "T4 - SYNC FE to SCLK FE");
			t5Timing          = TP.Program.CreateTestID(     i++,  "T5 - 24th SCLK FE to SYNC RE");
			t5aTiming         = TP.Program.CreateTestID(     i++,  "T5 - 16th SCLK FE to SYNC RE");
			t6Timing          = TP.Program.CreateTestID(     i++,  "T6 - Min SYNC High Time (WR)");
			t7Timing          = TP.Program.CreateTestID(     i++,  "T7 - Data Setup Time");
			t8Timing          = TP.Program.CreateTestID(     i++,  "T8 - Data Hold Time");
			t9Timing          = TP.Program.CreateTestID(     i++,  "T9 - CLR Low Activation Time");
			t10Timing         = TP.Program.CreateTestID(     i++,  "T10 - CLR High Activation Time");
			t11Timing         = TP.Program.CreateTestID(     i++,  "T11 - Min SYNC HIGH TIME (RD)");
			t13Timing         = TP.Program.CreateTestID(     i++,  "T13 - Min Reset Pulsewidth");

			vih				  = TP.Program.CreateTestID(	 i++,  "Vih Level");
			vil				  = TP.Program.CreateTestID(	 i++,  "Vil Level");
			voh				  = TP.Program.CreateTestID(	 i++,  "Voh Level");
			vol				  = TP.Program.CreateTestID(	 i++,  "Vol Level");
			#endregion

			#region Board Checker ID Init
			i = 1000;

			// ID Name                [Selector]         Test #    Test Name
			TwelveVoltSupply	= TP.Program.CreateTestID( i++,		"12V Supply");
			DiodeDrop			= TP.Program.CreateTestID( i++,		"Diode Drop");
			RL101				= TP.Program.CreateTestID( i++,		"RL101");
			RL105				= TP.Program.CreateTestID( i++,		"RL105");
			RL108				= TP.Program.CreateTestID( i++,		"RL108");
			RL110				= TP.Program.CreateTestID( i++,		"RL110");
			RL111				= TP.Program.CreateTestID( i++,		"RL111");
			RL113				= TP.Program.CreateTestID( i++,		"RL113");
			RL114				= TP.Program.CreateTestID( i++,		"RL114");
			RL116				= TP.Program.CreateTestID( i++,		"RL116");
			RL117				= TP.Program.CreateTestID( i++,		"RL117");
			RL118				= TP.Program.CreateTestID( i++,		"RL118");
			RL119				= TP.Program.CreateTestID( i++,		"RL119");
			RL121				= TP.Program.CreateTestID( i++,		"RL121");

			RL201				= TP.Program.CreateTestID( i++,		"RL201");
			RL205				= TP.Program.CreateTestID( i++,		"RL205");
			RL208				= TP.Program.CreateTestID( i++,		"RL208");
			RL210				= TP.Program.CreateTestID( i++,		"RL210");
			RL211				= TP.Program.CreateTestID( i++,		"RL211");
			RL213				= TP.Program.CreateTestID( i++,		"RL213");
			RL214				= TP.Program.CreateTestID( i++,		"RL214");
			RL216				= TP.Program.CreateTestID( i++,		"RL216");
			RL217				= TP.Program.CreateTestID( i++,		"RL217");
			RL218				= TP.Program.CreateTestID( i++,		"RL218");
			RL221				= TP.Program.CreateTestID( i++,		"RL221");

			RL301				= TP.Program.CreateTestID( i++,		"RL301");
			RL305				= TP.Program.CreateTestID( i++,		"RL305");
			RL308				= TP.Program.CreateTestID( i++,		"RL308");
			RL310				= TP.Program.CreateTestID( i++,		"RL310");
			RL311				= TP.Program.CreateTestID( i++,		"RL311");
			RL313				= TP.Program.CreateTestID( i++,		"RL313");
			RL314				= TP.Program.CreateTestID( i++,		"RL314");
			RL316				= TP.Program.CreateTestID( i++,		"RL316");
			RL317				= TP.Program.CreateTestID( i++,		"RL317");
			RL318				= TP.Program.CreateTestID( i++,		"RL318");
			RL319				= TP.Program.CreateTestID( i++,		"RL319");
			RL321				= TP.Program.CreateTestID( i++,		"RL321");

			RL401				= TP.Program.CreateTestID( i++,		"RL401");
			RL405				= TP.Program.CreateTestID( i++,		"RL405");
			RL408				= TP.Program.CreateTestID( i++,		"RL408");
			RL410				= TP.Program.CreateTestID( i++,		"RL410");
			RL411				= TP.Program.CreateTestID( i++,		"RL411");
			RL413				= TP.Program.CreateTestID( i++,		"RL413");
			RL414				= TP.Program.CreateTestID( i++,		"RL414");
			RL416				= TP.Program.CreateTestID( i++,		"RL416");
			RL417				= TP.Program.CreateTestID( i++,		"RL417");
			RL418				= TP.Program.CreateTestID( i++,		"RL418");
			RL421				= TP.Program.CreateTestID( i++,		"RL421");

			RL63				= TP.Program.CreateTestID( i++,		"RL63");
			RL64				= TP.Program.CreateTestID( i++,		"RL64");

			RL102x				= TP.Program.CreateTestID( i++,		"RL102A & RL102B");
			RL120x				= TP.Program.CreateTestID( i++,		"RL120A & RL120B");
			RL202x				= TP.Program.CreateTestID( i++,		"RL202A & RL202B");
			RL302x				= TP.Program.CreateTestID( i++,		"RL302A & RL302B");
			RL320x				= TP.Program.CreateTestID( i++,		"RL320A & RL320B");
			RL402x				= TP.Program.CreateTestID( i++,		"RL402A & RL402B");

			RLx03				= TP.Program.CreateTestID( i++,		"RL103, RL203, RL303, RL403");
			RLx04				= TP.Program.CreateTestID( i++,		"RL104, RL204, RL304, RL404");
			RLx06				= TP.Program.CreateTestID( i++,		"RL106, RL206, RL306, RL406");
			RLx07				= TP.Program.CreateTestID( i++,		"RL107, RL207, RL307, RL407");
			RLx09				= TP.Program.CreateTestID( i++,		"RL109, RL209, RL309, RL409");
			RLx12				= TP.Program.CreateTestID( i++,		"RL112, RL212, RL312, RL412");
			RLx15				= TP.Program.CreateTestID( i++,		"RL115, RL215, RL315, RL415");
			RLx22				= TP.Program.CreateTestID( i++,		"RL122, RL222, RL322, RL422");

			HighVoltageRelays	= TP.Program.CreateTestID( i++,		"High Voltage Relays");

			MuxAVref			= TP.Program.CreateTestID( i++,		"MuxA - VRef");
			MuxAVin				= TP.Program.CreateTestID( i++,		"MuxA - Vin");
			MuxAIout			= TP.Program.CreateTestID( i++,		"MuxA - Iout");
			MuxBVsenseN			= TP.Program.CreateTestID( i++,		"MuxB - VsenseN");
			MuxBVoutScale		= TP.Program.CreateTestID( i++,		"MuxB - Vout Scale");
			MuxBDutgnd			= TP.Program.CreateTestID( i++,		"MuxB - Dutgnd");
			MuxCVgaincheck		= TP.Program.CreateTestID( i++,		"MuxC - VGainCheck");

			IoutLoadResLow		= TP.Program.CreateTestID( i++,		"Iout Low Load Value");
			IoutLoadResHigh		= TP.Program.CreateTestID( i++,		"Iout High Load Value");
			IoutLoadResRatio	= TP.Program.CreateTestID( i++,		"Iout Load Resistor Ratio");
			RextRes				= TP.Program.CreateTestID( i++,		"Rext Value");
			VoutScale1			= TP.Program.CreateTestID( i++,		"Vout Scale Cct1 Gain");
			VoutScale2			= TP.Program.CreateTestID( i++,		"Vout Scale Cct2 Gain");
			#endregion
		}
		#endregion

	}// end of class IDs
	#endregion

	//
	// Test application Limits
	// 
	#region Limits                          :
	/// <summary>
	/// Encapsulates all the Limits used by this test program.
	/// </summary>
	public class Limits
	{
		#region Normal Limits Declaration
		public static TestLimits BlowFuses;

		public static TestLimits FuseV;
		public static TestLimits AVss;
		public static TestLimits AVdd;
		public static TestLimits Vref;
		public static TestLimits DVcc;
		public static TestLimits Site;
		public static TestLimits Temp;
		public static TestLimits Wafer;

		public static TestLimits ContThreeDiodeNeg;
		public static TestLimits ContThreeDiodePos;
		public static TestLimits ContTwoDiodeNeg;
		public static TestLimits ContTwoDiodePos;
		public static TestLimits ContOneDiodeNeg;
		public static TestLimits ContOneDiodePos;
		public static TestLimits ContComp1;
		public static TestLimits ContComp2;
		public static TestLimits ContVsenseN;
		public static TestLimits ContVsenseP;
		public static TestLimits ContRext2Pos;
		public static TestLimits ContRext2Neg;
		public static TestLimits GndRes50mV;
		public static TestLimits GndRes100mV;
		public static TestLimits DiodeRes;
		public static TestLimits VoutHiDiodeRes;
		public static TestLimits Rext2LoDiodeRes;
		public static TestLimits VsenseNRes;

		public static TestLimits PwrupZS;
		public static TestLimits PwrupMS;
		public static TestLimits PwrupTristate;

		public static TestLimits AIddPreTrim;
		public static TestLimits AIdd;
		public static TestLimits RangeAIdd;
		public static TestLimits AIssPreTrim;
		public static TestLimits AIss;
		public static TestLimits vRangeAIss;
		public static TestLimits iRangeAIss;
		public static TestLimits DIcc;
		public static TestLimits RangeDIcc;

		public static TestLimits IloadHighMeas;
		public static TestLimits IloadLowMeas;
		public static TestLimits VinMeas;
		public static TestLimits VrefError;

		public static TestLimits Leakage;
		public static TestLimits IfaultLkg;
		public static TestLimits VsenseNLkg;
		public static TestLimits IoutLeakage;
		public static TestLimits VrefLkg;

		public static TestLimits PassFail;
		public static TestLimits MasterFuseRead;
		public static TestLimits DeviceID;

		public static TestLimits [] vGainTrimCode = new TestLimits[App.Globals.NumTrimVRanges];
		public static TestLimits [] vOffsetTrimCode = new TestLimits[App.Globals.NumTrimVRanges];
		public static TestLimits [,] iGainTrimCode = new TestLimits[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];
		public static TestLimits [,] iOffsetTrimCode = new TestLimits[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];

		public static TestLimits RangeVOffsetError;
		public static TestLimits RangeVOffsetError5v;
		public static TestLimits RangeVOffsetError10v;
		public static TestLimits RangeVOffsetError5vBip;
		public static TestLimits RangeVOffsetError10vBip;
		public static TestLimits RangeVOffsetError40v;

		public static TestLimits RangeVZscaleError5v;
		public static TestLimits RangeVZscaleError10v;
		public static TestLimits RangeVZscaleError5vBip;
		public static TestLimits RangeVZscaleError10vBip;
		public static TestLimits RangeVZscaleError40v;

		public static TestLimits RangeVFSError;

		public static TestLimits [] RangeVMscaleError = new TestLimits[2];
		public static TestLimits RangeVGainError;
		public static TestLimits RangeVGainError40v;
		public static TestLimits RWVGainError10v;
		public static TestLimits RWVtue10v;

		public static TestLimits RangeVTue;
		public static TestLimits RangeVLin;

		public static TestLimits RangeIOffset;
		public static TestLimits [,] RangeIOffsetError = new TestLimits[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];
		public static TestLimits [] RangeIFSError = new TestLimits[App.Consts.NUM_RES_MODES];
		public static TestLimits [,] RangeIZscaleError = new TestLimits[App.Globals.NumTrimIRanges, App.Consts.NUM_RES_MODES];
		public static TestLimits [,] RangeIMscaleError = new TestLimits[2, App.Consts.NUM_RES_MODES];
		public static TestLimits [] RangeIGainError = new TestLimits[App.Consts.NUM_RES_MODES];
		public static TestLimits RangeITuePos;
		public static TestLimits RangeITueNeg;
		public static TestLimits RangeILinUni;
		public static TestLimits RangeILinBip;
		public static TestLimits RangeDeadband;

		public static TestLimits OverrangeIGain;
		public static TestLimits OverrangeIOffset;
		public static TestLimits OverrangeIVinOffset;
		public static TestLimits OverrangeVGain;
		public static TestLimits OverrangeVOffset;
		public static TestLimits OverrangeVGain44v;
		public static TestLimits OverrangeVOffset44v;

		public static TestLimits Vgen7V;
		public static TestLimits Vgen5V;

		public static TestLimits Read_X_Coordinate;
		public static TestLimits Read_Y_Coordinate;
		public static TestLimits Read_Wafer_number;

		public static TestLimits PreIbias;
		public static TestLimits IbiasCode;
		public static TestLimits PostIbias;
		public static TestLimits TcCode;

		public static TestLimits ShortCctCurPos;
		public static TestLimits ShortCctCurNeg;
		public static TestLimits ComplianceV;
		public static TestLimits Vsscompliance;
		public static TestLimits Vddcompliance;
		public static TestLimits complianceIout;
		public static TestLimits compIoutFSR;
		public static TestLimits ioutAccuracy;

		public static TestLimits VsenseNshift;

		public static TestLimits SelfHeatOffset;
		#endregion

		#region Char Limits Declaration
		public static TestLimits Ipsrr;
		public static TestLimits Vpsrr;
		public static TestLimits InternalNodes;
		public static TestLimits InternalOffsets;

		public static TestLimits txCLRtime;
		public static TestLimits t8HoldTime;
		public static TestLimits txSyncSetupHold;
		public static TestLimits t7SetupTime;
		public static TestLimits txPulsewidth;
		public static TestLimits t1Timing;

		public static TestLimits vih;
		public static TestLimits vil;
		public static TestLimits voh;
		public static TestLimits vol;
		
		#endregion

		#region Board Checker Limits Declaration
		public static TestLimits TwelveVoltSupply;
		public static TestLimits DiodeDrop;
		public static TestLimits SingleRelay;
		public static TestLimits DoubleRelay;
		public static TestLimits QuadRelay;
		public static TestLimits HighVoltageRelays;
		public static TestLimits MuxCheckPointFiveVolt;
		public static TestLimits MuxCheckTwoVolt;
		public static TestLimits MuxCheckOneVolt;
		public static TestLimits MuxCheckZeroVolt;
		public static TestLimits IoutResistorRatio;
		public static TestLimits IoutHighResistor;
		public static TestLimits IoutLowResistor;
		public static TestLimits ScaleCct2;
		public static TestLimits ScaleCct1;
		public static TestLimits RextValue;
		public static TestLimits VscaleLowLoad;
		public static TestLimits VscaleHighLoad;
		#endregion


		/// <summary>
		/// Initialize limits.
		/// </summary>
		public static void Load ( )
		{
			#region Normal Limits Init
			//
			// Limit Name             [Selector]            Lower   Upper  Units
			//
			Site              = TP.Program.CreateTestLimits(-0.1  , 8.1   , "Site");
			DVcc              = TP.Program.CreateTestLimits(-0.1  , 5.51  , "V");

			AVdd              = TP.Program.CreateTestLimits(-0.1  , 60.1  , "V");
			AVdd.SetLimits(    App.Selectors.PD_LV_5750  , -0.1  , 26.5  );
			AVdd.SetLimits(    App.Selectors.QC_LV_5750  , -0.05 , 26.5  );

			AVdd.SetLimits(    App.Selectors.QC_HV_5751  , -0.05 , 60.1 );
			AVdd.SetLimits(	   App.Selectors.PD_HV_5751	, -0.1	, 60.1 );

			AVdd.SetLimits(    App.Selectors.PD_LV_5750_1  , -0.1  , 26.5  );
			AVdd.SetLimits(    App.Selectors.QC_LV_5750_1  , -0.05 , 26.5  );

			AVdd.SetLimits(    App.Selectors.PD_LV_5750_2  , -0.1  , 26.5  );
			AVdd.SetLimits(    App.Selectors.QC_LV_5750_2  , -0.05 , 26.5  );

			AVdd.SetLimits(    App.Selectors.PD_RW_5750  , -0.1  , 26.5  );
			AVdd.SetLimits(    App.Selectors.QC_RW_5750  , -0.05 , 26.5  );

			AVdd.SetLimits(    App.Selectors.QC_HV_5749  , -0.05 , 60.1 );
			AVdd.SetLimits(	   App.Selectors.PD_HV_5749	, -0.1	, 60.1 );


			AVss               = TP.Program.CreateTestLimits(-26.5 , 0.1   , "V");
			AVss.SetLimits(    App.Selectors.PD_LV_5750  , -26.5 , 0.1  );
			AVss.SetLimits(    App.Selectors.QC_LV_5750  , -26.5 , 0.1 );

			AVss.SetLimits(    App.Selectors.QC_HV_5751  , -0.1 , 0.1 );
			AVss.SetLimits(    App.Selectors.PD_HV_5751  , -0.1 , 0.1  );

			AVss.SetLimits(    App.Selectors.PD_LV_5750_1  , -26.5 , 0.1  );
			AVss.SetLimits(    App.Selectors.QC_LV_5750_1  , -26.5 , 0.1 );

			AVss.SetLimits(    App.Selectors.PD_LV_5750_2  , -26.5 , 0.1  );
			AVss.SetLimits(    App.Selectors.QC_LV_5750_2  , -26.5 , 0.1 );

			AVss.SetLimits(    App.Selectors.PD_RW_5750  , -26.5 , 0.1  );
			AVss.SetLimits(    App.Selectors.QC_RW_5750  , -26.5 , 0.1 );

			AVss.SetLimits(    App.Selectors.QC_HV_5749  , -0.1 , 0.1 );
			AVss.SetLimits(    App.Selectors.PD_HV_5749  , -0.1 , 0.1  );

			Vref				= TP.Program.CreateTestLimits(4.095,		4.097,		"V");
			Vref.SetLimits(		App.Selectors.PD_LV_5750,	4.095,	4.097);
			Vref.SetLimits(		App.Selectors.QC_LV_5750,	4.095,	4.097);

			Vref.SetLimits(		App.Selectors.PD_HV_5751,	4.095,	4.097);
			Vref.SetLimits(		App.Selectors.QC_HV_5751,	4.095,	4.097);

			Vref.SetLimits(		App.Selectors.PD_HV_5749,	4.095,	4.097);
			Vref.SetLimits(		App.Selectors.QC_HV_5749,	4.095,	4.097);

			Vref.SetLimits(		App.Selectors.PD_LV_5750_1,	1.24,	1.26);
			Vref.SetLimits(		App.Selectors.QC_LV_5750_1,	1.24,	1.26);

			Vref.SetLimits(		App.Selectors.PD_LV_5750_2,	2.49,	2.51);
			Vref.SetLimits(		App.Selectors.QC_LV_5750_2,	2.49,	2.51);

			Vref.SetLimits(		App.Selectors.PD_RW_5750,	4.095,	4.097);
			Vref.SetLimits(		App.Selectors.QC_RW_5750,	4.095,	4.097);

			Temp				= TP.Program.CreateTestLimits(-41,			106,		"C");
			Wafer				= TP.Program.CreateTestLimits(1,			12,			"");

			FuseV             = TP.Program.CreateTestLimits(6.49  , 6.51  , "V");
			BlowFuses         = TP.Program.CreateTestLimits( 0.0  , 1.0   , "T/F");

			#region continuityLimits
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				ContOneDiodePos			= TP.Program.CreateTestLimits(0.55,		0.75,		"V");
				ContOneDiodeNeg			= TP.Program.CreateTestLimits(-0.75,	-0.45,		"V");
				ContTwoDiodePos			= TP.Program.CreateTestLimits(1.0,		1.3,		"V");
				ContTwoDiodeNeg			= TP.Program.CreateTestLimits(-1.8,		-0.8,		"V");
				ContThreeDiodePos		= TP.Program.CreateTestLimits(2.0,		2.7,		"V");
				ContThreeDiodeNeg		= TP.Program.CreateTestLimits(-2.7,		-1.2,		"V");
				ContComp1				= TP.Program.CreateTestLimits(1.9,		2.3,		"V");
				ContComp2				= TP.Program.CreateTestLimits(2.2,		2.7,		"V");
				ContVsenseN				= TP.Program.CreateTestLimits(2.4,		3.2,		"V");
				ContVsenseN.SetLimits(App.Selectors.PD_HV_5751, -0.5, 0.5);
				ContVsenseN.SetLimits(App.Selectors.QC_HV_5751, -0.5, 0.5);
				ContVsenseN.SetLimits(App.Selectors.PD_HV_5749, -0.5, 0.5);
				ContVsenseN.SetLimits(App.Selectors.QC_HV_5749, -0.5, 0.5);

				ContVsenseP				= TP.Program.CreateTestLimits(3.0,		3.5,		"V");
				ContRext2Pos			= TP.Program.CreateTestLimits(0.6,		1.4,		"V");
				ContRext2Neg			= TP.Program.CreateTestLimits(-0.8,		-0.05,		"V");
				DiodeRes				= TP.Program.CreateTestLimits(40.0,		100.0,		"Ohm");
				VoutHiDiodeRes			= TP.Program.CreateTestLimits(170.0,	250.0,		"Ohm");
				Rext2LoDiodeRes			= TP.Program.CreateTestLimits(10.0,		40.0,		"Ohm");
				VsenseNRes				= TP.Program.CreateTestLimits(2.0,		20.0,		"Ohm");
			
				GndRes50mV				= TP.Program.CreateTestLimits(4.6,		6.0,		"Ohm");
				GndRes100mV				= TP.Program.CreateTestLimits(5.0,		6.0,		"Ohm");
			}
			else
			{
				ContOneDiodePos			= TP.Program.CreateTestLimits(0.55,		0.9,		"V");
				ContOneDiodeNeg			= TP.Program.CreateTestLimits(-0.75,	-0.35,		"V");
				ContTwoDiodePos			= TP.Program.CreateTestLimits(0.7,		1.5,		"V");
				ContTwoDiodeNeg			= TP.Program.CreateTestLimits(-1.8,		-0.8,		"V");
				ContThreeDiodePos		= TP.Program.CreateTestLimits(1.8,		2.7,		"V");
				ContThreeDiodeNeg		= TP.Program.CreateTestLimits(-2.7,		-1.2,		"V");
				ContComp1				= TP.Program.CreateTestLimits(1.9,		2.3,		"V");
				ContComp2				= TP.Program.CreateTestLimits(2.2,		2.7,		"V");
				ContVsenseN				= TP.Program.CreateTestLimits(2.4,		3.2,		"V");
				ContVsenseN.SetLimits(App.Selectors.PD_HV_5751, -0.5, 0.5);
				ContVsenseN.SetLimits(App.Selectors.QC_HV_5751, -0.5, 0.5);
				ContVsenseN.SetLimits(App.Selectors.PD_HV_5749, -0.5, 0.5);
				ContVsenseN.SetLimits(App.Selectors.QC_HV_5749, -0.5, 0.5);

				ContVsenseP				= TP.Program.CreateTestLimits(2.5,		3.5,		"V");
				ContRext2Pos			= TP.Program.CreateTestLimits(0.6,		1.4,		"V");
				ContRext2Neg			= TP.Program.CreateTestLimits(-0.8,		-0.05,		"V");
				DiodeRes				= TP.Program.CreateTestLimits(40.0,		100.0,		"Ohm");
				VoutHiDiodeRes			= TP.Program.CreateTestLimits(170.0,	250.0,		"Ohm");
				Rext2LoDiodeRes			= TP.Program.CreateTestLimits(10.0,		500.0,		"Ohm");
				VsenseNRes				= TP.Program.CreateTestLimits(2.0,		20.0,		"Ohm");
			
				GndRes50mV				= TP.Program.CreateTestLimits(4.0,		7.0,		"Ohm");
				GndRes100mV				= TP.Program.CreateTestLimits(4.0,		7.0,		"Ohm");

			}
			#endregion

			PwrupZS					= TP.Program.CreateTestLimits(0.0001,	0.02,		"V");
			PwrupMS					= TP.Program.CreateTestLimits(2.48,		2.51,		"V");
			PwrupTristate			= TP.Program.CreateTestLimits(-700,		700,		"nA");

			#region supplyCurrents
			AIddPreTrim				= TP.Program.CreateTestLimits(0.1 ,		6.5 ,		"mA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				AIddPreTrim.SetLimits( App.Selectors.PD_LV_5750, 0.1 ,		6.5 );
				AIddPreTrim.SetLimits( App.Selectors.QC_LV_5750, 0.1 ,		6.5 );

				AIddPreTrim.SetLimits( App.Selectors.PD_HV_5751, 2.83 ,		4.8 );
				AIddPreTrim.SetLimits( App.Selectors.QC_HV_5751, 2.83 ,		4.8 );

				AIddPreTrim.SetLimits( App.Selectors.PD_HV_5749, 2.83 ,		4.8 );
				AIddPreTrim.SetLimits( App.Selectors.QC_HV_5749, 2.83 ,		4.8 );

				AIddPreTrim.SetLimits( App.Selectors.PD_LV_5750_1, 0.1 ,		6.5 );
				AIddPreTrim.SetLimits( App.Selectors.QC_LV_5750_1, 0.1 ,		6.5 );

				AIddPreTrim.SetLimits( App.Selectors.PD_LV_5750_2, 0.1 ,		6.5 );
				AIddPreTrim.SetLimits( App.Selectors.QC_LV_5750_2, 0.1 ,		6.5 );

				AIddPreTrim.SetLimits( App.Selectors.PD_RW_5750, 0.1 ,		6.5 );
				AIddPreTrim.SetLimits( App.Selectors.QC_RW_5750, 0.1 ,		6.5 );
			}
			AIdd					= TP.Program.CreateTestLimits(0.1,		5.1,		"mA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				AIdd.SetLimits( App.Selectors.PD_LV_5750, 0.1,		5.1 );
				AIdd.SetLimits( App.Selectors.QC_LV_5750, 0.1,		5.1 );

				AIdd.SetLimits( App.Selectors.PD_HV_5751, 2.83,		3.81 );
				AIdd.SetLimits( App.Selectors.QC_HV_5751, 2.83,		3.81 );

				AIdd.SetLimits( App.Selectors.PD_HV_5749, 2.83,		4.2 );
				AIdd.SetLimits( App.Selectors.QC_HV_5749, 2.83,		4.2 );

				AIdd.SetLimits( App.Selectors.PD_LV_5750_1, 0.1,		5.1 );
				AIdd.SetLimits( App.Selectors.QC_LV_5750_1, 0.1,		5.1 );

				AIdd.SetLimits( App.Selectors.PD_LV_5750_2, 0.1,		5.1 );
				AIdd.SetLimits( App.Selectors.QC_LV_5750_2, 0.1,		5.1 );

				AIdd.SetLimits( App.Selectors.PD_RW_5750, 0.1,		5.1 );
				AIdd.SetLimits( App.Selectors.QC_RW_5750, 0.1,		5.1 );
			}
			RangeAIdd				= TP.Program.CreateTestLimits(0.1 ,		6.0 ,		"mA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeAIdd.SetLimits( App.Selectors.PD_LV_5750, 0.1 ,		6.0 );
				RangeAIdd.SetLimits( App.Selectors.QC_LV_5750, 0.1,		6.0 );

				RangeAIdd.SetLimits( App.Selectors.PD_HV_5751, 0.1,		4.6 );
				RangeAIdd.SetLimits( App.Selectors.QC_HV_5751, 0.1,		4.6 );

				RangeAIdd.SetLimits( App.Selectors.PD_HV_5749, 0.1,		4.6 );
				RangeAIdd.SetLimits( App.Selectors.QC_HV_5749, 0.1,		4.6 );

				RangeAIdd.SetLimits( App.Selectors.PD_LV_5750_1, 0.1,		6.0 );
				RangeAIdd.SetLimits( App.Selectors.QC_LV_5750_1, 0.1,		6.0 );

				RangeAIdd.SetLimits( App.Selectors.PD_LV_5750_2, 0.1,		6.0 );
				RangeAIdd.SetLimits( App.Selectors.QC_LV_5750_2, 0.1,		6.0 );

				RangeAIdd.SetLimits( App.Selectors.PD_RW_5750, 0.1 ,		6.0 );
				RangeAIdd.SetLimits( App.Selectors.QC_RW_5750, 0.1,		6.0 );
			}

			AIssPreTrim				= TP.Program.CreateTestLimits(-6.2 ,	-0.1 ,		"mA");
			AIss					= TP.Program.CreateTestLimits(-2.4,		-0.1,		"mA");
			iRangeAIss				= TP.Program.CreateTestLimits(-2.9,		-1.8,		"mA");
			vRangeAIss				= TP.Program.CreateTestLimits(-2.9,		-1.9,		"mA");

			DIcc					= TP.Program.CreateTestLimits( 0.1,		 0.8,		"uA");

			RangeDIcc				= TP.Program.CreateTestLimits( 0.1,		0.8,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeDIcc.SetLimits( App.Selectors.PD_LV_5750, 0.1 ,		0.8 );
				RangeDIcc.SetLimits( App.Selectors.QC_LV_5750, 0.1,		0.8 );

				RangeDIcc.SetLimits( App.Selectors.PD_HV_5751, 0.1,		0.52 );
				RangeDIcc.SetLimits( App.Selectors.QC_HV_5751, 0.1,		0.52 );

				RangeDIcc.SetLimits( App.Selectors.PD_HV_5749, 0.1,		0.52 );
				RangeDIcc.SetLimits( App.Selectors.QC_HV_5749, 0.1,		0.52 );

				RangeDIcc.SetLimits( App.Selectors.PD_LV_5750_1, 0.1,		0.8 );
				RangeDIcc.SetLimits( App.Selectors.QC_LV_5750_1, 0.1,		0.8 );

				RangeDIcc.SetLimits( App.Selectors.PD_LV_5750_2, 0.1,		0.8 );
				RangeDIcc.SetLimits( App.Selectors.QC_LV_5750_2, 0.1,		0.8 );

				RangeDIcc.SetLimits( App.Selectors.PD_RW_5750, 0.1 ,		0.8 );
				RangeDIcc.SetLimits( App.Selectors.QC_RW_5750, 0.1,		0.8 );
			}
			#endregion

			VinMeas					= TP.Program.CreateTestLimits( -0.1 ,   4.1 ,		"V");
			VrefError				= TP.Program.CreateTestLimits( -0.1,	0.1,		"V");
			IloadLowMeas			= TP.Program.CreateTestLimits(299.5 , 300.5 ,		"Ohm");
			IloadHighMeas			= TP.Program.CreateTestLimits( 1790 ,  1810 ,		"Ohm");

			Leakage					= TP.Program.CreateTestLimits(-0.1 ,	0.1,		"uA");
			IfaultLkg				= TP.Program.CreateTestLimits(-0.3 ,	0.3 ,		"uA");
			VsenseNLkg				= TP.Program.CreateTestLimits(-2.0 ,	2.0 ,		"uA");
			IoutLeakage				= TP.Program.CreateTestLimits(-0.01 ,	0.01,		"uA");
			VrefLkg					= TP.Program.CreateTestLimits(-0.6 ,	0.6 ,		"uA");

			PassFail				= TP.Program.CreateTestLimits(-0.5 ,	0.5 ,		"");

			MasterFuseRead			= TP.Program.CreateTestLimits(-0.1 ,	1.1 ,		"");
			DeviceID				= TP.Program.CreateTestLimits(0.5 ,		4096 ,		"");

			Vgen5V					= TP.Program.CreateTestLimits(2.58,	2.6836 ,	"V");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				Vgen5V.SetLimits( App.Selectors.PD_LV_5750, 2.6253,	2.6836 );
				Vgen5V.SetLimits( App.Selectors.QC_LV_5750, 2.6253,	2.6836 );

				Vgen5V.SetLimits( App.Selectors.PD_HV_5751, 2.61,	2.6836 );
				Vgen5V.SetLimits( App.Selectors.QC_HV_5751, 2.61,	2.6836 );

				Vgen5V.SetLimits( App.Selectors.PD_HV_5749, 2.61,	2.6836 );
				Vgen5V.SetLimits( App.Selectors.QC_HV_5749, 2.61,	2.6836 );

				Vgen5V.SetLimits( App.Selectors.PD_LV_5750_1, 2.6253,	2.6836 );
				Vgen5V.SetLimits( App.Selectors.QC_LV_5750_1, 2.6253,	2.6836 );

				//Vgen5V.SetLimits( App.Selectors.PD_LV_5750_2, 2.6253,	2.6836 );//Was
				//Vgen5V.SetLimits( App.Selectors.QC_LV_5750_2, 2.6253,	2.6836 );//Was

				Vgen5V.SetLimits( App.Selectors.PD_LV_5750_2, 2.5800,	2.6836 );
				Vgen5V.SetLimits( App.Selectors.QC_LV_5750_2, 2.5800,	2.6836 );

				Vgen5V.SetLimits( App.Selectors.PD_RW_5750, 2.57,	2.7 );
				Vgen5V.SetLimits( App.Selectors.QC_RW_5750, 2.57,	2.7 );
			}
			Vgen7V					= TP.Program.CreateTestLimits(3.95 ,	4.1652 ,	"V");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				Vgen7V.SetLimits( App.Selectors.PD_LV_5750, 4.0245 ,	4.1652 );
				Vgen7V.SetLimits( App.Selectors.QC_LV_5750, 4.0245 ,	4.1652 );

				Vgen7V.SetLimits( App.Selectors.PD_HV_5751, 4.0 ,	4.1652 );
				Vgen7V.SetLimits( App.Selectors.QC_HV_5751, 4.0 ,	4.1652 );

				Vgen7V.SetLimits( App.Selectors.PD_HV_5749, 4.0 ,	4.1652 );
				Vgen7V.SetLimits( App.Selectors.QC_HV_5749, 4.0 ,	4.1652 );

				Vgen7V.SetLimits( App.Selectors.PD_LV_5750_1, 4.0245 ,	4.1652 );
				Vgen7V.SetLimits( App.Selectors.QC_LV_5750_1, 4.0245 ,	4.1652 );

				//Vgen7V.SetLimits( App.Selectors.PD_LV_5750_2, 4.0245 ,	4.1652 );//Was
				//Vgen7V.SetLimits( App.Selectors.QC_LV_5750_2, 4.0245 ,	4.1652 );//Was

				Vgen7V.SetLimits( App.Selectors.PD_LV_5750_2, 3.9500 ,	4.1652 );
				Vgen7V.SetLimits( App.Selectors.QC_LV_5750_2, 3.9500 ,	4.1652 );

				Vgen7V.SetLimits( App.Selectors.PD_RW_5750, 3.96 ,	4.18 );
				Vgen7V.SetLimits( App.Selectors.QC_RW_5750, 3.96 ,	4.18 );

			}

			Read_X_Coordinate	= TP.Program.CreateTestLimits(0,	100,	"X Coordinate");
			Read_Y_Coordinate	= TP.Program.CreateTestLimits(0,	100,	"Y Coordinate");
			Read_Wafer_number	= TP.Program.CreateTestLimits(0,	26,	"Wafer Number");


			PreIbias				= TP.Program.CreateTestLimits(1 ,		50 ,		"uA");
			IbiasCode				= TP.Program.CreateTestLimits(0 ,		16 ,		"");
			PostIbias				= TP.Program.CreateTestLimits(27.3 ,	32.7 ,		"uA");
			TcCode					= TP.Program.CreateTestLimits(-1,		3,			"");

			#region preTrimRangeLimits
			#region VrangeTrimCodes
			
			//0 - 5V offset/gain trim code limits
			#region 5vLimits
			int vIndexStart = 8;
			App.RangeOptions range = App.RangeOptions.FIVE_V;

			vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(7960,		8030,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 7960, 8030 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 7960, 8030 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 7960, 8030 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 7960, 8030 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 7960, 8030 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 7960, 8030 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 7820, 7920 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 7820, 7920 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 7820, 7920 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 7820, 7920 );
			
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );
			}

			vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(4500,		6800,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 4500, 6800 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 4500, 6800 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 4500, 6800 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 4500, 6800 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 4500, 6800 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 4500, 6800 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 2100, 4500 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 2100, 4500 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 2100, 4500 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 2100, 4500 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

			}
			#endregion

			//0 - 10V offset/gain trim code limits
			#region 10vLimits
			range = App.RangeOptions.TEN_V;

			vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(7970,		8030,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 7970, 8030 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 7970, 8030 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 7970, 8030 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 7970, 8030 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 7970, 8030 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 7970, 8030 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 7820, 7920 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 7820, 7920 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 7820, 7920 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 7820, 7920 );

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

			}

			vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(4500,		6800,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 4500, 6800 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 4500, 6800 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 4500, 6800 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 4500, 6800 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 4500, 6800 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 4500, 6800 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 2100, 4500 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 2100, 4500 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 2100, 4500 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 2100, 4500 );

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

			}
			#endregion

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//+/-5V offset/gain trim code limits
				#region 5vBipLimits
				range = App.RangeOptions.FIVE_V_BIP;

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(7970,		8030,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 7970, 8030 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 7970, 8030 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 7970, 8030 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 7970, 8030 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 7970, 8030 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 7970, 8030 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 7820, 7920 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 7820, 7920 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 7820, 7920 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 7820, 7920 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

				}

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(3300,		5100,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

				}
				#endregion

				//+/-10V offset/gain trim code limits
				#region 10vBipLimits
				range = App.RangeOptions.TEN_V_BIP;

				vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(7970,		8030,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 7970, 8030 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 7970, 8030 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 7970, 8030 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 7970, 8030 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 7970, 8030 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 7970, 8030 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 7820, 7920 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 7820, 7920 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 7820, 7920 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 7820, 7920 );

					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
					vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

				}

				vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart] = TP.Program.CreateTestLimits(3300,		5100,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5751, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5751, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_HV_5749, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_HV_5749, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_1, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_1, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_LV_5750_2, 3300, 5100 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_LV_5750_2, 3300, 5100 );

					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
					vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

				}
				#endregion
			}
			else
			{
				//0 - 40V offset/gain trim code limits
				#region 40vLimits
				range = App.RangeOptions.FORTY_V;
				int index = 2;	//3rd location in array

				vGainTrimCode[index] = TP.Program.CreateTestLimits(7970,		8050,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					vGainTrimCode[index].SetLimits( App.Selectors.PD_HV_5751, 7970, 8050 );
					vGainTrimCode[index].SetLimits( App.Selectors.QC_HV_5751, 7970, 8050 );

					vGainTrimCode[index].SetLimits( App.Selectors.PD_HV_5749, 7970, 8050 );
					vGainTrimCode[index].SetLimits( App.Selectors.QC_HV_5749, 7970, 8050 );
				}

				vOffsetTrimCode[index] = TP.Program.CreateTestLimits(5000,		7500,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					vOffsetTrimCode[index].SetLimits( App.Selectors.PD_HV_5751, 5000, 7500 );
					vOffsetTrimCode[index].SetLimits( App.Selectors.QC_HV_5751, 5000, 7500 );

					vOffsetTrimCode[index].SetLimits( App.Selectors.PD_HV_5749, 5000, 7500 );
					vOffsetTrimCode[index].SetLimits( App.Selectors.QC_HV_5749, 5000, 7500 );
				}
				#endregion
			}
			#endregion

			#region IrangeTrimCodes
			
			//4 - 20mA offset/gain trim code limits
			#region 4to20Limits
			range = App.RangeOptions.FOUR_TWENTY_MA;
			App.ResSel rSel = App.ResSel.R_INT;

			iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(3600,		5600,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 3600, 5600 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 3600, 5600 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 3600, 5600 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 3600, 5600 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 3600, 5600 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 3600, 5600 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 3600, 5600 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 3600, 5600 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 3600, 5600 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 3600, 5600 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

			}

			iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(1500,		4500,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 1500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 1500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 1500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 1500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 1500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 1500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 1500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 1500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 1500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 1500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );
			}

			rSel = App.ResSel.R_EXT;
			iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(5235,		5256,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 5235, 5256 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 5235, 5256 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 5235, 5256 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 5235, 5256 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 5235, 5256 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 5235, 5256 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 5140, 5190 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 5140, 5190 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 5140, 5190 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 5140, 5190 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );
			}

			iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(3930,		4130,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 3930, 4130 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 3930, 4130 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 3930, 4130 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 3930, 4130 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 3930, 4130 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 3930, 4130 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 3750, 3950 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 3750, 3950 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 3750, 3950 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 3750, 3950 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

			}
			#endregion

			//0 - 20mA offset/gain trim code limits
			#region 0to20Limits
			range = App.RangeOptions.TWENTY_MA;
			rSel = App.ResSel.R_INT;

			iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(4500,		7000,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 4500, 7000 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 4500, 7000 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 4500, 7000 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 4500, 7000 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 4500, 7000 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 4500, 7000 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 4500, 7000 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 4500, 7000 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 4500, 7000 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 4500, 7000 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );
			}

			iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(150,		650,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 150, 650 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 150, 650 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 150, 650 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 150, 650 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 150, 650 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 150, 650 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 150, 650 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 150, 650 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 150, 650 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 150, 650 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );
			}

			rSel = App.ResSel.R_EXT;

			iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(6540,		6575,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 6540, 6575 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 6540, 6575 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 6540, 6575 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 6540, 6575 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 6540, 6575 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 6540, 6575 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 6420, 6480 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 6420, 6480 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 6420, 6480 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 6420, 6480 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );

			}

			iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(500,		850,		"code");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 500, 850 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 500, 850 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 500, 850 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 500, 850 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 500, 850 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 500, 850 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 450, 800 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 450, 800 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 450, 800 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 450, 800 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, 0, 8192 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, 0, 8192 );
			}
			#endregion

			//0 - 24mA offset/gain trim code limits
			#region 0to24Limits
			range = App.RangeOptions.TWENTY_FOUR_MA;
			rSel = App.ResSel.R_INT;

			iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(5500,		8500,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 5500, 8500 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 5500, 8500 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 5500, 8500 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 5500, 8500 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 5500, 8500 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 5500, 8500 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 5500, 8500 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 5500, 8500 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 5500, 8500 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 5500, 8500 );
			}

			iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(0,		3000,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 0, 3000 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 0, 3000 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 0, 3000 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 0, 3000 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 0, 3000 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 0, 3000 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 0, 3000 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 0, 3000 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 0, 3000 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 0, 3000 );
			}

			rSel = App.ResSel.R_EXT;

			iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(7855,		7890,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 7855, 7890 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 7855, 7890 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 7855, 7890 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 7855, 7890 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 7855, 7890 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 7855, 7890 );

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 7710, 7780 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 7710, 7780 );
				
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 7710, 7780 );
				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 7710, 7780 );
			}

			iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(2500,		4500,		"");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 2500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 2500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 2500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 2500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 2500, 4500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 2500, 4500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 1500, 3500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 1500, 3500 );

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 1500, 3500 );
				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 1500, 3500 );
			}
			#endregion

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//+/-20mA offset/gain trim code limits
				#region 20mBipLimits
				range = App.RangeOptions.TWENTY_MA_BIP;
				rSel = App.ResSel.R_INT;

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(4500,		7000,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 4500, 7000 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 4500, 7000 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 4500, 7000 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 4500, 7000 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 4500, 7000 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 4500, 7000 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 4500, 7000 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 4500, 7000 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 4500, 7000 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 4500, 7000 );
				}

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(2200,		3600,		"code");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 2200, 3600 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 2200, 3600 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 2200, 3600 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 2200, 3600 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 2200, 3600 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 2200, 3600 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 2200, 3600 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 2200, 3600 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 2200, 3600 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 2200, 3600 );
				}

				rSel = App.ResSel.R_EXT;

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(6540,		6570,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 6540, 6570 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 6540, 6570 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 6540, 6570 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 6540, 6570 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 6540, 6570 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 6540, 6570 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 6420, 6480 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 6420, 6480 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 6420, 6480 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 6420, 6480 );
				}

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(3250,		3310,		"code");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 3250, 3310 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 3250, 3310 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 3250, 3310 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 3250, 3310 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 3250, 3310 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 3250, 3310 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 3160, 3280 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 3160, 3280 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 3160, 3280 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 3160, 3280 );
				}
				#endregion

				//+/-24mA offset/gain trim code limits
				#region 24mBipLimits
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				rSel = App.ResSel.R_INT;

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(5500,		8500,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 5500, 8500 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 5500, 8500 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 5500, 8500 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 5500, 8500 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 5500, 8500 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 5500, 8500 );
				
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 5500, 8500 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 5500, 8500 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 5500, 8500 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 5500, 8500 );
				}

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(2800,		4200,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 2800, 4200 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 2800, 4200 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 2800, 4200 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 2800, 4200 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 2800, 4200 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 2800, 4200 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 2800, 4200 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 2800, 4200 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 2800, 4200 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 2800, 4200 );
				}

				rSel = App.ResSel.R_EXT;

				iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(7855,		7890,		"");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 7855, 7890 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 7855, 7890 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 7855, 7890 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 7855, 7890 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 7855, 7890 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 7855, 7890 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 7700, 7780 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 7700, 7780 );

					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 7700, 7780 );
					iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 7700, 7780 );
				}

				iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(3910,		3960,		"code");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, 3910, 3960 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, 3910, 3960 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, 3910, 3960 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, 3910, 3960 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, 3910, 3960 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, 3910, 3960 );

					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, 3820, 3920 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, 3820, 3920 );
					
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, 3820, 3920 );
					iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, 3820, 3920 );
				}
				#endregion
			}
			#endregion
			#endregion

			#region postTrimRangeLimits
			//Voltage Range Limits
			#region VrangeOffsets
			//Voltage Range Offset Limits
			RangeVOffsetError			= TP.Program.CreateTestLimits(-20.0 ,	20.0 ,		"mV");

			RangeVOffsetError5v			= TP.Program.CreateTestLimits(-2.2 ,	2.2 ,		"mV");
			RangeVOffsetError10v		= TP.Program.CreateTestLimits(-4.0 ,	4.0 ,		"mV");
			RangeVOffsetError5vBip		= TP.Program.CreateTestLimits(-4.0 ,	4.0 ,		"mV");
			RangeVOffsetError10vBip		= TP.Program.CreateTestLimits(-5.0,		5.0,		"mV");
			RangeVOffsetError40v		= TP.Program.CreateTestLimits(-17.0,	17.0,		"mV");
			#endregion

			#region VrangeZS
			//Voltage Range ZS Limits - different limits for each Vrange
			//0 - 5V limits
			RangeVZscaleError5v		= TP.Program.CreateTestLimits(-20.0,		20.0,		"mV");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVZscaleError5v.SetLimits( App.Selectors.PD_LV_5750, -2.2, 2.2);
				RangeVZscaleError5v.SetLimits( App.Selectors.QC_LV_5750, -2.2, 2.2);

				RangeVZscaleError5v.SetLimits( App.Selectors.PD_HV_5751, -20.0, 20.0);
				RangeVZscaleError5v.SetLimits( App.Selectors.QC_HV_5751, -20.0, 20.0 );

				RangeVZscaleError5v.SetLimits( App.Selectors.PD_HV_5749, -20.0, 20.0);
				RangeVZscaleError5v.SetLimits( App.Selectors.QC_HV_5749, -20.0, 20.0 );

				RangeVZscaleError5v.SetLimits( App.Selectors.PD_LV_5750_1, -2.2, 2.2 );
				RangeVZscaleError5v.SetLimits( App.Selectors.QC_LV_5750_1, -2.2, 2.2 );

				RangeVZscaleError5v.SetLimits( App.Selectors.PD_LV_5750_2, -2.2, 2.2 );
				RangeVZscaleError5v.SetLimits( App.Selectors.QC_LV_5750_2, -2.2, 2.2 );

				RangeVZscaleError5v.SetLimits( App.Selectors.PD_RW_5750, -2.2, 2.2);
				RangeVZscaleError5v.SetLimits( App.Selectors.QC_RW_5750, -2.2, 2.2);

			}

			//0 - 10V limits
			RangeVZscaleError10v		= TP.Program.CreateTestLimits(-30.0,		30.0,		"mV");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVZscaleError10v.SetLimits( App.Selectors.PD_LV_5750, -4.0, 4.0);
				RangeVZscaleError10v.SetLimits( App.Selectors.QC_LV_5750, -4.0, 4.0);

				RangeVZscaleError10v.SetLimits( App.Selectors.PD_HV_5751, -30.0, 30.0);
				RangeVZscaleError10v.SetLimits( App.Selectors.QC_HV_5751, -30.0, 30.0 );

				RangeVZscaleError10v.SetLimits( App.Selectors.PD_HV_5749, -30.0, 30.0);
				RangeVZscaleError10v.SetLimits( App.Selectors.QC_HV_5749, -30.0, 30.0 );

				RangeVZscaleError10v.SetLimits( App.Selectors.PD_LV_5750_1, -4.0, 4.0 );
				RangeVZscaleError10v.SetLimits( App.Selectors.QC_LV_5750_1, -4.0, 4.0 );

				RangeVZscaleError10v.SetLimits( App.Selectors.PD_LV_5750_2, -4.0, 4.0 );
				RangeVZscaleError10v.SetLimits( App.Selectors.QC_LV_5750_2, -4.0, 4.0 );

				RangeVZscaleError10v.SetLimits( App.Selectors.PD_RW_5750, -4.0, 4.0);
				RangeVZscaleError10v.SetLimits( App.Selectors.QC_RW_5750, -4.0, 4.0);

			}

			// +/-5V limits
			RangeVZscaleError5vBip		= TP.Program.CreateTestLimits(-20.0,		20.0,		"mV");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVZscaleError5vBip.SetLimits( App.Selectors.PD_LV_5750, -4.0, 4.0);
				RangeVZscaleError5vBip.SetLimits( App.Selectors.QC_LV_5750, -4.0, 4.0);

				RangeVZscaleError5vBip.SetLimits( App.Selectors.PD_HV_5751, -20.0, 20.0);
				RangeVZscaleError5vBip.SetLimits( App.Selectors.QC_HV_5751, -20.0, 20.0 );

				RangeVZscaleError5vBip.SetLimits( App.Selectors.PD_HV_5749, -20.0, 20.0);
				RangeVZscaleError5vBip.SetLimits( App.Selectors.QC_HV_5749, -20.0, 20.0 );

				RangeVZscaleError5vBip.SetLimits( App.Selectors.PD_LV_5750_1, -4.0, 4.0 );
				RangeVZscaleError5vBip.SetLimits( App.Selectors.QC_LV_5750_1, -4.0, 4.0 );

				RangeVZscaleError5vBip.SetLimits( App.Selectors.PD_LV_5750_2, -4.0, 4.0 );
				RangeVZscaleError5vBip.SetLimits( App.Selectors.QC_LV_5750_2, -4.0, 4.0 );

				RangeVZscaleError5vBip.SetLimits( App.Selectors.PD_RW_5750, -4.0, 4.0);
				RangeVZscaleError5vBip.SetLimits( App.Selectors.QC_RW_5750, -4.0, 4.0);
			}

			// +/-10V limits
			RangeVZscaleError10vBip		= TP.Program.CreateTestLimits(-20.0,		20.0,		"mV");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVZscaleError10vBip.SetLimits( App.Selectors.PD_LV_5750, -5.0, 5.0);
				RangeVZscaleError10vBip.SetLimits( App.Selectors.QC_LV_5750, -5.0, 5.0);

				RangeVZscaleError10vBip.SetLimits( App.Selectors.PD_HV_5751, -20.0, 20.0);
				RangeVZscaleError10vBip.SetLimits( App.Selectors.QC_HV_5751, -20.0, 20.0 );

				RangeVZscaleError10vBip.SetLimits( App.Selectors.PD_HV_5749, -20.0, 20.0);
				RangeVZscaleError10vBip.SetLimits( App.Selectors.QC_HV_5749, -20.0, 20.0 );

				RangeVZscaleError10vBip.SetLimits( App.Selectors.PD_LV_5750_1, -5.0, 5.0 );
				RangeVZscaleError10vBip.SetLimits( App.Selectors.QC_LV_5750_1, -5.0, 5.0 );

				RangeVZscaleError10vBip.SetLimits( App.Selectors.PD_LV_5750_2, -5.0, 5.0 );
				RangeVZscaleError10vBip.SetLimits( App.Selectors.QC_LV_5750_2, -5.0, 5.0 );

				RangeVZscaleError10vBip.SetLimits( App.Selectors.PD_RW_5750, -7.0, 7.0);
				RangeVZscaleError10vBip.SetLimits( App.Selectors.QC_RW_5750, -7.0, 7.0);
			}

			// 40V limits
			RangeVZscaleError40v		= TP.Program.CreateTestLimits(-120.0,		120.0,		"mV");

			#endregion

			#region VrangeMS
			//Voltage Range MS Error Limits - 5V bip
			RangeVMscaleError[0]		= TP.Program.CreateTestLimits(-5.0,		5.0,		"mV");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVMscaleError[0].SetLimits( App.Selectors.PD_LV_5750, -4.0, 4.0);
				RangeVMscaleError[0].SetLimits( App.Selectors.QC_LV_5750, -4.0, 4.0);

				RangeVMscaleError[0].SetLimits( App.Selectors.PD_HV_5751, -4.0, 4.0);
				RangeVMscaleError[0].SetLimits( App.Selectors.QC_HV_5751, -4.0, 4.0 );

				RangeVMscaleError[0].SetLimits( App.Selectors.PD_HV_5749, -4.0, 4.0);
				RangeVMscaleError[0].SetLimits( App.Selectors.QC_HV_5749, -4.0, 4.0 );

				RangeVMscaleError[0].SetLimits( App.Selectors.PD_LV_5750_1, -4.0, 4.0 );
				RangeVMscaleError[0].SetLimits( App.Selectors.QC_LV_5750_1, -4.0, 4.0 );

				RangeVMscaleError[0].SetLimits( App.Selectors.PD_LV_5750_2, -4.0, 4.0 );
				RangeVMscaleError[0].SetLimits( App.Selectors.QC_LV_5750_2, -4.0, 4.0 );

				RangeVMscaleError[0].SetLimits( App.Selectors.PD_RW_5750, -4.0, 4.0);
				RangeVMscaleError[0].SetLimits( App.Selectors.QC_RW_5750, -4.0, 4.0);
			}


			//Voltage Range MS Error Limits - 10V bip
			RangeVMscaleError[1]		= TP.Program.CreateTestLimits(-10.0,		10.0,		"mV");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVMscaleError[1].SetLimits( App.Selectors.PD_LV_5750, -5.0, 5.0);
				RangeVMscaleError[1].SetLimits( App.Selectors.QC_LV_5750, -5.0, 5.0);

				RangeVMscaleError[1].SetLimits( App.Selectors.PD_HV_5751, -5.0, 5.0);
				RangeVMscaleError[1].SetLimits( App.Selectors.QC_HV_5751, -5.0, 5.0 );

				RangeVMscaleError[1].SetLimits( App.Selectors.PD_HV_5749, -5.0, 5.0);
				RangeVMscaleError[1].SetLimits( App.Selectors.QC_HV_5749, -5.0, 5.0 );

				RangeVMscaleError[1].SetLimits( App.Selectors.PD_LV_5750_1, -5.0, 5.0 );
				RangeVMscaleError[1].SetLimits( App.Selectors.QC_LV_5750_1, -5.0, 5.0 );

				RangeVMscaleError[1].SetLimits( App.Selectors.PD_LV_5750_2, -5.0, 5.0 );
				RangeVMscaleError[1].SetLimits( App.Selectors.QC_LV_5750_2, -5.0, 5.0 );

				RangeVMscaleError[1].SetLimits( App.Selectors.PD_RW_5750, -5.0, 5.0);
				RangeVMscaleError[1].SetLimits( App.Selectors.QC_RW_5750, -5.0, 5.0);
			}
			#endregion

			#region VrangeFS
			//Voltage Range FS Error Limits - 40V range FS error differs from Gain erro
			//All other voltage ranges having matching gain & FS error limits.
			RangeVFSError			= TP.Program.CreateTestLimits(-0.1 ,   0.1 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVFSError.SetLimits( App.Selectors.PD_LV_5750, -0.036, 0.036);
				RangeVFSError.SetLimits( App.Selectors.QC_LV_5750, -0.036, 0.036);

				RangeVFSError.SetLimits( App.Selectors.PD_HV_5751, -0.05, 0.05);
				RangeVFSError.SetLimits( App.Selectors.QC_HV_5751, -0.05, 0.05);

				RangeVFSError.SetLimits( App.Selectors.PD_HV_5749, -0.05, 0.05);
				RangeVFSError.SetLimits( App.Selectors.QC_HV_5749, -0.05, 0.05);

				RangeVFSError.SetLimits( App.Selectors.PD_LV_5750_1, -0.036, 0.036 );
				RangeVFSError.SetLimits( App.Selectors.QC_LV_5750_1, -0.036, 0.036 );

				RangeVFSError.SetLimits( App.Selectors.PD_LV_5750_2, -0.036, 0.036 );
				RangeVFSError.SetLimits( App.Selectors.QC_LV_5750_2, -0.036, 0.036 );

				RangeVFSError.SetLimits( App.Selectors.PD_RW_5750, -0.036, 0.036);
				RangeVFSError.SetLimits( App.Selectors.QC_RW_5750, -0.036, 0.036);

			}
			#endregion

			#region VrangeGain	
			//Voltage Range Gain Error Limits
			RangeVGainError			= TP.Program.CreateTestLimits(-0.1 ,   0.1 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVGainError.SetLimits( App.Selectors.PD_LV_5750, -0.036, 0.036);
				RangeVGainError.SetLimits( App.Selectors.QC_LV_5750, -0.036, 0.036);

				RangeVGainError.SetLimits( App.Selectors.PD_HV_5751, -0.036, 0.036);
				RangeVGainError.SetLimits( App.Selectors.QC_HV_5751, -0.036, 0.036);

				RangeVGainError.SetLimits( App.Selectors.PD_HV_5749, -0.036, 0.036);
				RangeVGainError.SetLimits( App.Selectors.QC_HV_5749, -0.036, 0.036);

				RangeVGainError.SetLimits( App.Selectors.PD_LV_5750_1, -0.036, 0.036 );
				RangeVGainError.SetLimits( App.Selectors.QC_LV_5750_1, -0.036, 0.036 );

				RangeVGainError.SetLimits( App.Selectors.PD_LV_5750_2, -0.036, 0.036 );
				RangeVGainError.SetLimits( App.Selectors.QC_LV_5750_2, -0.036, 0.036 );

				RangeVGainError.SetLimits( App.Selectors.PD_RW_5750, -0.036, 0.036);
				RangeVGainError.SetLimits( App.Selectors.QC_RW_5750, -0.036, 0.036);

			}

			RangeVGainError40v		= TP.Program.CreateTestLimits(-0.04,	0.04,		"%");
			RWVGainError10v			= TP.Program.CreateTestLimits(-0.1,		0.1,		"%");

			#endregion

			#region VrangesLin
			//Voltage Range Linearity Limits
			RangeVLin				= TP.Program.CreateTestLimits(-0.02 ,	0.02 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVLin.SetLimits( App.Selectors.PD_LV_5750, -0.017, 0.017);
				RangeVLin.SetLimits( App.Selectors.QC_LV_5750, -0.017, 0.017);

				RangeVLin.SetLimits( App.Selectors.PD_HV_5751, -0.017, 0.017 );
				RangeVLin.SetLimits( App.Selectors.QC_HV_5751, -0.017, 0.017 );

				RangeVLin.SetLimits( App.Selectors.PD_HV_5749, -0.017, 0.017 );
				RangeVLin.SetLimits( App.Selectors.QC_HV_5749, -0.017, 0.017 );

				RangeVLin.SetLimits( App.Selectors.PD_LV_5750_1, -0.017, 0.017 );
				RangeVLin.SetLimits( App.Selectors.QC_LV_5750_1, -0.017, 0.017 );

				RangeVLin.SetLimits( App.Selectors.PD_LV_5750_2, -0.017, 0.017 );
				RangeVLin.SetLimits( App.Selectors.QC_LV_5750_2, -0.017, 0.017 );

				RangeVLin.SetLimits( App.Selectors.PD_RW_5750, -0.017, 0.017);
				RangeVLin.SetLimits( App.Selectors.QC_RW_5750, -0.017, 0.017);
			}
			#endregion

			#region VrangeTUE
			//Voltage Range TUE limits
			RangeVTue				= TP.Program.CreateTestLimits(-0.1 ,	0.1 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeVTue.SetLimits( App.Selectors.PD_LV_5750, -0.05, 0.05 );
				RangeVTue.SetLimits( App.Selectors.QC_LV_5750, -0.05, 0.05 );

				RangeVTue.SetLimits( App.Selectors.PD_HV_5751, -0.05, 0.05 );
				RangeVTue.SetLimits( App.Selectors.QC_HV_5751, -0.05, 0.05 );

				RangeVTue.SetLimits( App.Selectors.PD_HV_5749, -0.05, 0.05 );
				RangeVTue.SetLimits( App.Selectors.QC_HV_5749, -0.05, 0.05 );

				RangeVTue.SetLimits( App.Selectors.PD_LV_5750_1, -0.05, 0.05 );
				RangeVTue.SetLimits( App.Selectors.QC_LV_5750_1, -0.05, 0.05 );

				RangeVTue.SetLimits( App.Selectors.PD_LV_5750_2, -0.05, 0.05 );
				RangeVTue.SetLimits( App.Selectors.QC_LV_5750_2, -0.05, 0.05 );

				RangeVTue.SetLimits( App.Selectors.PD_RW_5750, -0.05, 0.05 );
				RangeVTue.SetLimits( App.Selectors.QC_RW_5750, -0.05, 0.05 );

			}
			RWVtue10v			= TP.Program.CreateTestLimits(-0.1,		0.1,		"%");
			#endregion

			//Current Range Limits
			#region IrangeOffset
			RangeIOffset			= TP.Program.CreateTestLimits(-20.0 ,	20.0 ,		"uA");
			
			//4-20mA Rext ZS error limits
			rSel = App.ResSel.R_EXT;
			range = App.RangeOptions.FOUR_TWENTY_MA;

			RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(-11.0,		11.0,		"uA");

			//0-20mA Rext ZS error limits
			range = App.RangeOptions.TWENTY_MA;
			RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-7.0,		7.0,		"uA");

			//0-24mA Rext ZS error limits
			range = App.RangeOptions.TWENTY_FOUR_MA;
			RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-9.0,		9.0,		"uA");

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//+/-20mA Rext ZS error limits
				range = App.RangeOptions.TWENTY_MA_BIP;
				RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-15.0,		15.0,		"uA");

				//+/-24mA Rext ZS error limits
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-15.0,		15.0,		"uA");
			}

			//4-20mA Rint ZS error limits
			rSel = App.ResSel.R_INT;
			range = App.RangeOptions.FOUR_TWENTY_MA;

			RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(-10.0,		10.0,		"uA");

			//0-20mA Rint ZS error limits
			range = App.RangeOptions.TWENTY_MA;
			RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-8.0,		8.0,		"uA");

			//0-24mA Rint ZS error limits
			range = App.RangeOptions.TWENTY_FOUR_MA;
			RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-8.0,		8.0,		"uA");

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//+/-20mA Rint ZS error limits
				range = App.RangeOptions.TWENTY_MA_BIP;
				RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-26.0,		26.0,		"uA");

				//+/-24mA Rint ZS error limits
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-26.0,		26.0,		"uA");
			}
			#endregion

			#region IrangeZS
			//4-20mA Rext ZS error limits
			rSel = App.ResSel.R_EXT;
			range = App.RangeOptions.FOUR_TWENTY_MA;

			RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(-40.0,		40.0,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -11.0, 11.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -11.0, 11.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -40.0, 40.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -40.0, 40.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -40.0, 40.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -40.0, 40.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -11.0, 11.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -11.0, 11.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -11.0, 11.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -11.0, 11.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, -11.0, 11.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, -11.0, 11.0 );

			}

			//0-20mA Rext ZS error limits
			range = App.RangeOptions.TWENTY_MA;
			RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-50.0,		50.0,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -7.0, 7.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -7.0, 7.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -50.0, 50.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -50.0, 50.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -50.0, 50.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -50.0, 50.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -7.0, 7.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -7.0, 7.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -7.0, 7.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -7.0, 7.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, -7.0, 7.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, -7.0, 7.0 );
			}

			//0-24mA Rext ZS error limits
			range = App.RangeOptions.TWENTY_FOUR_MA;
			RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-60.0,		60.0,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -9.0, 9.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -9.0, 9.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -60.0, 60.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -60.0, 60.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -60.0, 60.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -60.0, 60.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -9.0, 9.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -9.0, 9.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -9.0, 9.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -9.0, 9.0 );
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//+/-20mA Rext ZS error limits
				range = App.RangeOptions.TWENTY_MA_BIP;
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-50.0,		50.0,		"uA");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -15.0, 15.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -15.0, 15.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -15.0, 15.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -15.0, 15.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -15.0, 15.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -15.0, 15.0 );
				}

				//+/-24mA Rext ZS error limits
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-50.0,		50.0,		"uA");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -15.0, 15.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -15.0, 15.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -15.0, 15.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -15.0, 15.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -15.0, 15.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -15.0, 15.0 );
				}
			}

			//4-20mA Rint ZS error limits
			rSel = App.ResSel.R_INT;
			range = App.RangeOptions.FOUR_TWENTY_MA;

			RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel] = TP.Program.CreateTestLimits(-40.0,		40.0,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -10.0, 10.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -10.0, 10.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -40.0, 40.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -40.0, 40.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -40.0, 40.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -40.0, 40.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -10.0, 10.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -10.0, 10.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -10.0, 10.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -10.0, 10.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, -10.0, 10.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, -10.0, 10.0 );

			}

			//0-20mA Rint ZS error limits
			range = App.RangeOptions.TWENTY_MA;
			RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-50.0,		50.0,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -8.0, 8.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -8.0, 8.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -50.0, 50.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -50.0, 50.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -50.0, 50.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -50.0, 50.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -8.0, 8.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -8.0, 8.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -8.0, 8.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -8.0, 8.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_RW_5750, -8.0, 8.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_RW_5750, -8.0, 8.0 );
			}

			//0-24mA Rint ZS error limits
			range = App.RangeOptions.TWENTY_FOUR_MA;
			RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-60.0,		60.0,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -8.0, 8.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -8.0, 8.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -60.0, 60.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -60.0, 60.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -60.0, 60.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -60.0, 60.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -8.0, 8.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -8.0, 8.0 );

				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -8.0, 8.0 );
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -8.0, 8.0 );
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//+/-20mA Rint ZS error limits
				range = App.RangeOptions.TWENTY_MA_BIP;
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-50.0,		50.0,		"uA");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -26.0, 26.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -26.0, 26.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -26.0, 26.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -26.0, 26.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -26.0, 26.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -26.0, 26.0 );
				}

				//+/-24mA Rint ZS error limits
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel]= TP.Program.CreateTestLimits(-50.0,		50.0,		"uA");
				if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
				{
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -26.0, 26.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -26.0, 26.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -26.0, 26.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -26.0, 26.0 );

					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -26.0, 26.0 );
					RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -26.0, 26.0 );
				}
			}
			#endregion

			#region IrangeFS
			//Current Range Rext FS Error Limits
			rSel = App.ResSel.R_EXT;
			RangeIFSError[(int)rSel] = TP.Program.CreateTestLimits(-0.2 ,   0.2 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750, -0.07, 0.07 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750, -0.07, 0.07 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_HV_5751, -0.07, 0.07 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_HV_5751, -0.07, 0.07 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_HV_5749, -0.07, 0.07 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_HV_5749, -0.07, 0.07 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -0.07, 0.07 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -0.07, 0.07 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -0.07, 0.07 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -0.07, 0.07 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_RW_5750, -0.07, 0.07 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_RW_5750, -0.07, 0.07 );

			}

			//Current Range Rint FS Error Limits
			rSel = App.ResSel.R_INT;
			RangeIFSError[(int)rSel] = TP.Program.CreateTestLimits(-0.3 ,   0.3 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750, -0.125, 0.125 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750, -0.125, 0.125 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_HV_5751, -0.125, 0.125 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_HV_5751, -0.125, 0.125 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_HV_5749, -0.125, 0.125 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_HV_5749, -0.125, 0.125 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -0.125, 0.125 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -0.125, 0.125 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -0.125, 0.125 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -0.125, 0.125 );

				RangeIFSError[(int)rSel].SetLimits( App.Selectors.PD_RW_5750, -0.125, 0.125 );
				RangeIFSError[(int)rSel].SetLimits( App.Selectors.QC_RW_5750, -0.125, 0.125 );

			}
			#endregion

			#region IrangeMS
			rSel = App.ResSel.R_EXT;
			//Current Range MS Error Limits - 20mA bip, Rext
			RangeIMscaleError[0, (int)rSel]	= TP.Program.CreateTestLimits(-35,		35,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -20.0, 20.0);
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -20.0, 20.0);

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -20.0, 20.0);
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -20.0, 20.0 );

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -20.0, 20.0);
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -20.0, 20.0 );

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -20.0, 20.0 );
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -20.0, 20.0 );

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -20.0, 20.0 );
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -20.0, 20.0 );
			}


			//Current Range MS Error Limits - 24mA bip, Rext
			RangeIMscaleError[1, (int)rSel]		= TP.Program.CreateTestLimits(-40.0,	40.0,	"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -22.0, 22.0);
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -22.0, 22.0);

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -22.0, 22.0);
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -22.0, 22.0 );

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -22.0, 22.0);
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -22.0, 22.0 );

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -22.0, 22.0 );
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -22.0, 22.0 );

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -22.0, 22.0 );
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -22.0, 22.0 );
			}

			rSel = App.ResSel.R_INT;
			//Current Range MS Error Limits - 20mA bip, Rext
			RangeIMscaleError[0, (int)rSel]	= TP.Program.CreateTestLimits(-40,		40,		"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -22.0, 22.0);
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -22.0, 22.0);

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -22.0, 22.0);
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -22.0, 22.0 );

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -22.0, 22.0);
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -22.0, 22.0 );

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -22.0, 22.0 );
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -22.0, 22.0 );

				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -22.0, 22.0 );
				RangeIMscaleError[0, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -22.0, 22.0 );
			}


			//Current Range MS Error Limits - 24mA bip, Rext
			RangeIMscaleError[1, (int)rSel]		= TP.Program.CreateTestLimits(-40.0,	40.0,	"uA");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_LV_5750, -24.0, 24.0);
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_LV_5750, -24.0, 24.0);

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_HV_5751, -24.0, 24.0);
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_HV_5751, -24.0, 24.0 );

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_HV_5749, -24.0, 24.0);
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_HV_5749, -24.0, 24.0 );

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -24.0, 24.0 );
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -24.0, 24.0 );

				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -24.0, 24.0 );
				RangeIMscaleError[1, (int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -24.0, 24.0 );
			}
			#endregion

			#region IrangeGain
			//Current Range Rext Gain Error Limits
			rSel = App.ResSel.R_EXT;
			RangeIGainError[(int)rSel] = TP.Program.CreateTestLimits(-0.2 ,   0.2 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750, -0.07, 0.07 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750, -0.07, 0.07 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_HV_5751, -0.07, 0.07 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_HV_5751, -0.07, 0.07 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_HV_5749, -0.07, 0.07 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_HV_5749, -0.07, 0.07 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -0.07, 0.07 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -0.07, 0.07 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -0.07, 0.07 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -0.07, 0.07 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_RW_5750, -0.07, 0.07 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_RW_5750, -0.07, 0.07 );

			}

			//Current Range Rint Gain Error Limits
			rSel = App.ResSel.R_INT;
			RangeIGainError[(int)rSel] = TP.Program.CreateTestLimits(-0.2 ,   0.2 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750, -0.12, 0.12 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750, -0.12, 0.12 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_HV_5751, -0.12, 0.12 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_HV_5751, -0.12, 0.12 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_HV_5749, -0.12, 0.12 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_HV_5749, -0.12, 0.12 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_1, -0.12, 0.12 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_1, -0.12, 0.12 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_LV_5750_2, -0.12, 0.12 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_LV_5750_2, -0.12, 0.12 );

				RangeIGainError[(int)rSel].SetLimits( App.Selectors.PD_RW_5750, -0.12, 0.12 );
				RangeIGainError[(int)rSel].SetLimits( App.Selectors.QC_RW_5750, -0.12, 0.12 );

			}
			#endregion

			#region IrangeLin
			//Current Range Linearity Limits - Unipolar
			RangeILinUni				= TP.Program.CreateTestLimits(-0.02 ,	0.02 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeILinUni.SetLimits( App.Selectors.PD_LV_5750, -0.017, 0.017 );
				RangeILinUni.SetLimits( App.Selectors.QC_LV_5750, -0.017, 0.017 );

				RangeILinUni.SetLimits( App.Selectors.PD_HV_5751, -0.017, 0.017 );
				RangeILinUni.SetLimits( App.Selectors.QC_HV_5751, -0.017, 0.017 );

				RangeILinUni.SetLimits( App.Selectors.PD_HV_5749, -0.017, 0.017 );
				RangeILinUni.SetLimits( App.Selectors.QC_HV_5749, -0.017, 0.017 );

				RangeILinUni.SetLimits( App.Selectors.PD_LV_5750_1, -0.017, 0.017 );
				RangeILinUni.SetLimits( App.Selectors.QC_LV_5750_1, -0.017, 0.017 );

				RangeILinUni.SetLimits( App.Selectors.PD_LV_5750_2, -0.017, 0.017 );
				RangeILinUni.SetLimits( App.Selectors.QC_LV_5750_2, -0.017, 0.017 );

				RangeILinUni.SetLimits( App.Selectors.PD_RW_5750, -0.017, 0.017 );
				RangeILinUni.SetLimits( App.Selectors.QC_RW_5750, -0.017, 0.017 );
			}

			//Current Range Linearity Limits - Bipolar
			RangeILinBip				= TP.Program.CreateTestLimits(-0.03 ,	0.03 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeILinBip.SetLimits( App.Selectors.PD_LV_5750, -0.027, 0.027 );
				RangeILinBip.SetLimits( App.Selectors.QC_LV_5750, -0.027, 0.027 );

				RangeILinBip.SetLimits( App.Selectors.PD_HV_5751, -0.027, 0.027 );
				RangeILinBip.SetLimits( App.Selectors.QC_HV_5751, -0.027, 0.027 );

				RangeILinBip.SetLimits( App.Selectors.PD_HV_5749, -0.027, 0.027 );
				RangeILinBip.SetLimits( App.Selectors.QC_HV_5749, -0.027, 0.027 );

				RangeILinBip.SetLimits( App.Selectors.PD_LV_5750_1, -0.027, 0.027 );
				RangeILinBip.SetLimits( App.Selectors.QC_LV_5750_1, -0.027, 0.027 );

				RangeILinBip.SetLimits( App.Selectors.PD_LV_5750_2, -0.027, 0.027 );
				RangeILinBip.SetLimits( App.Selectors.QC_LV_5750_2, -0.027, 0.027 );

			}
			#endregion

			#region IrangeTUE
			//Current Range TUE Limits - Positive TUE
			RangeITuePos				= TP.Program.CreateTestLimits(-0.2 ,	0.2 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeITuePos.SetLimits( App.Selectors.PD_LV_5750, -0.05, 0.05 );
				RangeITuePos.SetLimits( App.Selectors.QC_LV_5750, -0.05, 0.05 );

				RangeITuePos.SetLimits( App.Selectors.PD_HV_5751, -0.05, 0.05 );
				RangeITuePos.SetLimits( App.Selectors.QC_HV_5751, -0.05, 0.05 );

				RangeITuePos.SetLimits( App.Selectors.PD_HV_5749, -0.05, 0.05 );
				RangeITuePos.SetLimits( App.Selectors.QC_HV_5749, -0.05, 0.05 );

				RangeITuePos.SetLimits( App.Selectors.PD_LV_5750_1, -0.05, 0.05 );
				RangeITuePos.SetLimits( App.Selectors.QC_LV_5750_1, -0.05, 0.05 );

				RangeITuePos.SetLimits( App.Selectors.PD_LV_5750_2, -0.05, 0.05 );
				RangeITuePos.SetLimits( App.Selectors.QC_LV_5750_2, -0.05, 0.05 );

				RangeITuePos.SetLimits( App.Selectors.PD_RW_5750, -0.05, 0.05 );
				RangeITuePos.SetLimits( App.Selectors.QC_RW_5750, -0.05, 0.05 );
			}

			//Current Range TUE Limits - Negative TUE
			RangeITueNeg				= TP.Program.CreateTestLimits(-0.2 ,	0.2 ,		"%");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeITueNeg.SetLimits( App.Selectors.PD_LV_5750, -0.08, 0.08 );
				RangeITueNeg.SetLimits( App.Selectors.QC_LV_5750, -0.08, 0.08 );

				RangeITueNeg.SetLimits( App.Selectors.PD_HV_5751, -0.08, 0.08 );
				RangeITueNeg.SetLimits( App.Selectors.QC_HV_5751, -0.08, 0.08 );

				RangeITueNeg.SetLimits( App.Selectors.PD_HV_5749, -0.08, 0.08 );
				RangeITueNeg.SetLimits( App.Selectors.QC_HV_5749, -0.08, 0.08 );

				RangeITueNeg.SetLimits( App.Selectors.PD_LV_5750_1, -0.08, 0.08 );
				RangeITueNeg.SetLimits( App.Selectors.QC_LV_5750_1, -0.08, 0.08 );

				RangeITueNeg.SetLimits( App.Selectors.PD_LV_5750_2, -0.08, 0.08 );
				RangeITueNeg.SetLimits( App.Selectors.QC_LV_5750_2, -0.08, 0.08 );

				RangeITueNeg.SetLimits( App.Selectors.PD_RW_5750, -0.08, 0.08 );
				RangeITueNeg.SetLimits( App.Selectors.QC_RW_5750, -0.08, 0.08 );
			}
			#endregion


			RangeDeadband			= TP.Program.CreateTestLimits(-20.0,	20.0,		"mV");
			if((!App.Globals.CharTestingEnable) && (!App.Globals.YaTestingEnable))
			{
				RangeDeadband.SetLimits( App.Selectors.PD_LV_5750, -20.0,	20.0 );
				RangeDeadband.SetLimits( App.Selectors.QC_LV_5750, -20.0,	20.0 );

				RangeDeadband.SetLimits( App.Selectors.PD_HV_5751, 1.0, 12.5 );
				RangeDeadband.SetLimits( App.Selectors.QC_HV_5751, 1.0, 12.5 );

				RangeDeadband.SetLimits( App.Selectors.PD_HV_5749, 1.0, 12.5 );
				RangeDeadband.SetLimits( App.Selectors.QC_HV_5749, 1.0, 12.5 );

				RangeDeadband.SetLimits( App.Selectors.PD_LV_5750_1, -20.0,	20.0 );
				RangeDeadband.SetLimits( App.Selectors.QC_LV_5750_1, -20.0,	20.0 );

				RangeDeadband.SetLimits( App.Selectors.PD_LV_5750_2, -20.0,	20.0 );
				RangeDeadband.SetLimits( App.Selectors.QC_LV_5750_2, -20.0,	20.0 );
			}

			#endregion

			OverrangeVOffset		= TP.Program.CreateTestLimits(-20.0 ,	20.0 ,		"mV");
			OverrangeVGain			= TP.Program.CreateTestLimits(-0.2 ,	0.2 ,		"%");
			OverrangeVOffset44v		= TP.Program.CreateTestLimits(-150.0 ,	150.0 ,		"mV");
			OverrangeVGain44v		= TP.Program.CreateTestLimits(-0.3 ,	0.3 ,		"%");
			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				OverrangeIOffset		= TP.Program.CreateTestLimits(0 ,		700 ,		"uA");
			}
			else
			{
				OverrangeIOffset		= TP.Program.CreateTestLimits(300 ,		700 ,		"uA");
			}
			OverrangeIVinOffset		= TP.Program.CreateTestLimits(0.02,		0.1,		"V");
			OverrangeIGain			= TP.Program.CreateTestLimits(-5.0 ,	5.0 ,		"%");

			VsenseNshift			= TP.Program.CreateTestLimits(-555 ,	555 ,		"uV/V");

			ShortCctCurPos			= TP.Program.CreateTestLimits( 13.0 ,  21.0 ,		"mA");
			ShortCctCurNeg			= TP.Program.CreateTestLimits(-21.0 , -12.54 ,		"mA");
			ComplianceV				= TP.Program.CreateTestLimits(  0.0 ,   5.0 ,		"V");
			complianceIout			= TP.Program.CreateTestLimits(-30.0 ,  30.0 ,		"mA");
			compIoutFSR				= TP.Program.CreateTestLimits(-5.0  ,	5.0 ,		"%");
			Vddcompliance			= TP.Program.CreateTestLimits(  0.1 ,  55.0 ,		"V");
			Vsscompliance			= TP.Program.CreateTestLimits(-26.4 ,  -0.1 ,		"V");
			ioutAccuracy			= TP.Program.CreateTestLimits(-0.1 ,	0.1,		"%");

			SelfHeatOffset			= TP.Program.CreateTestLimits(-1.0,		1.0,		"uA");
			SelfHeatOffset.SetLimits(App.Selectors.PD_LV_5750, -0.3,	0.3 );
			SelfHeatOffset.SetLimits(App.Selectors.QC_LV_5750, -0.3,	0.3 );

			SelfHeatOffset.SetLimits(App.Selectors.PD_LV_5750_1, -0.3,	0.3 );
			SelfHeatOffset.SetLimits(App.Selectors.QC_LV_5750_1, -0.3,	0.3 );

			SelfHeatOffset.SetLimits(App.Selectors.PD_LV_5750_2, -0.3,	0.3 );
			SelfHeatOffset.SetLimits(App.Selectors.QC_LV_5750_2, -0.3,	0.3 );

			SelfHeatOffset.SetLimits(App.Selectors.PD_RW_5750, -0.3,	0.3 );
			SelfHeatOffset.SetLimits(App.Selectors.QC_RW_5750, -0.3,	0.3 );

			SelfHeatOffset.SetLimits(App.Selectors.PD_HV_5751, -1.0,	1.0 );
			SelfHeatOffset.SetLimits(App.Selectors.QC_HV_5751, -1.0,	1.0 );

			SelfHeatOffset.SetLimits(App.Selectors.PD_HV_5749, -1.0,	1.0 );
			SelfHeatOffset.SetLimits(App.Selectors.QC_HV_5749, -1.0,	1.0 );

			#endregion

			#region Char Limits Init
			Vpsrr					= TP.Program.CreateTestLimits(-100.0,	100.0,		"uV/V");
			Ipsrr					= TP.Program.CreateTestLimits(-0.5,		0.5,		"uA/V");
			InternalNodes			= TP.Program.CreateTestLimits(-5.0,		5.0,		"V");
			InternalOffsets			= TP.Program.CreateTestLimits(-1.0,		1.0,		"V");		

			t1Timing				= TP.Program.CreateTestLimits( 15.0 ,  33.0 ,		"ns");
			txPulsewidth			= TP.Program.CreateTestLimits(  1.0 ,  13.0 ,		"ns");
			t7SetupTime				= TP.Program.CreateTestLimits( -1.0 ,   6.0 ,		"ns");
			t8HoldTime				= TP.Program.CreateTestLimits( -1.0 ,   5.0 ,		"ns");
			txCLRtime				= TP.Program.CreateTestLimits(  0.0 ,     2 ,		"us");
			txSyncSetupHold			= TP.Program.CreateTestLimits(  0.0 ,   13.0,		"ns");

			vih						= TP.Program.CreateTestLimits( 0.8 ,	2.1 ,		"V");
			vil						= TP.Program.CreateTestLimits( 0.8 ,	1.8 ,		"V");
			voh						= TP.Program.CreateTestLimits( 1.9 ,	5.5 ,		"V");
			vol						= TP.Program.CreateTestLimits( 0.0 ,	0.4 ,		"V");

			#endregion

			#region Board Checker Limits Init
			//
			// Limit Name				[Selector]				Lower		Upper		Units
			//
			TwelveVoltSupply		= TP.Program.CreateTestLimits(11.0,		13.0,		"V");
			DiodeDrop				= TP.Program.CreateTestLimits(0.4,		0.8,		"V");
			SingleRelay				= TP.Program.CreateTestLimits(100,		1400,		"Ohm");
			DoubleRelay				= TP.Program.CreateTestLimits(100,		600,		"Ohm");
			QuadRelay				= TP.Program.CreateTestLimits(100,		400,		"Ohm");
			HighVoltageRelays		= TP.Program.CreateTestLimits(100 ,		350 ,		"Ohm");

			MuxCheckOneVolt			= TP.Program.CreateTestLimits(0.9 ,		1.1 ,		"V");
			MuxCheckTwoVolt			= TP.Program.CreateTestLimits(1.9 ,		2.1 ,		"V");
			MuxCheckPointFiveVolt	= TP.Program.CreateTestLimits(0.4 ,		0.6 ,		"V");
			MuxCheckZeroVolt		= TP.Program.CreateTestLimits(-0.1 ,	0.1 ,		"V");

			IoutLowResistor			= TP.Program.CreateTestLimits(250 ,		350 ,		"Ohm");
			IoutHighResistor		= TP.Program.CreateTestLimits(1500 ,	2100 ,		"Ohm");
			IoutResistorRatio		= TP.Program.CreateTestLimits(0.141 ,	0.145 ,		"Ohm");
			RextValue				= TP.Program.CreateTestLimits(14500 ,	15500 ,		"Ohm");
			ScaleCct1				= TP.Program.CreateTestLimits(0.155 ,	0.170 ,		"");
			ScaleCct2				= TP.Program.CreateTestLimits(0.447 ,	0.451 ,		"");
			VscaleHighLoad			= TP.Program.CreateTestLimits(230.0 ,	250.0 ,		"kOhm");
			VscaleLowLoad			= TP.Program.CreateTestLimits(4.7 ,		5.1 ,		"kOhm");
			#endregion

		}

	} // end of clas Limits
	#endregion

	//
	// Test Bins
	//
	#region Bins                            :
	/// <summary>
	/// Contains all the software bins for this test application.
	/// </summary>
	public class Bins
	{
		#region Bin Declarations
		public static TestBin General;
		public static TestBin BoardChecker;
		public static TestBin TC;
		public static TestBin Continuity;
		public static TestBin PwrupConditions;
		public static TestBin StandbyCurrent;
		public static TestBin SupplyCurrents;
		public static TestBin Leakage;
		public static TestBin LogicCurrents;
		public static TestBin PreTrimCode;
		public static TestBin PreTrimOffset;
		public static TestBin PreTrimGain;
		public static TestBin ShortCctCurrents;
		public static TestBin RefLkgs;
		public static TestBin VoutLeakage;
		public static TestBin DigFunc;
		public static TestBin RangeTrim;
		public static TestBin RangeGain;
		public static TestBin RangeOffset;
		public static TestBin FuseBlow;
		public static TestBin PostTrimTue;
		public static TestBin PostTrimLin;
		public static TestBin PostTrimOffset;
		public static TestBin PostTrimGain;
		public static TestBin IbiasTrim;
		public static TestBin AnalogFunc;
		public static TestBin PSRR;
		public static TestBin Headroom;
		public static TestBin Timing;
		public static TestBin Coordinates;
		#endregion

		/// <summary>
		/// Initialize bins.
		/// </summary>
		public static void Load ( )
		{
			//Bin Name									  Number	Name						Type
			General				= TP.Program.CreateTestBin(	100,	"General",				TestBin.Type.Failing);
			BoardChecker		= TP.Program.CreateTestBin(	 98,	"Board Checker",		TestBin.Type.Failing);
			TC					= TP.Program.CreateTestBin(	 40,	"TC",					TestBin.Type.Passing);
			VoutLeakage			= TP.Program.CreateTestBin(   7,	"Vout Leakage" ,		TestBin.Type.Failing);
			Continuity			= TP.Program.CreateTestBin(   8,	"Continuity",			TestBin.Type.Failing);
			SupplyCurrents		= TP.Program.CreateTestBin(   9,	"Supply Currents",		TestBin.Type.Failing);
			StandbyCurrent		= TP.Program.CreateTestBin(	 10,	"Standby Currents",		TestBin.Type.Failing);
			AnalogFunc			= TP.Program.CreateTestBin(  11 ,	"Analog Functionality",	TestBin.Type.Failing);
			FuseBlow			= TP.Program.CreateTestBin(  12,	"Fuse Failure",			TestBin.Type.Failing);
			Leakage				= TP.Program.CreateTestBin(  13,	"Leakage Currents" ,	TestBin.Type.Failing);
			DigFunc				= TP.Program.CreateTestBin(  14,	"Digital Functionality",TestBin.Type.Failing);
			LogicCurrents		= TP.Program.CreateTestBin(  16,	"Logic Pins Currents" ,	TestBin.Type.Failing);
			RefLkgs				= TP.Program.CreateTestBin(  31 ,	"Reference Failures",	TestBin.Type.Failing);

			PreTrimGain			= TP.Program.CreateTestBin(  21 ,	"PreTrim Gain Error",	TestBin.Type.Failing);
			PreTrimOffset		= TP.Program.CreateTestBin(  24 ,	"PreTrim Offset Error",	TestBin.Type.Failing);
			PreTrimCode			= TP.Program.CreateTestBin(  25 ,	"Trim Codes",			TestBin.Type.Failing);

			PostTrimGain		= TP.Program.CreateTestBin(  43,	"Post Trim Gain",		TestBin.Type.Failing);
			PostTrimOffset		= TP.Program.CreateTestBin(  42,	"Post Trim Offset",		TestBin.Type.Failing);
			PostTrimLin			= TP.Program.CreateTestBin(  40,	"Post Trim Linearity",	TestBin.Type.Failing);
			PostTrimTue			= TP.Program.CreateTestBin(  45,	"Post Trim TUE",		TestBin.Type.Failing);

			ShortCctCurrents	= TP.Program.CreateTestBin(  62,	"Short Cct Currents",	TestBin.Type.Failing);

			PwrupConditions		= TP.Program.CreateTestBin(  24,	"Power Up Conditions",	TestBin.Type.Failing);
			PSRR				= TP.Program.CreateTestBin(  30 ,	"PSRR Failure",			TestBin.Type.Failing);
			Headroom			= TP.Program.CreateTestBin(  31 ,	"Headroom Failure",		TestBin.Type.Failing);
			Timing				= TP.Program.CreateTestBin(  50 ,	"Timing Failure"   ,	TestBin.Type.Failing);

			Coordinates	= TP.Program.CreateTestBin(	 17,	"Coordinates",		TestBin.Type.Failing);
		}
	}
	#endregion

	//
	// Seq - add custom utility methods used by these sequencers to this class
	//
	#region Seq                             :
	/// <summary>
	/// User sequencer utility methods.
	/// </summary>
	public class Seq
	{
		#region Sub-Sequencer IDs           :

		//
		// All sub-sequencers should be given simple string names that are defined 
		// here. This will reduce any programming errors caused by having to type
		// the literal string out more than once.
		// 
		// e.g.
		// public const String IddSeqID                          = "Idd";
		// public const String IddPowerDownSeqID                 = "Idd Power Down";
		// public const String AinLeakageSeqID                   = "Ain Leakage";

		//
		// When creating a new sub-sequencer, use 'Seq.XxxID' as the sequencer name.
		//

		public const String OpensShortsSeqID					= "O/S";
		public const String LeakageSeqID						= "Leakage Tests";
		public const String VinVrefSeqID						= "Vin/Vref Tests";
		public const String PreTrimSeqID						= "PreTrim Tests";
		public const String AD5749_PreTrimSeqID					= "AD5749 PreTrim Tests";
		public const String RWPreTrimSeqID						= "RW PreTrim Tests";
		public const String FuseBlowSeqID						= "Fuse Blow Tests";
		public const String PostTrimSeqID						= "PostTrim Tests";
		public const String AD5749_PostTrimSeqID				= "AD5749 PostTrim Tests";
		public const String RWPostTrimSeqID						= "RW PostTrim Tests";
		public const String SWmodeFuncSeqID						= "S/W Mode Func Tests";
		public const String HWmodeFuncSeqID						= "H/W Mode Func Tests";
		public const String CharSeqID							= "Characterisation Tests";
		public const String TestModeSeqID						= "Internal Nodes Tests";

		#endregion
	} // end of class Seq
	#endregion

	//
	// AD575xSeq sequencer
	//
	#region Main Application Sequencer      :
	/// <summary>
	/// AD575x (16 bit) variant sequencer for both PD and QC.
	/// </summary>
	public class AD575xSeq : SequencerProxy
	{
		//
		// AD575xSeq - Tests and Sub-Sequencers are added here
		//
		#region Sequencer Constructor           :
		public AD575xSeq ( )
			: base("Seq : " + TP.Program.ActiveSelector.ToString())
		{
			//Add(new AD575xBrdChckrSeq());

			//   Test ID               Limits             Fail Bin           Test Function
			Add(IDs.SiteNumber,        Limits.Site,       Bins.General,      new SiteNumber( ));
			Add(IDs.DVccTC,            Limits.DVcc,       Bins.TC,           new TestConditions( ));
			Add(IDs.AVddTC,            Limits.AVdd,       Bins.TC,           new TestConditions( ));
			Add(IDs.AVssTC,            Limits.AVss,       Bins.TC,           new TestConditions( ));
			Add(IDs.VrefTC,            Limits.Vref,       Bins.TC,           new TestConditions( ));
			Add(IDs.TempTC,            Limits.Temp,       Bins.TC,           new TestConditions( ));
			Add(IDs.WaferTC,		   Limits.Wafer,	  Bins.TC,			 new TestConditions( ));
					

			Add(new OpensShortsSeq( ));

			Add(new LeakageSeq( ));

			Add(IDs.AIdd,              Limits.AIddPreTrim,		Bins.StandbyCurrent,	new SupplyCurrents( ));
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Add(IDs.AIss,              Limits.AIssPreTrim,	Bins.StandbyCurrent,	new SupplyCurrents( ));
			Add(IDs.DIcc,              Limits.DIcc,				Bins.StandbyCurrent,	new SupplyCurrents( ));

			Add(new VinVrefSeq( ));

			Add(IDs.readMasterFuse,    Limits.MasterFuseRead,	Bins.FuseBlow,			new MasterFuseRead( ));
//			Add(IDs.Read_X_Coordinate,	Limits.Read_X_Coordinate,	Bins.Coordinates,	new ReadCoordinates( ));
//			Add(IDs.Read_Y_Coordinate,	Limits.Read_Y_Coordinate,	Bins.Coordinates,	new ReadCoordinates( ));
//			Add(IDs.Read_Wafer_number,	Limits.Read_Wafer_number,	Bins.Coordinates,	new ReadCoordinates( ));
			Add(IDs.DeviceID,          Limits.DeviceID,			Bins.DigFunc,			new DeviceID( ));

			Add(IDs.Vgen5V,            Limits.Vgen5V,			Bins.AnalogFunc,		new VgenVoltages( ));
			Add(IDs.Vgen7V,            Limits.Vgen7V,			Bins.AnalogFunc,		new VgenVoltages( ));

			Add(IDs.IbiasTrimCode,     Limits.IbiasCode,		Bins.AnalogFunc,			new IbiasTrim( ));
			Add(IDs.IbiasPostTrim,     Limits.PostIbias,		Bins.AnalogFunc,			new IbiasTrim( ));
			Add(IDs.TempcoTrimCode,	   Limits.TcCode,			Bins.AnalogFunc,			new IbiasTrim( ));

			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				Add(new RWPreTrimSeq( ));
			}
			else if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
			{
				Add(new AD5749_PreTrimSeq( ));
			}
			else
                Add(new PreTrimSeq( ));

			Add(new FuseBlowSeq( ));


			/*
			if((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable))
			{
				//Add(IDs.VrefMeas,          Limits.VrefError,		Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VinLowMeas,			Limits.VrefError,		Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VinHighMeas,		Limits.VrefError,		Bins.TC,				new ConditionsCheck( ));
				Add(IDs.IloadLowMeas,		Limits.IloadLowMeas,	Bins.TC,				new ConditionsCheck( ));
				Add(IDs.IloadHighMeas,		Limits.IloadHighMeas,	Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VscaleLowLoad,		Limits.VscaleLowLoad,	Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VscaleLowRatio,		Limits.ScaleCct2,		Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VscaleHighLoad,		Limits.VscaleHighLoad,	Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VscaleHighRatio,	Limits.ScaleCct1,		Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VscaleHighM,		Limits.ScaleCct1,		Bins.TC,				new ConditionsCheck( ));
				Add(IDs.VscaleHighC,		Limits.RangeVOffsetError,Bins.TC,				new ConditionsCheck( ));
			}
			*/

			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				Add(new RWPostTrimSeq( ));
			}
			else if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
			{
				Add(new AD5749_PostTrimSeq( ));
			}
			else
				Add(new PostTrimSeq( ));
			
			if((App.Globals.ActiveSelector != App.Selectors.PD_HV_5749) && (App.Globals.ActiveSelector != App.Selectors.QC_HV_5749))
			{
				Add(IDs.PowerupToZero,		Limits.PwrupZS,			Bins.AnalogFunc,	new PowerUpCondition( ));
				Add(IDs.PowerupToMid,		Limits.PwrupMS,			Bins.AnalogFunc,	new PowerUpCondition( ));
				Add(IDs.PowerupTristate,	Limits.PwrupTristate,	Bins.AnalogFunc,	new PowerUpCondition( ));
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                Add(IDs.VsensenFunc,			Limits.VsenseNshift,Bins.AnalogFunc,		new VsensenFunc( ));

			Add(IDs.VRangeAIdd,				Limits.RangeAIdd,	Bins.SupplyCurrents,	new RangeSupplyCurrents( ));
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Add(IDs.VRangeAIss,			Limits.vRangeAIss,	Bins.SupplyCurrents,	new RangeSupplyCurrents( ));
			Add(IDs.VRangeDIcc,				Limits.RangeDIcc,	Bins.SupplyCurrents,	new RangeSupplyCurrents( ));
			Add(IDs.IRangeAIdd,				Limits.RangeAIdd,	Bins.SupplyCurrents,	new RangeSupplyCurrents( ));
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Add(IDs.IRangeAIss,			Limits.iRangeAIss,	Bins.SupplyCurrents,	new RangeSupplyCurrents( ));
			Add(IDs.IRangeDIcc,				Limits.RangeDIcc,	Bins.SupplyCurrents,	new RangeSupplyCurrents( ));

			Add(new HWmodeFuncSeq( ));

            Add(new TestModeSeq( ));
			Add(new SWmodeFuncSeq( ));


           // AddIf((App.Globals.CharTestingEnable || App.Globals.YaTestingEnable), new CharSeq( ));

			Add(IDs.IoutTristateLkg,		Limits.IoutLeakage,		Bins.Leakage,			new OutputsTristateLkg2( ));
			Add(IDs.vsensenLkg,				Limits.VsenseNLkg,		Bins.Leakage,			new OutputsTristateLkg2( ));
			Add(IDs.VoutTristateLkg,		Limits.Leakage,			Bins.VoutLeakage,		new OutputsTristateLkg2( ));

			App.RangeOptions range = App.RangeOptions.TWENTY_FOUR_MA;
			App.ResSel rSel = App.ResSel.R_INT;

			Add(IDs.PostTestAIdd,			Limits.AIdd,			Bins.StandbyCurrent,	new PostTestSupplyCurrents( ));
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Add(IDs.PostTestAIss,		Limits.AIss,			Bins.StandbyCurrent,	new PostTestSupplyCurrents( ));
			Add(IDs.PostTestDIcc,			Limits.DIcc,			Bins.StandbyCurrent,	new PostTestSupplyCurrents( ));

			Add(IDs.CoolOffset,	Limits.RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel],Bins.PostTrimOffset,	new SelfHeatingOffsetTest( ));
			Add(IDs.WarmOffset,	Limits.RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel],Bins.PostTrimOffset,	new SelfHeatingOffsetTest( ));
			Add(IDs.OffsetDelta,Limits.SelfHeatOffset,													Bins.VoutLeakage,		new SelfHeatingOffsetTest( ));
		}
		#endregion

		//
		// Run Method (called during a part loop)
		//
		#region Run                             :
		public override void Run()
		{
			Run  (IDs.SiteNumber);

			//RunIf(App.Globals.RunBoardChecker, "AD575x Board Checker Seq");
			//
			// Note: It is now possible to put any kind of method or other program construct 
			//       directly in the Run method of the sequencer. Here we make a call to a
			//       global method to setup the test conditions for the following tests.
			//

			#region TemplateCode
			//Run  (IDs.DVccTC);
			//Run  (IDs.AVddTC);
			//Run  (IDs.AVssTC);
			//Run  (IDs.BlowFusesTC);
			//Run  (IDs.FuseVTC);

			//Run  (IDs.Idd15Stby);
			//Run  (IDs.IddRefStby);
			//Run  (IDs.IddDigStby);

			//
			// It is now possible to combine variants and testing levels (QC/PD) into one 
			// sequencer. This can be achieved using a combination of test parameters, test
			// limits, selectors and RunIf logic.
			//
			// Here is an example Run implementation calling some common tests, it should
			// demonstrate how the user can create a unique test sequence within a common
			// sequencer.
			// 
			//		Run  (IDs.IddRefStby);
			//		Run  (IDs.IddDigStby);
			//		Run  (IDs.IddCompStby);
			//		RunIf(App.Selectors.PD_LV || App.Selectors.PD_LV, IDs.PowTotStby);
			//		Run  (IDs.Idd15PPwd);
			//		RunIf(App.Selectors.PD_LV || App.Selectors.PD_LV, IDs.PowTotPPwd);
			//
			//		RunIf(
			//			App.Selectors.PD_LV || 
			//			App.Selectors.PD_HV || 
			//			App.Selectors.PD_12_BIT, IDs.VrefLsb);
			//		RunIf(
			//			App.Selectors.QC_LV || 
			//			App.Selectors.QC_HV || 
			//			App.Selectors.QC_12_BIT, IDs.OscPost);
			//
			//		RunIf(
			//			App.Globals.CharTestingEnable && 
			//			(App.Selectors.PD_LV || App.Selectors.QC_LV), IDs.Vbe);
			//
			#endregion

			Run  (IDs.DVccTC);
			Run  (IDs.AVddTC);
			Run  (IDs.AVssTC);
			Run  (IDs.VrefTC);
			Run  (IDs.TempTC);
	
			//Close RLX01 to avoid voltage on DVcc
			HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.CLOSE);

			Run  (Seq.OpensShortsSeqID);
			Run  (Seq.LeakageSeqID);

			Run  (IDs.AIdd);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Run  (IDs.AIss);
			Run  (IDs.DIcc);

			Run  (Seq.VinVrefSeqID);

			Run  (IDs.readMasterFuse);
//			Run (IDs.Read_X_Coordinate);
//			Run (IDs.Read_Y_Coordinate);
//			Run (IDs.Read_Wafer_number);
			Run  (IDs.DeviceID);


			Run  (IDs.Vgen5V);
			Run  (IDs.Vgen7V);

			Run  (IDs.IbiasTrimCode);
			Run  (IDs.IbiasPostTrim);
			Run  (IDs.TempcoTrimCode);

			if(App.Globals.PincheckEnable)
                App.TC.BlowFuses = true;

			if(App.Globals.GndSnsEnable)
				HW.Rdc.Set(PM.D22, OpenClose.CLOSE);
			else
				HW.Rdc.Set(PM.D22, OpenClose.OPEN);

			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				RunIf(App.TC.BlowFuses, Seq.RWPreTrimSeqID);
			} 
			else if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
			{
				RunIf(App.TC.BlowFuses, Seq.AD5749_PreTrimSeqID);
			} 
			else
                RunIf(App.TC.BlowFuses, Seq.PreTrimSeqID);

			if(App.Globals.PincheckEnable)
                App.TC.BlowFuses = false;

			RunIf(App.TC.BlowFuses, Seq.FuseBlowSeqID);

			//RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.WaferTC);

			/*
			//RunIf  (App.Globals.CharTestingEnable, IDs.VrefMeas);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VinLowMeas);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VinHighMeas);
			//RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.IloadLowMeas);
			//RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.IloadHighMeas);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VscaleLowLoad);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VscaleLowRatio);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VscaleHighLoad);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VscaleHighRatio);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VscaleHighM);
			RunIf  (((App.Globals.CharTestingEnable) || (App.Globals.YaTestingEnable)), IDs.VscaleHighC);
*/

			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				Run  (Seq.RWPostTrimSeqID);
			} 
			else if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
			{
				Run  (Seq.AD5749_PostTrimSeqID);
			} 
			else
				Run  (Seq.PostTrimSeqID);

			if((App.Globals.ActiveSelector != App.Selectors.PD_HV_5749) && (App.Globals.ActiveSelector != App.Selectors.QC_HV_5749))
			{
				Run	 (IDs.PowerupToZero);
				Run  (IDs.PowerupToMid);
				Run	 (IDs.PowerupTristate);
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                Run  (IDs.VsensenFunc);

			Run  (IDs.VRangeAIdd);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Run  (IDs.VRangeAIss);
			Run  (IDs.VRangeDIcc);
			Run  (IDs.IRangeAIdd);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Run  (IDs.IRangeAIss);
			Run  (IDs.IRangeDIcc);

			Run  (Seq.HWmodeFuncSeqID);

			//RunIf  ((App.Globals.CharTestingEnable || App.Globals.YaTestingEnable), Seq.TestModeSeqID);
			Run  (Seq.SWmodeFuncSeqID);

			//RunIf ((App.Globals.CharTestingEnable || App.Globals.YaTestingEnable), Seq.CharSeqID);

			Run  (IDs.IoutTristateLkg);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Run  (IDs.vsensenLkg);
			Run  (IDs.VoutTristateLkg);

			Run	 (IDs.PostTestAIdd);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Run	(IDs.PostTestAIss);
			Run	 (IDs.PostTestDIcc);

			Run (IDs.CoolOffset);
			Run (IDs.WarmOffset);
			Run (IDs.OffsetDelta);

			//Disonnect outputs from relevant loads/feedback pins
			//VsenseN/Vsensep connection
			HW.Rdc.Set(PM.D15, OpenClose.OPEN);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.OPEN);

			HW.Rdc.Set(PM.D9, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.OPEN);
			//Default to 300ohm load
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.OPEN);

			if(((TP.Part.PassingSites & 0x1) == 1) && (App.TC.MasterFuse[Site.S1] == 0))
				App.TC.DeviceId[Site.S1]++;
			if((((TP.Part.PassingSites >> 1) & 0x1) == 1) && (App.TC.MasterFuse[Site.S2] == 0))
				App.TC.DeviceId[Site.S2]++;
			if((((TP.Part.PassingSites >> 2) & 0x1) == 1) && (App.TC.MasterFuse[Site.S3] == 0))
				App.TC.DeviceId[Site.S3]++;
			if((((TP.Part.PassingSites >> 3) & 0x1) == 1) && (App.TC.MasterFuse[Site.S4] == 0))
				App.TC.DeviceId[Site.S4]++;


		}
		#endregion

	} // end of class AD575xSeq
	#endregion

	//
	// OpensShortsSeq Sequencer
	//
	#region OpensShortsSeq                  :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class OpensShortsSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region OpensShortsSeq                  :
		public OpensShortsSeq()
			: base(Seq.OpensShortsSeqID)
		{
			//   Test ID               Limits					Fail Bin				Test Function
			Add(IDs.NCcheck,           Limits.PassFail,			Bins.Continuity,		new NoConnects( ));

			#region ContactResChecks
			Add(IDs.GndSnsRes50mv,	   Limits.GndRes50mV,		Bins.Continuity,		new GndResCheck( ));
			Add(IDs.GndSnsRes100mv,	   Limits.GndRes100mV,		Bins.Continuity,		new GndResCheck( ));

			Add(IDs.ContHighSD0,       Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighClrsel,    Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighClr,       Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighSync,      Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighSclk,      Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighSdin,      Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighAD2,       Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighAD1,       Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighAD0,       Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighRext1,     Limits.ContThreeDiodePos,Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighRext2,     Limits.ContRext2Pos,		Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighVref,      Limits.ContThreeDiodePos,Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighVin,       Limits.ContThreeDiodePos,Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighIout,      Limits.ContTwoDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighComp1,     Limits.ContComp1,		Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighComp2,     Limits.ContComp2,		Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighVsensen,   Limits.ContVsenseN,		Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighVout,      Limits.ContTwoDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighVsensep,   Limits.ContVsenseP,		Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighHwsel,     Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighReset,     Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighFault,     Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContHighNcIfault,  Limits.ContOneDiodePos,	Bins.Continuity,		new ContinuityResCheck( ));

			Add(IDs.ContLowSD0,        Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowClrsel,     Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowClr,        Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowSync,       Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowSclk,       Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowSdin,       Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowAD2,        Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowAD1,        Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowAD0,        Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowRext1,      Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowRext2,      Limits.ContRext2Neg,		Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowVref,       Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowVin,        Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowIout,       Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowComp1,      Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowComp2,      Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				Add(IDs.ContLowVsensen,    Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			}
			else
				Add(IDs.ContLowVsensen,    Limits.ContVsenseN,	Bins.Continuity,		new ContinuityResCheck( ));

			Add(IDs.ContLowVout,       Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowVsensep,    Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowHwsel,      Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowReset,      Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowFault,      Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.ContLowNcIfault,   Limits.ContOneDiodeNeg,	Bins.Continuity,		new ContinuityResCheck( ));

			Add(IDs.VoutHiRes,        Limits.VoutHiDiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));

			Add(IDs.Rext1LoRes,      Limits.DiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.Rext2LoRes,      Limits.Rext2LoDiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.VrefLoRes,       Limits.DiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.VinLoRes,        Limits.DiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.IoutLoRes,       Limits.DiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                Add(IDs.VsensenLoRes,    Limits.DiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.VoutLoRes,       Limits.DiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			Add(IDs.VsensepLoRes,    Limits.DiodeRes,	Bins.Continuity,		new ContinuityResCheck( ));
			#endregion

			Add(IDs.Continuity,        Limits.PassFail,			Bins.Continuity,		new Continuity2( ));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{

			Run  (IDs.NCcheck);

			#region ContactResCheck

			Run	 (IDs.GndSnsRes50mv);
			Run  (IDs.GndSnsRes100mv);

			Run  (IDs.ContHighSD0);
			Run  (IDs.ContHighClrsel);
			Run  (IDs.ContHighClr);
			Run  (IDs.ContHighSync);
			Run  (IDs.ContHighSclk);
			Run  (IDs.ContHighSdin);
			Run  (IDs.ContHighAD2);
			Run  (IDs.ContHighAD1);
			Run  (IDs.ContHighAD0);
			Run  (IDs.ContHighRext1);
			Run  (IDs.ContHighRext2);
			Run  (IDs.ContHighVref);
			Run  (IDs.ContHighVin);
			Run  (IDs.ContHighIout);
			Run  (IDs.ContHighComp1);
			Run  (IDs.ContHighComp2);
			Run  (IDs.ContHighVsensen);
			Run  (IDs.ContHighVout);
			Run  (IDs.ContHighVsensep);
			Run  (IDs.ContHighHwsel);
			Run  (IDs.ContHighReset);
			Run  (IDs.ContHighFault);
			Run  (IDs.ContHighNcIfault);

			Run  (IDs.ContLowSD0);
			Run  (IDs.ContLowClrsel);
			Run  (IDs.ContLowClr);
			Run  (IDs.ContLowSync);
			Run  (IDs.ContLowSclk);
			Run  (IDs.ContLowSdin);
			Run  (IDs.ContLowAD2);
			Run  (IDs.ContLowAD1);
			Run  (IDs.ContLowAD0);
			Run  (IDs.ContLowRext1);
			Run  (IDs.ContLowRext2);
			Run  (IDs.ContLowVref);
			Run  (IDs.ContLowVin);
			Run  (IDs.ContLowIout);
			Run  (IDs.ContLowComp1);
			Run  (IDs.ContLowComp2);
			Run  (IDs.ContLowVsensen);
			Run  (IDs.ContLowVout);
			Run  (IDs.ContLowVsensep);
			Run  (IDs.ContLowHwsel);
			Run  (IDs.ContLowReset);
			Run  (IDs.ContLowFault);
			Run  (IDs.ContLowNcIfault);

			Run  (IDs.VoutHiRes);

			//Run  (IDs.SD0LoRes);
			//Run  (IDs.ClrselLoRes);
			//Run  (IDs.ClrLoRes);
			//Run  (IDs.SyncLoRes);
			//Run  (IDs.SclkLoRes);
			//Run  (IDs.SdinLoRes);
			//Run  (IDs.AD2LoRes);
			//Run  (IDs.AD1LoRes);
			//Run  (IDs.AD0LoRes);
			Run  (IDs.Rext1LoRes);
			Run  (IDs.Rext2LoRes);
			Run  (IDs.VrefLoRes);
			Run  (IDs.VinLoRes);
			Run  (IDs.IoutLoRes);
			//Run  (IDs.Comp1LoRes);
			//Run  (IDs.Comp2LoRes);
			//Run  (IDs.VsensenLoRes);
			Run  (IDs.VoutLoRes);
			Run  (IDs.VsensepLoRes);
			//Run  (IDs.HwselLoRes);
			//Run  (IDs.ResetLoRes);
			//Run  (IDs.FaultLoRes);
			//Run  (IDs.NcIfaultLoRes);

			#endregion

		//	Run  (IDs.Continuity);
		
		}
		#endregion
	}// end of class OpensShortsSeq
	#endregion

	//
	// LeakageSeq Sequencer
	//
	#region LeakageSeq                      :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class LeakageSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region LeakageSeq                      :
		public LeakageSeq()
			: base(Seq.LeakageSeqID)
		{
			//   Test ID               Limits             Fail Bin           Test Function
			Add(IDs.SdoLeakage0V,      Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.ClrselLeakage0V,   Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.ClearLeakage0V,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.SyncLeakage0V,     Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.SclkLeakage0V,     Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.SdinLeakage0V,     Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.Ad2Leakage0V,      Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.Ad1Leakage0V,      Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.Ad0Leakage0V,      Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.HwselLeakage0V,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.ResetLeakage0V,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.FaultLeakage0V,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.IfaultLeakage0V,   Limits.IfaultLkg,		Bins.LogicCurrents,			new ParallelLeakage( ));

			Add(IDs.SdoLeakageDvcc,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.ClrselLeakageDvcc, Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.ClearLeakageDvcc,  Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.SyncLeakageDvcc,   Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.SclkLeakageDvcc,   Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.SdinLeakageDvcc,   Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.Ad2LeakageDvcc,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.Ad1LeakageDvcc,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.Ad0LeakageDvcc,    Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.HwselLeakageDvcc,  Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.ResetLeakageDvcc,  Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.FaultLeakageDvcc,  Limits.Leakage,			Bins.LogicCurrents,			new ParallelLeakage( ));
			Add(IDs.IfaultLeakageDvcc, Limits.IfaultLkg,		Bins.LogicCurrents,			new ParallelLeakage( ));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			Run  (IDs.SdoLeakage0V);
			Run  (IDs.ClrselLeakage0V);
			Run  (IDs.ClearLeakage0V);
			Run  (IDs.SyncLeakage0V);
			Run  (IDs.SclkLeakage0V);
			Run  (IDs.SdinLeakage0V);
			Run  (IDs.Ad2Leakage0V);
			Run  (IDs.Ad1Leakage0V);
			Run  (IDs.Ad0Leakage0V);
			Run  (IDs.HwselLeakage0V);
			Run  (IDs.ResetLeakage0V);
			Run  (IDs.FaultLeakage0V);
			Run  (IDs.IfaultLeakage0V);

			Run  (IDs.SdoLeakageDvcc);
			Run	 (IDs.ClrselLeakageDvcc);
			Run  (IDs.ClearLeakageDvcc);
			Run  (IDs.SyncLeakageDvcc);
			Run  (IDs.SclkLeakageDvcc);
			Run  (IDs.SdinLeakageDvcc);
			Run  (IDs.Ad2LeakageDvcc);
			Run  (IDs.Ad1LeakageDvcc);
			Run  (IDs.Ad0LeakageDvcc);
			Run  (IDs.HwselLeakageDvcc);
			Run  (IDs.ResetLeakageDvcc);
			Run  (IDs.FaultLeakageDvcc);
			Run  (IDs.IfaultLeakageDvcc);
		}
		#endregion
	}// end of class LeakageSeq
	#endregion

	//
	// VinVrefSeq Sequencer
	//
	#region VinVrefSeq                      :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class VinVrefSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region VinVrefSeq                      :
		public VinVrefSeq()
			: base(Seq.VinVrefSeqID)
		{
			//   Test ID               Limits             Fail Bin           Test Function
			Add(IDs.VrefCurrent,       Limits.VrefLkg,			Bins.RefLkgs,			new VinVrefTests( ));
			Add(IDs.VrefCurrentHi,     Limits.VrefLkg,			Bins.RefLkgs,			new VinVrefTests( ));
			Add(IDs.VinCurrent,        Limits.Leakage,			Bins.RefLkgs,			new VinVrefTests( ));
			Add(IDs.VinCurrentHi,      Limits.Leakage,			Bins.RefLkgs,			new VinVrefTests( ));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			Run  (IDs.VrefCurrent);
			Run  (IDs.VrefCurrentHi);
			Run  (IDs.VinCurrent);
			Run  (IDs.VinCurrentHi);
		}
		#endregion
	}// end of class VinVrefSeq
	#endregion

	//
	// PreTrimSeq Sequencer
	//
	#region PreTrimSeq                      :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class PreTrimSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region PreTrimSeq                      :
		public PreTrimSeq()
			: base(Seq.PreTrimSeqID)
		{
			App.MeasOptions resourceSelect;
			if(App.Globals.PreTrimDigDmm)
				resourceSelect = App.MeasOptions.DIG;
			else
				resourceSelect = App.MeasOptions.DMM;


			if(App.Globals.GenericType == App.GenericType.HV_GEN)
				Add(IDs.BlowHighVoltage,   Limits.PassFail,   Bins.FuseBlow,     new Blow5751Fuse( ));

			App.RangeOptions range = App.RangeOptions.FIVE_V;
			App.ResSel rSel = App.ResSel.R_INT;
			int vIndexStart = 8;
			int index40v = 2;

			//   Test ID               Limits						Fail Bin				Test Function
			Add(IDs.OffsetError5V,     Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode5V,  Limits.vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError5V,       Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode5V,    Limits.vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));

			range = App.RangeOptions.TEN_V;
			Add(IDs.OffsetError10V,    Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode10V, Limits.vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError10V,      Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode10V,   Limits.vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				range = App.RangeOptions.FIVE_V_BIP;
				Add(IDs.OffsetError5Vbip,  Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.FIVE_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.OffsetTrimCode5Vbip, Limits.vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FIVE_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainError5Vbip,    Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.FIVE_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainTrimCode5Vbip, Limits.vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FIVE_V_BIP, App.ResSel.R_INT, resourceSelect));

				range = App.RangeOptions.TEN_V_BIP;
				Add(IDs.OffsetError10Vbip, Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.OffsetTrimCode10Vbip, Limits.vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart], Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainError10Vbip,   Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainTrimCode10Vbip,Limits.vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
			}
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				range = App.RangeOptions.FORTY_V;
				Add(IDs.OffsetError40V,		Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.FORTY_V, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.OffsetTrimCode40V,	Limits.vOffsetTrimCode[index40v],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FORTY_V, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.GainError40V,		Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.FORTY_V, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.GainTrimCode40V,	Limits.vGainTrimCode[index40v],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FORTY_V, App.ResSel.R_EXT, resourceSelect));
			}
				
			range = App.RangeOptions.FOUR_TWENTY_MA;
			Add(IDs.OffsetError4to20mInt,	Limits.RangeIOffset,	Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode4to20mInt,Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError4to20mInt,		Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode4to20mInt,	Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));

			range = App.RangeOptions.TWENTY_MA;
			Add(IDs.OffsetError20mInt,		Limits.RangeIOffset,	Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode20mInt,	Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError20mInt,		Limits.RangeIGainError[(int)rSel],	Bins.RangeGain,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode20mInt,		Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			
			range = App.RangeOptions.TWENTY_FOUR_MA;
			Add(IDs.OffsetError24mInt,		Limits.RangeIOffset, Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode24mInt,	Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError24mInt,		Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode24mInt,		Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				range = App.RangeOptions.TWENTY_MA_BIP;
				Add(IDs.OffsetError20mBipInt,	Limits.RangeIOffset,	Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.OffsetTrimCode20mBipInt,Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainError20mBipInt,		Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,		new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainTrimCode20mBipInt,	Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_INT, resourceSelect));
			
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				Add(IDs.OffsetError24mBipInt,	Limits.RangeIOffset,	Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.OffsetTrimCode24mBipInt,Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainError24mBipInt,		Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainTrimCode24mBipInt,	Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_INT, resourceSelect));
			}

			rSel = App.ResSel.R_EXT;
			range = App.RangeOptions.FOUR_TWENTY_MA;
			Add(IDs.OffsetError4to20m, Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.OffsetTrimCode4to20m, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainError4to20m,   Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainTrimCode4to20m,Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));

			range = App.RangeOptions.TWENTY_MA;
			Add(IDs.OffsetError20m,    Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.OffsetTrimCode20m, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainError20m,      Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainTrimCode20m,   Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			
			range = App.RangeOptions.TWENTY_FOUR_MA;
			Add(IDs.OffsetError24m,    Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.OffsetTrimCode24m, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainError24m,      Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainTrimCode24m,   Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
			
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				range = App.RangeOptions.TWENTY_MA_BIP;
				Add(IDs.OffsetError20mBip, Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.OffsetTrimCode20mBip, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.GainError20mBip,   Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.GainTrimCode20mBip,Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_MA_BIP, App.ResSel.R_EXT, resourceSelect));
			
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
				Add(IDs.OffsetError24mBip, Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.OffsetTrimCode24mBip, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.GainError24mBip,   Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_EXT, resourceSelect));
				Add(IDs.GainTrimCode24mBip,Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA_BIP, App.ResSel.R_EXT, resourceSelect));
			}
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
                Run  (IDs.BlowHighVoltage);

			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);

			Run  (IDs.GainTrimCode5V);
			Run  (IDs.GainError5V);
			Run  (IDs.OffsetTrimCode5V);
			Run  (IDs.OffsetError5V);

			Run  (IDs.GainTrimCode10V);
			Run  (IDs.GainError10V);
			Run  (IDs.OffsetTrimCode10V);
			Run  (IDs.OffsetError10V);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				Run  (IDs.GainTrimCode5Vbip);
				Run  (IDs.GainError5Vbip);
				Run  (IDs.OffsetTrimCode5Vbip);
				Run  (IDs.OffsetError5Vbip);

				Run  (IDs.GainTrimCode10Vbip);
				Run  (IDs.GainError10Vbip);
				Run  (IDs.OffsetTrimCode10Vbip);
				Run  (IDs.OffsetError10Vbip);
			}
			else if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.CLOSE);
				Run  (IDs.GainTrimCode40V);
				Run  (IDs.GainError40V);
				Run  (IDs.OffsetTrimCode40V);
				Run  (IDs.OffsetError40V);
				HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);
			}

			// For current ranges, pull vout to 0 via load resistor
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			Run  (IDs.GainTrimCode4to20mInt);
			Run  (IDs.GainError4to20mInt);
			Run  (IDs.OffsetTrimCode4to20mInt);
			Run  (IDs.OffsetError4to20mInt);

			Run  (IDs.GainTrimCode20mInt);
			Run  (IDs.GainError20mInt);
			Run  (IDs.OffsetTrimCode20mInt);
			Run  (IDs.OffsetError20mInt);

			Run  (IDs.GainTrimCode24mInt);
			Run  (IDs.GainError24mInt);
			Run  (IDs.OffsetTrimCode24mInt);
			Run  (IDs.OffsetError24mInt);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				Run  (IDs.GainTrimCode20mBipInt);
				Run  (IDs.GainError20mBipInt);
				Run  (IDs.OffsetTrimCode20mBipInt);
				Run  (IDs.OffsetError20mBipInt);

				Run  (IDs.GainTrimCode24mBipInt);
				Run  (IDs.GainError24mBipInt);
				Run  (IDs.OffsetTrimCode24mBipInt);
				Run  (IDs.OffsetError24mBipInt);
			}

			Run  (IDs.GainTrimCode4to20m);
			Run  (IDs.GainError4to20m);
			Run  (IDs.OffsetTrimCode4to20m);
			Run  (IDs.OffsetError4to20m);

			Run  (IDs.GainTrimCode20m);
			Run  (IDs.GainError20m);
			Run  (IDs.OffsetTrimCode20m);
			Run  (IDs.OffsetError20m);

			Run  (IDs.GainTrimCode24m);
			Run  (IDs.GainError24m);
			Run  (IDs.OffsetTrimCode24m);
			Run  (IDs.OffsetError24m);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				Run  (IDs.GainTrimCode20mBip);
				Run  (IDs.GainError20mBip);
				Run  (IDs.OffsetTrimCode20mBip);
				Run  (IDs.OffsetError20mBip);

				Run  (IDs.GainTrimCode24mBip);
				Run  (IDs.GainError24mBip);
				Run  (IDs.OffsetTrimCode24mBip);
				Run  (IDs.OffsetError24mBip);
			}

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class PreTrimSeq
	#endregion

	//
	// PreTrimSeq Sequencer for Rockwell Special only
	//
	#region RWPreTrimSeq                      :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class RWPreTrimSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region RWPreTrimSeq                      :
		public RWPreTrimSeq()
			: base(Seq.RWPreTrimSeqID)
		{
			App.MeasOptions resourceSelect;
			if(App.Globals.PreTrimDigDmm)
				resourceSelect = App.MeasOptions.DIG;
			else
				resourceSelect = App.MeasOptions.DMM;

			App.RangeOptions range = App.RangeOptions.TEN_V;
			App.ResSel rSel = App.ResSel.R_INT;
			int vIndexStart = 8;

			//   Test ID               Limits						Fail Bin				Test Function
			range = App.RangeOptions.FIVE_V;
			Add(IDs.OffsetError5V,    Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode5V, Limits.vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError5V,      Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode5V,   Limits.vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FIVE_V, App.ResSel.R_INT, resourceSelect));

			range = App.RangeOptions.TEN_V;
			Add(IDs.OffsetError10V,    Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode10V, Limits.vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError10V,      Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode10V,   Limits.vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V, App.ResSel.R_INT, resourceSelect));

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				range = App.RangeOptions.TEN_V_BIP;
				Add(IDs.OffsetError10Vbip, Limits.RangeVOffsetError, Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.OffsetTrimCode10Vbip, Limits.vOffsetTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart], Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainError10Vbip,   Limits.RangeVGainError,	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
				Add(IDs.GainTrimCode10Vbip,Limits.vGainTrimCode[App.TC.RangeData[(int)range].Index - vIndexStart],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TEN_V_BIP, App.ResSel.R_INT, resourceSelect));
			}
				
			range = App.RangeOptions.FOUR_TWENTY_MA;
			Add(IDs.OffsetError4to20mInt,	Limits.RangeIOffset,	Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode4to20mInt,Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError4to20mInt,		Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode4to20mInt,	Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));

			range = App.RangeOptions.TWENTY_MA;
			Add(IDs.OffsetError20mInt,		Limits.RangeIOffset,	Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode20mInt,	Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError20mInt,		Limits.RangeIGainError[(int)rSel],	Bins.RangeGain,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode20mInt,		Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT, resourceSelect));

			rSel = App.ResSel.R_EXT;
			range = App.RangeOptions.FOUR_TWENTY_MA;
			Add(IDs.OffsetError4to20m, Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.OffsetTrimCode4to20m, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainError4to20m,   Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainTrimCode4to20m,Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));

			range = App.RangeOptions.TWENTY_MA;
			Add(IDs.OffsetError20m,    Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.OffsetTrimCode20m, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainError20m,      Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainTrimCode20m,   Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			
			Run  (IDs.GainTrimCode5V);
			Run  (IDs.GainError5V);
			Run  (IDs.OffsetTrimCode5V);
			Run  (IDs.OffsetError5V);

			Run  (IDs.GainTrimCode10V);
			Run  (IDs.GainError10V);
			Run  (IDs.OffsetTrimCode10V);
			Run  (IDs.OffsetError10V);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				Run  (IDs.GainTrimCode10Vbip);
				Run  (IDs.GainError10Vbip);
				Run  (IDs.OffsetTrimCode10Vbip);
				Run  (IDs.OffsetError10Vbip);
			}

			// For current ranges, pull vout to 0 via load resistor
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			Run  (IDs.GainTrimCode4to20mInt);
			Run  (IDs.GainError4to20mInt);
			Run  (IDs.OffsetTrimCode4to20mInt);
			Run  (IDs.OffsetError4to20mInt);

			Run  (IDs.GainTrimCode20mInt);
			Run  (IDs.GainError20mInt);
			Run  (IDs.OffsetTrimCode20mInt);
			Run  (IDs.OffsetError20mInt);

			Run  (IDs.GainTrimCode4to20m);
			Run  (IDs.GainError4to20m);
			Run  (IDs.OffsetTrimCode4to20m);
			Run  (IDs.OffsetError4to20m);

			Run  (IDs.GainTrimCode20m);
			Run  (IDs.GainError20m);
			Run  (IDs.OffsetTrimCode20m);
			Run  (IDs.OffsetError20m);

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class RWPreTrimSeq
	#endregion

	//
	// AD5749_PreTrimSeq Sequencer
	//
	#region AD5749_PreTrimSeq                      :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class AD5749_PreTrimSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region AD5749_PreTrimSeq                      :
		public AD5749_PreTrimSeq()
			: base(Seq.AD5749_PreTrimSeqID)
		{
			App.MeasOptions resourceSelect;
			if(App.Globals.PreTrimDigDmm)
				resourceSelect = App.MeasOptions.DIG;
			else
				resourceSelect = App.MeasOptions.DMM;


			if(App.Globals.GenericType == App.GenericType.HV_GEN)
				Add(IDs.BlowHighVoltage,   Limits.PassFail,   Bins.FuseBlow,     new Blow5751Fuse( ));


			App.RangeOptions range = App.RangeOptions.FOUR_TWENTY_MA;
			App.ResSel rSel = App.ResSel.R_INT;

			//   Test ID               Limits						Fail Bin				Test Function
			range = App.RangeOptions.FOUR_TWENTY_MA;
			Add(IDs.OffsetError4to20mInt,	Limits.RangeIOffset,	Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode4to20mInt,Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError4to20mInt,		Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode4to20mInt,	Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_INT, resourceSelect));

			range = App.RangeOptions.TWENTY_FOUR_MA;
			Add(IDs.OffsetError24mInt,		Limits.RangeIOffset, Bins.PreTrimOffset,	new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.OffsetTrimCode24mInt,	Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainError24mInt,		Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			Add(IDs.GainTrimCode24mInt,		Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_INT, resourceSelect));
			
			rSel = App.ResSel.R_EXT;
			range = App.RangeOptions.FOUR_TWENTY_MA;
			Add(IDs.OffsetError4to20m, Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.OffsetTrimCode4to20m, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainError4to20m,   Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainTrimCode4to20m,Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.FOUR_TWENTY_MA, App.ResSel.R_EXT, resourceSelect));

			range = App.RangeOptions.TWENTY_FOUR_MA;
			Add(IDs.OffsetError24m,    Limits.RangeIOffset,		Bins.PreTrimOffset,		new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.OffsetTrimCode24m, Limits.iOffsetTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainError24m,      Limits.RangeIGainError[(int)rSel],	Bins.PreTrimGain,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
			Add(IDs.GainTrimCode24m,   Limits.iGainTrimCode[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PreTrimCode,			new RangeTrim(App.RangeOptions.TWENTY_FOUR_MA, App.ResSel.R_EXT, resourceSelect));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
				Run  (IDs.BlowHighVoltage);

			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			// For current ranges, pull vout to 0 via load resistor
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			Run  (IDs.GainTrimCode4to20mInt);
			Run  (IDs.GainError4to20mInt);
			Run  (IDs.OffsetTrimCode4to20mInt);
			Run  (IDs.OffsetError4to20mInt);

			Run  (IDs.GainTrimCode24mInt);
			Run  (IDs.GainError24mInt);
			Run  (IDs.OffsetTrimCode24mInt);
			Run  (IDs.OffsetError24mInt);

			Run  (IDs.GainTrimCode4to20m);
			Run  (IDs.GainError4to20m);
			Run  (IDs.OffsetTrimCode4to20m);
			Run  (IDs.OffsetError4to20m);

			Run  (IDs.GainTrimCode24m);
			Run  (IDs.GainError24m);
			Run  (IDs.OffsetTrimCode24m);
			Run  (IDs.OffsetError24m);

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class AD5749_PreTrimSeq
	#endregion

	//
	// FuseBlowSeq Sequencer
	//
	#region FuseBlowSeq                     :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class FuseBlowSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region FuseBlowSeq                     :
		public FuseBlowSeq()
			: base(Seq.FuseBlowSeqID)
		{
			//   Test ID               Limits             Fail Bin           Test Function
			Add(IDs.BlowFuseMem,	Limits.PassFail,	Bins.FuseBlow,		new BlowFuses( ));
			Add(IDs.BlowMasterFuse,	Limits.PassFail,	Bins.FuseBlow,		new MasterFuseBlow( ));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			Run  (IDs.BlowFuseMem);
			Run  (IDs.BlowMasterFuse);
		}
		#endregion
	}// end of class FuseBlowSeq
	#endregion

	//
	// PostTrimSeq Sequencer
	//
	#region PostTrimSeq                     :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class PostTrimSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region PostTrimSeq                     :
		public PostTrimSeq()
			: base(Seq.PostTrimSeqID)
		{
			int msIndex;
			TestLimits zsLimit = Limits.RangeVZscaleError5v,
				offsetLimit = Limits.RangeVOffsetError5v,
				fsLimit = Limits.RangeVGainError, 
				gainLimit = Limits.RangeVGainError;

			//   Test ID						Limits					Fail Bin				Test Function
			App.MeasOptions resourceSelect;
			
			if(App.Globals.PostTrimDigDmm)
				resourceSelect = App.MeasOptions.DIG;
			else
				resourceSelect = App.MeasOptions.DMM;

			App.VLoadOptions load = App.VLoadOptions.LOAD_OFF;
			msIndex = 0;
			
			
			for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimVRanges; rangeIndex++)
			{
				App.RangeOptions range = App.TC.ActiveRanges[App.TC.NumActiveIRanges + rangeIndex];

				if(range == App.RangeOptions.FIVE_V)
				{
					zsLimit = Limits.RangeVZscaleError5v;
					offsetLimit = Limits.RangeVOffsetError5v;
					fsLimit = Limits.RangeVGainError;
					gainLimit = Limits.RangeVGainError;
				}
				else if(range == App.RangeOptions.TEN_V)
				{
					zsLimit = Limits.RangeVZscaleError10v;
					offsetLimit = Limits.RangeVOffsetError10v;
					fsLimit = Limits.RangeVGainError;
					gainLimit = Limits.RangeVGainError;
				}
				else if(range == App.RangeOptions.FIVE_V_BIP)
				{
					zsLimit = Limits.RangeVZscaleError5vBip;
					offsetLimit = Limits.RangeVOffsetError5vBip;
					fsLimit = Limits.RangeVGainError;
					gainLimit = Limits.RangeVGainError;
				}
				else if(range == App.RangeOptions.TEN_V_BIP)
				{
					zsLimit = Limits.RangeVZscaleError10vBip;
					offsetLimit = Limits.RangeVOffsetError10vBip;
					fsLimit = Limits.RangeVGainError;
					gainLimit = Limits.RangeVGainError;
				}
				else if(range == App.RangeOptions.FORTY_V)
				{
					zsLimit = Limits.RangeVZscaleError40v;
					offsetLimit = Limits.RangeVOffsetError40v;
					fsLimit = Limits.RangeVGainError;
					gainLimit = Limits.RangeVGainError40v;
				}


				if(App.Globals.GenericType == App.GenericType.HV_GEN)
					Add(IDs.vPostTrimOffset[rangeIndex],	offsetLimit, Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));

				Add(IDs.vPostTrimZSError[rangeIndex],		zsLimit,	Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
				Add(IDs.vPostTrimFSError[rangeIndex],		fsLimit,		Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
				if(App.TC.RangeData[(int)range].MidValue == 0.0)
				{
					Add(IDs.vPostTrimMSOffset[msIndex],		Limits.RangeVMscaleError[msIndex],	Bins.PostTrimOffset,	new RangeTue(range,	App.ResSel.R_EXT, load, resourceSelect));
					msIndex++;
				}
				if(App.Globals.GenericType == App.GenericType.HV_GEN)
				{
					//Run(IDs.vPostTrimDeadband[rangeIndex, (int)load, (int)resourceSelect]);
					Add(IDs.vPostTrimDBcalc[rangeIndex],	Limits.RangeDeadband,		Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
				}

				Add(IDs.vPostTrimGain[rangeIndex],			gainLimit,					Bins.PostTrimGain,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
				Add(IDs.vPostTrimLin[rangeIndex],			Limits.RangeVLin,			Bins.PostTrimLin,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
				Add(IDs.vPostTrimPosTueReal[rangeIndex],	Limits.RangeVTue,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
				Add(IDs.vPostTrimNegTueReal[rangeIndex],	Limits.RangeVTue,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
		
			}

			for(App.ResSel rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				msIndex = 0;

				for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimIRanges; rangeIndex++)
				{
					App.RangeOptions range = App.TC.ActiveRanges[rangeIndex];

					if(App.Globals.GenericType == App.GenericType.HV_GEN)
						Add(IDs.iPostTrimOffset[rangeIndex,(int)rSel],	Limits.RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PostTrimOffset,	new RangeTue(range, rSel, load, resourceSelect));

					Add(IDs.iPostTrimZSError[rangeIndex,(int)rSel],		Limits.RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					Add(IDs.iPostTrimFSError[rangeIndex,(int)rSel],		Limits.RangeIFSError[(int)rSel],		Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						Add(IDs.iPostTrimMSOffset[msIndex, (int)rSel],	Limits.RangeIMscaleError[msIndex, (int)rSel],	Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						msIndex++;
					}

					if(App.Globals.GenericType == App.GenericType.HV_GEN)
					{
						//Run(IDs.vPostTrimDeadband[rangeIndex, (int)load, (int)resourceSelect]);
						Add(IDs.iPostTrimDBcalc[rangeIndex,(int)rSel],	Limits.RangeDeadband,		Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					}

					Add(IDs.iPostTrimGain[rangeIndex,(int)rSel],		Limits.RangeIGainError[(int)rSel],		Bins.PostTrimGain,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						Add(IDs.iPostTrimLin[rangeIndex,(int)rSel],			Limits.RangeILinBip,			Bins.PostTrimLin,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					}
					else
					{
						Add(IDs.iPostTrimLin[rangeIndex,(int)rSel],			Limits.RangeILinUni,			Bins.PostTrimLin,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					}
					Add(IDs.iPostTrimPosTueReal[rangeIndex,(int)rSel],	Limits.RangeITuePos,		Bins.PostTrimTue,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					Add(IDs.iPostTrimNegTueReal[rangeIndex,(int)rSel],	Limits.RangeITueNeg,		Bins.PostTrimTue,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
				}
			}
			
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			int msIndex = 0;

			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			App.TC.RangeIndex = 0;

			//Temp Code
			
//			App.RangeOptions range = App.RangeOptions.FORTY_V;
//			Run(IDs.vPostTrimZSError[2]);
//			Run(IDs.vPostTrimFSError[2]);
//			if(App.Globals.GenericType == App.GenericType.HV_GEN)
//				Run(IDs.vPostTrimOffset[2]);
//			if(App.TC.RangeData[(int)range].MidValue == 0.0)
//			{
//				Run(IDs.vPostTrimMSOffset[msIndex]);
//				msIndex++;
//			}
//			Run(IDs.vPostTrimGain[2]);
//			Run(IDs.vPostTrimLin[2]);
//			Run(IDs.vPostTrimPosTueReal[2]);
//			Run(IDs.vPostTrimNegTueReal[2]);	
//			if(App.Globals.GenericType == App.GenericType.HV_GEN)
//			{
//				//Run(IDs.vPostTrimDeadband[rangeIndex, (int)load, (int)resourceSelect]);
//				Run(IDs.vPostTrimDBcalc[2]);
//			}
//			if(range == App.RangeOptions.FORTY_V)
//				HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);
			
			//Temp code!!
			


			for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimVRanges; rangeIndex++)
			{
				App.RangeOptions range = App.TC.ActiveRanges[App.TC.NumActiveIRanges + rangeIndex];

				if((App.TC.AVdd < 44.0) && (range == App.RangeOptions.FORTY_V))
				{
				}
				else
				{
					if(range == App.RangeOptions.FORTY_V)
					{
						HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.CLOSE);
					}

					Run(IDs.vPostTrimZSError[rangeIndex]);
					Run(IDs.vPostTrimFSError[rangeIndex]);
					if(App.Globals.GenericType == App.GenericType.HV_GEN)
						Run(IDs.vPostTrimOffset[rangeIndex]);
					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						Run(IDs.vPostTrimMSOffset[msIndex]);
						msIndex++;
					}
					Run(IDs.vPostTrimGain[rangeIndex]);
					Run(IDs.vPostTrimLin[rangeIndex]);
					Run(IDs.vPostTrimPosTueReal[rangeIndex]);
					Run(IDs.vPostTrimNegTueReal[rangeIndex]);	
					if(App.Globals.GenericType == App.GenericType.HV_GEN)
					{
						//Run(IDs.vPostTrimDeadband[rangeIndex, (int)load, (int)resourceSelect]);
						Run(IDs.vPostTrimDBcalc[rangeIndex]);
					}
					if(range == App.RangeOptions.FORTY_V)
						HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);
				}
			}


			for(App.ResSel rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				msIndex = 0;

				for(App.RangeOptions range = 0; (int)range < App.Globals.NumTrimIRanges; range++)
				{
					range = App.TC.ActiveRanges[(int)range];

					if(((range == App.RangeOptions.FORTY_V) && (App.TC.AVdd > 38.0)))
					{
					}
					else
					{
						Run(IDs.iPostTrimZSError[(int)range,(int)rSel]);
						Run(IDs.iPostTrimFSError[(int)range,(int)rSel]);
						if(App.Globals.GenericType == App.GenericType.HV_GEN)
							Run(IDs.iPostTrimOffset[(int)range,(int)rSel]);

						if(App.TC.RangeData[(int)range].MidValue == 0.0)
						{
							Run(IDs.iPostTrimMSOffset[msIndex, (int)rSel]);
							msIndex++;
						}

						Run(IDs.iPostTrimGain[(int)range,(int)rSel]);
						Run(IDs.iPostTrimLin[(int)range,(int)rSel]);
						Run(IDs.iPostTrimPosTueReal[(int)range,(int)rSel]);
						Run(IDs.iPostTrimNegTueReal[(int)range,(int)rSel]);
						if(App.Globals.GenericType == App.GenericType.HV_GEN)
						{
							//Run(IDs.iPostTrimDeadband[(int)range, (int)rSel, (int)resourceSelect]);
							Run(IDs.iPostTrimDBcalc[(int)range, (int)rSel]);
						}
					}
				}
			}
			
		}
		#endregion
	}// end of class PostTrimSeq
	#endregion

	//
	// RWPostTrimSeq Sequencer
	//
	#region RWPostTrimSeq                     :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class RWPostTrimSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region RWPostTrimSeq                     :
		public RWPostTrimSeq()
			: base(Seq.RWPostTrimSeqID)
		{
			int msIndex;
			TestLimits zsLimit = Limits.RangeVZscaleError5v,
				offsetLimit = Limits.RangeVOffsetError5v,
				fsLimit = Limits.RangeVGainError, 
				gainLimit = Limits.RangeVGainError;

			//   Test ID						Limits					Fail Bin				Test Function
			App.MeasOptions resourceSelect;
			
			if(App.Globals.PostTrimDigDmm)
				resourceSelect = App.MeasOptions.DIG;
			else
				resourceSelect = App.MeasOptions.DMM;

			App.VLoadOptions load = App.VLoadOptions.LOAD_OFF;
			msIndex = 1;
			
			#region VoltageRanges
			for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimVRanges; rangeIndex++)
			{
				//5V, 10V & +/-10V ranges only
				if(rangeIndex == 0)
				{
					App.RangeOptions range = App.TC.ActiveRanges[App.TC.NumActiveIRanges + rangeIndex];
					if(range == App.RangeOptions.FIVE_V)
					{
						zsLimit = Limits.RangeVZscaleError5v;
						offsetLimit = Limits.RangeVOffsetError5v;
						fsLimit = Limits.RangeVFSError;
						gainLimit = Limits.RangeVGainError;
					}

					Add(IDs.vPostTrimZSError[rangeIndex],		zsLimit,	Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					Add(IDs.vPostTrimFSError[rangeIndex],		fsLimit,	Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						Add(IDs.vPostTrimMSOffset[msIndex],		Limits.RangeVMscaleError[msIndex],	Bins.PostTrimOffset,	new RangeTue(range,	App.ResSel.R_EXT, load, resourceSelect));
						msIndex++;
					}
					Add(IDs.vPostTrimGain[rangeIndex],			gainLimit,					Bins.PostTrimGain,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					Add(IDs.vPostTrimLin[rangeIndex],			Limits.RangeVLin,			Bins.PostTrimLin,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					if((range == App.RangeOptions.TEN_V) || (range == App.RangeOptions.TEN_V_BIP))
					{
						Add(IDs.vPostTrimPosTueReal[rangeIndex],	Limits.RWVtue10v,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
						Add(IDs.vPostTrimNegTueReal[rangeIndex],	Limits.RWVtue10v,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					}
					else
					{
						Add(IDs.vPostTrimPosTueReal[rangeIndex],	Limits.RangeVTue,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
						Add(IDs.vPostTrimNegTueReal[rangeIndex],	Limits.RangeVTue,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					}
				}
			}
			#endregion

			#region currentRanges
			for(App.ResSel rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				msIndex = 0;

				for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimIRanges; rangeIndex++)
				{
					//4 - 20mA & 20mA ranges only
					if((rangeIndex == 0) || (rangeIndex == 1))
					{
						App.RangeOptions range = App.TC.ActiveRanges[rangeIndex];

						if(App.Globals.GenericType == App.GenericType.HV_GEN)
							Add(IDs.iPostTrimOffset[rangeIndex,(int)rSel],	Limits.RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PostTrimOffset,	new RangeTue(range, rSel, load, resourceSelect));

						Add(IDs.iPostTrimZSError[rangeIndex,(int)rSel],		Limits.RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						Add(IDs.iPostTrimFSError[rangeIndex,(int)rSel],		Limits.RangeIFSError[(int)rSel],		Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						if(App.TC.RangeData[(int)range].MidValue == 0.0)
						{
							Add(IDs.iPostTrimMSOffset[msIndex, (int)rSel],	Limits.RangeIMscaleError[msIndex, (int)rSel],	Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
							msIndex++;
						}

						if(App.Globals.GenericType == App.GenericType.HV_GEN)
						{
							//Run(IDs.vPostTrimDeadband[rangeIndex, (int)load, (int)resourceSelect]);
							Add(IDs.iPostTrimDBcalc[rangeIndex,(int)rSel],	Limits.RangeDeadband,		Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						}

						Add(IDs.iPostTrimGain[rangeIndex,(int)rSel],		Limits.RangeIGainError[(int)rSel],		Bins.PostTrimGain,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						if(App.TC.RangeData[(int)range].MidValue == 0.0)
						{
							Add(IDs.iPostTrimLin[rangeIndex,(int)rSel],			Limits.RangeILinBip,			Bins.PostTrimLin,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						}
						else
						{
							Add(IDs.iPostTrimLin[rangeIndex,(int)rSel],			Limits.RangeILinUni,			Bins.PostTrimLin,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						}
						Add(IDs.iPostTrimPosTueReal[rangeIndex,(int)rSel],	Limits.RangeITuePos,		Bins.PostTrimTue,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						Add(IDs.iPostTrimNegTueReal[rangeIndex,(int)rSel],	Limits.RangeITueNeg,		Bins.PostTrimTue,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					}
				}
			}
			#endregion

			#region RWoverranges
			int numOverranges = 2; 
			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				App.RangeOptions range = App.RangeOptions.TWELVE_V;

				for(int rangeIndex = 0; rangeIndex < numOverranges; rangeIndex++)
				{
					if(range == App.RangeOptions.TWELVE_V)
					{
						zsLimit = Limits.RangeVZscaleError10v;
						offsetLimit = Limits.RangeVOffsetError10v;
						fsLimit = Limits.RangeVGainError;
						gainLimit = Limits.RangeVGainError;
					}
					else if(range == App.RangeOptions.TWELVE_V_BIP)
					{
						zsLimit = Limits.RangeVZscaleError10vBip;
						offsetLimit = Limits.RangeVOffsetError10vBip;
						fsLimit = Limits.RangeVGainError;
						gainLimit = Limits.RangeVGainError;
					}

					Add(IDs.overRangeZS[rangeIndex],		zsLimit,	Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					Add(IDs.overRangeFS[rangeIndex],		fsLimit,		Bins.PostTrimOffset,	new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						Add(IDs.overRangeMS[rangeIndex],		Limits.RangeVMscaleError[rangeIndex],	Bins.PostTrimOffset,	new RangeTue(range,	App.ResSel.R_EXT, load, resourceSelect));
					}
					Add(IDs.overRangeGain[rangeIndex],			gainLimit,					Bins.PostTrimGain,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					Add(IDs.overRangeLin[rangeIndex],			Limits.RangeVLin,			Bins.PostTrimLin,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					Add(IDs.overRangePosTue[rangeIndex],	Limits.RangeVTue,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));
					Add(IDs.overRangeNegTue[rangeIndex],	Limits.RangeVTue,			Bins.PostTrimTue,		new RangeTue(range, App.ResSel.R_EXT, load, resourceSelect));

					range = range + 2; 
				}
			}
			#endregion

		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			int msIndex = 1;

			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			App.TC.RangeIndex = 0;
			
			#region voltageRanges
			for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimVRanges; rangeIndex++)
			{
				if(rangeIndex == 0)
				{
					App.RangeOptions range = App.TC.ActiveRanges[App.TC.NumActiveIRanges + rangeIndex];

					Run(IDs.vPostTrimZSError[rangeIndex]);
					Run(IDs.vPostTrimFSError[rangeIndex]);
					if(App.Globals.GenericType == App.GenericType.HV_GEN)
						Run(IDs.vPostTrimOffset[rangeIndex]);
					if(App.TC.RangeData[(int)range].MidValue == 0.0)
					{
						Run(IDs.vPostTrimMSOffset[msIndex]);
						msIndex++;
					}
					Run(IDs.vPostTrimGain[rangeIndex]);
					Run(IDs.vPostTrimLin[rangeIndex]);
					Run(IDs.vPostTrimPosTueReal[rangeIndex]);
					Run(IDs.vPostTrimNegTueReal[rangeIndex]);	
				}
			}

			#endregion

			#region currentRanges
			for(App.ResSel rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				msIndex = 0;

				for(App.RangeOptions range = 0; (int)range < App.Globals.NumTrimIRanges; range++)
				{
					range = App.TC.ActiveRanges[(int)range];

					if((range == App.RangeOptions.FOUR_TWENTY_MA) || (range == App.RangeOptions.TWENTY_MA))
					{
						Run(IDs.iPostTrimZSError[(int)range,(int)rSel]);
						Run(IDs.iPostTrimFSError[(int)range,(int)rSel]);
						if(App.Globals.GenericType == App.GenericType.HV_GEN)
							Run(IDs.iPostTrimOffset[(int)range,(int)rSel]);

						if(App.TC.RangeData[(int)range].MidValue == 0.0)
						{
							Run(IDs.iPostTrimMSOffset[msIndex, (int)rSel]);
							msIndex++;
						}

						Run(IDs.iPostTrimGain[(int)range,(int)rSel]);
						Run(IDs.iPostTrimLin[(int)range,(int)rSel]);
						Run(IDs.iPostTrimPosTueReal[(int)range,(int)rSel]);
						Run(IDs.iPostTrimNegTueReal[(int)range,(int)rSel]);
						if(App.Globals.GenericType == App.GenericType.HV_GEN)
						{
							//Run(IDs.iPostTrimDeadband[(int)range, (int)rSel, (int)resourceSelect]);
							Run(IDs.iPostTrimDBcalc[(int)range, (int)rSel]);
						}
					}                    		
				}
			}
			#endregion

			App.TC.RangeIndex = 0;

			#region Overranges
			int numOverranges = 2;

			App.RangeOptions rangeSelect = App.RangeOptions.TWELVE_V;

			for(int rangeIndex = 0; rangeIndex < numOverranges; rangeIndex++)
			{
				Run(IDs.overRangeZS[rangeIndex]);
				Run(IDs.overRangeFS[rangeIndex]);
				if(App.TC.RangeData[(int)rangeSelect].MidValue == 0.0)
				{
					Run(IDs.overRangeMS[rangeIndex]);
				}
				Run(IDs.overRangeGain[rangeIndex]);
				Run(IDs.overRangeLin[rangeIndex]);
				Run(IDs.overRangePosTue[rangeIndex]);
				Run(IDs.overRangeNegTue[rangeIndex]);

				rangeSelect = rangeSelect + 2; 
			}
			#endregion
		}
		#endregion
	}// end of class RWPostTrimSeq
	#endregion

	//
	// AD5749_PostTrimSeq Sequencer
	//
	#region AD5749_PostTrimSeq                     :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class AD5749_PostTrimSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region AD5749_PostTrimSeq                     :
		public AD5749_PostTrimSeq()
			: base(Seq.AD5749_PostTrimSeqID)
		{
			int msIndex;
			TestLimits zsLimit = Limits.RangeVZscaleError5v,
				offsetLimit = Limits.RangeVOffsetError5v,
				fsLimit = Limits.RangeVGainError, 
				gainLimit = Limits.RangeVGainError;

			//   Test ID						Limits					Fail Bin				Test Function
			App.MeasOptions resourceSelect;
			
			if(App.Globals.PostTrimDigDmm)
				resourceSelect = App.MeasOptions.DIG;
			else
				resourceSelect = App.MeasOptions.DMM;

			App.VLoadOptions load = App.VLoadOptions.LOAD_OFF;
			msIndex = 0;

			for(App.ResSel rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				msIndex = 0;

				for(int rangeIndex = 0; rangeIndex < App.Globals.NumTrimIRanges; rangeIndex++)
				{
					//4 - 20mA & 24mA ranges only
					if((rangeIndex == 0) || (rangeIndex == 2))
					{
						App.RangeOptions range = App.TC.ActiveRanges[rangeIndex];

						if(App.Globals.GenericType == App.GenericType.HV_GEN)
							Add(IDs.iPostTrimOffset[rangeIndex,(int)rSel],	Limits.RangeIOffsetError[App.TC.RangeData[(int)range].Index, (int)rSel], Bins.PostTrimOffset,	new RangeTue(range, rSel, load, resourceSelect));

						Add(IDs.iPostTrimZSError[rangeIndex,(int)rSel],		Limits.RangeIZscaleError[App.TC.RangeData[(int)range].Index, (int)rSel],	Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						Add(IDs.iPostTrimFSError[rangeIndex,(int)rSel],		Limits.RangeIFSError[(int)rSel],		Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						if(App.TC.RangeData[(int)range].MidValue == 0.0)
						{
							Add(IDs.iPostTrimMSOffset[msIndex, (int)rSel],	Limits.RangeIMscaleError[msIndex, (int)rSel],	Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
							msIndex++;
						}

						if(App.Globals.GenericType == App.GenericType.HV_GEN)
						{
							//Run(IDs.vPostTrimDeadband[rangeIndex, (int)load, (int)resourceSelect]);
							Add(IDs.iPostTrimDBcalc[rangeIndex,(int)rSel],	Limits.RangeDeadband,		Bins.PostTrimOffset,	new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						}

						Add(IDs.iPostTrimGain[rangeIndex,(int)rSel],		Limits.RangeIGainError[(int)rSel],		Bins.PostTrimGain,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						if(App.TC.RangeData[(int)range].MidValue == 0.0)
						{
							Add(IDs.iPostTrimLin[rangeIndex,(int)rSel],			Limits.RangeILinBip,			Bins.PostTrimLin,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						}
						else
						{
							Add(IDs.iPostTrimLin[rangeIndex,(int)rSel],			Limits.RangeILinUni,			Bins.PostTrimLin,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						}
						Add(IDs.iPostTrimPosTueReal[rangeIndex,(int)rSel],	Limits.RangeITuePos,		Bins.PostTrimTue,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
						Add(IDs.iPostTrimNegTueReal[rangeIndex,(int)rSel],	Limits.RangeITueNeg,		Bins.PostTrimTue,		new RangeTue(range, rSel, App.VLoadOptions.LOAD_ON, resourceSelect));
					}
				}
			}
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			int msIndex = 0;

			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			App.TC.RangeIndex = 0;
			
			for(App.ResSel rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				msIndex = 0;

				for(App.RangeOptions range = 0; (int)range < App.Globals.NumTrimIRanges; range++)
				{
					range = App.TC.ActiveRanges[(int)range];
					//4 - 20mA & 24mA ranges only
					if((range == App.RangeOptions.FOUR_TWENTY_MA) || (range == App.RangeOptions.TWENTY_FOUR_MA))
					{
						if(((range == App.RangeOptions.FORTY_V) && (App.TC.AVdd > 38.0)))
						{
						}
						else
						{
							Run(IDs.iPostTrimZSError[(int)range,(int)rSel]);
							Run(IDs.iPostTrimFSError[(int)range,(int)rSel]);
							if(App.Globals.GenericType == App.GenericType.HV_GEN)
								Run(IDs.iPostTrimOffset[(int)range,(int)rSel]);

							if(App.TC.RangeData[(int)range].MidValue == 0.0)
							{
								Run(IDs.iPostTrimMSOffset[msIndex, (int)rSel]);
								msIndex++;
							}

							Run(IDs.iPostTrimGain[(int)range,(int)rSel]);
							Run(IDs.iPostTrimLin[(int)range,(int)rSel]);
							Run(IDs.iPostTrimPosTueReal[(int)range,(int)rSel]);
							Run(IDs.iPostTrimNegTueReal[(int)range,(int)rSel]);
							if(App.Globals.GenericType == App.GenericType.HV_GEN)
							{
								//Run(IDs.iPostTrimDeadband[(int)range, (int)rSel, (int)resourceSelect]);
								Run(IDs.iPostTrimDBcalc[(int)range, (int)rSel]);
							}
						}
					}
				}
			}
			
		}
		#endregion
	}// end of class AD5749_PostTrimSeq
	#endregion

	//
	// HWmodeFuncSeq Sequencer
	//
	#region HWmodeFuncSeq                       :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class HWmodeFuncSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region HWmodeFuncSeq                       :
		public HWmodeFuncSeq()
			: base(Seq.HWmodeFuncSeqID)
		{
			//   Test ID							Limits				Fail Bin           Test Function
			#region HWRanges

			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				#region AD11/2077 HW checks
				Add(IDs.HwTrimmedRangesFunc,	Limits.PassFail,			Bins.DigFunc,		new HWrangesRW( ));

				if(App.TC.AVdd > 14.0)
				{
					Add(IDs.Hw12vGainExtR,			Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWrangesRW( ));
					Add(IDs.Hw12vOffsetExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
					Add(IDs.Hw12vFSErrExtR,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
				}

				if(App.TC.AVdd > 14.0)
				{
					Add(IDs.Hw12vBipGainExtR,		Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWrangesRW( ));
					Add(IDs.Hw12vBipOffsetExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
					Add(IDs.Hw12vBipFSErrExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
				}

				Add(IDs.Hw3ma92Gain,			Limits.OverrangeIGain,		Bins.PostTrimGain,	new HWrangesRW( ));
				Add(IDs.Hw3ma92Offset,			Limits.OverrangeIVinOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
				Add(IDs.Hw3ma92FSErr,			Limits.OverrangeIOffset,	Bins.PostTrimOffset,new HWrangesRW( ));

				Add(IDs.Hw20ma4Gain,			Limits.OverrangeIGain,		Bins.PostTrimGain,	new HWrangesRW( ));
				Add(IDs.Hw20ma4Offset,			Limits.OverrangeIVinOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
				Add(IDs.Hw20ma4FSErr,			Limits.OverrangeIOffset,	Bins.PostTrimOffset,new HWrangesRW( ));

				Add(IDs.Hw12vGain,				Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWrangesRW( ));
				Add(IDs.Hw12vOffset,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
				Add(IDs.Hw12vFSErr,				Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));

				Add(IDs.Hw12vBipGain,			Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWrangesRW( ));
				Add(IDs.Hw12vBipOffset,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
				Add(IDs.Hw12vBipFSErr,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWrangesRW( ));
				#endregion
			}
			else if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
			{
				#region AD5749 HW checks
				Add(IDs.HwTrimmedRangesFunc,	Limits.PassFail,			Bins.DigFunc,		new HWranges5749( ));

				Add(IDs.Hw3ma92Gain,			Limits.OverrangeIGain,		Bins.PostTrimGain,	new HWranges5749( ));
				Add(IDs.Hw3ma92Offset,			Limits.OverrangeIVinOffset,	Bins.PostTrimOffset,new HWranges5749( ));
				Add(IDs.Hw3ma92FSErr,			Limits.OverrangeIOffset,	Bins.PostTrimOffset,new HWranges5749( ));

				Add(IDs.Hw24ma5Gain,			Limits.OverrangeIGain,		Bins.PostTrimGain,	new HWranges5749( ));
				Add(IDs.Hw24ma5Offset,			Limits.OverrangeIVinOffset,	Bins.PostTrimOffset,new HWranges5749( ));
				Add(IDs.Hw24ma5FSErr,			Limits.OverrangeIOffset,	Bins.PostTrimOffset,new HWranges5749( ));
				#endregion
			}
			else
			{
				#region General HW checks
				Add(IDs.HwTrimmedRangesFunc,	Limits.PassFail,			Bins.DigFunc,		new HWranges( ));

				Add(IDs.Hw6vGainExtR,			Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw6vOffsetExtR,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw6vFSErrExtR,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));

				if(App.TC.AVdd > 14.0)
				{
					Add(IDs.Hw12vGainExtR,			Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
					Add(IDs.Hw12vOffsetExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
					Add(IDs.Hw12vFSErrExtR,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				}
				Add(IDs.Hw6vBipGainExtR,		Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw6vBipOffsetExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw6vBipFSErrExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));

				if(App.TC.AVdd > 14.0)
				{
					Add(IDs.Hw12vBipGainExtR,		Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
					Add(IDs.Hw12vBipOffsetExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
					Add(IDs.Hw12vBipFSErrExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				}

				Add(IDs.Hw2v5BipGainExtR,		Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw2v5BipOffsetExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw2v5BipFSErrExtR,		Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));

				if(App.Globals.GenericType == App.GenericType.HV_GEN)
				{
					Add(IDs.Hw44vGainExtR,			Limits.OverrangeVGain44v,		Bins.PostTrimGain,	new HWranges( ));
					Add(IDs.Hw44vOffsetExtR,		Limits.OverrangeVOffset44v,		Bins.PostTrimOffset,new HWranges( ));
					Add(IDs.Hw44vFSErrExtR,			Limits.OverrangeVOffset44v,		Bins.PostTrimOffset,new HWranges( ));
				}

				Add(IDs.Hw3ma92Gain,			Limits.OverrangeIGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw3ma92Offset,			Limits.OverrangeIVinOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw3ma92FSErr,			Limits.OverrangeIOffset,	Bins.PostTrimOffset,new HWranges( ));

				Add(IDs.Hw20ma4Gain,			Limits.OverrangeIGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw20ma4Offset,			Limits.OverrangeIVinOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw20ma4FSErr,			Limits.OverrangeIOffset,	Bins.PostTrimOffset,new HWranges( ));

				Add(IDs.Hw24ma5Gain,			Limits.OverrangeIGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw24ma5Offset,			Limits.OverrangeIVinOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw24ma5FSErr,			Limits.OverrangeIOffset,	Bins.PostTrimOffset,new HWranges( ));

				Add(IDs.Hw6vGain,				Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw6vOffset,				Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw6vFSErr,				Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));

				Add(IDs.Hw12vGain,				Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw12vOffset,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw12vFSErr,				Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));

				Add(IDs.Hw6vBipGain,			Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw6vBipOffset,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw6vBipFSErr,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));

				Add(IDs.Hw12vBipGain,			Limits.OverrangeVGain,		Bins.PostTrimGain,	new HWranges( ));
				Add(IDs.Hw12vBipOffset,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				Add(IDs.Hw12vBipFSErr,			Limits.OverrangeVOffset,	Bins.PostTrimOffset,new HWranges( ));
				#endregion
			}
			#endregion

			Add(IDs.HwClearFunc,			Limits.PassFail,	Bins.DigFunc,			new HWclear( ));
			
			if((App.Globals.ActiveSelector != App.Selectors.PD_HV_5749) && (App.Globals.ActiveSelector != App.Selectors.QC_HV_5749))
			{
				Add(IDs.HwVFaultFunc,			Limits.PassFail,	Bins.DigFunc,			new HWalarms( ));
				Add(IDs.HwVFault2mA5Func,		Limits.PassFail,	Bins.DigFunc,			new HWalarms( ));
			}
			Add(IDs.HwIFaultFunc,			Limits.PassFail,	Bins.DigFunc,			new HWalarms( ));
			Add(IDs.HwIFault2mA5Func,		Limits.PassFail,	Bins.DigFunc,			new HWalarms( ));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			Utl.SetDeviceMode(App.OpMode.HARDWARE);

			#region HwRanges

			if((App.Globals.ActiveSelector == App.Selectors.PD_RW_5750) || (App.Globals.ActiveSelector == App.Selectors.QC_RW_5750))
			{
				#region AD11/2077 HW checks
				Run  (IDs.HwTrimmedRangesFunc);

				if(App.TC.AVdd > 14.0)
				{
					Run  (IDs.Hw12vGainExtR);
					Run  (IDs.Hw12vOffsetExtR);
					Run  (IDs.Hw12vFSErrExtR);
				}
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{				
					if(App.TC.AVdd > 14.0)
					{
						Run  (IDs.Hw12vBipGainExtR);
						Run  (IDs.Hw12vBipOffsetExtR);
						Run  (IDs.Hw12vBipFSErrExtR);
					}
				}

				Run  (IDs.Hw3ma92Gain);
				Run  (IDs.Hw3ma92Offset);
				Run  (IDs.Hw3ma92FSErr);

				Run  (IDs.Hw20ma4Gain);
				Run  (IDs.Hw20ma4Offset);
				Run  (IDs.Hw20ma4FSErr);

				if(App.TC.AVdd > 14.0)
				{
					Run  (IDs.Hw12vGain);
					Run  (IDs.Hw12vOffset);
					Run  (IDs.Hw12vFSErr);
				}
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					if(App.TC.AVdd > 14.0)
					{
						Run  (IDs.Hw12vBipGain);
						Run  (IDs.Hw12vBipOffset);
						Run  (IDs.Hw12vBipFSErr);
					}
				}
				#endregion
			}
			else if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5749) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5749))
			{
				#region AD5749 HW checks
				Run  (IDs.HwTrimmedRangesFunc);

				Run  (IDs.Hw3ma92Gain);
				Run  (IDs.Hw3ma92Offset);
				Run  (IDs.Hw3ma92FSErr);

				Run  (IDs.Hw24ma5Gain);
				Run  (IDs.Hw24ma5Offset);
				Run  (IDs.Hw24ma5FSErr);
				#endregion
			}
			else
			{
				#region GenHWchecks
				Run  (IDs.HwTrimmedRangesFunc);

				Run  (IDs.Hw6vGainExtR);
				Run  (IDs.Hw6vOffsetExtR);
				Run  (IDs.Hw6vFSErrExtR);

				if(App.TC.AVdd > 14.0)
				{
					Run  (IDs.Hw12vGainExtR);
					Run  (IDs.Hw12vOffsetExtR);
					Run  (IDs.Hw12vFSErrExtR);
				}
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Run  (IDs.Hw6vBipGainExtR);
					Run  (IDs.Hw6vBipOffsetExtR);
					Run  (IDs.Hw6vBipFSErrExtR);
				
					if(App.TC.AVdd > 14.0)
					{
						Run  (IDs.Hw12vBipGainExtR);
						Run  (IDs.Hw12vBipOffsetExtR);
						Run  (IDs.Hw12vBipFSErrExtR);
					}
					Run  (IDs.Hw2v5BipGainExtR);
					Run  (IDs.Hw2v5BipOffsetExtR);
					Run  (IDs.Hw2v5BipFSErrExtR);
				}

				if((App.Globals.GenericType == App.GenericType.HV_GEN) && (App.TC.AVdd > 44.0))
				{
					Run  (IDs.Hw44vGainExtR);
					Run  (IDs.Hw44vOffsetExtR);
					Run  (IDs.Hw44vFSErrExtR);
				}

				Run  (IDs.Hw3ma92Gain);
				Run  (IDs.Hw3ma92Offset);
				Run  (IDs.Hw3ma92FSErr);

				Run  (IDs.Hw20ma4Gain);
				Run  (IDs.Hw20ma4Offset);
				Run  (IDs.Hw20ma4FSErr);

				Run  (IDs.Hw24ma5Gain);
				Run  (IDs.Hw24ma5Offset);
				Run  (IDs.Hw24ma5FSErr);

				Run  (IDs.Hw6vGain);
				Run  (IDs.Hw6vOffset);
				Run  (IDs.Hw6vFSErr);

				if(App.TC.AVdd > 14.0)
				{
					Run  (IDs.Hw12vGain);
					Run  (IDs.Hw12vOffset);
					Run  (IDs.Hw12vFSErr);
				}
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Run  (IDs.Hw6vBipGain);
					Run  (IDs.Hw6vBipOffset);
					Run  (IDs.Hw6vBipFSErr);

					if(App.TC.AVdd > 14.0)
					{
						Run  (IDs.Hw12vBipGain);
						Run  (IDs.Hw12vBipOffset);
						Run  (IDs.Hw12vBipFSErr);
					}
				}
				#endregion
			}

			#endregion

			Run  (IDs.HwClearFunc);
			//Run  (IDs.HwReset);

			if((App.Globals.ActiveSelector != App.Selectors.PD_HV_5749) && (App.Globals.ActiveSelector != App.Selectors.QC_HV_5749))
			{
				Run  (IDs.HwVFaultFunc);
				Run	 (IDs.HwVFault2mA5Func);
			}
			Run  (IDs.HwIFaultFunc);
			Run  (IDs.HwIFault2mA5Func);

			Utl.SetDeviceMode(App.OpMode.SOFTWARE);
			Utl.SetAddressPins(App.TC.DutAddress);
		}
		#endregion
	}// end of class HWmodeFuncSeq
	#endregion

	//
	// SWmodeFuncSeq Sequencer
	//
	#region SWmodeFuncSeq                   :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class SWmodeFuncSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region SWmodeFuncSeq                   :
		public SWmodeFuncSeq()
			: base(Seq.SWmodeFuncSeqID)
		{
			//   Test ID						Limits             Fail Bin				Test Function
			Add(IDs.DigLevelFunc,			Limits.PassFail,	Bins.DigFunc,			new DigLevelsFunc( ));
			Add(IDs.PecFunc,				Limits.PassFail,	Bins.DigFunc,			new DigLevelsFunc( ));

			Add(IDs.AddrFunc,				Limits.PassFail,	Bins.DigFunc,			new AddrPatFunc( ));
			Add(IDs.ClrFunc,				Limits.PassFail,	Bins.DigFunc,			new ClrFunc( ));
			Add(IDs.ResetFunc,				Limits.PassFail,	Bins.DigFunc,			new ResetFunc( ));
			Add(IDs.InvalidWrites,			Limits.PassFail,	Bins.DigFunc,			new InvalidWriteCheck( ));

			/*
			if(App.Globals.CharTestingEnable || App.Globals.YaTestingEnable)
			{
				Add(IDs.IFaultFuncChar,				Limits.PassFail,	Bins.DigFunc,			new IoutCompl( ));
				Add(IDs.IdealIoutVddChar,			Limits.complianceIout,	Bins.DigFunc,		new IoutCompl( ));
				Add(IDs.ComplianceVvddChar,			Limits.ComplianceV,	Bins.AnalogFunc,		new IoutCompl( ));
				Add(IDs.VddAlarmIoutChar,			Limits.complianceIout,	Bins.AnalogFunc,	new IoutCompl( ));
				Add(IDs.VddCurrAlrmDeltaFSRChar,	Limits.compIoutFSR, Bins.DigFunc,			new IoutCompl( ));
				
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Add(IDs.IdealIoutVssChar,			Limits.complianceIout,	Bins.DigFunc,		new IoutCompl( ));
					Add(IDs.ComplianceVvssChar,			Limits.ComplianceV, Bins.AnalogFunc,		new IoutCompl( ));
					Add(IDs.VssAlarmIoutChar,			Limits.complianceIout,	Bins.AnalogFunc,	new IoutCompl( ));
					Add(IDs.VssCurrAlrmDeltaFSRChar,	Limits.compIoutFSR, Bins.DigFunc,			new IoutCompl( ));
				}
				Add(IDs.SwFaultPinFuncChar,			Limits.PassFail,		Bins.DigFunc,			new IoutCompl( ));
				Add(IDs.SwFault2mA5FuncChar,		Limits.PassFail,		Bins.DigFunc,			new IoutCompl( ));
			}
*/
			Add(IDs.PecFaultFunc,			Limits.PassFail,	Bins.DigFunc,			new AlarmFunc( ));
			Add(IDs.OverTempFaultFunc,		Limits.PassFail,	Bins.DigFunc,			new AlarmFunc( ));

			Add(IDs.IFaultFunc,				Limits.PassFail,	Bins.DigFunc,			new AlarmFunc( ));
			Add(IDs.ComplFuncAvdd,			Limits.ioutAccuracy,Bins.DigFunc,			new AlarmFunc( ));
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				if((App.Globals.ActiveSelector != App.Selectors.PD_RW_5750) && (App.Globals.ActiveSelector != App.Selectors.QC_RW_5750))
				{
					Add(IDs.ComplFuncAvss,			Limits.ioutAccuracy,Bins.DigFunc,			new AlarmFunc( ));
				}
			}
			Add(IDs.SwFaultPinFunc,			Limits.PassFail,	Bins.DigFunc,			new AlarmFunc( ));
			Add(IDs.SwFault2mA5Func,		Limits.PassFail,	Bins.DigFunc,			new AlarmFunc( ));

			if((App.Globals.ActiveSelector != App.Selectors.PD_HV_5749) && (App.Globals.ActiveSelector != App.Selectors.QC_HV_5749))
			{
				Add(IDs.VFaultFunc,				Limits.PassFail,		Bins.DigFunc,			new VfaultFunc( ));
				Add(IDs.ShortCctCurPos,			Limits.ShortCctCurPos,	Bins.ShortCctCurrents,		new VfaultFunc( ));
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Add(IDs.ShortCctCurNeg,			Limits.ShortCctCurNeg,		Bins.ShortCctCurrents,		new VfaultFunc( ));
				}
				Add(IDs.VoutSwFaultPinFunc,		Limits.PassFail,		Bins.DigFunc,			new VfaultFunc( ));
				Add(IDs.VoutSwFault2mA5Func,	Limits.PassFail,		Bins.DigFunc,			new VfaultFunc( ));	
			}
		}
		
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble hvAvdd = 40.0;

			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				Utl.PowerDownDevice(App.Globals.vddResource);
				Utl.PowerUpDevice(App.AvddResource.AVDD_VIE, hvAvdd);
				Utl.SetDeviceMode(App.OpMode.SOFTWARE);
				Utl.SetAddressPins(App.TC.DutAddress);
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V_BIP].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			}
			Utl.ModifySupplies(hvAvdd, App.TC.AVss, 2.7);

			Run  (IDs.DigLevelFunc);
			Run	 (IDs.PecFunc);

			Run  (IDs.AddrFunc);
			Run  (IDs.ClrFunc);
			Run  (IDs.ResetFunc);
			Run  (IDs.InvalidWrites);

			Utl.ModifySupplies(hvAvdd, App.TC.AVss, App.TC.DVcc);
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				Utl.PowerDownDevice(App.AvddResource.AVDD_VIE);
				Utl.PowerUpDevice(App.Globals.vddResource, App.TC.AVdd);
				Utl.SetDeviceMode(App.OpMode.SOFTWARE);
				Utl.SetAddressPins(App.TC.DutAddress);
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V_BIP].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			}

			/*
			if(App.Globals.CharTestingEnable || App.Globals.YaTestingEnable)
			{
				#region CharComplianceTest
				Run  (IDs.IFaultFuncChar);
				Run  (IDs.IdealIoutVddChar);
				Run  (IDs.ComplianceVvddChar);
				Run  (IDs.VddAlarmIoutChar);
				Run  (IDs.VddCurrAlrmDeltaFSRChar);

				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Run  (IDs.IdealIoutVssChar);
					Run	 (IDs.ComplianceVvssChar);
					Run  (IDs.VssAlarmIoutChar);
					Run	 (IDs.VssCurrAlrmDeltaFSRChar);
				}
				Run  (IDs.SwFaultPinFuncChar);
				Run	 (IDs.SwFault2mA5FuncChar);
				#endregion
			}
				*/

			Run  (IDs.PecFaultFunc);
			Run  (IDs.OverTempFaultFunc);

			Run  (IDs.IFaultFunc);
			Run  (IDs.ComplFuncAvdd);
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				if((App.Globals.ActiveSelector != App.Selectors.PD_RW_5750) && (App.Globals.ActiveSelector != App.Selectors.QC_RW_5750))
				{
					Run  (IDs.ComplFuncAvss);
				}
			}
			Run  (IDs.SwFaultPinFunc);
			Run	 (IDs.SwFault2mA5Func);

			if((App.Globals.ActiveSelector != App.Selectors.PD_HV_5749) && (App.Globals.ActiveSelector != App.Selectors.QC_HV_5749))
			{
				Run(IDs.VFaultFunc);
				Run(IDs.ShortCctCurPos);
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Run  (IDs.ShortCctCurNeg);
				}	
				Run(IDs.VoutSwFaultPinFunc);
				Run(IDs.VoutSwFault2mA5Func);
			}
		}
		#endregion
	}// end of class SWmodeFuncSeq
	#endregion

	//
	// CharSeq Sequencer
	//
	#region CharSeq                         :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class CharSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region CharSeq                         :
		public CharSeq()
			: base(Seq.CharSeqID)
		{
			App.VLoadOptions load = App.VLoadOptions.LOAD_OFF;
			App.RangeOptions vrange = App.RangeOptions.FIVE_V, 
				irange = App.RangeOptions.TWENTY_MA;

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				vrange = App.RangeOptions.FIVE_V_BIP;
				irange = App.RangeOptions.TWENTY_MA_BIP;
			}
			else
			{
				vrange = App.RangeOptions.FIVE_V;
				irange = App.RangeOptions.TWENTY_MA;
			}

			for(load = App.VLoadOptions.LOAD_ON; load < (App.VLoadOptions.LOAD_OFF + 1); load++)
			{
				//   Test ID               Limits             Fail Bin           Test Function
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Add(IDs.vRangeVssPsrrSink[(int)load],		Limits.Vpsrr,      Bins.PSRR,         new Psrr(vrange, App.ResSel.R_INT, load));
					Add(IDs.vRangeVddPsrrSink[(int)load],		Limits.Vpsrr,      Bins.PSRR,         new Psrr(vrange, App.ResSel.R_INT, load));
					Add(IDs.vRangeVssPsrrSource[(int)load],		Limits.Vpsrr,      Bins.PSRR,         new Psrr(vrange, App.ResSel.R_INT, load));
				}
				Add(IDs.vRangeVddPsrrSource[(int)load],		Limits.Vpsrr,      Bins.PSRR,         new Psrr(vrange, App.ResSel.R_INT, load));
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				Add(IDs.iRangeVssPsrrSink,		Limits.Ipsrr,      Bins.PSRR,         new Psrr(irange, App.ResSel.R_INT, load));
				Add(IDs.iRangeVddPsrrSink,		Limits.Ipsrr,      Bins.PSRR,         new Psrr(irange, App.ResSel.R_INT, load));
				Add(IDs.iRangeVssPsrrSource,	Limits.Ipsrr,      Bins.PSRR,         new Psrr(irange, App.ResSel.R_INT, load));
			}
			Add(IDs.iRangeVddPsrrSource,	Limits.Ipsrr,      Bins.PSRR,         new Psrr(irange, App.ResSel.R_INT, load));

			for(load = App.VLoadOptions.LOAD_ON; load < (App.VLoadOptions.LOAD_OFF + 1); load++)
			{
				Add(IDs.VddHeadroom[(int)load],   Limits.ComplianceV,      Bins.Headroom,     new Headroom(load));
			}
			//if(App.Globals.GenericType == App.GenericType.LV_GEN)
			//	Add(IDs.VssHeadroomPass,   Limits.ioutAccuracy,     Bins.Headroom,     new HeadroomProd(load));
			//Add(IDs.VddHeadroomPass,   Limits.ioutAccuracy,     Bins.Headroom,     new HeadroomProd(load));

			#region Timing
			if(App.Globals.CharTestingEnable)
			{
				Add(IDs.t1Timing,			Limits.t1Timing,		Bins.Timing,       new t1_timing( ));
				Add(IDs.t2Timing,			Limits.txPulsewidth,	Bins.Timing,       new t2_timing( ));
				Add(IDs.t3Timing,			Limits.txPulsewidth,	Bins.Timing,       new t3_timing( ));
				Add(IDs.t4Timing,			Limits.txSyncSetupHold,	Bins.Timing,       new t4_timing( ));
				Add(IDs.t5Timing,			Limits.txSyncSetupHold,	Bins.Timing,       new t5_timing( ));
				Add(IDs.t5aTiming,			Limits.txSyncSetupHold,	Bins.Timing,       new t5a_timing( ));
				Add(IDs.t6Timing,			Limits.txPulsewidth,	Bins.Timing,	   new t6_timing( ));
				Add(IDs.t7Timing,			Limits.t7SetupTime,		Bins.Timing,       new t7_timing( ));
				Add(IDs.t8Timing,			Limits.t8HoldTime,		Bins.Timing,       new t8_timing( ));
				Add(IDs.t9Timing,			Limits.txCLRtime,		Bins.Timing,       new t9_timing( ));
				Add(IDs.t10Timing,			Limits.txCLRtime,		Bins.Timing,       new t9_timing( ));
				Add(IDs.t11Timing,			Limits.txPulsewidth,	Bins.Timing,	   new t11_timing( ));
				Add(IDs.t13Timing,			Limits.txPulsewidth,	Bins.Timing,       new t13_timing( ));

				Add(IDs.vih,				Limits.vih,				Bins.Timing,       new InputLevelsCheck( ));
				Add(IDs.vil,				Limits.vil,				Bins.Timing,       new InputLevelsCheck( ));
				Add(IDs.voh,				Limits.voh,				Bins.Timing,       new OutputLevelsCheck( ));
				Add(IDs.vol,				Limits.vol,				Bins.Timing,       new OutputLevelsCheck( ));
			}
			#endregion

		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			App.VLoadOptions load = App.VLoadOptions.LOAD_OFF;
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			for(load = App.VLoadOptions.LOAD_ON; load < (App.VLoadOptions.LOAD_OFF + 1); load++)
			{
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					Run  (IDs.vRangeVssPsrrSink[(int)load]);
					Run  (IDs.vRangeVddPsrrSink[(int)load]);
					Run  (IDs.vRangeVssPsrrSource[(int)load]);
				}
				Run  (IDs.vRangeVddPsrrSource[(int)load]);
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				Run  (IDs.iRangeVssPsrrSink);
				Run  (IDs.iRangeVddPsrrSink);
				Run  (IDs.iRangeVssPsrrSource);
			}
			Run  (IDs.iRangeVddPsrrSource);

			for(load = App.VLoadOptions.LOAD_ON; load < (App.VLoadOptions.LOAD_OFF + 1); load++)
			{
				//load = App.VLoadOptions.LOAD_OFF;
				Run  (IDs.VddHeadroom[(int)load]);
			}
			//if(App.Globals.GenericType == App.GenericType.LV_GEN)
			//	Run	 (IDs.VssHeadroomPass);
			//Run  (IDs.VddHeadroomPass);

			#region Timing
			if(App.Globals.CharTestingEnable)
			{
				Utl.SetDigitalLevels(App.DigLevelsOpts.TIMING);

				//INSERT TIMING TESTS HERE...
				Run  (IDs.t1Timing);
				Run  (IDs.t2Timing);
				Run  (IDs.t3Timing);
				Run  (IDs.t4Timing);
				Run  (IDs.t5Timing);
				Run  (IDs.t5aTiming);
				Run	 (IDs.t6Timing);
				Run  (IDs.t7Timing);
				Run  (IDs.t8Timing);
				Run  (IDs.t9Timing);
				Run  (IDs.t10Timing);
				Run  (IDs.t11Timing);
				Run  (IDs.t13Timing);

				Run	 (IDs.vih);
				Run	 (IDs.vil);
				Run	 (IDs.voh);
				Run	 (IDs.vol);

				Utl.SetDigitalLevels(App.DigLevelsOpts.DEFAULT);
			}
			#endregion

		}
		#endregion
	}// end of class CharSeq
	#endregion

	//
	// TestModeSeq Sequencer
	//
	#region TestModeSeq                         :
	/// <summary>
	/// Add summary description of this sequencer here
	/// </summary>
	public class TestModeSeq : SequencerProxy
	{
		//
		// Constructor - tests and sub-sequencers are added here
		//
		#region TestModeSeq                         :
		public TestModeSeq()
			: base(Seq.TestModeSeqID)
		{
			Add(IDs.vinMeas,           Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vinBufOp,          Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vinBufOffset,      Limits.InternalOffsets,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vrefMeas,          Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vrefBufOp,         Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vrefBufOffset,     Limits.InternalOffsets,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vOfsDac,           Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vOfsIp,            Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vOfsBufOffset,     Limits.InternalOffsets,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vDacVmode,         Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			//Add(IDs.vinNeg,            Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			//Add(IDs.opBufVinOffset,    Limits.InternalOffsets,	Bins.AnalogFunc,   new InternalNodes( ));
			//Add(IDs.OpBufVofsIp,       Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.vDacImode,         Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.Vref_div2,         Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.VtoItestpoint,     Limits.InternalNodes,	Bins.AnalogFunc,   new InternalNodes( ));
			Add(IDs.VtoIoBufOffs,      Limits.InternalOffsets,	Bins.AnalogFunc,   new InternalNodes( ));
		}
		#endregion

		//
		// Run Method - called at runtime to execute the tests in the sequencer
		//
		#region Run                             :
		public override void Run()
		{
			Run  (IDs.vinMeas);
			Run  (IDs.vinBufOp);
			Run  (IDs.vinBufOffset);

			Run  (IDs.vrefMeas);
			Run  (IDs.vrefBufOp);
			Run  (IDs.vrefBufOffset);

			Run  (IDs.vOfsDac);
			Run  (IDs.vOfsIp);
			Run  (IDs.vOfsBufOffset);

			Run  (IDs.vDacVmode);
			//Run  (IDs.vinNeg);
			//Run  (IDs.opBufVinOffset);

			//Run  (IDs.OpBufVofsIp);

			Run  (IDs.vDacImode);

			Run  (IDs.Vref_div2);
			Run  (IDs.VtoItestpoint);
			Run  (IDs.VtoIoBufOffs);
		}
		#endregion
	}// end of class CharSeq
	#endregion

} // end of namespace Adi.Cts.TestProgram
