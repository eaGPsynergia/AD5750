//
// Contains calibration methods that are used by the application.
//
// History:
// 11/29/05 - CTS - Template Created.
//
using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{

	//
	// Psrr Test Function
	//
	#region Psrr                            :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class Psrr : TestFunction
	{
		public App.RangeOptions range;
		public App.ResSel rSel;
		public App.VLoadOptions load;

		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region Psrr                            :
		public Psrr(App.RangeOptions range, App.ResSel rSel, App.VLoadOptions load)
		{
			this.range = range;
			this.rSel = rSel;
			this.load = load;
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vin1Q = App.TC.MaxInputVoltage/4.0,
				vin3Q = vin1Q*3, 
				vinMS = App.TC.MaxInputVoltage/2.0,
				vddLow, vssLow,
				idealOut1Q = App.TC.RangeData[(int)range].MinValue + ((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/4.0),
				idealOutMS = App.TC.RangeData[(int)range].MidValue,
				idealOut3Q = App.TC.RangeData[(int)range].MinValue + (3*((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/4.0)),
				idealOut = 0.0;
			MsDouble oHiVddSink = 0.0, oLoVddSink = 0.0, 
				oHiVddSource = 0.0, oLoVddSource = 0.0, 
				oHiVssSink = 0.0, oLoVssSink = 0.0, 
				oHiVssSource = 0.0, oLoVssSource = 0.0, 
				vddPsrrSink = 0, vssPsrrSink = 0,
				vddPsrrSource = 0, vssPsrrSource = 0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;


			if(App.TC.AVdd < 15.8)
				vddLow = App.TC.AVdd + 5.0;
			else
				vddLow = App.TC.AVdd - 5.0;

			if(App.TC.AVss > -15.8)
				vssLow = App.TC.AVss - 5.0;
			else
				vssLow = App.TC.AVss + 5.0;


			//If external resistor is selected, close D4 to switch in resistor
			if(this.rSel == App.ResSel.R_EXT)
			{
				HW.Rdc.Set(PM.D4, OpenClose.CLOSE);
			}

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE,
				App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

			#region VddPsrr

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("PSRR Vdd 1");

				//load 1/4 scale to Vin (sinking current)
				HW.Dcs.VOut(PM.VIN, vin1Q);
				App.Time.MsDelay(App.TC.OutputSettle);
				//measure output 
				oHiVddSink = Utl.MeasureOutput(range, idealOut1Q, resourceSelect);

				//load 3/4 scale to Vin (sourcing current for bipolar range)
				HW.Dcs.VOut(PM.VIN, vin3Q);
				App.Time.MsDelay(App.TC.OutputSettle);
				//measure output
				oHiVddSource = Utl.MeasureOutput(range, idealOut3Q, resourceSelect);
				idealOut = idealOut3Q;
			}
			else 
			{
				//load midscale to Vin (sourcing current for unipolar range)
				HW.Dcs.VOut(PM.VIN, vinMS);
				App.Time.MsDelay(App.TC.OutputSettle);
				//measure output
				oHiVddSource = Utl.MeasureOutput(range, idealOutMS, resourceSelect);
				idealOut = idealOutMS;
			}

			//reduce Vdd to lower supply
			Utl.ModifySupplies(vddLow, App.TC.AVss, App.TC.DVcc);
			App.Time.MsDelay(10);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("PSRR Vdd 2");

			//measure outputs
			oLoVddSource = Utl.MeasureOutput(range, idealOut, resourceSelect);

			//load 1/4 scale to Vin
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				HW.Dcs.VOut(PM.VIN, vin1Q);
				App.Time.MsDelay(App.TC.OutputSettle);
				oLoVddSink = Utl.MeasureOutput(range, idealOut1Q, resourceSelect);
			}

			//return Vdd to test value
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			App.Time.MsDelay(10);

			//VddPsrr = deltaOut/deltaVdd
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					vddPsrrSink[site] = ((oHiVddSink[site] - oLoVddSink[site])/(App.TC.AVdd - vddLow));
				}
				vddPsrrSource[site] = ((oHiVddSource[site] - oLoVddSource[site])/(App.TC.AVdd - vddLow));
			}
			#endregion

		
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//**Vss**
				#region VssPsrr
				//load 1/4 scale to Vin (Sinking current)
				HW.Dcs.VOut(PM.VIN, vin1Q);
				App.Time.MsDelay(App.TC.OutputSettle);
				//measure output
				oHiVssSink = Utl.MeasureOutput(range, idealOut1Q, resourceSelect);

				//load 3/4 scale to Vin (Sourcing current)
				HW.Dcs.VOut(PM.VIN, vin3Q);
				App.Time.MsDelay(App.TC.OutputSettle);
				//measure output
				oHiVssSource = Utl.MeasureOutput(range, idealOut3Q, resourceSelect);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("PSRR Vss 1");

				//reduce Vss to lower supply
				Utl.ModifySupplies(App.TC.AVdd, vssLow, App.TC.DVcc);
				App.Time.MsDelay(10);

				//measure output
				oLoVssSource = Utl.MeasureOutput(range, idealOut3Q, resourceSelect);

				//load 1/4 scale to Vin
				HW.Dcs.VOut(PM.VIN, vin1Q);
				App.Time.MsDelay(App.TC.OutputSettle);
				//measure output
				oLoVssSink = Utl.MeasureOutput(range, idealOut1Q, resourceSelect);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("PSRR Vss 2");

				//return Vss Test Voltage
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				App.Time.MsDelay(10);

				//VssPsrr = deltaOut/DeltaVss
				foreach(Site site in TP.MS.ActiveSites)
				{
					vssPsrrSink[site] = ((oHiVssSink[site] - oLoVssSink[site])/(App.TC.AVss - vssLow));
					vssPsrrSource[site] = ((oHiVssSource[site] - oLoVssSource[site])/(App.TC.AVss - vssLow));
				}
				#endregion
			}


			#region BinData
			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					App.Test[IDs.vRangeVssPsrrSink[(int)load]].Result = vssPsrrSink;
					App.Test[IDs.vRangeVddPsrrSink[(int)load]].Result = vddPsrrSink;
					App.Test[IDs.vRangeVssPsrrSource[(int)load]].Result = vssPsrrSource;
				}
				App.Test[IDs.vRangeVddPsrrSource[(int)load]].Result = vddPsrrSource;
			}
			else
			{
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					App.Test[IDs.iRangeVssPsrrSink].Result = vssPsrrSink;
					App.Test[IDs.iRangeVddPsrrSink].Result = vddPsrrSink;
					App.Test[IDs.iRangeVssPsrrSource].Result = vssPsrrSource;
				}
				App.Test[IDs.iRangeVddPsrrSource].Result = vddPsrrSource;
			}
			#endregion

			//Cleanup
			Utl.RunPattern(DP.hw_reset);
			HW.Dcs.VOut(PM.VIN, 0.0);
		}
		#endregion
	}// end of class Psrr
	#endregion

	//
	// Headroom Test Function
	//
	#region Headroom                        :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class Headroom : TestFunction
	{
		public App.RangeOptions range;
		public App.ResSel rSel;
		public App.VLoadOptions load;

		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region Headroom                        :
		public Headroom(App.VLoadOptions load)
		{
			this.load = load;
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			App.RangeOptions range;
			double errorMargin = 0.01/100,
				supplyStep = 100.0e-3,
				supply = App.TC.AVdd;
			MsDouble idealOutput,
				vout = 0.0,
				vddHeadroom = 0.0,
				vssHeadroom = 0.0;
			//double [] voutArray = new Double[50]; 

			HW.Dmm.Integration(PM.DMM, 0.02);

			//Select +/-10V range
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.TEN_V_BIP;
			else 
			{
				if(App.TC.AVdd < 42.0)
					range = App.RangeOptions.TEN_V;
				else
				{
					range = App.RangeOptions.FORTY_V;
					//Need to ensure no external load is selected if using the 40V range
					//Need to use the scale circuit and this represents an equivalent load.
					HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
				}
			}

			idealOutput = App.TC.RangeData[(int)range].MaxValue;

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE,
				App.ClearEn.NO_CLEAR, App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);

			//Select FS output
			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);

			//Reduce AVdd to within 4Volts of expected output
			supply = (double)idealOutput + 4.0;
			Utl.ModifySupplies(supply, App.TC.AVss, App.TC.DVcc);
			App.Time.MsDelay(10);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Headroom Vdd");

			foreach(Site site in TP.MS.ActiveSites)
			{
				vout = Utl.MeasureOutput(range, idealOutput[site], App.MeasOptions.DMM);
				idealOutput = vout;
			}

			//In 100mV steps, reduce AVdd until output voltage is more than errorMargin away from ideal
			foreach(Site site in TP.MS.ActiveSites)
			{
				for(int i = 0; i < 50; i++)
				{
					vout = Utl.MeasureOutput(range, idealOutput[site], App.MeasOptions.DMM);
					//voutArray[i] = vout[site];
					
					if((vout > (idealOutput + (errorMargin*idealOutput))) || (vout < (idealOutput - (errorMargin*idealOutput))))
					{
						supply = supply + supplyStep;
						vddHeadroom = supply - idealOutput;
						break;
					}

					supply = supply - supplyStep;
					Utl.ModifySupplies(supply, App.TC.AVss, App.TC.DVcc);
					App.Time.MsDelay(10);
				}
			}

			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Repeat above for Vss
				//Set output to -FS
				HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);
				idealOutput = App.TC.RangeData[(int)range].MinValue;

				//Reduce AVss to within 4 Volts of expected output
				supply = (double)idealOutput - 4.0;
				Utl.ModifySupplies(App.TC.AVdd, supply, App.TC.DVcc);
				App.Time.MsDelay(10);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Headroom Vss");

				vout = Utl.MeasureOutput(range, App.TC.MinInputVoltage, App.MeasOptions.DMM);
				//Use actual measured value as ideal to see 0.01% variation
				idealOutput = vout;

				//In 100mV steps, increase AVss until output voltage is more than errorMargin away from ideal
				foreach(Site site in TP.MS.ActiveSites)
				{
					for(int i = 0; i < 50; i++)
					{
						vout = Utl.MeasureOutput(range, idealOutput[site], App.MeasOptions.DMM);
						//voutArray[i] = vout[site];

						if((vout > (idealOutput - (errorMargin*idealOutput))) || (vout < (idealOutput + (errorMargin*idealOutput))))
						{
							i = 50;
							supply = supply - supplyStep;
							vssHeadroom = supply - idealOutput;
							vssHeadroom = -vssHeadroom;
							//Due to Supply not being *exactly* -10V, there's a chance that
							//output will go slightly below -10V - looking like -ve headroom
							//This should not be reported back as -ve headroom as this result
							//is not real.
							if((vssHeadroom < 0) && (vssHeadroom > -0.010))
								vssHeadroom = 0;
						}

						supply = supply + supplyStep;
						Utl.ModifySupplies(App.TC.AVdd, supply, App.TC.DVcc);
						App.Time.MsDelay(10);
					}
				}

				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			}

			App.Test[IDs.VddHeadroom[(int)load]].Result = vddHeadroom;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                App.Test[IDs.VssHeadroom[(int)load]].Result = vssHeadroom;

			//Cleanup
			HW.Dmm.Integration(PM.DMM, 0.002);
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.RunPattern(DP.hw_reset);
		}
		#endregion
	}// end of class Headroom
	#endregion


	//
	// Headroom Test Function
	//
	#region HeadroomProd                        :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class HeadroomProd : TestFunction
	{
		public App.RangeOptions range;
		public App.ResSel rSel;
		public App.VLoadOptions load;

		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region HeadroomProd                        :
		public HeadroomProd(App.VLoadOptions load)
		{
			this.load = load;
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			App.RangeOptions range;
			double errorMargin = 0.01/100,
				supplyStep = 100.0e-3;
			MsDouble supply = App.TC.AVdd,
				idealVout = 0.0,
				vout = 0.0,
				vddHeadroom = 0.0,
				vssHeadroom = 0.0;
			double vddTarget = 2.0, vssTarget = 0.5;
			MsDouble vssAccError = 0, vddAccError = 0;
			double vinZs = 20.0e-3;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			//double [] voutArray = new Double[50]; 

			//Select +/-10V range
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.TEN_V_BIP;
			else 
			{
				if(App.TC.AVdd < 42.0)
					range = App.RangeOptions.TEN_V;
				else
				{
					range = App.RangeOptions.FORTY_V;
					//Need to ensure no external load is selected if using the 40V range
					//Need to use the scale circuit and this represents an equivalent load.
					HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
				}
			}

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE,
				App.ClearEn.NO_CLEAR, App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			
			if(App.Globals.CharTestingEnable)
			{
				#region CharMethod
			
				//Select FS output
				HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);

				//Reduce AVdd to within 2Volts of expected output
				supply = App.TC.RangeData[(int)range].MaxValue + vddTarget;
				Utl.ModifySupplies(supply, App.TC.AVss, App.TC.DVcc);
				App.Time.MsDelay(10);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Headroom Vdd");

				idealVout = Utl.MeasureOutput(range, App.TC.RangeData[(int)range].MaxValue, resourceSelect);

				//In 100mV steps, reduce AVdd until output voltage is more than errorMargin away from ideal
				foreach(Site site in TP.MS.ActiveSites)
				{
					for(int i = 0; i < 20; i++)
					{
						vout = Utl.MeasureOutput(range, App.TC.RangeData[(int)range].MaxValue, resourceSelect);
					
						if((vout[site] > (idealVout[site] + (errorMargin*idealVout[site]))) || (vout[site] < (idealVout[site] - (errorMargin*idealVout[site]))))
						{
							supply[site] = supply[site] + supplyStep;
							vddHeadroom[site] = supply[site] - idealVout[site];
							break;
						}

						supply[site] = supply[site] - supplyStep;
						Utl.ModifySupplies(supply, App.TC.AVss, App.TC.DVcc);
						App.Time.MsDelay(10);
					}
				}
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				#endregion
			}

			#region VddHeadroom

				//Just check Vss headroom is ok at 0.5V

				//Set output to -FS
				HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);
				idealVout = App.TC.RangeData[(int)range].MaxValue;

				//Reduce AVdd to within 0.5V of expected output
				supply = App.TC.RangeData[(int)range].MaxValue + vddTarget;
				Utl.ModifySupplies(supply, App.TC.AVss, App.TC.DVcc);
				App.Time.MsDelay(10);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Headroom Vss");

				vout = Utl.MeasureOutput(range, App.TC.MinInputVoltage, resourceSelect);
				//Use actual measured value as ideal to see 0.01% variation

				//If vout doesn't meet accuracy spec with Vss set to Target Vout + 0.5V, then headroom test fails..
				foreach(Site site in TP.MS.ActiveSites)
				{
					//calculate %FSR error at Vss - 0.5V
					vddAccError[site] = ((vout[site] - idealVout[site]) / (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;
				}

			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			#endregion


			#region VssHeadroom
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Just check Vss headroom is ok at 0.5V

				//Set output to -FS
				HW.Dcs.VOut(PM.VIN, vinZs);
				idealVout = App.TC.RangeData[(int)range].MinValue + ((vinZs/App.TC.MaxInputVoltage)* (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));

				//Reduce AVss to within 0.5V of expected output
				supply = App.TC.RangeData[(int)range].MinValue - vssTarget;
				Utl.ModifySupplies(App.TC.AVdd, supply, App.TC.DVcc);
				App.Time.MsDelay(10);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Headroom Vss");

				vout = Utl.MeasureOutput(range, App.TC.MinInputVoltage, resourceSelect);
				//Use actual measured value as ideal to see 0.01% variation

				//If vout doesn't meet accuracy spec with Vss set to Target Vout + 0.5V, then headroom test fails..
				foreach(Site site in TP.MS.ActiveSites)
				{
					//calculate %FSR error at Vss - 0.5V
					vssAccError[site] = ((vout[site] - idealVout[site]) / (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;
				}

				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			}
			#endregion

			if(App.Globals.CharTestingEnable)
			{
				App.Test[IDs.VddHeadroom[(int)load]].Result = vddHeadroom;
			}
			else
				App.Test[IDs.VddHeadroomPass].Result = vddAccError;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				App.Test[IDs.VssHeadroomPass].Result = vssAccError;

			//Cleanup
			HW.Dmm.Integration(PM.DMM, 0.002);
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.RunPattern(DP.hw_reset);
		}
		#endregion
	}// end of class HeadroomProd
	#endregion

	//
	//Timing Tests
	//
	#region TimingTests
	
	//
	// t1_timing Test Function
	//
	#region t1_timing                       :
	/// <summary>
	/// SCLK cycle time test
	/// </summary>
	public class t1_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t1_timing                       :
		public t1_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 35.0e-9,
				minPeriod = 17.0e-9,
				timingStep = 1.0e-9,
				frequency;
			int passFail = 0;
			MsInt readData;

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("T1 timing");

			while ((passFail == 0) && (vectorPeriod > minPeriod))
			{
				frequency = 1.0/vectorPeriod;

				vectorPeriod = vectorPeriod - timingStep;
				Utl.SetInterfaceTiming(frequency);

				Utl.SetAddressPins(0x5);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.write24Bits(0x5, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.SetInterfaceTiming(frequency);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(0x5, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;
			}
	
			if (passFail != 0)
			{
				vectorPeriod = vectorPeriod + timingStep;
			}
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);

			App.Test[IDs.t1Timing].Result = vectorPeriod;
		}
		#endregion
	}// end of class t1_timing
	#endregion

	//
	// t2_timing Test Function
	//
	#region t2_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t2_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t2_timing                       :
		public t2_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9,
				minHighTime = 2.5e-9,
				clkFallingEdge,
				clkRisingEdge,
				timingStep = 1.0e-9,
				frequency, t2HighTime;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			clkFallingEdge = vectorPeriod/10.0 + vectorPeriod/2.0;
			clkRisingEdge = vectorPeriod/10.0;

			while((passFail == 0) && ((clkFallingEdge - clkRisingEdge) > minHighTime))
			{
				clkFallingEdge = clkFallingEdge - timingStep;
				HW.Dss.Trail(PM.SCLK_OUTEN, clkFallingEdge);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.write24Bits(dutAddress, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
				HW.Dss.Trail(PM.SCLK_OUTEN, clkFallingEdge);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;
				Utl.SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				clkFallingEdge = clkFallingEdge + timingStep;
			}
			t2HighTime = clkFallingEdge - clkRisingEdge;
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t2Timing].Result = t2HighTime;
		}
		#endregion
		
	}// end of class t2_timing
	#endregion

	//
	//t3 - SCLK Low Time
	//
	#region t3_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t3_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t3_timing                       :
		public t3_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9,
				minLowTime = 4.0e-9,
				clkFallingEdge,
				clkRisingEdge,
				timingStep = 1.0e-9,
				frequency, t3LowTime;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			clkFallingEdge = vectorPeriod/10.0 + vectorPeriod/2.0;
			clkRisingEdge = vectorPeriod/10.0;

			while((passFail == 0) && ((vectorPeriod - (clkFallingEdge - clkRisingEdge)) > minLowTime))
			{
				clkFallingEdge = clkFallingEdge + timingStep;
				HW.Dss.Trail(PM.SCLK_OUTEN, clkFallingEdge);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.write24Bits(dutAddress, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
				HW.Dss.Trail(PM.SCLK_OUTEN, clkFallingEdge);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				clkFallingEdge = clkFallingEdge - timingStep;
			}
			t3LowTime = vectorPeriod - (clkFallingEdge - clkRisingEdge);
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t3Timing].Result = t3LowTime;
		}
		#endregion
		
	}// end of class t3_timing
	#endregion

	//
	//t4 - SYNC Falling Edge to SCLK Falling Edge Setup Time
	//
	#region t4_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t4_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t4_timing                       :
		public t4_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9,
				clkFallingEdge,
				syncFallingEdge,
				syncTrailingEdge,
				timingStep = 1.0e-9,
				frequency, t4SyncToSclk;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			clkFallingEdge = vectorPeriod/10.0 + vectorPeriod/2.0;
			syncFallingEdge = vectorPeriod/11.0;
			//Need to set Trailing edge well beyond highest possible leading edge.
			syncTrailingEdge = vectorPeriod - 1.0e-9;

			while((passFail == 0) && (syncFallingEdge < clkFallingEdge))
			{
				syncFallingEdge = syncFallingEdge + timingStep;
				HW.Dss.Trail(PM.SYNC_RSEL, syncTrailingEdge);
				HW.Dss.Lead(PM.SYNC_RSEL, syncFallingEdge);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.write24Bits(dutAddress, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
				HW.Dss.Trail(PM.SYNC_RSEL, syncTrailingEdge);
				HW.Dss.Lead(PM.SYNC_RSEL, syncFallingEdge);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				syncFallingEdge = syncFallingEdge - timingStep;
			}
			t4SyncToSclk = clkFallingEdge - syncFallingEdge;

			//Most minimum possible is 200ps. Placement accuracys 150ps typ. So can't guarantee 200ps. Round off to 0ns.
			if(t4SyncToSclk < 0.0)
				t4SyncToSclk = 0.0;

	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t4Timing].Result = t4SyncToSclk;
		}
		#endregion
		
	}// end of class t4_timing
	#endregion

	//
	//t5 - 24th SCLK Falling Edge to SYNC Rising Edge
	//
	#region t5_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t5_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t5_timing                       :
		public t5_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9,
				clkFallingEdge,
				syncRisingEdge,
				timingStep = 1.0e-9,
				frequency, t5SclkToSync;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.t5SetInterfaceTiming(frequency);

			clkFallingEdge = App.TC.TimingData.SclkTrail;
			syncRisingEdge = App.TC.TimingData.SyncTrail;
			syncRisingEdge = syncRisingEdge + timingStep;

			while((passFail == 0) && (syncRisingEdge > clkFallingEdge))
			{
				syncRisingEdge = syncRisingEdge - timingStep;
				HW.Dss.Trail(PM.SYNC_RSEL, syncRisingEdge);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.t5Write24Bits(dutAddress, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.t5SetInterfaceTiming(frequency);
				HW.Dss.Trail(PM.SYNC_RSEL, syncRisingEdge);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.t5Write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;

				Utl.t5SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				syncRisingEdge = syncRisingEdge + timingStep;
			}
			t5SclkToSync = syncRisingEdge - clkFallingEdge;

			//Minimum possible is -700ps. Typical edge placement accuracy 200ps. Test has been proven to fail
			//at next breakpoint i.e. -1.7ns. Can't guarantee negative edge so close to spec, so rounding to 0.
			if(t5SclkToSync < 0)
				t5SclkToSync = 0.0;

	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t5Timing].Result = t5SclkToSync;
		}
		#endregion
		
	}// end of class t5_timing
	#endregion

	//
	//t5 - 16th SCLK Falling Edge to SYNC Rising Edge
	//
	#region t5a_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t5a_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t5a_timing                       :
		public t5a_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9,
				clkFallingEdge,
				syncRisingEdge,
				timingStep = 1.0e-9,
				frequency, t5SclkToSync;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.t5SetInterfaceTiming(frequency);

			clkFallingEdge = App.TC.TimingData.SclkTrail;
			syncRisingEdge = App.TC.TimingData.SyncTrail;
			syncRisingEdge = syncRisingEdge + timingStep;

			while((passFail == 0) && (syncRisingEdge > clkFallingEdge))
			{
				syncRisingEdge = syncRisingEdge - timingStep;
				HW.Dss.Trail(PM.SYNC_RSEL, syncRisingEdge);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.t5ShortWrite(dutAddress, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.t5SetInterfaceTiming(frequency);
				HW.Dss.Trail(PM.SYNC_RSEL, syncRisingEdge);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.t5ShortWrite(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;

				Utl.t5SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				syncRisingEdge = syncRisingEdge + timingStep;
			}
			t5SclkToSync = syncRisingEdge - clkFallingEdge;
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t5aTiming].Result = t5SclkToSync;
		}
		#endregion
		
	}// end of class t5a_timing
	#endregion

	//
	//t6 - Minimum SYNC High Time
	//
	#region t6_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t6_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t6_timing                       :
		public t6_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9, frequency,
				syncLeadingEdge, syncTrailingEdge,
				timingStep = 1.0e-9,
				t6SyncHiWr,
				minPulsewidth = 2.0e-9;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			syncLeadingEdge = App.TC.TimingData.SyncLead;

			//Set trailing edge to 50% of vector period
			syncTrailingEdge = vectorPeriod/2.0;
			HW.Dss.Trail(PM.SYNC_RSEL, syncTrailingEdge);

			//Now Sync pulsewidth = (vectorPeriod - syncTrailingEdge) + syncLeadingEdge

			//2 consequtive writes in t6_write pattern. 
			//Write 1: Addr = 0x5, Range = 0x5, Clr to Zero, Enable O/P, No Clear, Rext, No Reset -> 1010 0010 1010 1000
			//Write 2: Addr = 0x5, Range = 0xA, Clr to Mid, Disable O/P, No Clear, Rint, No Reset -> 1010 0101 0100 1000
			//Sync high time between both writes is reduced and readback should, if sync high is long enough:
			//Readback: Addr = 0x5, Range = 0xA, Clr to Mid, Disable O/P, No Clear, Rint, No Reset -> 101 0101 0000
			while((passFail == 0) && ((syncTrailingEdge - syncLeadingEdge) > minPulsewidth))
			{
				syncTrailingEdge = syncTrailingEdge - timingStep;
				HW.Dss.Trail(PM.SYNC_RSEL, syncTrailingEdge);

				Utl.RunPattern(DP.hw_reset);
				App.Time.MsDelay(App.TC.OutputSettle);

				//Run 2-write pattern
				Utl.RunPattern(DP.t6_dual_write);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				syncTrailingEdge = syncTrailingEdge + timingStep;
			}
			t6SyncHiWr = syncTrailingEdge - syncLeadingEdge;
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t6Timing].Result = t6SyncHiWr;
		}
		#endregion
		
	}// end of class t6_timing
	#endregion

	//
	//t7 - Data Setup Time
	//
	#region t7_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t7_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t7_timing                       :
		public t7_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9,
				clkFallingEdge,
				dataSetupEdge,
				timingStep = 1.0e-9,
				frequency, t7DataSetup;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			clkFallingEdge = vectorPeriod/10.0 + vectorPeriod/2.0;
			dataSetupEdge = vectorPeriod/4.0;

			while((passFail == 0) && (dataSetupEdge < clkFallingEdge))
			{
				dataSetupEdge = dataSetupEdge + timingStep;
				HW.Dss.Lead(PM.SDIN_R0, dataSetupEdge);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.t7and8write24Bits(dutAddress, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
				HW.Dss.Lead(PM.SDIN_R0, dataSetupEdge);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.t7and8write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				dataSetupEdge = dataSetupEdge - timingStep;
			}
			t7DataSetup = clkFallingEdge - dataSetupEdge;
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t7Timing].Result = t7DataSetup;
		}
		#endregion
		
	}// end of class t7_timing
	#endregion

	//
	//t8 - Data Hold Time
	//
	#region t8_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t8_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t8_timing                       :
		public t8_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 33.0e-9,
				clkFallingEdge,
				dataHoldEdge,
				timingStep = 1.0e-9,
				frequency, t8DataHold;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			clkFallingEdge = vectorPeriod/10.0 + vectorPeriod/2.0;
			dataHoldEdge = 3.0*vectorPeriod/4.0;

			while((passFail == 0) && (dataHoldEdge > clkFallingEdge))
			{
				dataHoldEdge = dataHoldEdge - timingStep;
				HW.Dss.Trail(PM.SDIN_R0, dataHoldEdge);

				//Construct 24 bit write so that word is almost fully checkerboard
				Utl.t7and8write24Bits(dutAddress, 0xA, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x550)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
				HW.Dss.Trail(PM.SDIN_R0, dataHoldEdge);

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.t7and8write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				dataHoldEdge = dataHoldEdge + timingStep;
			}
			t8DataHold = dataHoldEdge - clkFallingEdge;
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t8Timing].Result = t8DataHold;
		}
		#endregion
		
	}// end of class t8_timing
	#endregion

	//
	//t9, t10 - CLEAR pulse High/Low Activation Time
	//
	#region t9_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t9_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t9_timing                       :
		public t9_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double t9ClrLoTime = -5, 
				t10ClrHiTime = -5,
				vectorPeriod, clrLeadingEdge, voutStrobeEdge;
			MsInt readback = 0;
			MsUInt64 [] readArray = MsUInt64.CreateArray(86,0);
			int i;

			Utl.SetAddressPins(App.TC.DutAddress);

			//Enable 5V range with FS on the output and set Clear mode to CLRtoZERO.
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, App.ClearMode.CLR_TO_ZERO,
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);

			//Setup drive/receive edges
			vectorPeriod = 1/App.TC.Frequency;
			clrLeadingEdge = vectorPeriod/11;	//3ns
			voutStrobeEdge = vectorPeriod/11;	//3ns
			HW.Dss.Lead(PM.CLEAR, clrLeadingEdge);
			HW.Dss.Strobe(PM.VOUT, voutStrobeEdge);

			//Conect Vout to pincard so that edges can be found
			HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.OUTPUT);
			//Need to find where Vout starts moving
			HW.Dss.ControlValue(PM.VOUT, Dss.Control.VOH, 4.9);
			HW.Dss.ControlValue(PM.VOUT, Dss.Control.VOL, 4.8);
			HW.Rdc.Set(PM.D15, OpenClose.OPEN);

			//Run pattern to Clear the output to 0V and measure time between clear rising edge and Vout falling edge.
			HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.DRIVE_PATTERN);
			Utl.RunPattern(DP.hw_clear);
			readArray = HW.Dss.CapRead(PM.VOUT, 84, 0, Dss.CapReadFormat.DATA);

			foreach(Site site in TP.MS.ActiveSites)
			{
				for(i = 0; i < 32; i++)
				{
					if(readArray[i][site] == 0)
					{
						//found High to Low threshold
						t10ClrHiTime = vectorPeriod + i*vectorPeriod;
						break;
					}
				}
			}

			//Need to find where Vout starts coming out of clear mode again
			HW.Dss.ControlValue(PM.VOUT, Dss.Control.VOH, 0.2);
			HW.Dss.ControlValue(PM.VOUT, Dss.Control.VOL, 0.1);

			//Run pattern to Clear the output to 0V and measure time between clear rising edge and Vout falling edge.
			Utl.RunPattern(DP.hw_clear);
			readArray = HW.Dss.CapRead(PM.VOUT, 84, 0, Dss.CapReadFormat.DATA);

			foreach(Site site in TP.MS.ActiveSites)
			{

				for(i = 0; i < 52; i++)
				{
					if(readArray[i+32][site] == 1)
					{
						//found Low to High threshold
						t9ClrLoTime = vectorPeriod + i*vectorPeriod;
						break;
					}
				}
			}

			//Cleanup 
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.RunPattern(DP.hw_reset);
			HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			HW.Dss.DriverInputSelect(PM.CLEAR, Dss.DriveData.FORCE_LOW);

			App.Test[IDs.t9Timing].Result = t9ClrLoTime;
			App.Test[IDs.t10Timing].Result = t10ClrHiTime;
		}
		#endregion
		
	}// end of class t9_timing
	#endregion

	//
	//t11 - Minimum SYNC High Time (Read Mode)
	//
	#region t11_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t11_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t11_timing                       :
		public t11_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vectorPeriod = 100.0e-9, frequency,
				syncLeadingEdge, syncTrailingEdge,
				timingStep = 1.0e-9,
				t11SyncHiRd,
				minPulsewidth = 2.0e-9;
			int passFail = 0;
			int dutAddress = 0x5;
			MsInt readData;

			Utl.SetAddressPins(dutAddress);

			//Frequency set to 10MHz since due to read operation
			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			syncLeadingEdge = App.TC.TimingData.SyncLead;

			//Set trailing edge to 50% of vector period
			syncTrailingEdge = vectorPeriod/2.0;
			HW.Dss.Trail(PM.SYNC_RSEL, syncTrailingEdge);

			//Now Sync pulsewidth = (vectorPeriod - syncTrailingEdge) + syncLeadingEdge

			//Read followed by write in t11_read pattern. 
			//Write 1: Addr = 0x5, Range = 0x5, Clr to Zero, Enable O/P, No Clear, Rext, No Reset -> 1010 0010 1010 1000
			//Sync high time between write and read is reduced and readback should, if sync high is long enough:
			//Readback: Addr = 0x5, Range = 0xA, Clr to Mid, Disable O/P, No Clear, Rint, No Reset -> 101 0101 0000
			while((passFail == 0) && ((syncTrailingEdge - syncLeadingEdge) > minPulsewidth))
			{
				syncTrailingEdge = syncTrailingEdge - timingStep;
				HW.Dss.Trail(PM.SYNC_RSEL, syncTrailingEdge);

				Utl.RunPattern(DP.hw_reset);
				App.Time.MsDelay(App.TC.OutputSettle);

				//Run 2-write pattern
				readData = Utl.t11ReadAddr();
				if(readData != 0x2b0)
					passFail++;

				Utl.SetInterfaceTiming(frequency);
			}
	
			if (passFail != 0)
			{
				syncTrailingEdge = syncTrailingEdge + timingStep;
			}
			t11SyncHiRd = syncTrailingEdge - syncLeadingEdge;
	
			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);
			App.Test[IDs.t11Timing].Result = t11SyncHiRd;
		}
		#endregion
		
	}// end of class t11_timing
	#endregion

	//t12 - SCLK Rising Edge to SDO Valid
		//Testing to be done in eval due to low drive capability of SDO (15pF)

	//
	//t13 - RESET pulse Width
	//
	#region t13_timing                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class t13_timing : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region t13_timing                       :
		public t13_timing()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double resetFallingEdge, resetRisingEdge;
			double vectorPeriod = 33.0e-9,
				minPulsewidth = 2.0e-9,
				frequency, 
				t13ResetPulsewidth,
				timingStep = 1.0e-9;
			MsInt passFail = 0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;
			double zeroVolts = 0.0;
			double maxVolt = App.TC.RangeData[(int)App.RangeOptions.FIVE_V].MaxValue;
			MsInt readData;

			Utl.SetAddressPins(App.TC.DutAddress);

			frequency = 1.0/vectorPeriod;
			Utl.SetInterfaceTiming(frequency);

			resetFallingEdge = App.TC.TimingData.ResetLead;
			resetRisingEdge = App.TC.TimingData.ResetTrail;

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);

			while((passFail[Site.S1] == 0) && ((resetRisingEdge - resetFallingEdge) > minPulsewidth))
			{
				resetRisingEdge = resetRisingEdge - timingStep;
				HW.Dss.Trail(PM.RESET, resetRisingEdge);

				//Write to device with output enabled and verify output goes to FS 
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, 
					App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				//Measure vout voltage
				passFail += Utl.TestVout(maxVolt, resourceSelect);
				
				//Reset the device using RESET pin and verify reset
				Utl.RunPattern(DP.hw_reset);
				App.Time.UsDelay(100); 

				//Measure vout voltage
				passFail += Utl.TestVout(zeroVolts, resourceSelect);

				//Readback register contents and verify POR conditions
				readData = Utl.ReadAddr(App.TC.DutAddress);
				if(readData != 0)
					passFail++;
			}
	
			if (passFail != 0)
			{
				resetRisingEdge = resetRisingEdge + timingStep;
			}
			t13ResetPulsewidth = resetRisingEdge - resetFallingEdge;

			App.Test[IDs.t13Timing].Result = t13ResetPulsewidth;

			//Cleanup 
			Utl.SetInterfaceTiming(App.TC.Frequency);		
		}
		#endregion
		
	}// end of class t13_timing
	#endregion

	//
	//InputLevelsCheck
	//
	#region InputLevelsCheck                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class InputLevelsCheck : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region InputLevelsCheck                       :
		public InputLevelsCheck()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vih = App.TC.DVcc,
				vil = 0.0,
				levelStep = 100e-3;
			int passFail = 0;
			MsInt readData;
			int dutAddress = 0x5;

			Utl.RunPattern(DP.hw_reset);
			Utl.SetAddressPins(dutAddress);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Input Levels");

			while(passFail == 0)
			{
				vih = vih - levelStep;
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, vih);

				//Write to device with output enabled and verify write is successful using readback
				Utl.write24Bits(dutAddress, App.TC.RangeData[(int)App.RangeOptions.TEN_V].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, 
					App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				//Readback register contents and verify POR conditions
				readData = Utl.ReadAddr(App.TC.DutAddress);
				if(readData != 0)
					passFail++;

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;
			}
	
			if (passFail != 0)
			{
				vih = vih + levelStep;
			}

			Utl.SetDigitalLevels(App.DigLevelsOpts.TIMING);

			//Vil Levels
			passFail = 0;
			Utl.RunPattern(DP.hw_reset);

			while(passFail == 0)
			{
				vil = vil + levelStep;
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, vil);

				//Write to device with output enabled and verify write is successful using readback
				Utl.write24Bits(dutAddress, App.TC.RangeData[(int)App.RangeOptions.TEN_V].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, 
					App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				//Readback register contents and verify POR conditions
				readData = Utl.ReadAddr(App.TC.DutAddress);
				if(readData != 0)
					passFail++;

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;
			}

			if(passFail != 0)
			{
				vil = vil - levelStep;
			}

			Utl.SetDigitalLevels(App.DigLevelsOpts.TIMING);
			Utl.RunPattern(DP.hw_reset);

			App.Test[IDs.vih].Result = vih;
			App.Test[IDs.vil].Result = vil;
		}
		#endregion
		
	}// end of class InputLevelsCheck
	#endregion

	//
	//OutputLevelsCheck
	//
	#region OutputLevelsCheck                       :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class OutputLevelsCheck : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region OutputLevelsCheck                       :
		public OutputLevelsCheck()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double voh = App.TC.DVcc - 0.4,
				vol = 0.4,
				levelStep = 100e-3,
				maxVoh = 7.0,
				minVol = -2.0;
			int passFail = 0;
			MsInt readData;
			MsUInt64 [] readArray = MsUInt64.CreateArray(11,0);
			int dutAddress = 0x5;

			Utl.RunPattern(DP.hw_reset);
			Utl.SetAddressPins(dutAddress);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Output Levels");

			//Voh Levels
			while((passFail == 0) && (voh < maxVoh))
			{
				voh = voh + levelStep;
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, voh);

				//Write to device with output enabled and verify write is successful using readback
				Utl.write24Bits(dutAddress, App.TC.RangeData[(int)App.RangeOptions.TEN_V].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, 
					App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				//Readback register contents and verify POR conditions
				readData = Utl.ReadAddr(App.TC.DutAddress);
				if(readData != 0)
					passFail++;

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;
			}
	
			if (passFail != 0)
			{
				voh = voh - levelStep;
			}

			Utl.SetDigitalLevels(App.DigLevelsOpts.TIMING);

			//Vol Levels
			passFail = 0;
			Utl.RunPattern(DP.hw_reset);

			while((passFail == 0) && (vol > minVol))
			{
				vol = vol - levelStep;
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, vol);

				//Write to device with output enabled and verify write is successful using readback
				Utl.write24Bits(dutAddress, App.TC.RangeData[(int)App.RangeOptions.TEN_V].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, 
					App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				//Readback register contents and verify POR conditions
				readData = Utl.ReadAddr(App.TC.DutAddress);
				if(readData != 0)
					passFail++;

				//Check that all data is outside Voh/Vol
				readArray = HW.Dss.CapRead(PM.SDO_VFAULT, 11, 0, Dss.CapReadFormat.MIDBAND);
				for(int bit = 0; bit < 11; bit++)
				{
					if(readArray[bit] != 1)
						passFail++;
				}

				//Construct another 24 bit write so that word is almost fully inverse checkerboard
				Utl.write24Bits(dutAddress, 0x5, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(100);
				readData = Utl.ReadAddr(0x5);
				if(readData != 0x2A0)
					passFail++;

				//Check that all data is outside Voh/Vol
				readArray = HW.Dss.CapRead(PM.SDO_VFAULT, 11, 0, Dss.CapReadFormat.MIDBAND);
				for(int bit = 0; bit < 11; bit++)
				{
					if(readArray[bit] != 1)
						passFail++;
				}
			}

			if(passFail != 0)
			{
				vol = vol + levelStep;
			}

			Utl.SetDigitalLevels(App.DigLevelsOpts.TIMING);
			Utl.RunPattern(DP.hw_reset);

			App.Test[IDs.voh].Result = voh;
			App.Test[IDs.vol].Result = vol;
		}
		#endregion
		
	}// end of class OutputLevelsCheck
	#endregion

	#endregion

} // end of namespace Adi.Cts.TestProgram
