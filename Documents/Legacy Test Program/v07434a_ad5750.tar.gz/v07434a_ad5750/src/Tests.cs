//
//		Probe Release
//		SECN v07434p01a_ad5750_8yj97wd
//


//
using System;
using Adi.Cts.Tos;
using Adi.Cts.Tos.Core;

namespace Adi.Cts.TestProgram
{

	//
	// SiteNumber test function
	//
	#region SiteNumber                      :
	/// <summary>
	/// Bin site details.
	/// </summary>
	public class SiteNumber : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region SiteNumber                      :
		public SiteNumber()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble result = 0.0;

			foreach (Site site in TP.MS.ActiveSites) // Site Loop
			{
				result[site] = (double)site + 1;
			}

			if (App.Globals.DebugEnable)
			{
				TP.Console.WriteLine("@Test {0}: result is {1}", IDs.SiteNumber.Name, result);
			} 

			App.Test[IDs.SiteNumber].Result = result;
		} 
		#endregion

	} // end of class SiteNumber
	#endregion

	//
	// TestConditions test function
	//
	#region TestConditions                  :
	/// <summary>
	/// Bin all the test conditions.
	/// </summary>
	public class TestConditions : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region TestConditions                  :
		public TestConditions()
		{
		}
		#endregion


		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			App.Test[IDs.DVccTC].Result       = App.TC.DVcc;
			App.Test[IDs.AVddTC].Result       = App.TC.AVdd;
			App.Test[IDs.AVssTC].Result       = App.TC.AVss;
			App.Test[IDs.VrefTC].Result       = App.TC.VRef;
			App.Test[IDs.TempTC].Result       = App.TC.Temp;

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				App.Test[IDs.WaferTC].Result	  = App.TC.WaferNum;
			}

		}
		#endregion
	} // end of class TestConditionsTF
	#endregion

	//
	//Continuity tests + NC checks
	//
	#region AssembleyTests
	//
	// Continuity Test Function
	//
	#region Continuity                      :
	/// <summary>
	/// Checks for Opens and shorts on all pins
	/// </summary>
	public class Continuity : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region Continuity                      :
		public Continuity()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			//int numEvenPins, numOddPins;
			double testCurrent,
				vsensenCurrent = 50.0e-6,
				allPinsCurrent = 200.0e-6;
			MsDouble diodeVoltage;
			int numPins = 23;
			int i;

			MsDouble [] highDiodeArray = MsDouble.CreateArray(numPins, 0);
			MsDouble [] lowDiodeArray = MsDouble.CreateArray(numPins, 0);

			//numEvenPins = 10;
			//numOddPins = 10;

			//Ensure all pins are switched to pincards
			HW.Rdc.Set(PM.CONT_RELAYS_OPEN, OpenClose.OPEN);
			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Force all pins to 0V and check each pin individually
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.CONT_PINS, Dss.PmuMode.FVMI_200_UA, 0.0);

			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.SUPPLIES, Dss.PmuMode.FVMI_200_UA, 0.0);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Continuity");

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking diodes to AVdd/Dvcc");
			for(i = 0; i < numPins; i++)
			{
				if((PM.CONT_PINS[i] == PM.VSENSEN) || (PM.CONT_PINS[i] == PM.COMP2))
					testCurrent = vsensenCurrent;
				else
					testCurrent = allPinsCurrent;
				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_200_UA, testCurrent);
				App.Time.MsDelay(1.0);
				diodeVoltage = HW.Dss.PmuRead(PM.CONT_PINS[i], App.Globals.NumPmuAverages);
				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FVMI_200_UA, 0.0);
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Pin: {0}, Diode Voltage: {1}", i, diodeVoltage); 
				highDiodeArray[i] = diodeVoltage;
			}

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking diodes to AVss/Gnd");
			for(i = 0; i < numPins; i++)
			{
				testCurrent = allPinsCurrent;
				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_200_UA, (-1)*testCurrent);
				App.Time.MsDelay(1.0);
				diodeVoltage = HW.Dss.PmuRead(PM.CONT_PINS[i], App.Globals.NumPmuAverages);
				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FVMI_200_UA, 0.0);
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Pin: {0}, Diode Voltage: {1}", i, diodeVoltage);
				lowDiodeArray[i] = diodeVoltage;
			}

			//Cleanup 
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.DISCONNECT);

			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN); 

			App.Test[IDs.ContHighSD0].Result = highDiodeArray[0];
			App.Test[IDs.ContHighClrsel].Result = highDiodeArray[1];
			App.Test[IDs.ContHighClr].Result = highDiodeArray[2];
			App.Test[IDs.ContHighSync].Result = highDiodeArray[3];
			App.Test[IDs.ContHighSclk].Result = highDiodeArray[4];
			App.Test[IDs.ContHighSdin].Result = highDiodeArray[5];
			App.Test[IDs.ContHighAD2].Result = highDiodeArray[6];
			App.Test[IDs.ContHighAD1].Result = highDiodeArray[7];
			App.Test[IDs.ContHighAD0].Result = highDiodeArray[8];
			App.Test[IDs.ContHighRext1].Result = highDiodeArray[9];
			App.Test[IDs.ContHighRext2].Result = highDiodeArray[10];
			App.Test[IDs.ContHighVref].Result = highDiodeArray[11];
			App.Test[IDs.ContHighVin].Result = highDiodeArray[12];
			App.Test[IDs.ContHighIout].Result = highDiodeArray[13];
			App.Test[IDs.ContHighComp1].Result = highDiodeArray[14];
			App.Test[IDs.ContHighComp2].Result = highDiodeArray[15];
			App.Test[IDs.ContHighVsensen].Result = highDiodeArray[16];
			App.Test[IDs.ContHighVout].Result = highDiodeArray[17];
			App.Test[IDs.ContHighVsensep].Result = highDiodeArray[18];
			App.Test[IDs.ContHighHwsel].Result = highDiodeArray[19];
			App.Test[IDs.ContHighReset].Result = highDiodeArray[20];
			App.Test[IDs.ContHighFault].Result = highDiodeArray[21];
			App.Test[IDs.ContHighNcIfault].Result = highDiodeArray[22];

			App.Test[IDs.ContLowSD0].Result = lowDiodeArray[0];
			App.Test[IDs.ContLowClrsel].Result = lowDiodeArray[1];
			App.Test[IDs.ContLowClr].Result = lowDiodeArray[2];
			App.Test[IDs.ContLowSync].Result = lowDiodeArray[3];
			App.Test[IDs.ContLowSclk].Result = lowDiodeArray[4];
			App.Test[IDs.ContLowSdin].Result = lowDiodeArray[5];
			App.Test[IDs.ContLowAD2].Result = lowDiodeArray[6];
			App.Test[IDs.ContLowAD1].Result = lowDiodeArray[7];
			App.Test[IDs.ContLowAD0].Result = lowDiodeArray[8];
			App.Test[IDs.ContLowRext1].Result = lowDiodeArray[9];
			App.Test[IDs.ContLowRext2].Result = lowDiodeArray[10];
			App.Test[IDs.ContLowVref].Result = lowDiodeArray[11];
			App.Test[IDs.ContLowVin].Result = lowDiodeArray[12];
			App.Test[IDs.ContLowIout].Result = lowDiodeArray[13];
			App.Test[IDs.ContLowComp1].Result = lowDiodeArray[14];
			App.Test[IDs.ContLowComp2].Result = lowDiodeArray[15];
			App.Test[IDs.ContLowVsensen].Result = lowDiodeArray[16];
			App.Test[IDs.ContLowVout].Result = lowDiodeArray[17];
			App.Test[IDs.ContLowVsensep].Result = lowDiodeArray[18];
			App.Test[IDs.ContLowHwsel].Result = lowDiodeArray[19];
			App.Test[IDs.ContLowReset].Result = lowDiodeArray[20];
			App.Test[IDs.ContLowFault].Result = lowDiodeArray[21];
			App.Test[IDs.ContLowNcIfault].Result = lowDiodeArray[22];
		}
		#endregion
	}// end of class Continuity
	#endregion

	//
	// ContinuityResCheck Test Function
	//
	#region ContinuityResCheck         :
	/// <summary>
	/// Checks for Opens and shorts on all pins
	/// </summary>
	public class ContinuityResCheck : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region ContinuityResCheck                      :
		public ContinuityResCheck()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			//int numEvenPins, numOddPins;
			double testCurrent,
				vsensenCurrent = 50.0e-6,
				rext2Current = 1.0e-3,
				allPinsCurrent = 200.0e-6,
				contactCheckCurrent = 2.0e-3;
			MsDouble diodeVoltage;
			int numPins = 23;
			int i;

			MsDouble [] highDiodeArray = MsDouble.CreateArray(numPins, 0);
			MsDouble [] lowDiodeArrayA = MsDouble.CreateArray(numPins, 0);
			MsDouble [] lowDiodeArrayB = MsDouble.CreateArray(numPins, 0);

			MsDouble voutHighDiodeB;
			MsDouble voutContactResHigh = 0;
			MsDouble [] contactResLow = MsDouble.CreateArray(numPins, 0);

			//numEvenPins = 10;
			//numOddPins = 10;

			//Ensure all pins are switched to pincards
			HW.Rdc.Set(PM.CONT_RELAYS_OPEN, OpenClose.OPEN);
			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Force all pins to 0V and check each pin individually
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_2_MA);
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_2_MA);
			
			HW.Dss.PmuModeValue(PM.CONT_PINS, Dss.PmuMode.FVMI_2_MA, 0.0);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.PMU_TO_PIN);

			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_2_MA);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_2_MA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.SUPPLIES, Dss.PmuMode.FVMI_2_MA, 0.0);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Continuity");

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking diodes to AVdd/Dvcc");
			for(i = 0; i < numPins; i++)
			{
				if((PM.CONT_PINS[i] == PM.VSENSEN) || (PM.CONT_PINS[i] == PM.COMP2))
					testCurrent = vsensenCurrent;
				else
					testCurrent = allPinsCurrent;

				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_2_MA, testCurrent);
                App.Time.MsDelay(3.0);
				diodeVoltage = HW.Dss.PmuRead(PM.CONT_PINS[i], App.Globals.NumPmuAverages);
				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FVMI_2_MA, 0.0);
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Pin: {0}, Diode Voltage: {1}", i, diodeVoltage); 
				highDiodeArray[i] = diodeVoltage;
			}

//
			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FIMV_2_MA, contactCheckCurrent);
				App.Time.MsDelay(3.0);
				diodeVoltage = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_2_MA, 0.0);
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Pin: {0}, Diode Voltage: {1}", i, diodeVoltage); 
				voutHighDiodeB = diodeVoltage;
				voutContactResHigh = (voutHighDiodeB - highDiodeArray[17]) / (MsDouble)(contactCheckCurrent - allPinsCurrent);
			}
//



			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking diodes to AVss/Gnd");
			for(i = 0; i < numPins; i++)
			{
				if(PM.CONT_PINS[i] == PM.REXT2)
				{
					testCurrent = rext2Current;
					HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_2_MA, (-1)*contactCheckCurrent);
					App.Time.MsDelay(3.0);
				}
				else 
					testCurrent = allPinsCurrent;

				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_2_MA, (-1)*testCurrent);
				App.Time.MsDelay(3.0);
				diodeVoltage = HW.Dss.PmuRead(PM.CONT_PINS[i], App.Globals.NumPmuAverages);

				if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
				{
					if(PM.CONT_PINS[i] == PM.REXT2)
					{
						foreach(Site site in TP.MS.ActiveSites)
						{
							if(diodeVoltage[site] > -0.4)
							{
								HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_2_MA, (-1)*contactCheckCurrent);
								App.Time.MsDelay(App.TC.Rext2Delay);
								HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_2_MA, (-1)*testCurrent);
								App.Time.MsDelay(App.TC.Rext2Delay);
								diodeVoltage = HW.Dss.PmuRead(PM.CONT_PINS[i], App.Globals.NumPmuAverages);
							}
			
						}
					}
				}
					

				HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FVMI_2_MA, 0.0);
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Pin: {0}, Diode Voltage: {1}", i, diodeVoltage);
				lowDiodeArrayA[i] = diodeVoltage;
			}

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				//Now need to check some sensitive pins and a different current
				for(i = 0; i < numPins; i++)
				{
					if((PM.CONT_PINS[i] == PM.REXT1) ||
						(PM.CONT_PINS[i] == PM.REXT2) ||
						(PM.CONT_PINS[i] == PM.VREF) ||
						(PM.CONT_PINS[i] == PM.VIN) ||
						(PM.CONT_PINS[i] == PM.IOUT) ||
						(PM.CONT_PINS[i] == PM.VSENSEN) ||
						(PM.CONT_PINS[i] == PM.VOUT) ||
						(PM.CONT_PINS[i] == PM.VSENSEP))
					{
						HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FIMV_2_MA, (-1)*contactCheckCurrent);
						App.Time.MsDelay(3.0);
						diodeVoltage = HW.Dss.PmuRead(PM.CONT_PINS[i], App.Globals.NumPmuAverages);
						HW.Dss.PmuModeValue(PM.CONT_PINS[i], Dss.PmuMode.FVMI_2_MA, 0.0);
						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Pin: {0}, Diode Voltage: {1}", i, diodeVoltage);
						lowDiodeArrayB[i] = diodeVoltage;
						contactResLow[i] = (lowDiodeArrayB[i] - lowDiodeArrayA[i]) / (MsDouble)((-1)*contactCheckCurrent - (-1)*allPinsCurrent);
						if(i == 10)
							contactResLow[i] = (lowDiodeArrayB[i] - lowDiodeArrayA[i]) / (MsDouble)((-1)*contactCheckCurrent - (-1)*rext2Current);
					}
				}
			}

			//Cleanup 
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.DISCONNECT);

			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN); 

			#region binData
			App.Test[IDs.ContHighSD0].Result = highDiodeArray[0];
			App.Test[IDs.ContHighClrsel].Result = highDiodeArray[1];
			App.Test[IDs.ContHighClr].Result = highDiodeArray[2];
			App.Test[IDs.ContHighSync].Result = highDiodeArray[3];
			App.Test[IDs.ContHighSclk].Result = highDiodeArray[4];
			App.Test[IDs.ContHighSdin].Result = highDiodeArray[5];
			App.Test[IDs.ContHighAD2].Result = highDiodeArray[6];
			App.Test[IDs.ContHighAD1].Result = highDiodeArray[7];
			App.Test[IDs.ContHighAD0].Result = highDiodeArray[8];
			App.Test[IDs.ContHighRext1].Result = highDiodeArray[9];
			App.Test[IDs.ContHighRext2].Result = highDiodeArray[10];
			App.Test[IDs.ContHighVref].Result = highDiodeArray[11];
			App.Test[IDs.ContHighVin].Result = highDiodeArray[12];
			App.Test[IDs.ContHighIout].Result = highDiodeArray[13];
			App.Test[IDs.ContHighComp1].Result = highDiodeArray[14];
			App.Test[IDs.ContHighComp2].Result = highDiodeArray[15];
			App.Test[IDs.ContHighVsensen].Result = highDiodeArray[16];
			App.Test[IDs.ContHighVout].Result = highDiodeArray[17];
			App.Test[IDs.ContHighVsensep].Result = highDiodeArray[18];
			App.Test[IDs.ContHighHwsel].Result = highDiodeArray[19];
			App.Test[IDs.ContHighReset].Result = highDiodeArray[20];
			App.Test[IDs.ContHighFault].Result = highDiodeArray[21];
			App.Test[IDs.ContHighNcIfault].Result = highDiodeArray[22];

			App.Test[IDs.ContLowSD0].Result = lowDiodeArrayA[0];
			App.Test[IDs.ContLowClrsel].Result = lowDiodeArrayA[1];
			App.Test[IDs.ContLowClr].Result = lowDiodeArrayA[2];
			App.Test[IDs.ContLowSync].Result = lowDiodeArrayA[3];
			App.Test[IDs.ContLowSclk].Result = lowDiodeArrayA[4];
			App.Test[IDs.ContLowSdin].Result = lowDiodeArrayA[5];
			App.Test[IDs.ContLowAD2].Result = lowDiodeArrayA[6];
			App.Test[IDs.ContLowAD1].Result = lowDiodeArrayA[7];
			App.Test[IDs.ContLowAD0].Result = lowDiodeArrayA[8];
			App.Test[IDs.ContLowRext1].Result = lowDiodeArrayA[9];
			App.Test[IDs.ContLowRext2].Result = lowDiodeArrayA[10];
			App.Test[IDs.ContLowVref].Result = lowDiodeArrayA[11];
			App.Test[IDs.ContLowVin].Result = lowDiodeArrayA[12];
			App.Test[IDs.ContLowIout].Result = lowDiodeArrayA[13];
			App.Test[IDs.ContLowComp1].Result = lowDiodeArrayA[14];
			App.Test[IDs.ContLowComp2].Result = lowDiodeArrayA[15];
			App.Test[IDs.ContLowVsensen].Result = lowDiodeArrayA[16];
			App.Test[IDs.ContLowVout].Result = lowDiodeArrayA[17];
			App.Test[IDs.ContLowVsensep].Result = lowDiodeArrayA[18];
			App.Test[IDs.ContLowHwsel].Result = lowDiodeArrayA[19];
			App.Test[IDs.ContLowReset].Result = lowDiodeArrayA[20];
			App.Test[IDs.ContLowFault].Result = lowDiodeArrayA[21];
			App.Test[IDs.ContLowNcIfault].Result = lowDiodeArrayA[22];


			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				App.Test[IDs.VoutHiRes].Result = voutContactResHigh;

				//App.Test[IDs.SD0LoRes].Result = contactResLow[0];
				//App.Test[IDs.ClrselLoRes].Result = contactResLow[1];
				//App.Test[IDs.ClrLoRes].Result = contactResLow[2];
				//App.Test[IDs.SyncLoRes].Result = contactResLow[3];
				//App.Test[IDs.SclkLoRes].Result = contactResLow[4];
				//App.Test[IDs.SdinLoRes].Result = contactResLow[5];
				//App.Test[IDs.AD2LoRes].Result = contactResLow[6];
				//App.Test[IDs.AD1LoRes].Result = contactResLow[7];
				//App.Test[IDs.AD0LoRes].Result = contactResLow[8];
				App.Test[IDs.Rext1LoRes].Result = contactResLow[9];
				App.Test[IDs.Rext2LoRes].Result = contactResLow[10];
				App.Test[IDs.VrefLoRes].Result = contactResLow[11];
				App.Test[IDs.VinLoRes].Result = contactResLow[12];
				App.Test[IDs.IoutLoRes].Result = contactResLow[13];
				//App.Test[IDs.Comp1LoRes].Result = contactResLow[14];
				//App.Test[IDs.Comp2LoRes].Result = contactResLow[15];
				App.Test[IDs.VsensenLoRes].Result = contactResLow[16];
				App.Test[IDs.VoutLoRes].Result = contactResLow[17];
				App.Test[IDs.VsensepLoRes].Result = contactResLow[18];
				//App.Test[IDs.HwselLoRes].Result = contactResLow[19];
				//App.Test[IDs.ResetLoRes].Result = contactResLow[20];
				//App.Test[IDs.FaultLoRes].Result = contactResLow[21];
				//App.Test[IDs.NcIfaultLoRes].Result = contactResLow[22];
			}

			#endregion

		}
		#endregion
	}// end of class ContinuityResCheck
	#endregion

	//
	// Continuity2 Test Function
	//
	#region Continuity2                      :
	/// <summary>
	/// Checks for Opens and shorts on all pins
	/// </summary>
	public class Continuity2 : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region Continuity2                      :
		public Continuity2()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vilLevel = 0.0,
				vohOneDiode = 0.9,
				volOneDiode = 0.2,
				vohTwoDiode = 1.8,
				volTwoDiode = 0.8,
				vohThreeDiode = 2.7,
				volThreeDiode = 1.2,
				vthLevel = 5.0,
				ncVthLevel = 0.5,
				iohLevel = 1.0e-3,
				iolLevel = 1.0e-3;
			int numPins = 27;	//exclude Supply & Gnd Pins
			int dataOffset = 0;
			MsInt passFail = 0;
			MsUInt64 [] readData = MsUInt64.CreateArray(1,0);

			//Ensure all pins are switched to pincards
			HW.Rdc.Set(PM.CONT_RELAYS_OPEN, OpenClose.OPEN);
			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.CLOSE);

			//Force all pins to 0V and check each pin individually
			HW.Dss.ControlValue(PM.EVERY_PIN, Dss.Control.IOH, 0.0);
			HW.Dss.ControlValue(PM.EVERY_PIN, Dss.Control.IOL, iolLevel);
			HW.Dss.ControlValue(PM.EVERY_PIN, Dss.Control.VTH, vthLevel);
			HW.Dss.ControlValue(PM.NO_CONNECTS, Dss.Control.VTH, ncVthLevel);

			HW.Dss.ConnectionSet(PM.EVERY_PIN, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.DriverInputSelect(PM.EVERY_PIN, Dss.DriveData.DRIVE_PATTERN);
			HW.Dss.ControlValue(PM.EVERY_PIN, Dss.Control.VIL, vilLevel);

			//Different Voh/Vol levels to be set according to expected diodes
			HW.Dss.ControlValue(PM.ONE_DIODE_PINS, Dss.Control.VOL, volOneDiode);
			HW.Dss.ControlValue(PM.ONE_DIODE_PINS, Dss.Control.VOH, vohOneDiode);

			HW.Dss.ControlValue(PM.TWO_DIODE_PINS, Dss.Control.VOL, volTwoDiode);
			HW.Dss.ControlValue(PM.TWO_DIODE_PINS, Dss.Control.VOH, vohTwoDiode);

			HW.Dss.ControlValue(PM.THREE_DIODE_PINS, Dss.Control.VOL, volThreeDiode);
			HW.Dss.ControlValue(PM.THREE_DIODE_PINS, Dss.Control.VOH, vohThreeDiode);

			//Set up capture format to check for Valids.
			HW.Dss.Freq(PM.EVERY_PIN, 1.0e6);
			HW.Dss.Lead(PM.EVERY_PIN, 10.0e-9, 10.0e-9);
			HW.Dss.Trail(PM.EVERY_PIN, 950.0e-9, 950.0e-9);
			HW.Dss.Strobe(PM.EVERY_PIN, 900.0e-9);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Continuity");

			//Run Pattern
			Utl.RunPattern(DP.ContinuityLowPat);

			for(int i = 0; i < numPins; i++)
			{
				if((PM.EVERY_PIN[i] != PM.AVDD) && (PM.EVERY_PIN[i] != PM.AVSS) && (PM.EVERY_PIN[i] != PM.DVCC))
				{
					if(PM.EVERY_PIN[i] == PM.VREF)
						dataOffset++;
					readData = HW.Dss.CapRead(PM.EVERY_PIN[i], 1, (i + dataOffset), Dss.CapReadFormat.MIDBAND);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(readData[0][site] == 1)
						{
							passFail[site]++;
							TP.Console.WriteLine("Pin: {0} failed", PM.EVERY_PIN[i].Name);
						}
					}
				}
			}

			TP.Console.WriteLine("");
			TP.Console.WriteLine("");
			
			//Different Voh/Vol levels to be set according to expected diodes
			HW.Dss.ControlValue(PM.ONE_DIODE_PINS, Dss.Control.VOL, -vohOneDiode);
			HW.Dss.ControlValue(PM.ONE_DIODE_PINS, Dss.Control.VOH, -volOneDiode);

			HW.Dss.ControlValue(PM.TWO_DIODE_PINS, Dss.Control.VOL, -vohOneDiode);
			HW.Dss.ControlValue(PM.TWO_DIODE_PINS, Dss.Control.VOH, -volOneDiode);

			HW.Dss.ControlValue(PM.THREE_DIODE_PINS, Dss.Control.VOL, -vohOneDiode);
			HW.Dss.ControlValue(PM.THREE_DIODE_PINS, Dss.Control.VOH, -volOneDiode);

			//Force all pins to 0V and check each pin individually
			HW.Dss.ControlValue(PM.EVERY_PIN, Dss.Control.IOH, iohLevel);
			HW.Dss.ControlValue(PM.EVERY_PIN, Dss.Control.IOL, 0.0);
			HW.Dss.ControlValue(PM.EVERY_PIN, Dss.Control.VTH, vthLevel);
			HW.Dss.ControlValue(PM.NO_CONNECTS, Dss.Control.VTH, ncVthLevel);

			//Run Pattern
			Utl.RunPattern(DP.ContinuityHighPat);

			for(int i = 0; i < numPins; i++)
			{
				if((PM.EVERY_PIN[i] != PM.AVDD) && (PM.EVERY_PIN[i] != PM.AVSS) && (PM.EVERY_PIN[i] != PM.DVCC))
				{
					readData = HW.Dss.CapRead(PM.EVERY_PIN[i], PM.EVERY_PIN.Count, 0, Dss.CapReadFormat.MIDBAND);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(readData[i][site] == 1)
						{
							passFail[site]++;
							TP.Console.WriteLine("Pin: {0} failed", PM.EVERY_PIN[i].Name);				
						}
					}
				}
			}
			TP.Console.WriteLine("");
			TP.Console.WriteLine("");	
			App.Test[IDs.Continuity].Result = passFail;

			//Cleanup 
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.DISCONNECT);

			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, App.TC.DVcc);

			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN); 

		}
		#endregion
	}// end of class Continuity2
	#endregion

	//
	// NoConnects Test Function
	//
	#region NoConnects                      :
	/// <summary>
	/// Function checks that No connect pins are open and not shorted to adjacent pins
	/// </summary>
	public class NoConnects : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region NoConnects                      :
		public NoConnects()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsUInt64 [] readData = MsUInt64.CreateArray(20, 0);
			MsInt passFail = 0;
			int i, numNCs = 4;

			//Verify that none of the no-connects are shorted to their adjacent pins

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("No Connects");
		

			//Ensure all pins are switched to pincards
			HW.Rdc.Set(PM.CONT_RELAYS_OPEN, OpenClose.OPEN);
			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.CLOSE);

			//Force all pins to 0V and check each pin individually
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.CONT_PINS, Dss.PmuMode.FVMI_200_UA, 0.0);

			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.SUPPLIES, Dss.PmuMode.FVMI_200_UA, 0.0);

			HW.Dss.ControlValue(PM.NO_CONNECTS, Dss.Control.IOH, 0.001);
			HW.Dss.ControlValue(PM.NO_CONNECTS, Dss.Control.IOL, 0.001);
			HW.Dss.ControlValue(PM.NO_CONNECTS, Dss.Control.VTH, 0.5);
			HW.Dss.ConnectionSet(PM.NO_CONNECTS, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.DriverInputSelect(PM.NO_CONNECTS, Dss.DriveData.DRIVE_PATTERN);

			
			HW.Dss.Freq(PM.NO_CONNECTS, 1.0e6);
			HW.Dss.Lead(PM.NO_CONNECTS, 10.0e-9, 10.0e-9);
			HW.Dss.Trail(PM.NO_CONNECTS, 950.0e-9, 950.0e-9);
			HW.Dss.Strobe(PM.NO_CONNECTS, 900.0e-9);

			HW.Dss.ControlValue(PM.NO_CONNECTS, Dss.Control.VOL, 0.2);
			HW.Dss.ControlValue(PM.NO_CONNECTS, Dss.Control.VOH, 0.9);

			Utl.RunPattern(DP.ncPat);

			for(i = 0; i< numNCs; i++)
			{
				readData = HW.Dss.CapRead(PM.NO_CONNECTS[i], 4, 0, Dss.CapReadFormat.MIDBAND);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(readData[i][site] == 1)
					{
						passFail[site]++;
						TP.Console.WriteLine("Pin {0} failed opens test", PM.NO_CONNECTS[i].Name);
					}
				}
			}

			App.Test[IDs.NCcheck].Result = passFail;

			//Cleanup 
			HW.Dss.ConnectionSet(PM.NO_CONNECTS, Dss.ConnectionMode.DISCONNECT);

			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.DISCONNECT);

			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN); 
		}
		#endregion
	}// end of class NoConnects
	#endregion


	//
	// GndResCheck Test Function
	//
	#region GndResCheck         :
	/// <summary>
	/// Checks for contact resistance between 2 gnd pins
	/// </summary>
	public class GndResCheck : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region GndResCheck                      :
		public GndResCheck()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
	
			MsDouble testVoltage1 = 50e-3, 
				testVoltage2 = 100e-3;
			MsDouble iMeas1 = 0.0,
				iMeas2 = 0.0;
			MsDouble res50mv = 0.0,
				res100mv = 0.0;

			//Ensure all pins are switched to pincards
			HW.Rdc.Set(PM.CONT_RELAYS_OPEN, OpenClose.OPEN);
			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Force all pins to 0V and check each pin individually
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_2_MA);
			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_2_MA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.CONT_PINS, Dss.PmuMode.FVMI_2_MA, 0.0);

			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_2_MA);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_2_MA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.SUPPLIES, Dss.PmuMode.FVMI_2_MA, 0.0);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Continuity");

			//Close Gnd Sns relays & connect PMU to gnd1 pin
			HW.Rdc.Set(PM.D22, OpenClose.CLOSE);
			HW.Dss.PmuConnectMode(PM.GND1_PMU, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_100_MA);
			HW.Dss.PmuConnectMode(PM.GND1_PMU, Dss.PmuConnectionMode.PMU_POGO, Dss.PmuMode.FVMI_100_MA);
			App.Time.MsDelay(App.TC.RelaySettle);				

			HW.Dss.PmuModeValue(PM.GND1_PMU, Dss.PmuMode.FVMI_100_MA, testVoltage1);
			iMeas1 = HW.Dss.PmuRead(PM.GND1_PMU, App.Globals.NumPmuAverages);
			res50mv = testVoltage1 / iMeas1;

			HW.Dss.PmuModeValue(PM.GND1_PMU, Dss.PmuMode.FVMI_100_MA, testVoltage2);
			iMeas2 = HW.Dss.PmuRead(PM.GND1_PMU, App.Globals.NumPmuAverages);
			res100mv = testVoltage2 / iMeas2;

			//Cleanup 
			HW.Dss.PmuModeValue(PM.GND1_PMU, Dss.PmuMode.FVMI_100_MA, 0.0);
			HW.Dss.PmuModeValue(PM.GND1_PMU, Dss.PmuMode.FIMV_200_UA, 0.0);
			HW.Dss.PmuConnectMode(PM.GND1_PMU, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_200_UA);

			HW.Rdc.Set(PM.D22, OpenClose.OPEN);

			HW.Dss.PmuConnectMode(PM.CONT_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.CONT_PINS, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.PmuConnectMode(PM.SUPPLIES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.SUPPLIES, Dss.ConnectionMode.DISCONNECT);

			HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN); 
                
			#region binData
			App.Test[IDs.GndSnsRes50mv].Result = res50mv;
			App.Test[IDs.GndSnsRes100mv].Result = res100mv;
			#endregion

		}
		#endregion
	}// end of class GndResCheck
	#endregion

	#endregion

	//
	//Supply Currents Tests for different device modes
	//
	#region SupplyCurrentTests
	//
	// SupplyCurrents Test Function
	//
	#region SupplyCurrents                  :
	/// <summary>
	/// Measures supply currents on AVdd, AVss and DVss
	/// </summary>
	public class SupplyCurrents : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region SupplyCurrents                  :
		public SupplyCurrents()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble avddCurrent = 0.0;
			MsDouble avssCurrent = 0.0;
			MsDouble dvccCurrent = 0.0;


			MsInt readbackWord = 0;

			//Setup device conditions
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V_BIP].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);

			//CLOSE supply relays - open rlx13 while switching out caps to avoid ringing on VsenseN pin
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.OPEN);
			}

			HW.Rdc.Set(PM.D3, OpenClose.CLOSE);
			HW.Rdc.Set(PM.D7, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);

			//Set up logic levels to 0 and DVcc
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.DVcc);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, 0.0);
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_50_UA);

			App.Time.MsDelay(App.TC.VfaultDelay);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Supply Currents");

			//Measure Supply Currents
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				avddCurrent = HW.Upc.ReadI(PM.HV_SUPPLY1_HI);	
			}
			else
			{
				avddCurrent = HW.Vi.ReadI(PM.AVDD);
			}


			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				avssCurrent = HW.Vi.ReadI(PM.AVSS);

			
			dvccCurrent = HW.Dvi.ReadI(PM.DVCC);

			if(App.Globals.OfflineDev)
			{
				avddCurrent = 26.5e-3;
				avssCurrent = -25.0e-3;
				dvccCurrent = 0.9e-6;
			}

			App.Test[IDs.AIdd].Result = avddCurrent;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				App.Test[IDs.AIss].Result = avssCurrent;
			App.Test[IDs.DIcc].Result = dvccCurrent;

			//Cleanup
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
			HW.Rdc.Set(PM.D3, OpenClose.OPEN);
			HW.Rdc.Set(PM.D7, OpenClose.OPEN);
			Utl.RunPattern(DP.hw_reset);

		}
		#endregion
	}// end of class SupplyCurrents
	#endregion

	//
	// RangeSupplyCurrents Test Function
	//
	#region RangeSupplyCurrents             :
	/// <summary>
	/// Measures supply currents for Vout enabled (Vin = 0V) and Iout enabled (Vin = 0V)
	/// </summary>
	public class RangeSupplyCurrents : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region RangeSupplyCurrents             :
		public RangeSupplyCurrents()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{

			MsDouble avddCurrent = 0.0;
			MsDouble avssCurrent = 0.0;
			MsDouble dvccCurrent = 0.0;

			//Setup device conditions for voltage range
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);

			//Ensure Vin = 0V
			HW.Dcs.VOut(PM.VIN, 0.0);
			App.Time.MsDelay(App.TC.OutputSettle);

			//CLOSE supply relays
			HW.Rdc.Set(PM.D3, OpenClose.CLOSE);
			HW.Rdc.Set(PM.D7, OpenClose.CLOSE);

			//Set up logic levels to 0 and DVcc
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.DVcc);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, 0.0);
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_50_UA);
		
			App.Time.MsDelay(App.TC.VfaultDelay);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Range Supply Currents");

			//Measure Supply Currents
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				//can only measure two sites at a time. 
				avddCurrent = HW.Upc.ReadI(PM.HV_SUPPLY1_HI);
			}
			else
			{
				avddCurrent = HW.Vi.ReadI(PM.AVDD);
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				avssCurrent = HW.Vi.ReadI(PM.AVSS);

			dvccCurrent = HW.Dvi.ReadI(PM.DVCC);

	
			if(App.Globals.OfflineDev)
			{
				avddCurrent = 26.5e-3;
				avssCurrent = -25.0e-3;
				dvccCurrent = 0.9e-6;
			}

			App.Test[IDs.VRangeAIdd].Result = avddCurrent;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				App.Test[IDs.VRangeAIss].Result = avssCurrent;
			App.Test[IDs.VRangeDIcc].Result = dvccCurrent;

			//Setup device conditions for current output 
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.TWENTY_MA].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.VfaultDelay);

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Measure Supply Currents
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				//can only measure two sites at a time. 
			}
			else
			{
				avddCurrent = HW.Vi.ReadI(PM.AVDD);
			}

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				avssCurrent = HW.Vi.ReadI(PM.AVSS);

			dvccCurrent = HW.Dvi.ReadI(PM.DVCC);

			if(App.Globals.OfflineDev)
			{
				avddCurrent = 26.5e-3;
				avssCurrent = -25.0e-3;
				dvccCurrent = 0.9e-6;
			}

			App.Test[IDs.IRangeAIdd].Result = avddCurrent;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				App.Test[IDs.IRangeAIss].Result = avssCurrent;
			App.Test[IDs.IRangeDIcc].Result = dvccCurrent;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
			HW.Rdc.Set(PM.D3, OpenClose.OPEN);
			HW.Rdc.Set(PM.D7, OpenClose.OPEN);
		}
		#endregion
	}// end of class RangeSupplyCurrents
	#endregion

	//
	// PostTestSupplyCurrents Test Function
	//
	#region PostTestSupplyCurrents                  :
	/// <summary>
	/// Measures supply currents on AVdd, AVss and DVss at end of test program
	/// </summary>
	public class PostTestSupplyCurrents : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region PostTestSupplyCurrents                  :
		public PostTestSupplyCurrents()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble avddCurrent = 0.0;
			MsDouble avssCurrent = 0.0;
			MsDouble dvccCurrent = 0.0;

			MsInt readbackWord = 0;

			//Setup device conditions
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V_BIP].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);

			//CLOSE supply relays - open rlx13 while switching out caps to avoid ringing on VsenseN pin
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.D3, OpenClose.CLOSE);
			HW.Rdc.Set(PM.D7, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);

			//Set up logic levels to 0 and DVcc
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.DVcc);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, 0.0);
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_50_UA);

			App.Time.MsDelay(App.TC.VfaultDelay);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Supply Currents");

			//Measure Supply Currents
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				avddCurrent = HW.Upc.ReadI(PM.HV_SUPPLY1_HI);
			}
			else
			{
				avddCurrent = HW.Vi.ReadI(PM.AVDD);
			}

			
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				avssCurrent = HW.Vi.ReadI(PM.AVSS);


			dvccCurrent = HW.Dvi.ReadI(PM.DVCC);

			if(App.Globals.OfflineDev)
			{
				avddCurrent = 26.5e-3;
				avssCurrent = -25.0e-3;
				dvccCurrent = 0.9e-6;
			}

			App.Test[IDs.PostTestAIdd].Result = avddCurrent;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				App.Test[IDs.PostTestAIss].Result = avssCurrent;
			App.Test[IDs.PostTestDIcc].Result = dvccCurrent;

			//Cleanup
			HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
			HW.Rdc.Set(PM.D3, OpenClose.OPEN);
			HW.Rdc.Set(PM.D7, OpenClose.OPEN);
			Utl.RunPattern(DP.hw_reset);

		}
		#endregion
	}// end of class PostTestSupplyCurrents
	#endregion


	#endregion

	//
	//Leakage Tests for Dig I/Ps & O/Ps, Analog O/Ps, Vref & Vin
	//
	#region LeakageTests
	//
	// Leakage Test Function
	//
	#region Leakage                         :
	/// <summary>
	/// Test to measure leakage on digital pins
	/// </summary>
	public class Leakage : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region Leakage                         :
		public Leakage()
		{
		}
		#endregion

		//
		//Force DVcc & 0V on each of the digital pins sequentially
		//and measure the corresponding current in each pin.
		//
		#region Run                             :
		public override void Run()
		{
			int i;
			int numLeakagePins = 11,
				numHwLkgPins = 2,
				//Only checking 2 of the h/w fault pnis as the rest are tested in S/W mode
				totalPins = numLeakagePins + numHwLkgPins;
			int numAverages = 10;
			MsDouble leakageCurrent = 0.0;
			double zeroVolts = 0.0, pullupVoltage;

			MsDouble [] leakageArrayZero = MsDouble.CreateArray(totalPins, 0);
			MsDouble [] leakageArrayDvcc = MsDouble.CreateArray(totalPins, 0);

			//All digital pins are directly connected to pincards,
			//except for NC/IFAULT - need to ensure this relay is switched open
			HW.Rdc.Set(PM.RLX21_RELAYS, OpenClose.OPEN);

			//Set up each pin to FVMI with 0V and measure corresponding current
			HW.Dss.PmuConnectMode(PM.DIG_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.PmuConnectMode(PM.DIG_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.DIG_PINS, Dss.PmuMode.FVMI_20_UA, 2.0);

			App.Time.MsDelay(App.TC.RelaySettle);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Leakage");

			//HW.Dss.PmuReadMulti

			for(i = 0; i < numLeakagePins; i++)
			{
				HW.Dss.PmuModeValue(PM.LEAKAGE_PINS[i], Dss.PmuMode.FVMI_20_UA, zeroVolts);
				leakageCurrent = HW.Dss.PmuRead(PM.LEAKAGE_PINS[i], numAverages); 
				if(App.Globals.OfflineDev)
				{
					leakageCurrent = 0.5e-6;
				}
				leakageArrayZero[i] = leakageCurrent;
				HW.Dss.PmuModeValue(PM.LEAKAGE_PINS[i], Dss.PmuMode.FVMI_20_UA, 2.0);
			}

			for(i = 0; i < numLeakagePins; i++)
			{
				HW.Dss.PmuModeValue(PM.LEAKAGE_PINS[i], Dss.PmuMode.FVMI_20_UA, App.TC.DVcc);
				leakageCurrent = HW.Dss.PmuRead(PM.LEAKAGE_PINS[i], numAverages); 
				if(App.Globals.OfflineDev)
				{
					leakageCurrent = 0.7e-6;
				}
				leakageArrayDvcc[i] = leakageCurrent;
				HW.Dss.PmuModeValue(PM.LEAKAGE_PINS[i], Dss.PmuMode.FVMI_20_UA, 2.0);
			}


			App.Time.MsDelay(App.TC.IfaultLkgSettle);

			//Need to enable hardware mode to measure tristate current on opendrain NC/IFault & Fault/Temp pins
			HW.Dss.PmuConnectMode(PM.HW_SELECT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.HW_SELECT, Dss.ConnectionMode.OUTPUT);
			HW.Dss.DriverInputSelect(PM.HW_SELECT, Dss.DriveData.FORCE_HIGH);

			HW.Dss.PmuConnectMode(PM.HW_FAULT_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.HW_FAULT_PINS, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.HW_FAULT_PINS, Dss.PmuMode.FVMI_20_UA, zeroVolts);

			//Need to ensure that VsenseN & VsenseP are set up correctly to close feedback loop
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);

			for(i = 0; i < numHwLkgPins; i++)
			{
				if(PM.HW_FAULT_PINS[i+1] == PM.NC_IFAULT)
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i+1], Dss.PmuMode.FVMI_200_UA, zeroVolts);
				else
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i+1], Dss.PmuMode.FVMI_20_UA, zeroVolts);

				leakageCurrent = HW.Dss.PmuRead(PM.HW_FAULT_PINS[i+1], numAverages); 
				if(App.Globals.OfflineDev)
				{
					leakageCurrent = 0.5e-6;
				}
				leakageArrayZero[i + numLeakagePins] = leakageCurrent;
				HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i+1], Dss.PmuMode.FVMI_20_UA, zeroVolts);

			}

			for(i = 0; i < numHwLkgPins; i++)
			{
				if(PM.HW_FAULT_PINS[i+1] == PM.NC_IFAULT)
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i+1], Dss.PmuMode.FVMI_200_UA, App.TC.DVcc);
				else
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i+1], Dss.PmuMode.FVMI_20_UA, App.TC.DVcc);
				leakageCurrent = HW.Dss.PmuRead(PM.HW_FAULT_PINS[i+1], numAverages); 
				if(App.Globals.OfflineDev)
				{
					leakageCurrent = 0.7e-6;
				}
				leakageArrayDvcc[i + numLeakagePins] = leakageCurrent;
				HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i+1], Dss.PmuMode.FVMI_20_UA, zeroVolts);
			}


			//Cleanup
			HW.Dss.DriverInputSelect(PM.HW_SELECT, Dss.DriveData.FORCE_LOW);

			HW.Dss.PmuConnectMode(PM.DIG_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.OUTPUT);

			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);

			App.Test[IDs.SdoLeakageDvcc].Result = leakageArrayDvcc[0];
			App.Test[IDs.ClrselLeakageDvcc].Result = leakageArrayDvcc[1];
			App.Test[IDs.ClearLeakageDvcc].Result = leakageArrayDvcc[2];
			App.Test[IDs.SyncLeakageDvcc].Result = leakageArrayDvcc[3];
			App.Test[IDs.SclkLeakageDvcc].Result = leakageArrayDvcc[4];
			App.Test[IDs.SdinLeakageDvcc].Result = leakageArrayDvcc[5];
			App.Test[IDs.Ad2LeakageDvcc].Result = leakageArrayDvcc[6];
			App.Test[IDs.Ad1LeakageDvcc].Result = leakageArrayDvcc[7];
			App.Test[IDs.Ad0LeakageDvcc].Result = leakageArrayDvcc[8];
			App.Test[IDs.HwselLeakageDvcc].Result = leakageArrayDvcc[9];
			App.Test[IDs.ResetLeakageDvcc].Result = leakageArrayDvcc[10];
			App.Test[IDs.FaultLeakageDvcc].Result = leakageArrayDvcc[11];
			App.Test[IDs.IfaultLeakageDvcc].Result = leakageArrayDvcc[12];

			App.Test[IDs.SdoLeakage0V].Result = leakageArrayZero[0];
			App.Test[IDs.ClrselLeakage0V].Result = leakageArrayZero[1];
			App.Test[IDs.ClearLeakage0V].Result = leakageArrayZero[2];
			App.Test[IDs.SyncLeakage0V].Result = leakageArrayZero[3];
			App.Test[IDs.SclkLeakage0V].Result = leakageArrayZero[4];
			App.Test[IDs.SdinLeakage0V].Result = leakageArrayZero[5];
			App.Test[IDs.Ad2Leakage0V].Result = leakageArrayZero[6];
			App.Test[IDs.Ad1Leakage0V].Result = leakageArrayZero[7];
			App.Test[IDs.Ad0Leakage0V].Result = leakageArrayZero[8];
			App.Test[IDs.HwselLeakage0V].Result = leakageArrayZero[9];
			App.Test[IDs.ResetLeakage0V].Result = leakageArrayZero[10];
			App.Test[IDs.FaultLeakage0V].Result = leakageArrayZero[11];
			App.Test[IDs.IfaultLeakage0V].Result = leakageArrayZero[12];
		}
		#endregion
	}// end of class Leakage
	#endregion

	//
	// Parallel Leakage Test Function
	//
	#region ParallelLeakage                         :
	/// <summary>
	/// Test to measure leakage on digital pins
	/// </summary>
	public class ParallelLeakage : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region ParallelLeakage                         :
		public ParallelLeakage()
		{
		}
		#endregion

		//
		//Force DVcc & 0V on each of the digital pins sequentially
		//and measure the corresponding current in each pin.
		//
		#region Run                             :
		public override void Run()
		{
			int i;
			int numHwLkgPins = 3;			
			//Only checking 2 of the h/w fault pnis as the rest are tested in S/W mode
			MsDoubleList oddPinslkg0V,
				evenPinslkg0V,
				oddPinslkgDvcc,
				evenPinslkgDvcc;
			double zeroVolts = 0.0;
			MsDouble maxLkg, minLkg, meanLkg;
			MsDouble leakageCurrent = 0.0;
			double pullupVoltage = 0;

			MsDouble [] leakageArrayZero = MsDouble.CreateArray(numHwLkgPins, 0);
			MsDouble [] leakageArrayDvcc = MsDouble.CreateArray(numHwLkgPins, 0);

			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			#region Powerup And Init

			if(!App.Globals.MultisiteTest)
			{
				
					//Power up the DUT & Setup in software mode with default address
					Utl.PowerUpDevice();
					Utl.SetDeviceMode(App.OpMode.SOFTWARE);
					Utl.SetAddressPins(App.TC.DutAddress);

					//Connect outputs to relevant loads/feedback pins
					//VsenseN/Vsensep connection
					HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
					HW.Rdc.Set(PM.D15, OpenClose.CLOSE);

					HW.Rdc.Set(PM.D9, OpenClose.CLOSE);
					HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.CLOSE);
					//Default to 300ohm load
					HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
					App.Time.MsDelay(App.TC.RelaySettle);
					
			}

			#endregion

			//Can't drive digital levels to 2V for HV part because 10k resistor is in series with DVcc
			//With levels at 2V, DIcc is up to 2mA - 2mA * 10k = 20V! 

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Set up each pin to FVMI with 0V and measure corresponding current
				HW.Dss.PmuConnectMode(PM.DIG_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.PmuConnectMode(PM.DIG_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuModeValue(PM.DIG_PINS, Dss.PmuMode.FVMI_20_UA, 2.0);

				HW.Dss.PmuConnectMode(PM.NO_CONNECTS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.PmuConnectMode(PM.NO_CONNECTS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.NO_CONNECTS, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuModeValue(PM.NO_CONNECTS, Dss.PmuMode.FVMI_20_UA, 2.0);
			}

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Leakage");

			//Check leakage to 0V on all odd pins and leakage to DVcc on even pins
			HW.Dss.PmuModeValue(PM.ODD_LKG_PINS, Dss.PmuMode.FVMI_20_UA, zeroVolts);
			HW.Dss.PmuModeValue(PM.EVEN_LKG_PINS, Dss.PmuMode.FVMI_20_UA, App.TC.DVcc);
			App.Time.MsDelay(App.TC.PmuMultiDelay);
			oddPinslkg0V = HW.Dss.PmuReadMulti(PM.ODD_LKG_PINS, App.Globals.NumPmuAverages, out maxLkg, out minLkg, out meanLkg);
			evenPinslkgDvcc = HW.Dss.PmuReadMulti(PM.EVEN_LKG_PINS, App.Globals.NumPmuAverages, out maxLkg, out minLkg, out meanLkg);

			//Check leakage to 0V on all even pins and leakage to DVcc on odd pins
			HW.Dss.PmuModeValue(PM.ODD_LKG_PINS, Dss.PmuMode.FVMI_20_UA, App.TC.DVcc);
			HW.Dss.PmuModeValue(PM.EVEN_LKG_PINS, Dss.PmuMode.FVMI_20_UA, zeroVolts);
			App.Time.MsDelay(App.TC.PmuMultiDelay);
			evenPinslkg0V = HW.Dss.PmuReadMulti(PM.EVEN_LKG_PINS, App.Globals.NumPmuAverages, out maxLkg, out minLkg, out meanLkg);
			oddPinslkgDvcc = HW.Dss.PmuReadMulti(PM.ODD_LKG_PINS, App.Globals.NumPmuAverages, out maxLkg, out minLkg, out meanLkg);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				HW.Dss.PmuModeValue(PM.EVEN_LKG_PINS, Dss.PmuMode.FVMI_20_UA, 2.0);
				HW.Dss.PmuModeValue(PM.ODD_LKG_PINS, Dss.PmuMode.FVMI_20_UA, 2.0);
			}

			//Need to enable hardware mode to measure tristate current on opendrain NC/IFault & Fault/Temp pins
			HW.Dss.PmuConnectMode(PM.HW_SELECT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.HW_SELECT, Dss.ConnectionMode.OUTPUT);
			HW.Dss.DriverInputSelect(PM.HW_SELECT, Dss.DriveData.FORCE_HIGH);

			HW.Dss.PmuConnectMode(PM.HW_FAULT_PINS, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.HW_FAULT_PINS, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.HW_FAULT_PINS, Dss.PmuMode.FVMI_20_UA, zeroVolts);

			//Ensure that VsenseN & VsenseP are set up correctly to close feedback loop
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//No need to check SDO/Vfault pin again (1st pin in pinlist)
			for(i = 1; i < numHwLkgPins; i++)
			{
				if(PM.HW_FAULT_PINS[i] == PM.NC_IFAULT)
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i], Dss.PmuMode.FVMI_200_UA, zeroVolts);
				else
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i], Dss.PmuMode.FVMI_20_UA, zeroVolts);

				leakageCurrent = HW.Dss.PmuRead(PM.HW_FAULT_PINS[i], App.Globals.NumPmuAverages);

				#region Offline Setup
				if(App.Globals.OfflineDev)
				{
					leakageCurrent = 0.5e-6;
				}
				#endregion

				leakageArrayZero[i] = leakageCurrent;
				HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i], Dss.PmuMode.FVMI_20_UA, zeroVolts);

			}

			for(i = 1; i < numHwLkgPins; i++)
			{
				if(PM.HW_FAULT_PINS[i] == PM.NC_IFAULT)
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i], Dss.PmuMode.FVMI_200_UA, App.TC.DVcc);
				else
					HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i], Dss.PmuMode.FVMI_20_UA, App.TC.DVcc);
				leakageCurrent = HW.Dss.PmuRead(PM.HW_FAULT_PINS[i], App.Globals.NumPmuAverages);

				#region Offline Setup
				if(App.Globals.OfflineDev)
				{
					leakageCurrent = 0.7e-6;
				}
				#endregion

				leakageArrayDvcc[i] = leakageCurrent;
				HW.Dss.PmuModeValue(PM.HW_FAULT_PINS[i], Dss.PmuMode.FVMI_20_UA, zeroVolts);
			}


			//Cleanup
			HW.Dss.DriverInputSelect(PM.HW_SELECT, Dss.DriveData.FORCE_LOW);

			HW.Dss.PmuConnectMode(PM.DIG_PINS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.OUTPUT);

			HW.Dss.PmuConnectMode(PM.NO_CONNECTS, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.NO_CONNECTS, Dss.ConnectionMode.OUTPUT);

			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);

			App.Test[IDs.SdoLeakageDvcc].Result = oddPinslkgDvcc[PM.SDO_VFAULT];
			App.Test[IDs.ClrselLeakageDvcc].Result = evenPinslkgDvcc[PM.CLRSEL];
			App.Test[IDs.ClearLeakageDvcc].Result = oddPinslkgDvcc[PM.CLEAR];
			App.Test[IDs.SyncLeakageDvcc].Result = oddPinslkgDvcc[PM.SYNC_RSEL];
			App.Test[IDs.SclkLeakageDvcc].Result = evenPinslkgDvcc[PM.SCLK_OUTEN];
			App.Test[IDs.SdinLeakageDvcc].Result = oddPinslkgDvcc[PM.SDIN_R0];
			App.Test[IDs.Ad2LeakageDvcc].Result = evenPinslkgDvcc[PM.AD2_R1];
			App.Test[IDs.Ad1LeakageDvcc].Result = oddPinslkgDvcc[PM.AD1_R2];
			App.Test[IDs.Ad0LeakageDvcc].Result = evenPinslkgDvcc[PM.AD0_R3];
			App.Test[IDs.HwselLeakageDvcc].Result = oddPinslkgDvcc[PM.HW_SELECT];
			App.Test[IDs.ResetLeakageDvcc].Result = evenPinslkgDvcc[PM.RESET];
			App.Test[IDs.FaultLeakageDvcc].Result = leakageArrayDvcc[1];
			App.Test[IDs.IfaultLeakageDvcc].Result = leakageArrayDvcc[2];

			App.Test[IDs.SdoLeakage0V].Result = oddPinslkg0V[PM.SDO_VFAULT];
			App.Test[IDs.ClrselLeakage0V].Result = evenPinslkg0V[PM.CLRSEL];
			App.Test[IDs.ClearLeakage0V].Result = oddPinslkg0V[PM.CLEAR];
			App.Test[IDs.SyncLeakage0V].Result = oddPinslkg0V[PM.SYNC_RSEL];
			App.Test[IDs.SclkLeakage0V].Result = evenPinslkg0V[PM.SCLK_OUTEN];
			App.Test[IDs.SdinLeakage0V].Result = oddPinslkg0V[PM.SDIN_R0];
			App.Test[IDs.Ad2Leakage0V].Result = evenPinslkg0V[PM.AD2_R1];
			App.Test[IDs.Ad1Leakage0V].Result = oddPinslkg0V[PM.AD1_R2];
			App.Test[IDs.Ad0Leakage0V].Result = evenPinslkg0V[PM.AD0_R3];
			App.Test[IDs.HwselLeakage0V].Result = oddPinslkg0V[PM.HW_SELECT];
			App.Test[IDs.ResetLeakage0V].Result = evenPinslkg0V[PM.RESET];
			App.Test[IDs.FaultLeakage0V].Result = leakageArrayZero[1];
			App.Test[IDs.IfaultLeakage0V].Result = leakageArrayZero[2];
		}
		#endregion
	}// end of class ParallelLeakage
	#endregion

	//
	// VinVrefTests Test Function
	//
	#region VinVrefTests                       :
	/// <summary>
	/// VinVrefTests Tests - checks Vref & Vin I/P leakage currents
	/// </summary>
	public class VinVrefTests : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region VinVrefTests                       :
		public VinVrefTests()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble refCurrent = 0.0,
				vinCurrent = 0.0;
			double zeroVolts = 0.0;
			double [] refArray = new double[1000];

			//Switch in pincard to measure leakage in Vref/Vin pins
			HW.Rdc.Set(PM.D6, OpenClose.CLOSE);
			//Set up pin to FVMI with 0V and measure corresponding current
			HW.Dss.PmuConnectMode(PM.DC_SOURCES, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.PmuConnectMode(PM.DC_SOURCES, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.DC_SOURCES, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuModeValue(PM.DC_SOURCES, Dss.PmuMode.FVMI_20_UA, zeroVolts);
			App.Time.MsDelay(App.TC.RelaySettle);

			App.Time.MsDelay(App.TC.VrefLkgSettle);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Vin/Vref Leakage");

			vinCurrent = HW.Dss.PmuRead(PM.VIN, App.Globals.NumPmuAverages);
			refCurrent = HW.Dss.PmuRead(PM.VREF, App.Globals.NumPmuAverages);

			if(App.Globals.OfflineDev)
			{
				refCurrent = 0.4e-6;
				vinCurrent = 0.55e-6;
			}
			App.Test[IDs.VrefCurrent].Result = refCurrent;
			App.Test[IDs.VinCurrent].Result = vinCurrent;


			HW.Dss.PmuModeValue(PM.DC_SOURCES, Dss.PmuMode.FVMI_20_UA, App.TC.DVcc/2);
			HW.Dss.PmuModeValue(PM.DC_SOURCES, Dss.PmuMode.FVMI_20_UA, App.TC.DVcc);
			App.Time.MsDelay(App.TC.RelaySettle);
			App.Time.MsDelay(App.TC.VrefLkgSettle);

			vinCurrent = HW.Dss.PmuRead(PM.VIN, App.Globals.NumPmuAverages);
			refCurrent = HW.Dss.PmuRead(PM.VREF, App.Globals.NumPmuAverages);

			if(App.Globals.OfflineDev)
			{
				refCurrent = 0.4e-6;
				vinCurrent = 0.55e-6;
			}
			App.Test[IDs.VrefCurrentHi].Result = refCurrent;
			App.Test[IDs.VinCurrentHi].Result = vinCurrent;

			//CLEANUP
			HW.Dss.PmuModeValue(PM.DC_SOURCES, Dss.PmuMode.FVMI_20_UA, App.TC.DVcc/2);
			HW.Dss.PmuModeValue(PM.DC_SOURCES, Dss.PmuMode.FVMI_20_UA, zeroVolts);
			HW.Dss.PmuConnectMode(PM.DC_SOURCES,Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.DC_SOURCES, Dss.ConnectionMode.DISCONNECT);
			HW.Rdc.Set(PM.D6, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.RelaySettle);
		}
		#endregion
	}// end of class VinVrefTests
	#endregion

	//
	// OutputsTristateLkg Test Function
	//
	#region OutputsTristateLkg              :
	/// <summary>
	/// Checks the "tristate leakage" of Iout and Vout when outputs are disabled and 
	/// tied to 0V via external load.
	/// </summary>
	public class OutputsTristateLkg : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region OutputsTristateLkg              :
		public OutputsTristateLkg()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			App.RangeOptions range;
			MsDouble load, vout, voutLkgCurrent = 0.0, 
				ioutLkgCurrent = 0.0, 
				vsensenLkg = 0.0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			if(App.TC.AVdd < 40.0)
			{
				//Select voltage range and disable the output
				range = App.RangeOptions.FIVE_V;

				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO,
					App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				HW.Rdc.Set(PM.D15, OpenClose.OPEN);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("O/Ps Tristate Lkg");

				//Check leakage on Vout pin
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_20_UA, 0.0);
				App.Time.MsDelay(App.TC.RelaySettle);

				voutLkgCurrent = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);

				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			}

			//Select current range and disable the output
			range = App.RangeOptions.FOUR_TWENTY_MA;

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			//300ohm load resistor switched out already
			load = App.TC.BoardVars.IoutLowRes;
			App.Time.MsDelay(App.TC.RelaySettle);

			vout = Utl.IoutMeas(resourceSelect);
			ioutLkgCurrent = vout/load;

			if(App.TC.AVdd < 40.0)
			{
				//Check leakage on VsenseN pin
				HW.Dss.PmuConnectMode(PM.VSENSEN, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.PmuConnectMode(PM.VSENSEN, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VSENSEN, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuModeValue(PM.VSENSEN, Dss.PmuMode.FVMI_20_UA, 0.0);
				App.Time.MsDelay(App.TC.VsenseNSettle);

				vsensenLkg = HW.Dss.PmuRead(PM.VSENSEN, App.Globals.NumPmuAverages);

				HW.Dss.PmuConnectMode(PM.VSENSEN, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VSENSEN, Dss.ConnectionMode.DISCONNECT);
			}

			App.Test[IDs.IoutTristateLkg].Result = ioutLkgCurrent;
			if(App.TC.AVdd < 40.0)
			{
				App.Test[IDs.vsensenLkg].Result = vsensenLkg;
				App.Test[IDs.VoutTristateLkg].Result = voutLkgCurrent;
			}

			//Cleanup
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
			Utl.RunPattern(DP.hw_reset);
		}
		#endregion
	}// end of class OutputsTristateLkg
	#endregion

	//
	// OutputsTristateLkg2 Test Function
	//
	#region OutputsTristateLkg2              :
	/// <summary>
	/// Checks the "tristate leakage" of Iout and Vout when outputs are disabled and 
	/// tied to 0V via external load.
	/// </summary>
	public class OutputsTristateLkg2 : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region OutputsTristateLkg2              :
		public OutputsTristateLkg2()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			App.RangeOptions range;

			MsDouble lkgAvdd = 36.0;
			MsDouble lkgAvss = -4.0;

			MsDouble load, vout, voutLkgCurrentA = 0.0, voutLkgCurrentB = 0.0, 
				ioutLkgCurrent = 0.0, 
				vsensenLkg = 0.0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;
			//MsDouble voutLoad = 1e3, voutV = 0.0;
			MsDouble posAvddClamp = App.TC.AVdd + 0.2*App.TC.AVdd;

			//Set Supplies to 44V (holding voltage of breadown diodes to AVdd is 45V - don't want to exceed this) and 0V

			
			Utl.ModifySupplies(lkgAvdd, lkgAvss, App.TC.DVcc);

			Utl.RunPattern(DP.hw_reset);

			//Select voltage range and DISABLE the output
			range = App.RangeOptions.FIVE_V;

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO,
				App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			HW.Rdc.Set(PM.D15, OpenClose.OPEN);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("O/Ps Tristate Lkg");

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				//Check leakage on Vout pin
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_20_UA, 0.0);
				App.Time.MsDelay(App.TC.RelaySettle);

				voutLkgCurrentA = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);

				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			}
			else
			{
				//Check leakage on Vout pin
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_20_UA, -4.0);
				App.Time.MsDelay(App.TC.RelaySettle);

				voutLkgCurrentA = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);

				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			}

			#region ResistorMethod
			//Method B
			//HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			//Measure voltage on Vout with resistor to GND
			//HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
			//HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.OPEN);

			//voutV = Utl.MeasureNode(App.MuxNodes.VOUT_MEAS, App.MeasOptions.DMM);
			//voutLkgCurrentB = voutV / voutLoad; 

			//Cleanup
			//HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			//HW.Rdc.Set(PM.D15, OpenClose.OPEN);
			//HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.CLOSE);
			#endregion
		
			#region Iout Leakage

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				//Reset Supplies
				Utl.PowerDownDeviceForVoutLkg();
				Utl.PowerUpDevice();
				Utl.SetDeviceMode(App.OpMode.SOFTWARE);
				Utl.SetAddressPins(App.TC.DutAddress);

			
				//Select current range and disable the output
				range = App.RangeOptions.FOUR_TWENTY_MA;

				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				//300ohm load resistor switched out already
				load = App.TC.BoardVars.IoutLowRes;
				App.Time.MsDelay(App.TC.RelaySettle);

				vout = Utl.IoutMeas(resourceSelect);
				ioutLkgCurrent = vout/load;

				if(App.TC.AVdd < 40.0)
				{
					//Check leakage on VsenseN pin
					HW.Dss.PmuConnectMode(PM.VSENSEN, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
					HW.Dss.PmuConnectMode(PM.VSENSEN, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_20_UA);
					HW.Dss.ConnectionSet(PM.VSENSEN, Dss.ConnectionMode.PMU_TO_PIN);
					HW.Dss.PmuModeValue(PM.VSENSEN, Dss.PmuMode.FVMI_20_UA, 0.0);
					App.Time.MsDelay(App.TC.VsenseNSettle);

					vsensenLkg = HW.Dss.PmuRead(PM.VSENSEN, App.Globals.NumPmuAverages);

					HW.Dss.PmuConnectMode(PM.VSENSEN, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
					HW.Dss.ConnectionSet(PM.VSENSEN, Dss.ConnectionMode.DISCONNECT);
				}

				App.Test[IDs.IoutTristateLkg].Result = ioutLkgCurrent;
				if(App.TC.AVdd < 40.0)
				{
					App.Test[IDs.vsensenLkg].Result = vsensenLkg;
					App.Test[IDs.VoutTristateLkg].Result = voutLkgCurrentA;
				}

				
			}
			#endregion

			// set supplies back to +/-24V
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);

			App.Test[IDs.VoutTristateLkg].Result = voutLkgCurrentA;

			//Cleanup
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
			Utl.RunPattern(DP.hw_reset);

		}
		#endregion
	}// end of class OutputsTristateLkg2
	#endregion

	#endregion

	//
	// Digital Tests checking Clear, Address, Reset, PEC functionality
	//
	#region DigitalTests
	//
	// AddrFunc Test Function
	//
	#region AddrFunc               :
	/// <summary>
	/// Function checks that DUT only responds to 
	/// correct address (for all 8 combinations of address)
	/// </summary>
	public class AddrFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region AddrFunc               :
		public AddrFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			int address = 0, 
				addr, 
				numAddresses = 8, 
				currentAddress = 0;
			App.RangeOptions range = App.RangeOptions.FIVE_V;
			MsInt passFail = 0;
			MsInt readWord = 0, 
				rangeData = 0;

			for(address = 0; address < numAddresses; address++)
			{
				currentAddress = address;
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Current Address: {0}", currentAddress);

				//set address pins to correct device id
				Utl.SetAddressPins(currentAddress);

				//Check that writes with Address bits not set to correct values are not carried out.

				for(addr=0; addr<numAddresses; addr++)
				{
					if(addr != currentAddress)
					{
						//Write to device
						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Writing to address: {0}", addr);
						Utl.ShortWrite(addr, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
							App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

						//Readback range data to check that it's not set to selected range
						//TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking range is set to 0....");
						readWord = Utl.ReadAddr(addr);

						if(App.Globals.OfflineDev)
						{
							readWord = 4095;
						}

						foreach(Site site in TP.MS.ActiveSites)
						{
							rangeData[site] = (readWord[site] >> 7) & 0xF;
							if(rangeData[site] == App.TC.RangeData[(int)range].ProgBits)
							{
								passFail[site]++;
								TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "READBACK failing");
							}
						}
					}
				}

				//Now check with correct address

				//Write to device
				addr = currentAddress;
				Utl.SetAddressPins(addr);
				//TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Writing to address: {0}", addr);

				Utl.ShortWrite(addr, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
					App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Address Functionality");

				//Readback range data to check if it's set to the selected range
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking range is set to 5V...");
				readWord = Utl.ReadAddr(addr);
				if(App.Globals.OfflineDev)
				{
					readWord = 688;
				}

				foreach(Site site in TP.MS.ActiveSites)
				{
					rangeData[site] = (readWord[site] >> 7) & 0xF;
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Readback word: {0}", readWord[site]);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range readback: {0}", rangeData[site]);

					if(rangeData[site] != App.TC.RangeData[(int)range].ProgBits)
					{
						passFail[site]++;
						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "READBACK failing");
					}
				}
	
				//clear outputs to zero
				Utl.ShortWrite(addr, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
					App.ClearEn.CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
				App.Time.UsDelay(10);
			}

			//Cleanup
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			Utl.SetAddressPins(App.TC.DutAddress);
			Utl.RunPattern(DP.hw_reset);
			HW.Dcs.VOut(PM.VIN, 0.0);
			HW.Rdc.Set(PM.D17, OpenClose.OPEN);

			App.Test[IDs.AddrFunc].Result = passFail;
		}
		#endregion
	}// end of class AddrFunc
	#endregion

	//
	// AddrFunc Test Function
	//
	#region AddrPatFunc               :
	/// <summary>
	/// Pattern checks that DUT only responds to 
	/// correct address (for all 8 combinations of address)
	/// </summary>
	public class AddrPatFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region AddrPatFunc               :
		public AddrPatFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsBool passFail;
			MsInt addrFunc = 0;

			//Before running pattern to check all address options, must set address pins to be controlled by pattern
			HW.Dss.DriverInputSelect(PM.ADDR_PINS, Dss.DriveData.DRIVE_PATTERN);

			Utl.RunPattern(DP.hw_reset);
			Utl.SetInterfaceTiming(1.0e6);

			//Run Address Functionality Pattern
			Utl.RunPattern(DP.addrFuncPat);
			passFail = HW.Dss.PatStatus(PM.SDO_VFAULT, Dss.Status.PASS);

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
					addrFunc[site]++;
			}

			//Cleanup
			Utl.SetAddressPins(App.TC.DutAddress);
			Utl.RunPattern(DP.hw_reset);
			Utl.SetInterfaceTiming(App.TC.Frequency);

			App.Test[IDs.AddrFunc].Result = addrFunc;
		}
		#endregion
	}// end of class AddrPatFunc
	#endregion

	//
	// ClrFunc Test Function
	//
	#region ClrFunc                :
	/// <summary>
	/// Check CLEAR functionality in HARDWARE/SOFTWARE modes
	/// </summary>
	public class ClrFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region ClrFunc                :
		public ClrFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt passFail = 0;
			int addr = App.TC.DutAddress;
			int range = App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits;
			double vinVoltage = App.TC.MaxInputVoltage;
			double minVolt = App.TC.RangeData[(int)App.RangeOptions.FIVE_V].MinValue;
			double maxVolt = App.TC.RangeData[(int)App.RangeOptions.FIVE_V].MaxValue;
			double midVolt = App.TC.RangeData[(int)App.RangeOptions.FIVE_V].MidValue;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			//Set Vin to max value for this test
			HW.Dcs.VOut(PM.VIN, vinVoltage);

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Operating Range: 0 to 10V range");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Current Address: {0}", addr);
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "");
 
			//**************Check output enabled/disabled modes*************
			//Expecting output to be disabled -> i.e. floating. 
			//Close Rlyx17 to switch Vout to ground via load resistor.
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			//Write to device with output disabled and verify output stays at 0V
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with Output disabled...");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_DISABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET); 
	  
			//Measure vout voltage
			passFail += Utl.TestVout(minVolt, resourceSelect);

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			//Write to device with output enabled and verify output goes to FS 
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with output enabled...");
			Utl.ShortWrite(addr,range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);

			//Measure vout voltage
			passFail += Utl.TestVout(maxVolt, resourceSelect);

			//*********Check Clear modes***********

			//Clear output using CLEAR bit, CLRSEL pin = 0, CLRSEL bit = 0
			//=> expect clear to zero
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR bit: CLRSEL pin = 0, CLRSEL bit = 0");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to zero");

			Utl.HwClearMode(App.ClearMode.CLR_TO_ZERO);
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Clear Functionality");

			//Measure vout voltage
			passFail += Utl.TestVout(minVolt, resourceSelect);

			//Enable output and bring part out of clear mode and verify output goes to FS 
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with output enabled...");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);

			//Measure vout voltage & verify fullscale
			passFail += Utl.TestVout(maxVolt, resourceSelect);

			//Clear output using CLEAR bit, CLRSEL pin = 0, CLRSEL bit = 1
			//=> expect clear to midscale
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR bit: CLRSEL pin = 0, CLRSEL bit = 1");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to midscale");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_ENABLE, 
				App.ClearEn.CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);

			//Measure vout voltage & verify clear
			passFail += Utl.TestVout(midVolt, resourceSelect);

			//Write to device with output enabled and verify output goes to FS 
			//Enable output and bring part out of clear mode and verify output goes to FS 
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with output enabled...");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);

			//Measure vout voltage & verify fullscale
			passFail += Utl.TestVout(maxVolt, resourceSelect);
	  
			//Clear output using CLEAR bit, CLRSEL pin = 1, CLRSEL bit = 0
			//=> expect clear to mid
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR bit: CLRSEL pin = 1, CLRSEL bit = 0");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to midscale");

			Utl.HwClearMode(App.ClearMode.CLR_TO_MID);
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);
 
			//Measure vout voltage
			passFail += Utl.TestVout(midVolt, resourceSelect);

			//Write to device with output enabled and verify output goes to FS 
			//Enable output and bring part out of clear mode and verify output goes to FS 
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with output enabled...");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);

			//Measure vout voltage & verify fullscale
			passFail += Utl.TestVout(maxVolt, resourceSelect);


			//Clear output using CLEAR bit, CLRSEL pin = 1, CLRSEL bit = 1
			//=> expect clear to midscale
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR bit: CLRSEL pin = 1, CLRSEL bit = 1");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to midscale");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_ENABLE, 
				App.ClearEn.CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);	  

			//Measure vout voltage & verify clear
			passFail += Utl.TestVout(midVolt, resourceSelect);

			//Write to device with output enabled and verify output goes to FS 
			//Enable output and bring part out of clear mode and verify output goes to FS 
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with output enabled...");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);

			//Measure vout voltage & verify fullscale
			passFail += Utl.TestVout(maxVolt, resourceSelect);

			//Clear output using CLEAR pin, CLRSEL pin = 0, CLRSEL bit = 0
			//=> expect clear to zero
			Utl.HwClearMode(App.ClearMode.CLR_TO_ZERO);
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR pin: CLRSEL pin = 0, CLRSEL bit = 0");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to zero");

			Utl.HwClearEn(App.ClearEn.CLEAR);
			App.Time.UsDelay(100);

			//Measure vout voltage & verify clear - output only stays clear while CLEAR pin is high.
			passFail += Utl.TestVout(minVolt, resourceSelect);

			Utl.HwClearEn(App.ClearEn.NO_CLEAR);
			App.Time.UsDelay(100);

			//Measure vout voltage & verify fullscale
			passFail += Utl.TestVout(maxVolt, resourceSelect);

			//Clear output using CLEAR pin, CLRSEL pin = 0, CLRSEL bit =1
			//=> expect clear to midcale

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR pin: CLRSEL pin = 0, CLRSEL bit = 1");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to midscale");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
	
			Utl.HwClearEn(App.ClearEn.CLEAR);
			App.Time.UsDelay(100);		
  
			//Measure vout voltage & verify clear - output only stays clear while CLEAR pin is high.
			passFail += Utl.TestVout(midVolt, resourceSelect);
			Utl.HwClearEn(App.ClearEn.NO_CLEAR);
			App.Time.UsDelay(100);	


			//Clear output using CLEAR pin, CLRSEL pin = 1, CLRSEL bit = 1
			//=> expect clear to midcale
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR pin: CLRSEL pin = 1, CLRSEL bit = 1");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to midscale");
			Utl.HwClearMode(App.ClearMode.CLR_TO_MID);
			Utl.HwClearEn(App.ClearEn.CLEAR);
			App.Time.UsDelay(100);	

  
			//Measure vout voltage & verify clear - output only stays clear while CLEAR pin is high.
			passFail += Utl.TestVout(midVolt, resourceSelect);

			Utl.HwClearEn(App.ClearEn.NO_CLEAR);
			App.Time.UsDelay(100);	


			//Clear output using CLEAR pin, CLRSEL pin = 1, CLRSEL bit = 0
			//=> expect clear to midcale
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Clear using CLEAR pin: CLRSEL pin = 1, CLRSEL bit = 0");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "=>Expect clear to midscale");

			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			Utl.HwClearEn(App.ClearEn.CLEAR);

			//Measure vout voltage & verify clear - output only stays clear while CLEAR pin is high.
			passFail += Utl.TestVout(midVolt, resourceSelect);

			Utl.HwClearEn(App.ClearEn.NO_CLEAR);
			Utl.HwClearMode(App.ClearMode.CLR_TO_ZERO);
			App.Time.UsDelay(100);	

			App.Test[IDs.ClrFunc].Result = passFail;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);
			//Set Vin to back to 0V
			HW.Dcs.VOut(PM.VIN, 0.0);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class ClrFunc
	#endregion

	//
	// ResetFunc Test Function
	//
	#region ResetFunc              :
	/// <summary>
	/// Checks RESET in HARDWARE/SOFTWARE modes
	/// </summary>
	public class ResetFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region ResetFunc              :
		public ResetFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt passFail = 0;
			int addr = App.TC.DutAddress;
			int range = App.TC.RangeData[(int)App.RangeOptions.TEN_V].ProgBits;
			double vinVoltage = App.TC.MaxInputVoltage;
			double minVolt = App.TC.RangeData[(int)App.RangeOptions.TEN_V].MinValue;
			double maxVolt = App.TC.RangeData[(int)App.RangeOptions.TEN_V].MaxValue;
			double midVolt = App.TC.RangeData[(int)App.RangeOptions.TEN_V].MidValue;
			double zeroVolts = 0.0;
			MsInt readWord = 0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			//Set Vin to max value for this test
			HW.Dcs.VOut(PM.VIN, vinVoltage);

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Operating Range: 0 to 10V range");
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Current Address: {0}", addr);
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "");

			//**************SOFTWARE RESET****************************
			//Write to device with output enabled and verify output goes to FS 
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with output enabled...");
			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100);
	  
			//Measure vout voltage
			passFail += Utl.TestVout(maxVolt, resourceSelect);

			//Reset the device using RESET bit and verify reset
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Reset Device using RESET bit...");

			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.RESET);
			App.Time.UsDelay(100);


			//Expecting output to be disabled -> i.e. floating. 
			//Close Rlyx17 to switch Vout to ground via load resistor.
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Reset Functionality");

			//Measure vout voltage
			passFail += Utl.TestVout(zeroVolts, resourceSelect);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			//Readback register contents and verify POR conditions
			readWord = Utl.ReadAddr(addr);

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Readback Word: {0}", readWord);
			if(App.Globals.OfflineDev)
			{
				readWord = 0;
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(readWord[site] != 0)
				{
					passFail[site]++;
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "READBACK on RESET failing");
				}
			}

			//**************HARDWARE RESET****************************
			//Write to device with output enabled and verify output goes to FS 
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Write with output enabled...");

			Utl.ShortWrite(addr, range, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
				App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.UsDelay(100); 
	  
			//Measure vout voltage
			passFail += Utl.TestVout(maxVolt, resourceSelect);

			//Reset the device using RESET pin and verify reset
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Reset Device using RESET pin...");

			Utl.RunPattern(DP.hw_reset);
			App.Time.UsDelay(100); 

			//Measure vout voltage
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			passFail += Utl.TestVout(zeroVolts, resourceSelect);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			//Readback register contents and verify POR conditions
			readWord = Utl.ReadAddr(addr);

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Readback Word: {0}", readWord);
			if(App.Globals.OfflineDev)
			{
				readWord = 0;
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(readWord[site] != 0)
				{
					passFail[site]++;
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "READBACK on RESET failing");
				}
			}

			App.Test[IDs.ResetFunc].Result = passFail;

			//Cleanup 
			HW.Dcs.VOut(PM.VIN, 0.0);
		}
		#endregion
	}// end of class ResetFunc
	#endregion

	//
	// PecFunctionality Test Function
	//
	#region PecFunctionality                :
	/// <summary>
	/// To verify PEC addressing, this function checks all range modes while utilising PEC code.
	/// </summary>
	public class PecFunctionality : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region PecFunctionality                :
		public PecFunctionality()
		{

		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt passFail = 0;
			int rangeIndex;
			App.RangeOptions range;
			App.ResSel rSel;
			double vin1Q, vin3Q, out1Q, out3Q;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			vin1Q = App.TC.MaxInputVoltage/4.0;
			vin3Q = 3 * vin1Q;
			
			//********Check all ranges in software mode and ensure that zs and fs are correct********

			//Set Vin to 3/4 scale value
			HW.Dcs.VOut(PM.VIN, vin3Q);
			App.Time.UsDelay(100);
			//Switch in external resistor
			HW.Rdc.Set(PM.D4, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX05_RELAYS, OpenClose.OPEN);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("PEC Functionality");

			for(rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				//If external resistor is selected, close D4 to switch in resistor
				if(rSel == App.ResSel.R_EXT)
					HW.Rdc.Set(PM.D4, OpenClose.CLOSE);
				else if(rSel == App.ResSel.R_INT)
					HW.Rdc.Set(PM.D4, OpenClose.OPEN);

				//Check all applicable ranges for specific generic
				for(rangeIndex = 0; rangeIndex < App.TC.NumActiveRanges; rangeIndex++)
				{
					range = App.TC.ActiveRanges[rangeIndex];

					if(((range == App.RangeOptions.FORTY_V) || (range == App.RangeOptions.FORTY_FOUR_V)) && (App.TC.AVdd < 44.0))
					{
					}
					else 
					{
						if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
						{
							HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
						}
						else
						{
							HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
						}

						App.Time.MsDelay(App.TC.RelaySettle);

						out1Q = App.TC.RangeData[(int)range].MinValue + ( (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue) / 4.0 );
						out3Q = App.TC.RangeData[(int)range].MinValue + ( 3.0 * ((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue) / 4.0) );

						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Use SPI to set up {0} range", App.TC.RangeData[(int)range].RangeName);
						Utl.write24Bits(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
							App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);
						App.Time.UsDelay(100);


						if( ((range == App.RangeOptions.TWO_P_FIVE_V_BIP) && rSel == (App.ResSel.R_INT)) ||
							((range == App.RangeOptions.FORTY_V) && rSel == (App.ResSel.R_INT)) ||
							((range == App.RangeOptions.FORTY_FOUR_V) && rSel == (App.ResSel.R_INT)) ||
							((range == App.RangeOptions.THREE_TWENTY_MA) && rSel == (App.ResSel.R_EXT)) ||
							((range == App.RangeOptions.TWENTY_P_FOUR_MA) && rSel == (App.ResSel.R_EXT)) ||
							((range == App.RangeOptions.TWENTY_FOUR_P_FIVE_MA) && rSel == (App.ResSel.R_EXT)) )
						{
							//Expecting output to be disabled -> i.e. floating. 
							//Close Rlyx17 to switch Vout to ground via load resistor.
							if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
							{
								HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
								App.Time.MsDelay(App.TC.RelaySettle);
							}
							else
							{
								HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
								App.Time.MsDelay(App.TC.RelaySettle);
							}

							out3Q = 0.0;
							out1Q = 0.0;
						}
						//Measure output for correct value
						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking for output of: {0}...", out3Q);
						passFail += Utl.TestOutput(range, out3Q, resourceSelect);

						//Change VIN voltage to 1/4FS and check that corresponding output is correct
						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Setting Vin to 1/4 FS... ");
						HW.Dcs.VOut(PM.VIN, vin1Q);
						App.Time.UsDelay(100);

						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking for output of: {0}...", out1Q);
						passFail += Utl.TestOutput(range, out1Q, resourceSelect);

						//Set VIN back to 3/4 FS voltage
						TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Setting Vin to 3/4 Vin... ");
						HW.Dcs.VOut(PM.VIN, vin3Q);
						App.Time.UsDelay(100);
					}
				}
			}
			
			//*****************Check 2 dud ranges with Ext Resistor selected*******************
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "********CHECKING DUD RANGE OPTIONS WITH EXTERNAL RESISTOR SELECTED********");
			/*			for(rangeIndex = 0; rangeIndex < App.TC.NumDudRanges; rangeIndex++)
						{
							range = App.TC.DudRanges[rangeIndex];
							Utl.write24Bits(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, 
								App.ClearEn.NO_CLEAR, App.ResSel.R_EXT,App.SoftResetEn.NO_RESET);
							App.Time.UsDelay(100);

							//Measure Iout current for correct 0 value
							TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking for zero current of 0mA...");
							passFail += Utl.TestIout(0.0, App.MeasOptions.DMM);

							//Change VIN voltage to 0V and check that corresponding Iout is 0 value
							TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Setting Vin to 0.0V... ");
							HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);
							App.Time.UsDelay(100);

							TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Checking for zero current of 0mA...");
							passFail += Utl.TestIout(0.0, App.MeasOptions.DMM);

							//Set VIN back to FS voltage of 4.096V
							TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Setting Vin to 4.096V... ");
							HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);
							App.Time.UsDelay(100);
						}
			*/
			App.Test[IDs.PecFunc].Result = passFail;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);
			HW.Dcs.VOut(PM.VIN, 0.0);
			//Switch out external resistor
			HW.Rdc.Set(PM.D4, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class PecFunctionality
	#endregion

	//
	// InvalidWriteCheck Test Function
	//
	#region InvalidWriteCheck               :
	/// <summary>
	/// Test checks that if any one of the 3 unused bits in the input word are set, no write takes place.
	/// </summary>
	public class InvalidWriteCheck : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region InvalidWriteCheck               :
		public InvalidWriteCheck()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			int inputWord, pecWord, readWriteBit, numInvalidBits = 3, i;
			int [] invalidBits = {0,0,0};
			MsInt readData = 0, passFail = 0;

			readWriteBit = 0;

			//Ensure POR conditions
			Utl.RunPattern(DP.hw_reset);

			for(i = 0; i< numInvalidBits; i++)
			{
				invalidBits[i] = 1;

				//Set each invalid bit to 1 and check that write is not carried out.
				inputWord = (App.TC.DutAddress << 13) + (readWriteBit << 12) + (invalidBits[2] << 11)
					+ (App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits << 7) + ((int)App.ClearMode.CLR_TO_ZERO << 6)
					+ ((int)App.OutputEn.OP_ENABLE << 5) + ((int)App.ClearEn.NO_CLEAR << 4) + ((int)App.ResSel.R_INT << 3)
					+ ((int)App.SoftResetEn.NO_RESET << 2) + (invalidBits[1] << 1) + invalidBits[0];
				pecWord = Utl.CalculatePecWord(inputWord);
				inputWord = (inputWord << 8) + pecWord;

				Utl.write24Bits(inputWord);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Invalid Write Test");

				readData = Utl.ReadAddr(App.TC.DutAddress);

				foreach(Site site in TP.MS.ActiveSites)
				{
					if(readData[site] != 0x0)
						passFail[site]++;
				}

				invalidBits[i] = 0;
			}

			App.Test[IDs.InvalidWrites].Result = passFail;
		}
		#endregion
	}// end of class InvalidWriteCheck
	#endregion
	#endregion

	//
	// RangeTrim Test Function
	//
	#region RangeTrim                       :
	/// <summary>
	/// Calculates Offset and Gain Trim Codes and post trim errors for whichever range parameter is passed in
	/// </summary>
	public class RangeTrim : TestFunction
	{
		public App.RangeOptions range;
		public App.ResSel rSel;
		public App.MeasOptions resourceSelect;

		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region RangeTrim                       :
		public RangeTrim(App.RangeOptions range, App.ResSel rSel, App.MeasOptions resourceSelect)
		{
			this.range = range;
			this.rSel = rSel;
			this.resourceSelect = resourceSelect;
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			
			//App.MeasOptions resourceSelect = App.MeasOptions.DMM;
			//App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			int fsCode = (int)Math.Pow(2.0, App.Globals.NumTrimBits) - 1;
			int msCode = (int)(Math.Pow(2.0, App.Globals.NumTrimBits)/ 2.0);
			int zsCode = 0;
			int maxCode = (int)Math.Pow(2.0, App.Globals.NumTrimBits) - 1;
			double vinO1, vinO7, vin;
			MsDouble outputO1 = 0.0, 
				outputO7 = 0.0, 
				output1 = 0.0, 
				output2 = 0.0, 
				output3 = 0.0,
				zsOutput = 0.0,
				fsOutput = 0.0,
				zsError = 0.0,
				lsbSize = 0.0;
			double idealOutputO1, idealOutputO7, idealGain, idealRange;
			MsDouble actualRange = 0.0 , 
				errorFactor = 0.0, 
				gainError = 0.0, 
				postTrimGain = 0.0, 
				origGainError = 0.0, 
				origOffsetError = 0.0,
				offsetError = 0.0;
			MsInt gainTrimCode = 0,
				offsetTrimCode = 0,
				code2 = 0,
				code1 = (int)(Math.Pow(2.0, App.Globals.NumTrimBits)/ 2.0),
				origTrimCode = 0;
			double targetValue = 500.0e-6, 
				idealGainError = 0.005,
				idealOffsetError = (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)*(0.01/100);
			double expectedOutput;


			//used in working out error factor. This will change depending on what points in the transfer function are used.
			double gainFactor;		

			double [] offsetArray = new double[fsCode];
			double [] outputO1Array = new double[fsCode];
			double [] outputO7Array = new double[fsCode];
			double [] vRefArray  = new double[5000];

			//If external resistor is selected, close D4 to switch in resistor
			//Also, initialise offset Trim Code to approximate values.
			if(this.rSel == App.ResSel.R_EXT)
			{
				HW.Rdc.Set(PM.D4, OpenClose.CLOSE);
				code1 = App.TC.RangeData[(int)range].ExtOffsetTrimCode;
				App.Time.MsDelay(App.TC.RelaySettle);
			}
			else
				code1 = App.TC.RangeData[(int)range].OffsetTrimCode;

			//Set vin1 and vin2 to one eight and three eights of the input voltage range
			vinO1 = (App.TC.MaxInputVoltage - App.TC.MinInputVoltage)/8.0;
			vinO7 = vinO1 * 7;
			vin = 0.030;
			gainFactor = App.TC.MaxInputVoltage / (vinO7 - vinO1);

			idealOutputO1 = App.TC.RangeData[(int)range].MinValue + ((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/8.0);
			idealOutputO7 = App.TC.RangeData[(int)range].MinValue + 7.0*((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/8.0);
			idealGain = (idealOutputO7 - idealOutputO1)/(vinO7 - vinO1);

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Calculating Gain Trim Code for {0} Range", App.TC.RangeData[(int)range].RangeName);

			//Need to set Vin to 0V initially to avoid Vout defaulting to an unknown value when bypass mode is enabled.
			HW.Dcs.VOut(PM.VIN, 0.0);

			//Select correct range 
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

			//Need to blow TC trim code before trimming ranges. This only needs to be done at first range

			
				if(range == App.RangeOptions.FIVE_V)
				{

					//Increase DVcc to blow voltage level
					if(App.TC.CurrentVcc != App.TC.FuseV)
					{   
						Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
						HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
						App.Time.MsDelay(10);
					}

					//Enter Test Mode
					Utl.EnterTM();
					Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
						App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

					Utl.BlowFuseMem(rSel, range, App.BlowBlockBits.WAFER_BLOCK, App.TC.TcTrimCode);
					Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
					HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);
				}
		

			//Enter Test Mode
			Utl.EnterTM();

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

			//Enable fuse bypass mode
			Utl.TmWrite(App.TestModes.TM_FUSE_BYPASS, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, 0x0);
			Utl.TmWrite(App.TestModes.TM_GAIN_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, fsCode);

			//Initialise bias/offset/gain  bits
			//Load ibias register with correct code
			Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, code1);
			Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.IbiasTrimCode);
			Utl.TmWrite(App.TestModes.TM_TC_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.TcTrimCode);

			
			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				// setting relay for VOUT

				// open relay rly15 to connect to pincard 
				HW.Rdc.Set(PM.D15, OpenClose.OPEN);
				App.Time.MsDelay(App.TC.RelaySettle);

			}
			else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
			{
				// setting relay for IOUT

				// open relay RLY 09
				HW.Rdc.Set(Rdc.A16RDC_K9, OpenClose.OPEN);
				App.Time.MsDelay(App.TC.RelaySettle);

			}



			#region Gain Trim Code


			//************Gain Trim Code Calulations************//
			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Range Trim");

			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Measure Outputs with FS gain code: 0x1fff");
			//Set Input Voltage to 0.512V and measure corresponding output
			HW.Dcs.VOut(PM.VIN, vinO1);
			App.Time.MsDelay(App.TC.OutputSettle);
			expectedOutput = idealOutputO1;
			//When using the scale circuits, a load is introduced to Vout.
			//For consistency, want to measure Vout with the same load in place throughout.
			//Once expecting 40V each time, the same scale circuit will be selected.
			if(range == App.RangeOptions.FORTY_V)
				expectedOutput = 40.0;
			outputO1 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

			//Set Input Voltage to 3.584V and measure corresponding output
			HW.Dcs.VOut(PM.VIN, vinO7);
			App.Time.MsDelay(App.TC.OutputSettle);
			expectedOutput = idealOutputO7;
			if(range == App.RangeOptions.FORTY_V)
				expectedOutput = 40.0;
			outputO7 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

			HW.Dcs.VOut(PM.VIN, 0.0);

			idealRange = App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue;
			foreach(Site site in TP.MS.ActiveSites)
			{
				//Work out error factor of output
				actualRange[site] = gainFactor *(outputO7[site] - outputO1[site]);
				errorFactor[site] = idealRange/actualRange[site];
				//Trim Code = FS code * Error Factor
				gainTrimCode[site] = (int)Math.Floor((fsCode * errorFactor[site]) + 0.5);
				
				if(gainTrimCode[site] > fsCode)
					gainTrimCode[site] = fsCode;
				else if(gainTrimCode[site] < 0)
					gainTrimCode[site] = 0;
			}

			Utl.TmWrite(App.TestModes.TM_GAIN_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, gainTrimCode);
			gainTrimCode = Utl.FineTuneGainError(gainTrimCode, fsCode, idealGainError, range, rSel);

			#endregion

			#region Offset Trim Code

			//************Offset Trim Code Calculations************//
			
			//First, calculate rough offset code
			//Load code ZS (0), set Vin = FS/8 (anything closer to 0V can run into deadband issues) & measure output
			Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, zsCode);
			HW.Dcs.VOut(PM.VIN, App.TC.MidInputVoltage);
			App.Time.MsDelay(App.TC.OutputSettle);
			if(range == App.RangeOptions.FORTY_V)
				expectedOutput = 40.0;
			zsOutput = Utl.MeasureOutput(range, expectedOutput, resourceSelect);			

			//load code FS (8191) & measure output
			//When trimming one of the bipolar current ranges, a code of 8191, causes up to 45mA through 300Ohms 
			// => 13.5V. DMM is set to use 10V range so overranging occurs.
			if((range == App.RangeOptions.TWENTY_MA_BIP) || (range == App.RangeOptions.TWENTY_FOUR_MA_BIP))
				maxCode = 6000;

			Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, maxCode);
			fsOutput = Utl.MeasureOutput(range, expectedOutput, resourceSelect);			

			//calculate lsb size & approximate offset code
			foreach(Site site in TP.MS.ActiveSites)
			{
				lsbSize[site] = (fsOutput[site] - zsOutput[site]) / (maxCode - zsCode);
				zsError[site] = zsOutput[site] - App.TC.RangeData[(int)range].MidValue;
				code1[site] = (int) (-1*(zsError[site]) / lsbSize[site]);
				if(code1[site] > fsCode)
					code1[site] = fsCode;
				else if(code1[site] < zsCode)
					code1[site] = zsCode;
			}

			targetValue = (vin/App.TC.MaxInputVoltage)*(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue);
			expectedOutput = App.TC.RangeData[(int)range].MinValue + targetValue;
			if(range == App.RangeOptions.FORTY_V)
				expectedOutput = 40.0;

			//Approx code loaded to offset register
			//Load ibias register with correct code
			Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, code1);


			HW.Dcs.VOut(PM.VIN, vin);
			App.Time.MsDelay(App.TC.OutputSettle);
			output1 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);


			//Now load test code to offset register and measure corresponding voltage
			//Select 2nd offset code for 2 point measurement. 
			foreach(Site site in TP.MS.ActiveSites)
			{
				code2[site] = (int)code1[site] + 1024;
			}
			Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, code2);
			App.Time.MsDelay(App.TC.OutputSettle);
			output2 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);
			TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Code {0} loaded, Output: {1}", code2, output2);

			foreach(Site site in TP.MS.ActiveSites)
			{
				//trimcode = old code - ( (error from ideal) / (step size) )
				// error from ideal = output 2 measured - (zeroscale + target)
				//step size = (output2 - output1)/(code2 - code1)
				offsetTrimCode[site] = (int)Math.Floor( 0.5 + (code2[site] - ((output2[site] - (App.TC.RangeData[(int)range].MinValue + targetValue)) / 
					((output2[site] - output1[site])/(code2[site] - code1[site])))));
		
				if(offsetTrimCode[site] > fsCode)
					offsetTrimCode[site] = fsCode;
				else if(offsetTrimCode[site] < 0)
					offsetTrimCode[site] = 0;

				code1[site] = offsetTrimCode[site];
				code2[site] = offsetTrimCode[site] + 50;
			}

			Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetTrimCode);
			App.Time.MsDelay(App.TC.OutputSettle);
//
			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				output1 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);
				Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, code2);

				App.Time.MsDelay(App.TC.OutputSettle);
				output2 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);


				foreach(Site site in TP.MS.ActiveSites)
				{
					offsetTrimCode[site] = (int)Math.Floor( 0.5 + (code2[site] - ((output2[site] - (App.TC.RangeData[(int)range].MinValue + targetValue)) / 
						((output2[site] - output1[site])/(code2[site] - code1[site])))));
	
					if(offsetTrimCode[site] > fsCode)
						offsetTrimCode[site] = fsCode;
					else if(offsetTrimCode[site] < 0)
						offsetTrimCode[site] = 0;


					code1[site] = offsetTrimCode[site];
					code2[site] = offsetTrimCode[site] + 20;
				}

				Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetTrimCode);
				App.Time.MsDelay(App.TC.OutputSettle);
				output1 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);
				Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, code2);

				App.Time.MsDelay(App.TC.OutputSettle);
				output2 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

				foreach(Site site in TP.MS.ActiveSites)
				{
					offsetTrimCode[site] = (int)Math.Floor( 0.5 + (code2[site] - ((output2[site] - (App.TC.RangeData[(int)range].MinValue + targetValue)) / 
						((output2[site] - output1[site])/(code2[site] - code1[site])))));
	
					if(offsetTrimCode[site] > fsCode)
						offsetTrimCode[site] = fsCode;
					else if(offsetTrimCode[site] < 0)
						offsetTrimCode[site] = 0;
				}

				Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetTrimCode);
			}
//

			#endregion 


			offsetTrimCode = Utl.FineTuneOffsetError(offsetTrimCode, vin, targetValue, idealOffsetError, range, rSel);
			gainTrimCode = Utl.FineTuneGainError(gainTrimCode, fsCode, idealGainError, range, rSel);

			offsetError = Utl.MeasureRangeOffsetError(range, vin, resourceSelect);
			gainError = Utl.MeasureRangeGainError(range, resourceSelect);


			//Assign trim codes to global variables
			if(rSel == App.ResSel.R_INT)
			{
				App.TC.RangeData[(int)range].OffsetTrimCode = offsetTrimCode;
				App.TC.RangeData[(int)range].GainTrimCode = gainTrimCode;
			}
			else if (rSel == App.ResSel.R_EXT)
			{
				App.TC.RangeData[(int)range].ExtOffsetTrimCode = offsetTrimCode;
				App.TC.RangeData[(int)range].ExtGainTrimCode = gainTrimCode;	
			}


			// clean up the relay setup
			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				// setting relay for VOUT

				// open relay rly15 to connect to pincard 
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);

			}
			else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
			{
				// setting relay for IOUT

				// open relay RLY 09
				HW.Rdc.Set(Rdc.A16RDC_K9, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);

			}

			//Bin Results
			#region BinResults
			if((range == App.RangeOptions.FIVE_V) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError5V].Result = offsetError;
				App.Test[IDs.OffsetTrimCode5V].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError5V].Result = gainError;
				App.Test[IDs.GainTrimCode5V].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.TEN_V) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError10V].Result = offsetError;
				App.Test[IDs.OffsetTrimCode10V].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError10V].Result = gainError;
				App.Test[IDs.GainTrimCode10V].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.FIVE_V_BIP) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError5Vbip].Result = offsetError;
				App.Test[IDs.OffsetTrimCode5Vbip].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError5Vbip].Result = gainError;
				App.Test[IDs.GainTrimCode5Vbip].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.TEN_V_BIP) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError10Vbip].Result = offsetError;
				App.Test[IDs.OffsetTrimCode10Vbip].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError10Vbip].Result = gainError;
				App.Test[IDs.GainTrimCode10Vbip].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.FORTY_V) && (rSel == App.ResSel.R_EXT))
			{
				App.Test[IDs.OffsetError40V].Result = offsetError;
				App.Test[IDs.OffsetTrimCode40V].Result = App.TC.RangeData[(int)range].ExtOffsetTrimCode;
				App.Test[IDs.GainError40V].Result = gainError;
				App.Test[IDs.GainTrimCode40V].Result = App.TC.RangeData[(int)range].ExtGainTrimCode;
			}
			else if((range == App.RangeOptions.FOUR_TWENTY_MA) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError4to20mInt].Result = offsetError;
				App.Test[IDs.OffsetTrimCode4to20mInt].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError4to20mInt].Result = gainError;
				App.Test[IDs.GainTrimCode4to20mInt].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_MA) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError20mInt].Result = offsetError;
				App.Test[IDs.OffsetTrimCode20mInt].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError20mInt].Result = gainError;
				App.Test[IDs.GainTrimCode20mInt].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_FOUR_MA) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError24mInt].Result = offsetError;
				App.Test[IDs.OffsetTrimCode24mInt].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError24mInt].Result = gainError;
				App.Test[IDs.GainTrimCode24mInt].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_MA_BIP) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError20mBipInt].Result = offsetError;
				App.Test[IDs.OffsetTrimCode20mBipInt].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError20mBipInt].Result = gainError;
				App.Test[IDs.GainTrimCode20mBipInt].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_FOUR_MA_BIP) && (rSel == App.ResSel.R_INT))
			{
				App.Test[IDs.OffsetError24mBipInt].Result = offsetError;
				App.Test[IDs.OffsetTrimCode24mBipInt].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
				App.Test[IDs.GainError24mBipInt].Result = gainError;
				App.Test[IDs.GainTrimCode24mBipInt].Result = App.TC.RangeData[(int)range].GainTrimCode;
			}
			else if((range == App.RangeOptions.FOUR_TWENTY_MA) && (rSel == App.ResSel.R_EXT))
			{
				App.Test[IDs.OffsetError4to20m].Result = offsetError;
				App.Test[IDs.OffsetTrimCode4to20m].Result = App.TC.RangeData[(int)range].ExtOffsetTrimCode;
				App.Test[IDs.GainError4to20m].Result = gainError;
				App.Test[IDs.GainTrimCode4to20m].Result = App.TC.RangeData[(int)range].ExtGainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_MA) && (rSel == App.ResSel.R_EXT))
			{
				App.Test[IDs.OffsetError20m].Result = offsetError;
				App.Test[IDs.OffsetTrimCode20m].Result = App.TC.RangeData[(int)range].ExtOffsetTrimCode;
				App.Test[IDs.GainError20m].Result = gainError;
				App.Test[IDs.GainTrimCode20m].Result = App.TC.RangeData[(int)range].ExtGainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_FOUR_MA) && (rSel == App.ResSel.R_EXT))
			{
				App.Test[IDs.OffsetError24m].Result = offsetError;
				App.Test[IDs.OffsetTrimCode24m].Result = App.TC.RangeData[(int)range].ExtOffsetTrimCode;
				App.Test[IDs.GainError24m].Result = gainError;
				App.Test[IDs.GainTrimCode24m].Result = App.TC.RangeData[(int)range].ExtGainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_MA_BIP) && (rSel == App.ResSel.R_EXT))
			{
				App.Test[IDs.OffsetError20mBip].Result = offsetError;
				App.Test[IDs.OffsetTrimCode20mBip].Result = App.TC.RangeData[(int)range].ExtOffsetTrimCode;
				App.Test[IDs.GainError20mBip].Result = gainError;
				App.Test[IDs.GainTrimCode20mBip].Result = App.TC.RangeData[(int)range].ExtGainTrimCode;
			}
			else if((range == App.RangeOptions.TWENTY_FOUR_MA_BIP) && (rSel == App.ResSel.R_EXT))
			{
				App.Test[IDs.OffsetError24mBip].Result = offsetError;
				App.Test[IDs.OffsetTrimCode24mBip].Result = App.TC.RangeData[(int)range].ExtOffsetTrimCode;
				App.Test[IDs.GainError24mBip].Result = gainError;
				App.Test[IDs.GainTrimCode24mBip].Result = App.TC.RangeData[(int)range].ExtGainTrimCode;
			}
			#endregion

			//Cleanup

			Utl.RunPattern(DP.hw_reset);
			HW.Dcs.VOut(PM.VIN, 0.0);


			if(App.Globals.ActiveSelector == App.Selectors.AD575x_Probe)
			{
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_2_MA);
				
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
				
			}

			if(this.rSel == App.ResSel.R_EXT)
			{
				HW.Rdc.Set(PM.D4, OpenClose.OPEN);
			}

		}
		#endregion

	}// end of class RangeTrim
	#endregion

	//
	// Probe Range Trim Attempt Test Function
	//
	#region ProbeRangeTrim                       :
	/// <summary>
	/// Calculates Offset and Gain Trim Codes and post trim errors for whichever range parameter is passed in
	/// </summary>
	public class ProbeRangeTrim : TestFunction
	{
		public App.RangeOptions range;
		public App.ResSel rSel;
		public App.MeasOptions resourceSelect;

		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region ProbeRangeTrim                       :
		public ProbeRangeTrim(App.RangeOptions range, App.ResSel rSel, App.MeasOptions resourceSelect)
		{
			this.range = range;
			this.rSel = rSel;
			this.resourceSelect = resourceSelect;
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			
			
				int fsCode = (int)Math.Pow(2.0, App.Globals.NumTrimBits) - 1;
				int msCode = (int)(Math.Pow(2.0, App.Globals.NumTrimBits)/ 2.0);
				//int zsCode = 0;
				int maxCode = (int)Math.Pow(2.0, App.Globals.NumTrimBits) - 1;
				double vinO1, vinO7, vin;
				MsDouble outputO1 = 0.0, 
					outputO7 = 0.0, 
					output1 = 0.0, 
					output2 = 0.0, 
					output3 = 0.0,
					zsOutput = 0.0,
					fsOutput = 0.0,
					zsError = 0.0,
					lsbSize = 0.0;
				double idealOutputO1, idealOutputO7, idealGain, idealRange;
				MsDouble actualRange = 0.0 , 
					errorFactor = 0.0, 
					gainError = 0.0, 
					postTrimGain = 0.0, 
					origGainError = 0.0, 
					origOffsetError = 0.0,
					offsetError = 0.0;
				MsInt gainTrimCode = 0,
					offsetTrimCode = 0,
					code2 = 0,
					code1 = (int)(Math.Pow(2.0, App.Globals.NumTrimBits)/ 2.0),
					origTrimCode = 0;
				double targetValue = 500.0e-6, 
					idealGainError = 0.005,
					idealOffsetError = (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)*(0.01/100);
				double expectedOutput;


				//used in working out error factor. This will change depending on what points in the transfer function are used.
				double gainFactor;		

				double [] offsetArray = new double[fsCode];
				double [] outputO1Array = new double[fsCode];
				double [] outputO7Array = new double[fsCode];
				double [] vRefArray  = new double[5000];

				// get the defualt values
				offsetTrimCode = App.TC.RangeData[(int)range].OffsetTrimCode;
				gainTrimCode = App.TC.RangeData[(int)range].GainTrimCode;
				
			#region Defualt Values
				// 5V
				//offsetTrimCode = 5921;
				//gainTrimCode = 7992;

				// 24mA
				//offsetTrimCode = 674;
				//gainTrimCode = 6770;

			#endregion

				//Set vin1 and vin2 to one eight and three eights of the input voltage range
				vinO1 = (App.TC.MaxInputVoltage - App.TC.MinInputVoltage)/8.0;
				vinO7 = vinO1 * 7;
				vin = 0.030;
				gainFactor = App.TC.MaxInputVoltage / (vinO7 - vinO1);

				idealOutputO1 = App.TC.RangeData[(int)range].MinValue + ((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/8.0);
				idealOutputO7 = App.TC.RangeData[(int)range].MinValue + 7.0*((App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/8.0);
				idealGain = (idealOutputO7 - idealOutputO1)/(vinO7 - vinO1);

				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Calculating Gain Trim Code for {0} Range", App.TC.RangeData[(int)range].RangeName);

				//Need to set Vin to 0V initially to avoid Vout defaulting to an unknown value when bypass mode is enabled.
				HW.Dcs.VOut(PM.VIN, 0.0);

				//Select correct range 
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);



				Utl.RunPattern(DP.hw_reset);

				//Enter Test Mode
				Utl.EnterTM();

				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);


				//Enable fuse bypass mode
				Utl.TmWrite(App.TestModes.TM_FUSE_BYPASS, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, 0x0);

				//Load ibias  gain register with correct code
				Utl.TmWrite(App.TestModes.TM_GAIN_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, fsCode);
				//Load ibias offset register with correct code
				Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetTrimCode);

				//Initialise bias reg/offset/gain  bits
				Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.IbiasTrimCode);
				Utl.TmWrite(App.TestModes.TM_TC_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.TcTrimCode);

			

				if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
				{
					// setting relay for VOUT
					// open relay rly15 to connect to pincard 
					HW.Rdc.Set(PM.D15, OpenClose.OPEN);
					App.Time.MsDelay(App.TC.RelaySettle);
				}
				else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
				{
					// setting relay for IOUT
					// open relay RLY 09
					HW.Rdc.Set(Rdc.A16RDC_K9, OpenClose.OPEN);
					App.Time.MsDelay(App.TC.RelaySettle);

					HW.Dss.ConnectionSet(PM.IOUT_PINCARD, Dss.ConnectionMode.PMU_TO_PIN);
					HW.Dss.PmuConnectMode(PM.IOUT_PINCARD, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_100_MA);
					HW.Dss.PmuModeValue(PM.IOUT_PINCARD, Dss.PmuMode.FVMI_100_MA, 0);

				}

				
				//if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
				{

					#region GainTrim Code

					// after trim code is found is passed to finetunegainerror function
					//gainTrimCode = Utl.FineTuneGainError(gainTrimCode, fsCode, idealGainError, range, rSel);
				


					
					//Set Input Voltage to 0.512V and measure corresponding output
					HW.Dcs.VOut(PM.VIN, vinO1);
					App.Time.MsDelay(App.TC.OutputSettle);
					expectedOutput = idealOutputO1;
					//When using the scale circuits, a load is introduced to Vout.
					//For consistency, want to measure Vout with the same load in place throughout.
					//Once expecting 40V each time, the same scale circuit will be selected.
					if(range == App.RangeOptions.FORTY_V)
						expectedOutput = 40.0;
					outputO1 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

					//Set Input Voltage to 3.584V and measure corresponding output
					HW.Dcs.VOut(PM.VIN, vinO7);
					App.Time.MsDelay(App.TC.OutputSettle);
					expectedOutput = idealOutputO7;
					if(range == App.RangeOptions.FORTY_V)
						expectedOutput = 40.0;
					outputO7 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

					HW.Dcs.VOut(PM.VIN, 0.0);

					idealRange = App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue;
					foreach(Site site in TP.MS.ActiveSites)
					{
						//Work out error factor of output
						actualRange[site] = gainFactor *(outputO7[site] - outputO1[site]);
						errorFactor[site] = idealRange/actualRange[site];
						//Trim Code = FS code * Error Factor
						gainTrimCode[site] = (int)Math.Floor((fsCode * errorFactor[site]) + 0.5);
				
						if(gainTrimCode[site] > fsCode)
							gainTrimCode[site] = fsCode;
						else if(gainTrimCode[site] < 0)
							gainTrimCode[site] = 0;
					}

					Utl.TmWrite(App.TestModes.TM_GAIN_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, gainTrimCode);
					gainTrimCode = Utl.FineTuneGainError(gainTrimCode, fsCode, idealGainError, range, rSel);


					#endregion



					#region OffsetTrim Code

					expectedOutput = 0;

					targetValue = (vin/App.TC.MaxInputVoltage)*(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue);
					expectedOutput = App.TC.RangeData[(int)range].MinValue + targetValue;

					HW.Dcs.VOut(PM.VIN, vin);

					// measure offset error
					output1 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

				
					// make interval wider
					foreach(Site site in TP.MS.ActiveSites)
					{
						code2[site] = (int)offsetTrimCode[site] + 500;
					}
				
					Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, code2);


					// measure offset error 
					output2 = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

					foreach(Site site in TP.MS.ActiveSites)
					{
						
						offsetTrimCode[site] = (int)Math.Floor( 0.5 + (code2[site] - ((output2[site] - (App.TC.RangeData[(int)range].MinValue + targetValue)) / 
							((output2[site] - output1[site])/(code2[site] - offsetTrimCode[site])))));
		
						if(offsetTrimCode[site] > fsCode)
							offsetTrimCode[site] = fsCode;
						else if(offsetTrimCode[site] < 0)
							offsetTrimCode[site] = 0;

					}


					Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetTrimCode);

					#endregion

				}


				//offsetTrimCode = Utl.FineTuneOffsetError(offsetTrimCode, vin, targetValue, idealOffsetError, range, rSel);
				//gainTrimCode = Utl.FineTuneGainError(gainTrimCode, fsCode, idealGainError, range, rSel);

				offsetError = Utl.MeasureRangeOffsetError(range, vin, resourceSelect);
				gainError = Utl.MeasureRangeGainError(range, resourceSelect);



				//Assign trim codes to global variables
				if(rSel == App.ResSel.R_INT)
				{
					App.TC.RangeData[(int)range].OffsetTrimCode = offsetTrimCode;
					App.TC.RangeData[(int)range].GainTrimCode = gainTrimCode;
				}


				// clean up the relay setup
				HW.Dcs.VOut(PM.VIN, 0.0);
				Utl.RunPattern(DP.hw_reset);


				if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
				{
					// setting relay for VOUT

					// open relay rly15 to connect to pincard 
					HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
					App.Time.MsDelay(App.TC.RelaySettle);

				}
				else if (App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
				{

					// setting relay for IOUT

					// open relay RLY 09
					HW.Rdc.Set(Rdc.A16RDC_K9, OpenClose.CLOSE);
					App.Time.MsDelay(App.TC.RelaySettle);

				}


				//Bin Results
				#region BinResults

				if((range == App.RangeOptions.FIVE_V) && (rSel == App.ResSel.R_INT))
				{
					App.Test[IDs.OffsetError5V].Result = offsetError;
					App.Test[IDs.OffsetTrimCode5V].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
					App.Test[IDs.GainError5V].Result = gainError;
					App.Test[IDs.GainTrimCode5V].Result = App.TC.RangeData[(int)range].GainTrimCode;
				}
				
				else if((range == App.RangeOptions.TWENTY_FOUR_MA) && (rSel == App.ResSel.R_INT))
				{
					App.Test[IDs.OffsetError24mInt].Result = offsetError;
					App.Test[IDs.OffsetTrimCode24mInt].Result = App.TC.RangeData[(int)range].OffsetTrimCode;
					App.Test[IDs.GainError24mInt].Result = gainError;
					App.Test[IDs.GainTrimCode24mInt].Result = App.TC.RangeData[(int)range].GainTrimCode;
				}

				
				#endregion


				if(App.Globals.ActiveSelector == App.Selectors.AD575x_Probe)
				{
					HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
					HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_2_MA);

					
					HW.Dss.ConnectionSet(PM.IOUT_PINCARD, Dss.ConnectionMode.DISCONNECT);
					HW.Dss.PmuConnectMode(PM.IOUT_PINCARD, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_2_MA);
				
					HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
				
				}

				if(this.rSel == App.ResSel.R_EXT)
				{
					HW.Rdc.Set(PM.D4, OpenClose.OPEN);
				}
			
		}
		#endregion

	}// end of class RangeTrim



	#endregion

	//
	// RangeTue Test Function
	//
	#region RangeTue                        :
	/// <summary>
	/// Post trim check for trimmed ranges. Bins back offset, gain, linearity and TUE results for each range
	/// </summary>
	public class RangeTue : TestFunction
	{
		public App.RangeOptions range;
		public App.ResSel rSel;
		public App.VLoadOptions load;
		public App.MeasOptions resourceSelect;

		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region RangeTue                        :
		public RangeTue(App.RangeOptions range, App.ResSel rSel, App.VLoadOptions load, App.MeasOptions resourceSelect)
		{
			this.range = range;
			this.rSel = rSel;
			this.load = load;
			this.resourceSelect = resourceSelect;
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			int numLinearityPoints = 9;
			int i;
			double inputStep;
			MsDouble [] indexArray = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] inputArray = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] outputArray = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] idealOutput = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] idealStraightLine = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] linearityError = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] tueError = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble idealGain = 0.0,
				actualGain = 0.0, 
				gainError = 0.0,
				offsetError = 0.0,
				zsError = 0.0,
				fsError = 0.0,
				posError = 0.0,
				posTueError = 0.0,
				negError = 0.0, 
				negTueError = 0.0,
				posErrorFsr = 0.0,
				negErrorFsr = 0.0,
				outputStep = 0.0,
				idealStep = 0.0,
				linearityFsr = 0.0,  
				offsetOutput = 0.0, 
				offsetFsr = 0.0,
				fsFsr = 0.0,
				posTueA = 0.0,
				negTueA = 0.0,
				posTue = 0.0,
				negTue = 0.0,
				midscaleOffset = 0.0,
				m = 0.0,	// straight line gain
				c = 0.0;	// straight line offset
			double vinOffset = 0.02, 
				idealOffsetOutput = 0.0,
				fullScaleRange;
			double [] vRefArray  = new double[numLinearityPoints];
			double [] dataOutputArray = new double[numLinearityPoints];
			double [] linearityArray = new double[numLinearityPoints];
			double [] tueArray = new double[numLinearityPoints];
			double expectedOutput;
			MsDouble yIntersect = 0.0,
				deadbandCalc = 100e-3,
				wcTue;
			//deadbandFind = 100e-3,


			//debug code
			#region debugCode
			if(App.Globals.DebugEnable)
			{
				MsInt offsetCode = 0, 
					ibiasCode = 0, readData;
				int gainCode = 0;

				//Enter Test Mode
				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

				//Increase DVcc to blow voltage level
				if(App.TC.CurrentVcc != App.TC.FuseV)
				{   
					Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
					HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
					App.Time.MsDelay(10);
				}

				//Utl.BlowFuseMem(rSel, range, App.BlowBlockBits.WAFER_BLOCK, 0x0); 
				Utl.BlowFuseMem(rSel, range, App.BlowBlockBits.WAFER_BLOCK, App.TC.TcTrimCode);
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);

				readData = Utl.ReadFuseMem(rSel, range, App.BlockBits.BIAS_BLOCK);

				//Enable fuse bypass mode
				Utl.TmWrite(App.TestModes.TM_FUSE_BYPASS, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, 0x0);
				Utl.TmWrite(App.TestModes.TM_GAIN_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, gainCode);

				//Initialise bias/offset/gain  bits

				//Load ibias register with correct code
				Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetCode);
				Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, ibiasCode);
				Utl.TmWrite(App.TestModes.TM_TC_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.TcTrimCode);
			}
			//end of debug code
			#endregion

			//Headroom with loaded Vout ~2.5V -> So, 10V & +/-10V ranges need to be tested with supply = +/-13.0V 
			//This is only changed for test cycle 1 (i.e. +11.2/-10.8V supplies)
			if(((App.TC.AVdd < 12.0) || (App.TC.AVss > -12.0)) && 
				((range == App.RangeOptions.TEN_V) || (range == App.RangeOptions.TEN_V_BIP)) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.LV_GEN))
			{
				Utl.ModifySupplies(12.5, -12.5, App.TC.DVcc);
			}
			else if((App.TC.AVdd < 13.0) && 
				(range == App.RangeOptions.TEN_V) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.HV_GEN))
			{
				Utl.ModifySupplies(13.0, App.TC.AVss, App.TC.DVcc);
			}

			//Reset the part
			Utl.RunPattern(DP.hw_reset);
			App.Time.MsDelay(App.TC.OutputSettle);

			//If external resistor is selected, close D4 to switch in resistor
			if(this.rSel == App.ResSel.R_EXT)
			{
				HW.Rdc.Set(PM.D4, OpenClose.CLOSE);
			}

			//Setup input array for linearity measurement
			inputStep = (App.TC.MaxInputVoltage - App.TC.MinInputVoltage) / (numLinearityPoints - 1);
			for(i = 0; i < numLinearityPoints; i++)
			{
				indexArray[i] = i;
				inputArray[i] = App.TC.MinInputVoltage + i*inputStep;
			}

			fullScaleRange = App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue;
			if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751))
			{
				idealOffsetOutput = App.TC.RangeData[(int)range].MinValue + ((vinOffset/App.TC.MaxInputVoltage) * fullScaleRange);
			}

			//Select correct range 
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);
			//TP.Console.WriteLine("Range: {0}", App.TC.RangeData[(int)range].RangeName);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Range TUE");

			//Sweep through input Array and measure corresponding outputs
			for(i = 0; i < numLinearityPoints; i++)
			{
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Measure Outputs with input set to: {0}", inputArray[i]);
				//vRefArray[i] = (double)Utl.MeasureNode(App.MuxNodes.VREF_MEAS, App.MeasOptions.DMM);
				//Set Input Voltage and measure corresponding output
				HW.Dcs.VOut(PM.VIN, inputArray[i]);
				expectedOutput = App.TC.RangeData[(int)range].MinValue + (((double)inputArray[i]/App.TC.MaxInputVoltage)*fullScaleRange);
				//When using the scale circuits, a load is introduced to Vout.
				//For consistency, want to measure Vout with the same load in place throughout.
				//Once expecting 40V each time, the same scale circuit will be selected.
				if(range == App.RangeOptions.FORTY_V)
					expectedOutput = 40.0;

				App.Time.MsDelay(App.TC.OutputSettle);
				outputArray[i] = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

				//TP.Console.WriteLine("Vin: {0}, Output: {1}", inputArray[i], outputArray[i]);

				//dataOutputArray[i] = (double)outputArray[i];
			}

			//Offset Measurement
			if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751))
			{
				HW.Dcs.VOut(PM.VIN, vinOffset);
				App.Time.MsDelay(App.TC.OutputSettle);
				expectedOutput = App.TC.RangeData[(int)range].MinValue + ((vinOffset/App.TC.MaxInputVoltage)*fullScaleRange);
				offsetOutput = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

				Utl.MeasIntNodes(this.range, this.rSel, this.load);
			}

			//Print results to screen
			//TP.Console.WriteLine();
			//TP.Console.WriteLine("Vin: 0V, Output: {0}", outputArray[0]);
			//TP.Console.WriteLine("Vin: 4.096V, Output: {0}", outputArray[numLinearityPoints-1]);
			//TP.Console.WriteLine("Vin: {0}V, Output: {1}", vinOffset, offsetOutput);
			//TP.Console.WriteLine();


			//Gain, Offset, ZS, FS Error Calculations
			//When calculating gain, use 10mV on input & corresponding out for zs measurement. Deadband may
			//cause poor results.
			idealGain = (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/((double)inputArray[numLinearityPoints - 1] - (double)inputArray[0]);

			foreach(Site site in TP.MS.ActiveSites)
			{
				actualGain[site] = (outputArray[numLinearityPoints - 1][site] - outputArray[0][site]) / (inputArray[numLinearityPoints - 1][site] - (double)inputArray[0]);
				gainError[site] = ((actualGain[site] - idealGain[site])  / idealGain[site]) * 100;

				if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751))
				{
					offsetError[site] = offsetOutput[site] - idealOffsetOutput;
					offsetFsr[site] = (offsetError[site]/fullScaleRange) * 100;
				}

				midscaleOffset[site] = outputArray[(numLinearityPoints/2)][site] - (App.TC.RangeData[(int)range].MinValue + fullScaleRange/2);

				zsError[site] = outputArray[0][site] - App.TC.RangeData[(int)range].MinValue;
				fsError[site] = outputArray[numLinearityPoints - 1][site] - App.TC.RangeData[(int)range].MaxValue;
				fsFsr[site] = (fsError[site]/fullScaleRange) * 100;
			}
		
			//Linearity & TUE Calculations

			foreach(Site site in TP.MS.ActiveSites)
			{
				//Use line equation to find best fit line between 2 endpoints
				//m = (y2 - y1) / (x2 - x1)
				//y = mx + c

				m[site] = (outputArray[numLinearityPoints - 1][site] - outputArray[0][site]) / (App.TC.MaxInputVoltage - App.TC.MinInputVoltage);
				c[site] = outputArray[numLinearityPoints - 1][site] - (m[site] * App.TC.MaxInputVoltage);

				for(i = 0; i < numLinearityPoints; i++)
				{
					idealOutput[i][site] = (m[site] * inputArray[i][site]) + c[site];
					linearityError[i][site] = outputArray[i][site] - idealOutput[i][site];
					linearityArray[i] = linearityError[i][site];
					if(linearityError[i][site] > posError[site])
						posError[site] = linearityError[i][site];
					else if(linearityError[i][site] < negError[site])
						negError[site] = linearityError[i][site];

					idealStraightLine[i][site] = App.TC.RangeData[(int)range].MinValue + ((inputArray[i][site]/App.TC.MaxInputVoltage) * fullScaleRange);
					tueError[i][site] = outputArray[i][site] - idealStraightLine[i][site];
					tueArray[i] = tueError[i][site];
					if(tueError[i][site] > posTueError[site])
						posTueError[site] = tueError[i][site];
					else if (tueError[i][site] < negTueError[site])
						negTueError[site] = tueError[i][site];

					TP.Console.WriteLineIf(App.Globals.AppsPlots, "Vin: {0}", inputArray[i]);
					TP.Console.WriteLineIf(App.Globals.AppsPlots, "Linearity: {0}", linearityArray[i]);
					TP.Console.WriteLineIf(App.Globals.AppsPlots, "TUE: {0}", tueArray[i]);
				}

				//String fileName = @String.Format("{0}_{1}_{2}_linearity_data_{3}.txt", App.TC.RangeData[(int)range].VoltageCurrentIdentifier, range, rSel, site);
				//Utl.WriteFile(linearityArray, numLinearityPoints, fileName);

				posErrorFsr[site] = (posError[site]/fullScaleRange) * 100;
				negErrorFsr[site] = (negError[site]/fullScaleRange) * 100;

				posTueA[site] = (posTueError[site]/fullScaleRange) * 100;
				negTueA[site] = (negTueError[site]/fullScaleRange) * 100;

				if( Math.Abs(posErrorFsr[site]) > Math.Abs(negErrorFsr[site]))
					linearityFsr[site] = posErrorFsr[site];
				else if( Math.Abs(posErrorFsr[site]) < Math.Abs(negErrorFsr[site]) )
					linearityFsr[site] = negErrorFsr[site];

				if(Math.Abs(posTueA[site]) > Math.Abs(negTueA[site]))
					wcTue = posTueA;
				else
					wcTue = negTueA;

				//***METHOD 1****
				//deadbandFind = Utl.FindUnipolarDeadband(wcTue, inputArray[avoidDeadbandInt], range, resourceSelect);

				//***METHOD 2***
				if((App.Globals.ActiveSelector == App.Selectors.PD_HV_5751) || (App.Globals.ActiveSelector == App.Selectors.QC_HV_5751))
				{
					deadbandCalc[site] = App.TC.MaxInputVoltage * ( zsError[site] / (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
				}
			}


			#region BinData
			int testIndex = 0;

			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				testIndex = App.TC.RangeIndex;
				//App.Test[IDs.vPostTrimOffset[testIndex, (int)this.load, (int)this.resourceSelect]].Result = offsetError;
				App.Test[IDs.vPostTrimZSError[testIndex]].Result = zsError;
				App.Test[IDs.vPostTrimFSError[testIndex]].Result = fsFsr;
				if(range == App.RangeOptions.FIVE_V_BIP)
					App.Test[IDs.vPostTrimMSOffset[0]].Result = midscaleOffset;
				else if(range == App.RangeOptions.TEN_V_BIP)
					App.Test[IDs.vPostTrimMSOffset[1]].Result = midscaleOffset;

				//App.Test[IDs.vPostTrimDeadband[testIndex, (int)this.load, (int)this.resourceSelect]].Result = deadbandFind;
				//App.Test[IDs.vPostTrimDBcalc[testIndex, (int)this.load, (int)this.resourceSelect]].Result = deadbandCalc;

				App.Test[IDs.vPostTrimGain[testIndex]].Result = gainError;
				App.Test[IDs.vPostTrimLin[testIndex]].Result = linearityFsr;

				App.Test[IDs.vPostTrimPosTueReal[testIndex]].Result = posTueA;
				App.Test[IDs.vPostTrimNegTueReal[testIndex]].Result = negTueA;

				App.TC.RangeIndex ++;
			}
			else
			{
				//App.Test[IDs.iPostTrimOffset[(int)this.range, (int)this.rSel, (int)this.resourceSelect]].Result = offsetError;
				App.Test[IDs.iPostTrimZSError[(int)this.range, (int)this.rSel]].Result = zsError;
				App.Test[IDs.iPostTrimFSError[(int)this.range, (int)this.rSel]].Result = fsFsr;
				if(range == App.RangeOptions.TWENTY_MA_BIP)
					App.Test[IDs.iPostTrimMSOffset[0, (int)this.rSel]].Result = midscaleOffset;
				else if(range == App.RangeOptions.TWENTY_FOUR_MA_BIP)
					App.Test[IDs.iPostTrimMSOffset[1,  (int)this.rSel]].Result = midscaleOffset;

				//App.Test[IDs.iPostTrimDeadband[(int)this.range, (int)this.rSel, (int)this.resourceSelect]].Result = deadbandFind;
				//App.Test[IDs.iPostTrimDBcalc[(int)this.range, (int)this.rSel, (int)this.resourceSelect]].Result = deadbandCalc;

				App.Test[IDs.iPostTrimGain[(int)this.range, (int)this.rSel]].Result = gainError;
				App.Test[IDs.iPostTrimLin[(int)this.range, (int)this.rSel]].Result = linearityFsr;

				App.Test[IDs.iPostTrimPosTueReal[(int)this.range, (int)this.rSel]].Result = posTueA;
				App.Test[IDs.iPostTrimNegTueReal[(int)this.range, (int)this.rSel]].Result = negTueA;
			}
			#endregion


			//Cleanup
			#region Cleanup
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.RunPattern(DP.hw_reset);
			HW.Rdc.Set(PM.D4, OpenClose.OPEN);
			if(((App.TC.AVdd < 12.0) || (App.TC.AVss > -12.0)) && 
				((range == App.RangeOptions.TEN_V) || (range == App.RangeOptions.TEN_V_BIP)) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.LV_GEN))
			{
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			}
			else if((App.TC.AVdd < 12.0) && 
				(range == App.RangeOptions.TEN_V) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.HV_GEN))
			{
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			}
			#endregion

		}
		#endregion
	}// end of class RangeTue
	#endregion

	//
	// RangeTue15v Test Function
	//
	#region RangeTue15v                        :
	/// <summary>
	/// Post trim check for trimmed ranges. Bins back offset, gain, linearity and TUE results for each range
	/// </summary>
	public class RangeTue15v : TestFunction
	{
		public App.RangeOptions range;
		public App.ResSel rSel;
		public App.VLoadOptions load;
		public App.MeasOptions resourceSelect;

		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region RangeTue15v                        :
		public RangeTue15v(App.RangeOptions range, App.ResSel rSel, App.VLoadOptions load, App.MeasOptions resourceSelect)
		{
			this.range = range;
			this.rSel = rSel;
			this.load = load;
			this.resourceSelect = resourceSelect;
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			int numLinearityPoints = 9;
			int i;
			double inputStep;
			MsDouble [] indexArray = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] inputArray = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] outputArray = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] idealOutput = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] idealStraightLine = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] linearityError = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble [] tueError = MsDouble.CreateArray(numLinearityPoints, 0);
			MsDouble idealGain = 0.0,
				actualGain = 0.0, 
				gainError = 0.0,
				offsetError = 0.0,
				zsError = 0.0,
				fsError = 0.0,
				posError = 0.0,
				posTueError = 0.0,
				negError = 0.0, 
				negTueError = 0.0,
				posErrorFsr = 0.0,
				negErrorFsr = 0.0,
				outputStep = 0.0,
				idealStep = 0.0,
				linearityFsr = 0.0,  
				offsetOutput = 0.0, 
				offsetFsr = 0.0,
				posTueA = 0.0,
				negTueA = 0.0,
				posTue = 0.0,
				negTue = 0.0,
				midscaleOffset = 0.0,
				m = 0.0,	// straight line gain
				c = 0.0;	// straight line offset
			double vinOffset = 0.03, 
				idealOffsetOutput,
				fullScaleRange;
			double [] vRefArray  = new double[numLinearityPoints];
			double [] dataOutputArray = new double[numLinearityPoints];
			double [] linearityArray = new double[numLinearityPoints];
			double [] tueArray = new double[numLinearityPoints];
			double expectedOutput;
			MsDouble deadbandFind = 100e-3,
				deadbandCalc = 100e-3,
				yIntersect = 0.0,
				wcTue;


			//debug code

			//Adjust supplies to +/-15V
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
                Utl.ModifySupplies(15.0, -15.0, App.TC.DVcc);
			else
				Utl.ModifySupplies(15.0, App.TC.AVss, App.TC.DVcc);

			if(App.Globals.DebugEnable)
			{
				MsInt offsetCode = 0, 
					ibiasCode = 0, readData;
				int gainCode = 0;

				//Enter Test Mode
				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);

				//Increase DVcc to blow voltage level
				if(App.TC.CurrentVcc != App.TC.FuseV)
				{   
					Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
					HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
					App.Time.MsDelay(10);
				}

				//Utl.BlowFuseMem(rSel, range, App.BlowBlockBits.WAFER_BLOCK, 0x0); 
				Utl.BlowFuseMem(rSel, range, App.BlowBlockBits.WAFER_BLOCK, App.TC.TcTrimCode);
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);

				readData = Utl.ReadFuseMem(rSel, range, App.BlockBits.BIAS_BLOCK);

				//Enable fuse bypass mode
				Utl.TmWrite(App.TestModes.TM_FUSE_BYPASS, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, 0x0);
				Utl.TmWrite(App.TestModes.TM_GAIN_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, gainCode);

				//Initialise bias/offset/gain  bits
				//Load ibias register with correct code
				Utl.TmWrite(App.TestModes.TM_OFFSET_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, offsetCode);
				Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, ibiasCode);
				Utl.TmWrite(App.TestModes.TM_TC_REG, App.TC.RangeData[(int)range].ProgBits, rSel, 0x0, App.TC.TcTrimCode);
			}
			//end of debug code


			//Headroom with loaded Vout ~2.5V -> So, 10V & +/-10V ranges need to be tested with supply = +/-13.0V 
			//This is only changed for test cycle 1 (i.e. +11.2/-10.8V supplies)
			if(((App.TC.AVdd < 12.0) || (App.TC.AVss > -12.0)) && 
				((range == App.RangeOptions.TEN_V) || (range == App.RangeOptions.TEN_V_BIP)) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.LV_GEN))
			{
				Utl.ModifySupplies(12.5, -12.5, App.TC.DVcc);
			}
			else if((App.TC.AVdd < 13.0) && 
				(range == App.RangeOptions.TEN_V) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.HV_GEN))
			{
				Utl.ModifySupplies(13.0, App.TC.AVss, App.TC.DVcc);
			}

			//Reset the part
			Utl.RunPattern(DP.hw_reset);
			App.Time.MsDelay(App.TC.OutputSettle);

			//If external resistor is selected, close D4 to switch in resistor
			if(this.rSel == App.ResSel.R_EXT)
			{
				HW.Rdc.Set(PM.D4, OpenClose.CLOSE);
			}

			//Setup input array for linearity measurement
			inputStep = (App.TC.MaxInputVoltage - App.TC.MinInputVoltage) / (numLinearityPoints - 1);
			for(i = 0; i < numLinearityPoints; i++)
			{
				indexArray[i] = i;
				inputArray[i] = App.TC.MinInputVoltage + i*inputStep;
			}

			fullScaleRange = App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue;
			idealOffsetOutput = App.TC.RangeData[(int)range].MinValue + ((vinOffset/App.TC.MaxInputVoltage) * fullScaleRange);

			//Select correct range 
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, rSel, App.SoftResetEn.NO_RESET);
			TP.Console.WriteLine("Range: {0}", App.TC.RangeData[(int)range].RangeName);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Range TUE");

			//Sweep through input Array and measure corresponding outputs
			for(i = 0; i < numLinearityPoints; i++)
			{
				TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Measure Outputs with input set to: {0}", inputArray[i]);
				//vRefArray[i] = (double)Utl.MeasureNode(App.MuxNodes.VREF_MEAS, App.MeasOptions.DMM);
				//Set Input Voltage and measure corresponding output
				HW.Dcs.VOut(PM.VIN, inputArray[i]);
				expectedOutput = App.TC.RangeData[(int)range].MinValue + (((double)inputArray[i]/App.TC.MaxInputVoltage)*fullScaleRange);
				//When using the scale circuits, a load is introduced to Vout.
				//For consistency, want to measure Vout with the same load in place throughout.
				//Once expecting 40V each time, the same scale circuit will be selected.
				if(range == App.RangeOptions.FORTY_V)
					expectedOutput = 40.0;

				App.Time.MsDelay(App.TC.OutputSettle);
				outputArray[i] = Utl.MeasureOutput(range, expectedOutput, resourceSelect);
				//dataOutputArray[i] = (double)outputArray[i];
			}

			//Offset Measurement
			HW.Dcs.VOut(PM.VIN, vinOffset);
			App.Time.MsDelay(App.TC.OutputSettle);
			expectedOutput = App.TC.RangeData[(int)range].MinValue + ((vinOffset/App.TC.MaxInputVoltage)*fullScaleRange);
			offsetOutput = Utl.MeasureOutput(range, expectedOutput, resourceSelect);

			//Utl.MeasIntNodes(this.range, this.rSel, this.load);

			//Print results to screen
			TP.Console.WriteLine();
			TP.Console.WriteLine("Vin: 0V, Output: {0}", outputArray[0]);
			TP.Console.WriteLine("Vin: 4.096V, Output: {0}", outputArray[numLinearityPoints-1]);
			TP.Console.WriteLine("Vin: {0}V, Output: {1}", vinOffset, offsetOutput);
			TP.Console.WriteLine();

			//Gain, Offset, ZS, FS Error Calculations
			//When calculating gain, use 10mV on input & corresponding out for zs measurement. Deadband may
			//cause poor results.
			idealGain = (App.TC.RangeData[(int)range].MaxValue - idealOffsetOutput)/((double)inputArray[numLinearityPoints - 1] - vinOffset);

			foreach(Site site in TP.MS.ActiveSites)
			{
				actualGain[site] = (outputArray[numLinearityPoints - 1][site] - offsetOutput[site]) / (inputArray[numLinearityPoints - 1][site] - vinOffset);
				gainError[site] = ((actualGain[site] - idealGain[site])  / idealGain[site]) * 100;

				offsetError[site] = offsetOutput[site] - idealOffsetOutput;
				offsetFsr[site] = (offsetError[site]/fullScaleRange) * 100;

				midscaleOffset[site] = outputArray[(numLinearityPoints/2)][site] - (App.TC.RangeData[(int)range].MinValue + fullScaleRange/2);

				zsError[site] = outputArray[0][site] - App.TC.RangeData[(int)range].MinValue;
				fsError[site] = outputArray[numLinearityPoints - 1][site] - App.TC.RangeData[(int)range].MaxValue;
			}
		
			//Linearity & TUE Calculations
			//NB****
			//***To avoid deadband on unipolar ranges, not using the first data point in the linearity/TUE
			//***calculations
			//*****

			//Use this variable to discount 1st datapoint in array
			//int avoidDeadbandInt = 1;

			foreach(Site site in TP.MS.ActiveSites)
			{
				//Use line equation to find best fit line between 2 endpoints
				//m = (y2 - y1) / (x2 - x1)
				//y = mx + c

				m[site] = (outputArray[numLinearityPoints - 1][site] - offsetOutput[site]) / (App.TC.MaxInputVoltage - vinOffset);
				c[site] = outputArray[numLinearityPoints - 1][site] - (m[site] * App.TC.MaxInputVoltage);

				for(i = 0; i < numLinearityPoints; i++)
				{
					if(i == 0)
					{
						idealOutput[i][site] = (m[site] * vinOffset) + c[site];
						linearityError[i][site] = offsetOutput[site] - idealOutput[i][site];
					}
					else
					{
						idealOutput[i][site] = (m[site] * inputArray[i][site]) + c[site];
						linearityError[i][site] = outputArray[i][site] - idealOutput[i][site];
					}
					linearityArray[i] = linearityError[i][site];

					if(linearityError[i][site] > posError[site])
						posError[site] = linearityError[i][site];
					else if(linearityError[i][site] < negError[site])
						negError[site] = linearityError[i][site];

					if(i == 0)
					{
						idealStraightLine[i][site] = App.TC.RangeData[(int)range].MinValue + ((vinOffset/App.TC.MaxInputVoltage) * fullScaleRange);
						tueError[i][site] = offsetOutput[site] - idealStraightLine[i][site];
					}
					else
					{
						idealStraightLine[i][site] = App.TC.RangeData[(int)range].MinValue + ((inputArray[i][site]/App.TC.MaxInputVoltage) * fullScaleRange);
						tueError[i][site] = outputArray[i][site] - idealStraightLine[i][site];
					}
					tueArray[i] = tueError[i][site];

					if(tueError[i][site] > posTueError[site])
						posTueError[site] = tueError[i][site];
					else if (tueError[i][site] < negTueError[site])
						negTueError[site] = tueError[i][site];
				}

				//String fileName = @String.Format("{0}_{1}_{2}_linearity_data_{3}.txt", App.TC.RangeData[(int)range].VoltageCurrentIdentifier, range, rSel, site);
				//Utl.WriteFile(linearityArray, numLinearityPoints, fileName);

				posErrorFsr[site] = (posError[site]/fullScaleRange) * 100;
				negErrorFsr[site] = (negError[site]/fullScaleRange) * 100;

				posTueA[site] = (posTueError[site]/fullScaleRange) * 100;
				negTueA[site] = (negTueError[site]/fullScaleRange) * 100;

				if( Math.Abs(posErrorFsr[site]) > Math.Abs(negErrorFsr[site]))
					linearityFsr = posErrorFsr[site];
				else if( Math.Abs(posErrorFsr[site]) < Math.Abs(negErrorFsr[site]) )
					linearityFsr = negErrorFsr[site];

				if(Math.Abs(posTueA[site]) > Math.Abs(negTueA[site]))
					wcTue = posTueA;
				else
					wcTue = negTueA;

				//***METHOD 1****
				//deadbandFind = Utl.FindUnipolarDeadband(wcTue, inputArray[avoidDeadbandInt], range, resourceSelect);

				//***METHOD 2***
				deadbandCalc[site] = App.TC.MaxInputVoltage * ( zsError[site] / (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
			}


			int testIndex = 0;

			if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE)
			{
				testIndex = App.TC.RangeIndex;
				App.Test[IDs.v10Offset15vSupply].Result = offsetError;
				App.Test[IDs.v10Zs15vSupply].Result = zsError;
				App.Test[IDs.v10Fs15vSupply].Result = fsError;
				App.Test[IDs.v10Dband15vSupply].Result = deadbandCalc;
				App.Test[IDs.v10Gain15vSupply].Result = gainError;
				App.Test[IDs.v10Lin15vSupply].Result = linearityFsr;
				App.Test[IDs.v10PosTue15vSupply].Result = posTueA;
				App.Test[IDs.v10NegTue15vSupply].Result = negTueA;
			}
			else
			{
				App.Test[IDs.i24Offset15vSupply].Result = offsetError;
				App.Test[IDs.i24Zs15vSupply].Result = zsError;
				App.Test[IDs.i24Fs15vSupply].Result = fsError;
				App.Test[IDs.i24Dband15vSupply].Result = deadbandCalc;
				App.Test[IDs.i24Gain15vSupply].Result = gainError;
				App.Test[IDs.i24Lin15vSupply].Result = linearityFsr;
				App.Test[IDs.i24PosTue15vSupply].Result = posTueA;
				App.Test[IDs.i24NegTue15vSupply].Result = negTueA;
			}

			//Cleanup
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.RunPattern(DP.hw_reset);
			HW.Rdc.Set(PM.D4, OpenClose.OPEN);

			//Return supplies to normal program conditions
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			else
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);

			if(((App.TC.AVdd < 12.0) || (App.TC.AVss > -12.0)) && 
				((range == App.RangeOptions.TEN_V) || (range == App.RangeOptions.TEN_V_BIP)) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.LV_GEN))
			{
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			}
			else if((App.TC.AVdd < 12.0) && 
				(range == App.RangeOptions.TEN_V) &&
				(this.load == App.VLoadOptions.LOAD_ON) && 
				(App.Globals.GenericType == App.GenericType.HV_GEN))
			{
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			}

		}
		#endregion
	}// end of class RangeTue
	#endregion

	//
	//Alarm Tests - S/W mode
	//
	#region AlarmTests
	//
	// AlarmChar Test Function
	//
	#region AlarmChar                       :
	/// <summary>
	/// This test checks all alarm modes of the device - verifys both status register and fault pin functionality
	/// </summary>
	public class AlarmChar : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region AlarmChar                       :
		public AlarmChar()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt tempAlarm = 0, 
				pecAlarm = 0, 
				ioutAlarm = 0, 
				faultPinFunc = 0,
				fault2mA5Func = 0;
			App.RangeOptions range;
			int writeWord, pecWord, wordWithPec, i;
			MsInt readback, alarmBit = 0;
			MsBool passFail = false; 
			MsDouble iout = 0.0, vddComplianceVoltage = 0.0, vssComplianceVoltage = 0.0, vout = 0.0,
				alarmIoutVdd = 0.0, alarmIoutVss = 0.0, alarmVdd = 0.0, alarmVss = 0.0, 
				vddAlrmDeltaIoutFSR = 0.0, vssAlrmDeltaIoutFSR = 0.0,
				vddComplDeltaIoutFSR = 0.0, vssComplDeltaIoutFSR = 0.0,
				vin = 0.0, idealIout = 0.0,
				idealIoutVdd = 0.0, idealIoutVss = 0.0,
				vddSupply = 16.0, vssSupply = -16.0,
				vddStart = 0.0, vssStart = 0.0;
			double volSpec10k = 0.4,
				volSpec2mA5 = 0.6,
				guardband = 100.0e-3,
				complianceSpec = 2.5, 
				complianceAllow = 0.5,
				voltageStep = 0.050,
				pullupVoltage;
			double loadCurrent = App.TC.DVcc / 10.0e3;

			if(App.Globals.CharTestingEnable)
				HW.Dmm.Integration(PM.DMM, 0.020);

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.FIVE_V_BIP;
			else
				range = App.RangeOptions.FIVE_V;

			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			//Ensure fault pin has correct pull-up
			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));

			//1. Verify PEC fault detection
			#region PECfault			
			//construct 16 bit word and generate pec word. 
			//Adjust pec word so that incorrect word is appended to write word
			writeWord = (App.TC.DutAddress << 13 ) + (App.TC.RangeData[(int)range].ProgBits << 7) + 
				((int)App.ClearMode.CLR_TO_ZERO << 6) + ((int)App.OutputEn.OP_ENABLE << 5) + 
				((int)App.ClearEn.NO_CLEAR << 4) + ((int)App.ResSel.R_INT << 3) + ((int)App.SoftResetEn.NO_RESET << 2);        
			pecWord = Utl.CalculatePecWord(writeWord);
			pecWord = (pecWord << 1);
			wordWithPec = (writeWord << 8) + pecWord;

			//Write 24 bit word, readback status register and extract PEC error bit
			Utl.write24Bits(wordWithPec);

			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					faultPinFunc[site]++;
					pecAlarm[site]++;
				}
			}

			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					fault2mA5Func[site]++;
					pecAlarm[site]++;
				}
			}
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));

			//Readback also clears alarm state
			readback = Utl.ReadAddr(App.TC.DutAddress);
			alarmBit = (readback >> 3) & 0x1;

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(alarmBit[site] != 1)
					pecAlarm[site]++;
			}
			#endregion

			//2. Verify Over Temp fault detection
			#region OverTempFault
			//Enter testmode, enable temp shutdown mode using tmux and check fault pin
			//Note: Not possible to read status register in test mode.
			Utl.EnterTM();
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, (int)App.TmuxBits.TEMP_SHUTDOWN_EN);

			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					faultPinFunc[site]++;
					tempAlarm[site]++;
				}
			}

			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);
			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					fault2mA5Func[site]++;
					tempAlarm[site]++;
				}
			}

			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);

			//Reset fault by writing 0 to TMux register
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, 0);
			Utl.RunPattern(DP.hw_reset);
			#endregion
			
			//3. Verify Iout Open Circuit Fault
			#region IoutOpenCctFault
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			//Set Iout to drop across 2.1K resistor. Set Iout to generate ideal voltage of Vdd - 2V
			//at top of 2.1k. Drop supply by 100mV at a time until Iout degenerates by 0.01%. 
			// -> alarm should be set

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
			else
				range = App.RangeOptions.TWENTY_FOUR_MA;

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.OutputSettle);
		
			//Check for Vdd Compliance
			#region VddCompliance
			alarmBit = 0;

			foreach(Site site in TP.MS.ActiveSites)
			{
				if((App.TC.AVdd > 14.0) || (App.TC.AVss < -14.0))
				{
					idealIout[site] = (App.TC.AVdd - (complianceSpec + complianceAllow))/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
					if(idealIout[site] > App.TC.RangeData[(int)range].MaxValue)
					{
						idealIout[site] = App.TC.RangeData[(int)range].MaxValue;
						vddStart[site] = (idealIout[site] * (App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site])) + (complianceSpec + complianceAllow);
					}
					else
						vddStart[site] = App.TC.AVdd;

					vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
				}
				else
				{
					idealIout[site] = App.TC.AVdd/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
					vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
					vddStart[site] = App.TC.AVdd + (complianceSpec + complianceAllow);
				}

				vddSupply[site] = vddStart[site];
				Utl.ModifySupplies(vddSupply[site], App.TC.AVss, App.TC.DVcc);

				HW.Dcs.VOut(PM.VIN, vin[site]);
				App.Time.MsDelay(App.TC.OutputSettle);
			}

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Iout Alarm");

			//Need to set ideal value to actual value at correct Vdd.
			iout = Utl.IoutMeas(App.MeasOptions.DMM);
			idealIout = iout;
			idealIoutVdd = idealIout;

			for(i = 0; i< 100; i++)
			{
				iout = Utl.IoutMeas(App.MeasOptions.DMM);

				foreach(Site site in TP.MS.ActiveSites)
				{
					if((iout[site] > (idealIout[site] + (0.01/100)*idealIout[site])) || (iout[site] < (idealIout[site] - (0.01/100)*idealIout[site])))
					{
						vddComplDeltaIoutFSR[site] = ((iout[site] - idealIout[site])/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;

						vddSupply[site] = vddSupply[site] + voltageStep;
						Utl.ModifySupplies(vddSupply[site], App.TC.AVss, App.TC.DVcc);
						App.Time.MsDelay(App.TC.OutputSettle);
						iout = Utl.IoutMeas(App.MeasOptions.DMM);

						vout[site] = iout[site] * (App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
						vddComplianceVoltage[site] = vddSupply[site] - vout[site];
		
						while((alarmBit[site] != 1) && (vddSupply > 0.0))
						{
							Utl.ModifySupplies(vddSupply[site], App.TC.AVss, App.TC.DVcc);
							App.Time.MsDelay(App.TC.OutputSettle);

							//Check alarm is set
							readback = Utl.ReadAddr(App.TC.DutAddress);
							alarmBit = (readback >> 1) & 0x1;
							vddSupply = vddSupply[site] - voltageStep;
						}

						vddSupply = vddSupply[site] + voltageStep;

						//Need to delay by 30ms before alarm goes off. 
						App.Time.MsDelay(App.TC.IfaultDelay);

						if(alarmBit[site] != 1)
							ioutAlarm[site]++;

						alarmIoutVdd = Utl.IoutMeas(App.MeasOptions.DMM);
						alarmVdd = vddSupply;
						//deltaIoutFSR = (current delta/full scale range)*100
						vddAlrmDeltaIoutFSR[site] = ((alarmIoutVdd[site] - idealIout[site])/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;

						App.Time.MsDelay(App.TC.VfaultDelay);

						//Check fault pin
						Utl.RunPattern(DP.checkFaultCond);
						passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
						if(!passFail[site])
						{
							faultPinFunc[site]++;
							ioutAlarm[site]++;
						}

						//Check fault pin with 2.5mA load on pin
						HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
						HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
						HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
						App.Time.MsDelay(App.TC.OutputSettle);

						App.Time.MsDelay(App.TC.VfaultDelay);

						Utl.RunPattern(DP.checkFaultCond);
						passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
						if(!passFail[site])
						{
							fault2mA5Func[site]++;
							ioutAlarm[site]++;
						}

						HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
						HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
						HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
						App.Time.MsDelay(App.TC.OutputSettle);

						i = 100;
					}
					vddSupply[site] = vddSupply[site] - voltageStep;
					Utl.ModifySupplies(vddSupply[site], App.TC.AVss, App.TC.DVcc);
					App.Time.MsDelay(App.TC.IfaultDelay);
				}
			}

			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			#endregion

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Check for Vss Compliance
				#region VssCompliance
				alarmBit = 0;

				//complianceAllow = 0.5;

				foreach(Site site in TP.MS.ActiveSites)
				{
					if(App.TC.AVss < -14.0)
					{
						idealIout[site] = (App.TC.AVss + (complianceSpec + complianceAllow))/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
						vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
						vssStart[site] = App.TC.AVss;
					}
					else
					{
						idealIout = App.TC.AVss/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
						vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
						vssStart[site] = App.TC.AVss - (complianceSpec + complianceAllow);
					}

					vssSupply[site] = vssStart[site];
					Utl.ModifySupplies(App.TC.AVdd, vssSupply[site], App.TC.DVcc);

					HW.Dcs.VOut(PM.VIN, vin[site]);
					App.Time.MsDelay(App.TC.OutputSettle);
				}
				iout = Utl.IoutMeas(App.MeasOptions.DMM);
				idealIout = iout;
				idealIoutVss = idealIout;

				for(i = 0; i< 100; i++)
				{
					iout = Utl.IoutMeas(App.MeasOptions.DMM);

					foreach(Site site in TP.MS.ActiveSites)
					{
						if((iout[site] > (idealIout[site] - (0.01/100)*idealIout[site])) || (iout[site] < (idealIout[site] + (0.01/100)*idealIout[site])))
						{
							vssComplDeltaIoutFSR = ((iout[site] - idealIout[site])/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;

							vssSupply[site] = vssSupply[site] - voltageStep;
							Utl.ModifySupplies(App.TC.AVdd, vssSupply[site], App.TC.DVcc);
							App.Time.MsDelay(App.TC.OutputSettle);
							iout = Utl.IoutMeas(App.MeasOptions.DMM);

							vout[site] = iout[site] * (App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
							vssComplianceVoltage[site] = vssSupply[site] - vout[site];
							vssComplianceVoltage[site] = -vssComplianceVoltage[site];

							while((alarmBit[site] != 1) && (vssSupply < 0))
							{
								vssSupply[site] = vssSupply[site] + voltageStep;
								Utl.ModifySupplies(App.TC.AVdd, vssSupply[site], App.TC.DVcc);
								App.Time.MsDelay(App.TC.IfaultDelay);

								//Check alarm is set
								readback = Utl.ReadAddr(App.TC.DutAddress);
								alarmBit = (readback >> 1) & 0x1;
							}

							//Need to delay by 30ms before alarm goes off. 
							App.Time.MsDelay(App.TC.IfaultDelay);

							if(alarmBit[site] != 1)
								ioutAlarm[site]++;

							alarmIoutVss = Utl.IoutMeas(App.MeasOptions.DMM);
							alarmVss = vssSupply;
							//deltaIoutFSR = (current delta/full scale range)*100
							vssAlrmDeltaIoutFSR[site] = ((alarmIoutVss[site] - idealIout[site])/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;

							//Check fault pin
							Utl.RunPattern(DP.checkFaultCond);
							passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
							if(!passFail[site])
							{
								faultPinFunc[site]++;
								ioutAlarm[site]++;
							}

							//Check fault pin with 2.5mA load on pin
							HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
							HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
							HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
							App.Time.MsDelay(App.TC.OutputSettle);

							Utl.RunPattern(DP.checkFaultCond);
							passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
							if(!passFail[site])
							{
								fault2mA5Func[site]++;
								ioutAlarm[site]++;
							}

							HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
							HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
							HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
							App.Time.MsDelay(App.TC.OutputSettle);

							i = 100;
						}
						vssSupply[site]= vssSupply[site] + voltageStep;
						Utl.ModifySupplies(App.TC.AVdd, vssSupply[site], App.TC.DVcc);
						App.Time.MsDelay(App.TC.IfaultDelay);
					}
				}

				HW.Dcs.VOut(PM.VIN, 0.0);
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				#endregion
			}

			#endregion

			App.Test[IDs.PecFaultFunc].Result = pecAlarm;
			App.Test[IDs.OverTempFaultFunc].Result = tempAlarm;

			App.Test[IDs.IFaultFunc].Result = ioutAlarm;

			App.Test[IDs.ComplianceVvdd].Result = vddComplianceVoltage;
			App.Test[IDs.IdealIoutVdd].Result = idealIoutVdd;
			App.Test[IDs.VddAlarmIout].Result = alarmIoutVdd;
			App.Test[IDs.VddCurrAlrmDeltaFSR].Result = vddAlrmDeltaIoutFSR;	
			App.Test[IDs.VddCurrComplDeltaFSR].Result = vddComplDeltaIoutFSR;	
			App.Test[IDs.AlarmVdd].Result = alarmVdd;

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				App.Test[IDs.ComplianceVvss].Result = vssComplianceVoltage;
				App.Test[IDs.IdealIoutVss].Result = idealIoutVss;
				App.Test[IDs.VssAlarmIout].Result = alarmIoutVss;
				App.Test[IDs.VssCurrAlrmDeltaFSR].Result = vssAlrmDeltaIoutFSR;
				App.Test[IDs.VssCurrComplDeltaFSR].Result = vssComplDeltaIoutFSR;	
				App.Test[IDs.AlarmVss].Result = alarmVss;
			}

			App.Test[IDs.SwFaultPinFunc].Result = faultPinFunc;	
			App.Test[IDs.SwFault2mA5Func].Result = fault2mA5Func;

			//Cleanup
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			Utl.RunPattern(DP.hw_reset);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
			if(App.Globals.CharTestingEnable)
				HW.Dmm.Integration(PM.DMM, 0.002);
		}
		#endregion
	}// end of class AlarmChar
	#endregion

	//
	// AlarmFunc Test Function
	//
	#region AlarmFunc                       :
	/// <summary>
	/// This test checks all alarm modes of the device - verifys both status register and fault pin functionality
	/// </summary>
	public class AlarmFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region AlarmFunc                       :
		public AlarmFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt tempAlarm = 0, 
				pecAlarm = 0, 
				ioutAlarm = 0, 
				faultPinFunc = 0,
				fault2mA5Func = 0;
			App.RangeOptions range;
			int writeWord, pecWord, wordWithPec;
			MsInt readback, alarmBit = 0;
			MsBool passFail = false; 

			MsDouble iout = 0.0, 
				ioutErrorVdd = 0.0, ioutErrorVss = 0.0;
			double vddSupply = 16.0, vssSupply = -16.0, 
				idealIout = 0.0, vin = 0.0, ioutLoad = 2100;	//typical load on Iout

			double volSpec10k = 0.4,
				volSpec2mA5 = 0.6,
				guardband = 100.0e-3,
				complianceSpec = 1.25,
				pullupVoltage;
			double loadCurrent = App.TC.DVcc / 10.0e3;

			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.FIVE_V_BIP;
			else
				range = App.RangeOptions.FIVE_V;

			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			//Ensure fault pin has correct pull-up
			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));

			//1. Verify PEC fault detection
			#region PECfault			
			//construct 16 bit word and generate pec word. 
			//Adjust pec word so that incorrect word is appended to write word
			writeWord = (App.TC.DutAddress << 13 ) + (App.TC.RangeData[(int)range].ProgBits << 7) + 
				((int)App.ClearMode.CLR_TO_ZERO << 6) + ((int)App.OutputEn.OP_ENABLE << 5) + 
				((int)App.ClearEn.NO_CLEAR << 4) + ((int)App.ResSel.R_INT << 3) + ((int)App.SoftResetEn.NO_RESET << 2);        
			pecWord = Utl.CalculatePecWord(writeWord);
			pecWord = (pecWord << 1);
			wordWithPec = (writeWord << 8) + pecWord;

			//Write 24 bit word, readback status register and extract PEC error bit
			Utl.write24Bits(wordWithPec);

			//Check fault pin assuming 10k pullup to DVcc
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					faultPinFunc[site]++;
					pecAlarm[site]++;
				}
			}

			//Readback also clears alarm state
			readback = Utl.ReadAddr(App.TC.DutAddress);
			alarmBit = (readback >> 3) & 0x1;

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(alarmBit[site] != 1)
					pecAlarm[site]++;
			}
			#endregion

			//2. Verify Over Temp fault detection
			#region OverTempFault
			//Enter testmode, enable temp shutdown mode using tmux and check fault pin
			//Note: Not possible to read status register in test mode.
			Utl.EnterTM();
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, (int)App.TmuxBits.TEMP_SHUTDOWN_EN);

			//Check fault pin assuming 2.5mA load on Fault pin
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);

			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					fault2mA5Func[site]++;
					tempAlarm[site]++;
				}
			}

			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);

			//Reset fault by writing 0 to TMux register
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, 0);
			Utl.RunPattern(DP.hw_reset);
			#endregion
			
			//3. Verify Iout Open Circuit Fault

			//These tests assume AVdd > 14V for AD5750 and AVdd > 50V for AD5751!!
			#region IoutOpenCctFault
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			//Set Iout to drop across 2.1K resistor. Set Iout to generate ideal voltage of Vdd - 2.5V
			//at top of 2.1k. Device should not reach compliance at this point. Reduce Vdd by 2.5V and verify
			//that alarm has now been set. Repeat for both AVdd and AVss

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
			else
				range = App.RangeOptions.TWENTY_FOUR_MA;

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.RelaySettle);
		
			//Check for Vdd Compliance
			#region VddCompliance
			alarmBit = 0;

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				idealIout = (App.TC.AVdd - complianceSpec)/ioutLoad;
			else
			{
				idealIout = App.TC.RangeData[(int)range].MaxValue;
				vddSupply = (idealIout * ioutLoad) + complianceSpec;
				Utl.ModifySupplies(vddSupply, App.TC.AVss, App.TC.DVcc);				
			}

			vin = App.TC.MaxInputVoltage * ((idealIout - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));

			HW.Dcs.VOut(PM.VIN, vin);
			App.Time.MsDelay(App.TC.OutputSettle);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Iout Alarm");

			//Measure Iout and verify that it's accurate to 0.01%
			iout = Utl.IoutMeas(resourceSelect);

			foreach(Site site in TP.MS.ActiveSites)
			{
				ioutErrorVdd[site] = ((iout[site] - idealIout)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)) * 100;
			}

			//Now reduce AVdd to known voltage that will cause compliance to be reached.
			vddSupply = idealIout * ioutLoad;
			Utl.ModifySupplies(vddSupply, App.TC.AVss, App.TC.DVcc);
			//Need to delay by 200us before alarm goes off. 
			App.Time.MsDelay(App.TC.IfaultDelay);

			//Check alarm is set
			readback = Utl.ReadAddr(App.TC.DutAddress);
			alarmBit = (readback >> 1) & 0x1;

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(alarmBit[site] != 1)
					ioutAlarm[site]++;

				//Check fault pin assuming 10k pullup to DVcc
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
				if(!passFail[site])
				{
					faultPinFunc[site]++;
					ioutAlarm[site]++;
				}
			}
			//Return supplies to normal
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);

			#endregion

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Check for Vss Compliance
				#region VssCompliance
				alarmBit = 0;

				if(App.Globals.GenericType == App.GenericType.LV_GEN)
					idealIout = (App.TC.AVss + complianceSpec)/ioutLoad;
				else
				{
					idealIout = App.TC.RangeData[(int)range].MinValue;
					vssSupply = (idealIout * ioutLoad) - complianceSpec;
					Utl.ModifySupplies(vssSupply, App.TC.AVss, App.TC.DVcc);				
				}

				vin = App.TC.MaxInputVoltage * ((idealIout - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
				HW.Dcs.VOut(PM.VIN, vin);
				App.Time.MsDelay(App.TC.OutputSettle);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Iout Alarm");

				//Measure Iout and verify that it's accurate to 0.01%
				iout = Utl.IoutMeas(resourceSelect);

				foreach(Site site in TP.MS.ActiveSites)
				{
					ioutErrorVss[site] = ((iout[site] - idealIout)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)) * 100;
				}

				//Now reduce AVss to known voltage that will cause compliance to be reached.
				vssSupply = idealIout * ioutLoad;
				Utl.ModifySupplies(App.TC.AVdd, vssSupply, App.TC.DVcc);
				//Need to delay by 200us before alarm goes off. 
				App.Time.MsDelay(App.TC.IfaultDelay);

				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
				App.Time.MsDelay(App.TC.OutputSettle);

				//Check alarm is set
				readback = Utl.ReadAddr(App.TC.DutAddress);
				alarmBit = (readback >> 1) & 0x1;

				foreach(Site site in TP.MS.ActiveSites)
				{
					if(alarmBit[site] != 1)
						ioutAlarm[site]++;

					//Check fault pin with 2.5mA load on pin
					Utl.RunPattern(DP.checkFaultCond);
					passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
					if(!passFail[site])
					{
						fault2mA5Func[site]++;
						ioutAlarm[site]++;
					}
				}

				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
				App.Time.MsDelay(App.TC.OutputSettle);

				//Return supplies to normal
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);

				//Reset Vin to 0V
				HW.Dcs.VOut(PM.VIN, 0.0);
				#endregion
			}

			#endregion

			App.Test[IDs.PecFaultFunc].Result = pecAlarm;
			App.Test[IDs.OverTempFaultFunc].Result = tempAlarm;

			App.Test[IDs.IFaultFunc].Result = ioutAlarm;
			App.Test[IDs.ComplFuncAvdd].Result = ioutErrorVdd;
			App.Test[IDs.ComplFuncAvss].Result = ioutErrorVss;

			App.Test[IDs.SwFaultPinFunc].Result = faultPinFunc;	
			App.Test[IDs.SwFault2mA5Func].Result = fault2mA5Func;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
		}
		#endregion
	}// end of class AlarmFunc
	#endregion

	//
	// IoutCompl Test Function
	//
	#region IoutCompl                       :
	/// <summary>
	/// This test finds Iout Compl threshold
	/// </summary>
	public class IoutCompl : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region IoutCompl                       :
		public IoutCompl()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt ioutAlarm = 0, 
				faultPinFunc = 0,
				fault2mA5Func = 0,
				tempAlarm = 0, 
				pecAlarm = 0;
			int writeWord, pecWord, wordWithPec;
			App.RangeOptions range;
			MsInt readback, alarmBit = 0;
			MsBool passFail = false; 
			MsDouble vddComplianceVoltage = 0.0, vssComplianceVoltage = 0.0, vout = 0.0,
				vddAlrmDeltaIoutFSR = 0.0, vssAlrmDeltaIoutFSR = 0.0,
				vddIout = 0.0, vssIout = 0.0,
				vin = 0.0, idealIout= 0.0,
				idealIoutVdd = 0.0, idealIoutVss = 0.0,
				vddSupply = 16.0, vssSupply = -16.0,
				vddStart = 0.0, vssStart = 0.0;
			double volSpec10k = 0.4,
				volSpec2mA5 = 0.6,
				guardband = 100.0e-3,
				complianceSpec = 2.75, 
				complianceAllow = 0.5,
				voltageStep = 0.050,
				pullupVoltage;
			double loadCurrent = App.TC.DVcc / 10.0e3;

			if(App.Globals.CharTestingEnable)
				HW.Dmm.Integration(PM.DMM, 0.020);

			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.FIVE_V_BIP;
			else
				range = App.RangeOptions.FIVE_V;

			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			//Ensure fault pin has correct pull-up
			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));

			//1. Verify PEC fault detection
			#region PECfault			
			//construct 16 bit word and generate pec word. 
			//Adjust pec word so that incorrect word is appended to write word
			writeWord = (App.TC.DutAddress << 13 ) + (App.TC.RangeData[(int)range].ProgBits << 7) + 
				((int)App.ClearMode.CLR_TO_ZERO << 6) + ((int)App.OutputEn.OP_ENABLE << 5) + 
				((int)App.ClearEn.NO_CLEAR << 4) + ((int)App.ResSel.R_INT << 3) + ((int)App.SoftResetEn.NO_RESET << 2);        
			pecWord = Utl.CalculatePecWord(writeWord);
			pecWord = (pecWord << 1);
			wordWithPec = (writeWord << 8) + pecWord;

			//Write 24 bit word, readback status register and extract PEC error bit
			Utl.write24Bits(wordWithPec);

			//Check fault pin assuming 10k pullup to DVcc
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					faultPinFunc[site]++;
					pecAlarm[site]++;
				}
			}

			//Readback also clears alarm state
			readback = Utl.ReadAddr(App.TC.DutAddress);
			alarmBit = (readback >> 3) & 0x1;

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(alarmBit[site] != 1)
					pecAlarm[site]++;
			}
			#endregion

			//2. Verify Over Temp fault detection
			#region OverTempFault
			//Enter testmode, enable temp shutdown mode using tmux and check fault pin
			//Note: Not possible to read status register in test mode.
			Utl.EnterTM();
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, (int)App.TmuxBits.TEMP_SHUTDOWN_EN);

			//Check fault pin assuming 2.5mA load on Fault pin
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);

			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					fault2mA5Func[site]++;
					tempAlarm[site]++;
				}
			}

			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);

			//Reset fault by writing 0 to TMux register
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, 0);
			Utl.RunPattern(DP.hw_reset);
			#endregion
			
			// Verify Iout Open Circuit Fault
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			//Set Iout to drop across 2.1K resistor. Set Iout to generate ideal voltage of Vdd - 2V
			//at top of 2.1k. Drop supply by 100mV at a time until Iout degenerates by 0.01%. 
			// -> alarm should be set

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
			else
				range = App.RangeOptions.TWENTY_FOUR_MA;

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.OutputSettle);
		
			//Check for Vdd Compliance
			#region VddCompliance
			alarmBit = 0;

			foreach(Site site in TP.MS.ActiveSites)
			{
				if((App.TC.AVdd > 14.0) || (App.TC.AVss < -14.0))
				{
					idealIout[site] = (App.TC.AVdd - (complianceSpec + complianceAllow))/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
					if(idealIout[site] > App.TC.RangeData[(int)range].MaxValue)
					{
						idealIout[site] = App.TC.RangeData[(int)range].MaxValue;
						vddSupply[site] = (idealIout[site] * (App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site])) + (complianceSpec + complianceAllow);
					}
					else
						vddSupply[site] = App.TC.AVdd;

					vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
				}
				else
				{
					idealIout[site] = App.TC.AVdd/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
					vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
					vddStart[site] = App.TC.AVdd + (complianceSpec + complianceAllow);
				}

				Utl.ModifySupplies(vddSupply[site], App.TC.AVss, App.TC.DVcc);

				HW.Dcs.VOut(PM.VIN, vin[site]);
				App.Time.MsDelay(App.TC.OutputSettle);
			}

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Iout Alarm");

			//Need to set ideal value to actual value at correct Vdd.
			idealIoutVdd = Utl.IoutMeas(resourceSelect);

			foreach(Site site in TP.MS.ActiveSites)
			{
				while((alarmBit[site] != 1) && (vddSupply > 0.0))
				{
					vddSupply[site] = vddSupply[site] - voltageStep;
					Utl.ModifySupplies(vddSupply, App.TC.AVss, App.TC.DVcc);
					//Need to delay by 200us (min) before alarm goes off. 
					App.Time.MsDelay(App.TC.IfaultDelay);

					//Check alarm is set
					readback = Utl.ReadAddr(App.TC.DutAddress);
					alarmBit = (readback >> 1) & 0x1;
				}

				if(alarmBit[site] != 1)
					ioutAlarm[site]++;

				//Measure current after alarm has gone off
				vddIout = Utl.IoutMeas(resourceSelect);
				vout[site] = vddIout[site] * (App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
				vddComplianceVoltage[site] = vddSupply[site] - vout[site];

				//deltaIoutFSR = (current delta/full scale range)*100
				vddAlrmDeltaIoutFSR[site] = ((vddIout[site] - idealIoutVdd[site])/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;


				//Check fault pin
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
				if(!passFail[site])
				{
					vddSupply[site] = vddSupply[site] - voltageStep;
					Utl.ModifySupplies(vddSupply, App.TC.AVss, App.TC.DVcc);
					//Need to delay by 200us (min) before alarm goes off. 
					App.Time.MsDelay(App.TC.IfaultDelay);
					//Check fault pin
					Utl.RunPattern(DP.checkFaultCond);
					passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);

					if(!passFail[site])
					{
						faultPinFunc[site]++;
						ioutAlarm[site]++;
					}
				}

				//Check fault pin with 2.5mA load on pin
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
				App.Time.MsDelay(App.TC.OutputSettle);

				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
				if(!passFail[site])
				{
					vddSupply[site] = vddSupply[site] - voltageStep;
					Utl.ModifySupplies(vddSupply, App.TC.AVss, App.TC.DVcc);
					//Need to delay by 200us (min) before alarm goes off. 
					App.Time.MsDelay(App.TC.IfaultDelay);
					//Check fault pin
					Utl.RunPattern(DP.checkFaultCond);
					passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);

					if(!passFail[site])
					{
						fault2mA5Func[site]++;
						ioutAlarm[site]++;
					}
				}

				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
				App.Time.MsDelay(App.TC.OutputSettle);
			}

			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			#endregion


			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				//Check for Vss Compliance
				#region VssCompliance
				alarmBit = 0;

				foreach(Site site in TP.MS.ActiveSites)
				{
					if((App.TC.AVdd > 14.0) || (App.TC.AVss < -14.0))
					{
						idealIout[site] = (App.TC.AVss + (complianceSpec + complianceAllow))/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
						if(idealIout[site] < App.TC.RangeData[(int)range].MinValue)
						{
							idealIout[site] = App.TC.RangeData[(int)range].MinValue;
							vssStart[site] = (idealIout[site] * (App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site])) - (complianceSpec + complianceAllow);
						}
						else
							vssStart[site] = App.TC.AVss;

						vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
					}
					else
					{
						idealIout[site] = App.TC.AVss/(App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
						vin[site] = App.TC.MaxInputVoltage * ((idealIout[site] - App.TC.RangeData[(int)range].MinValue)/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
						vssStart[site] = App.TC.AVss - (complianceSpec + complianceAllow);
					}

					vssSupply[site] = vssStart[site];
					Utl.ModifySupplies(App.TC.AVdd, vssSupply[site], App.TC.DVcc);

					HW.Dcs.VOut(PM.VIN, vin[site]);
					App.Time.MsDelay(App.TC.OutputSettle);
				}

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Iout Alarm");

				//Need to set ideal value to actual value at correct Vdd.
				idealIoutVss = Utl.IoutMeas(resourceSelect);

				foreach(Site site in TP.MS.ActiveSites)
				{
					while((alarmBit[site] != 1) && (vssSupply < 0.0))
					{
						vssSupply[site] = vssSupply[site] + voltageStep;
						Utl.ModifySupplies(App.TC.AVdd, vssSupply, App.TC.DVcc);
						//Need to delay by 200us (min) before alarm goes off. 
						App.Time.MsDelay(App.TC.IfaultDelay);

						//Check alarm is set
						readback = Utl.ReadAddr(App.TC.DutAddress);
						alarmBit = (readback >> 1) & 0x1;
					}

					if(alarmBit[site] != 1)
						ioutAlarm[site]++;

					//Measure current after alarm has gone off
					vssIout = Utl.IoutMeas(resourceSelect);
					vout[site] = vssIout[site] * (App.TC.BoardVars.IoutHighRes[site] + App.TC.BoardVars.IoutLowRes[site]);
					vssComplianceVoltage[site] = vssSupply[site] - vout[site];
					vssComplianceVoltage[site] = -vssComplianceVoltage[site];

					//deltaIoutFSR = (current delta/full scale range)*100
					vssAlrmDeltaIoutFSR[site] = ((vssIout[site] - idealIoutVss[site])/(App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue))*100;


					//Check fault pin
					Utl.RunPattern(DP.checkFaultCond);
					passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
					if(!passFail[site])
					{
						faultPinFunc[site]++;
						ioutAlarm[site]++;
					}

					//Check fault pin with 2.5mA load on pin
					HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
					HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
					HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
					App.Time.MsDelay(App.TC.OutputSettle);

					Utl.RunPattern(DP.checkFaultCond);
					passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
					if(!passFail[site])
					{
						fault2mA5Func[site]++;
						ioutAlarm[site]++;
					}

					HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
					HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
					HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
					App.Time.MsDelay(App.TC.OutputSettle);
				}

				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				#endregion
			}


			App.Test[IDs.PecFaultFunc].Result = pecAlarm;
			App.Test[IDs.OverTempFaultFunc].Result= tempAlarm;

			App.Test[IDs.IFaultFunc].Result = ioutAlarm;

			App.Test[IDs.ComplianceVvdd].Result = vddComplianceVoltage;
			App.Test[IDs.IdealIoutVdd].Result = idealIoutVdd;
			App.Test[IDs.VddAlarmIout].Result = vddIout;
			App.Test[IDs.VddCurrAlrmDeltaFSR].Result = vddAlrmDeltaIoutFSR;	

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				App.Test[IDs.ComplianceVvss].Result = vssComplianceVoltage;
				App.Test[IDs.IdealIoutVss].Result = idealIoutVss;
				App.Test[IDs.VssAlarmIout].Result = vssIout;
				App.Test[IDs.VssCurrAlrmDeltaFSR].Result = vssAlrmDeltaIoutFSR;
			}

			App.Test[IDs.SwFaultPinFunc].Result = faultPinFunc;	
			App.Test[IDs.SwFault2mA5Func].Result = fault2mA5Func;

			//Cleanup
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
			Utl.RunPattern(DP.hw_reset);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
			if(App.Globals.CharTestingEnable)
				HW.Dmm.Integration(PM.DMM, 0.002);
		}
		#endregion
	}// end of class IoutCompl
	#endregion

	//
	// VfaultFunc Test Function
	//
	#region VfaultFunc                 :
	/// <summary>
	/// This test checks all alarm modes of the device - verifys both status register and fault pin functionality
	/// </summary>
	public class VfaultFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region VfaultFunc                       :
		public VfaultFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt voutAlarm = 0, 
				faultPinFunc = 0,
				fault2mA5Func = 0;
			App.RangeOptions range;
			MsInt readback, alarmBit = 0;
			MsBool passFail = false;
			MsDouble shortCctCurrPos = 0.0,
				shortCctCurrNeg = 0.0;
			double volSpec10k = 0.4,
				volSpec2mA5 = 0.6,
				guardband = 100.0e-3,
				pullupVoltage;
			double loadCurrent = App.TC.DVcc / 10.0e3;


			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			//Ensure fault pin has correct pull-up
			HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));

			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				//If short cct current > 25mA, supply currents will overrange on 30mA clamp. 
				//Adjust clamp levels to 40mA for this test
				HW.Upc.Gate(PM.HV_SUPPLY1_LO, OpenClose.CLOSE, App.TC.AVdd/2.0, 40.0e-3, App.TC.AvddSlewRate);
				HW.Upc.Gate(PM.HV_SUPPLY1_HI, OpenClose.CLOSE, App.TC.AVdd/2.0, 40.0e-3, App.TC.AvddSlewRate);
			}

			//Verify Vout Short Circuit Faults
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				range = App.RangeOptions.FIVE_V_BIP;
			else
				range = App.RangeOptions.FORTY_V;

			#region posShortCct
			HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);

			//Ensure a voltage range is selected, then switch Vout to pincard and short to ground. 
			//Read back status register and check fault pin
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);

			//Set Vin to Full scale - Vout will try to force to 5.0V
			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);

			HW.Rdc.Set(PM.D15, OpenClose.OPEN);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Short Vout to 0V using PMU
			HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_100_MA);
			HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_100_MA, 0.0);
			App.Time.MsDelay(App.TC.OutputSettle);

			//Need to delay by 30ms before alarm goes off. 
			App.Time.MsDelay(App.TC.VfaultDelay);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Vout Alarm");

			shortCctCurrPos = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);
			shortCctCurrPos = -shortCctCurrPos;

			//Check alarm is set
			readback = Utl.ReadAddr(App.TC.DutAddress);
			alarmBit = readback & 0x1;
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(alarmBit[site] != 1)
					voutAlarm[site]++;
			}

			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					faultPinFunc[site]++;
					voutAlarm[site]++;
				}
			}

			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);

			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
				{
					fault2mA5Func[site]++;
					voutAlarm[site]++;
				}
			}

			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
			App.Time.MsDelay(App.TC.OutputSettle);

			//Reset fault
			HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_200_UA);
			HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
			#endregion

			if(App.Globals.GenericType == App.GenericType.LV_GEN)
			{
				#region negShortCct
				//Set Vin to 0V - Vout will try to force to -5V
				HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);

				//Short Vout to 0V using PMU
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_100_MA);
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_100_MA, 0.0);
				App.Time.MsDelay(App.TC.OutputSettle);

				//Need to delay by 30ms before alarm goes off. 
				App.Time.MsDelay(App.TC.VfaultDelay);

				shortCctCurrNeg = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);
				shortCctCurrNeg = -shortCctCurrNeg;

				//Check fault pin
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(!passFail[site])
					{
						faultPinFunc[site]++;
						voutAlarm[site]++;
					}
				}

				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 2.5e-3);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 2.5e-3);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec2mA5 - guardband));
				App.Time.MsDelay(App.TC.OutputSettle);
				
				//Check fault pin
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.FAULT_TEMP, Dss.Status.PASS);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(!passFail[site])
					{
						fault2mA5Func[site]++;
						voutAlarm[site]++;
					}
				}

				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, loadCurrent);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, loadCurrent);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VOL, (volSpec10k - guardband));
				App.Time.MsDelay(App.TC.OutputSettle);

				//Reset fault
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_200_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
				#endregion
			}


			App.Test[IDs.VFaultFunc].Result = voutAlarm;
			App.Test[IDs.VoutSwFaultPinFunc].Result = faultPinFunc;	
			App.Test[IDs.VoutSwFault2mA5Func].Result = fault2mA5Func;
			App.Test[IDs.ShortCctCurPos].Result = shortCctCurrPos;
			if(App.Globals.GenericType == App.GenericType.LV_GEN)
				App.Test[IDs.ShortCctCurNeg].Result = shortCctCurrNeg;

			//Cleanup
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);
			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			Utl.RunPattern(DP.hw_reset);
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				HW.Upc.Gate(PM.HV_SUPPLY1_LO, OpenClose.CLOSE, App.TC.AVdd/2.0, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
				HW.Upc.Gate(PM.HV_SUPPLY1_HI, OpenClose.CLOSE, App.TC.AVdd/2.0, App.TC.AvddCurrentClamp, App.TC.AvddSlewRate);
			}
			else
				HW.Vi.WriteV(PM.AVDD, App.TC.AVdd);

		}
		#endregion 
	}// end of class VfaultFunc
	#endregion

	#endregion

	//
	//Fuse Blow/Read Test Functions
	//
	#region FuseTests
	//
	// BlowFuses Test Function
	//
	#region BlowFuses                       :
	/// <summary>
	/// Blows all fuses for AD5750/1 trims
	/// </summary>
	public class BlowFuses : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region BlowFuses                       :
		public BlowFuses()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt passFail = 0;
			MsInt gainReadback = 0, 
				offsetReadback = 0, 
				biasReadback = 0,
				tcReadback = 0,
				readback = 0;
			App.RangeOptions range;
			MsInt partId = 0;
			MsDouble hvAvdd = 40.0;

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Blow Fuses");

			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				//Need to power down HVS, disable HV protect cctry so that DVcc can be run from VIF without 10k in series
				Utl.PowerDownDevice();

				//Power up AVdd with HVS and DVcc with VIF
				HW.Dvi.Gate(PM.DVCC, OpenClose.CLOSE);
				HW.Vi.Gate(PM.AVDD, OpenClose.CLOSE);				

				//Ensure decoupling caps are switched in
				HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN);
				//Tie VsenseN to DUTGND & Vout to VsenseP
				HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);

				//Setup AVdd using VIE
				HW.Rdc.Set(PM.RLX08_RELAYS, OpenClose.OPEN);
				Utl.StepSupplyVoltageTo(PM.AVDD, hvAvdd, App.TC.CurrentVdd);
				App.Time.UsDelay(100);
				HW.Rdc.Set(PM.RLX01_RELAYS, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);

				//Set up DVcc
				HW.Dvi.WriteV(PM.DVCC, App.TC.DVcc);
				App.Time.UsDelay(100);

				//Set up Vref
				HW.Dcs.VOut(PM.VREF, App.TC.VRef);
				App.Time.UsDelay(100);
				//Force 0V on Vin initially
				HW.Dcs.VOut(PM.VIN, 0.0);
				App.Time.UsDelay(100);
				//Connect Digital Pins & set up logic levels
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, App.TC.Voh);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, App.TC.Vol);
				HW.Dss.DriverInputSelect(PM.DIG_PINS, Dss.DriveData.DRIVE_PATTERN);
				HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.OUTPUT);

				HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, App.TC.DVcc);

				//AD57571 Note: AVss disconnected as it's internally tied to VsenseN which is tied to DUTGND for the whole test run
				App.TC.CurrentVdd = hvAvdd;
				App.TC.CurrentVss = App.TC.AVss;

				App.TC.CurrentVcc[Site.S1] = App.TC.DVcc;
				App.TC.CurrentVcc[Site.S2] = App.TC.DVcc;
				App.TC.CurrentVcc[Site.S3] = App.TC.DVcc;
				App.TC.CurrentVcc[Site.S4] = App.TC.DVcc;

				//Setup correct timing
				Utl.SetInterfaceTiming(App.TC.Frequency);

				Utl.SetDeviceMode(App.OpMode.SOFTWARE);
				Utl.SetAddressPins(App.TC.DutAddress);

				//Connect outputs to relevant loads/feedback pins
				//VsenseN/Vsensep connection
				HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);

				HW.Rdc.Set(PM.D9, OpenClose.CLOSE);
				HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.CLOSE);
				//Default to 300ohm load
				HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);
			}

			if(App.Globals.FuseBlowEnable && (App.TC.MasterFuse == 0))
			{
				//Increase DVcc to blow voltage level
				if(App.TC.CurrentVcc != App.TC.FuseV)
				{   
					Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
					HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
					App.Time.MsDelay(10);
				}

				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits,
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				//Device ID Trims
				//0x1000 to specify wafer map fuses of memory block
				foreach(Site site in TP.MS.ActiveSites)
				{
					partId[site] = 0x1000 + App.TC.DeviceId[site];
				}

				Utl.BlowFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlowBlockBits.WAFER_BLOCK, partId);
				//Miscellaneous Trims
				Utl.BlowFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlowBlockBits.WAFER_BLOCK, App.TC.TcTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlowBlockBits.BIAS_BLOCK, App.TC.IbiasTrimCode);

				//Voltage Range Trims
				range = App.RangeOptions.FIVE_V;
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

				range = App.RangeOptions.TEN_V;
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					range = App.RangeOptions.FIVE_V_BIP;
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

					range = App.RangeOptions.TEN_V_BIP;
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);
				}
				if(App.Globals.GenericType == App.GenericType.HV_GEN)
				{
					range = App.RangeOptions.FORTY_V;
					Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].ExtGainTrimCode);
					Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].ExtOffsetTrimCode);
				}

				//Current Range Trims
				range = App.RangeOptions.FOUR_TWENTY_MA;
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].ExtGainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].ExtOffsetTrimCode);


				range = App.RangeOptions.TWENTY_MA;
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].ExtGainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].ExtOffsetTrimCode);


				range = App.RangeOptions.TWENTY_FOUR_MA;
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].ExtGainTrimCode);
				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].ExtOffsetTrimCode);


				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					range = App.RangeOptions.TWENTY_MA_BIP;
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

					Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].ExtGainTrimCode);
					Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].ExtOffsetTrimCode);


					range = App.RangeOptions.TWENTY_FOUR_MA_BIP;
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].GainTrimCode);
					Utl.BlowFuseMem(App.ResSel.R_INT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].OffsetTrimCode);

					Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.GAIN_BLOCK, App.TC.RangeData[(int)range].ExtGainTrimCode);
					Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.OFFSET_BLOCK, App.TC.RangeData[(int)range].ExtOffsetTrimCode);
				}

				//Return DVcc to normal operating voltage
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);


				//Readback all locations to verify that they have been blown correctly
				
				//Check part ID
				readback = Utl.ReadFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlockBits.WAFER_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(readback[site] != App.TC.DeviceId[site])
						passFail[site]++;
				}

				//Check miscellaneous data
				readback = Utl.ReadFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlockBits.BIAS_BLOCK);
				biasReadback = readback & 0xF;
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(biasReadback[site] != App.TC.IbiasTrimCode[site])
						passFail[site]++;
				}

				tcReadback = (readback >> 4) & 0x3;
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(tcReadback[site] != App.TC.TcTrimCode[site])
						passFail[site]++;
				}

				//Check low voltage range programming
				for(range = App.RangeOptions.FIVE_V; range < App.RangeOptions.SIX_V; range++)
				{
					gainReadback = Utl.ReadFuseMem(App.ResSel.R_INT, range, App.BlockBits.GAIN_BLOCK);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(gainReadback[site] != App.TC.RangeData[(int)range].GainTrimCode[site])
							passFail[site]++;
					}

					offsetReadback = Utl.ReadFuseMem(App.ResSel.R_INT, range, App.BlockBits.OFFSET_BLOCK);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(offsetReadback[site] != App.TC.RangeData[(int)range].OffsetTrimCode[site])
							passFail[site]++;
					}

					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Gain Trim Code: {1}", App.TC.RangeData[(int)range].RangeName, App.TC.RangeData[(int)range].GainTrimCode);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Offset Trim Code: {1}", App.TC.RangeData[(int)range].RangeName, App.TC.RangeData[(int)range].OffsetTrimCode);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");

					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Gain Code Readback: {1}", App.TC.RangeData[(int)range].RangeName, gainReadback);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Offset Code Readback: {1}", App.TC.RangeData[(int)range].RangeName, offsetReadback);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");
				}

				//Check 40V programming
				range = App.RangeOptions.FORTY_V;
				gainReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.GAIN_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(gainReadback[site] != App.TC.RangeData[(int)range].ExtGainTrimCode[site])
						passFail[site]++;
				}

				offsetReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.OFFSET_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(offsetReadback[site] != App.TC.RangeData[(int)range].ExtOffsetTrimCode[site])
						passFail[site]++;
				}

				//Check Current range programming
				for(range = App.RangeOptions.FOUR_TWENTY_MA; range < App.RangeOptions.THREE_TWENTY_MA; range++)
				{
					gainReadback = Utl.ReadFuseMem(App.ResSel.R_INT, range, App.BlockBits.GAIN_BLOCK);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(gainReadback[site] != App.TC.RangeData[(int)range].GainTrimCode[site])
							passFail[site]++;
					}

					offsetReadback = Utl.ReadFuseMem(App.ResSel.R_INT, range, App.BlockBits.OFFSET_BLOCK);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(offsetReadback[site] != App.TC.RangeData[(int)range].OffsetTrimCode[site])
							passFail[site]++;
					}

					gainReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.GAIN_BLOCK);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(gainReadback[site] != App.TC.RangeData[(int)range].ExtGainTrimCode[site])
							passFail[site]++;
					}

					offsetReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.OFFSET_BLOCK);
					foreach(Site site in TP.MS.ActiveSites)
					{
						if(offsetReadback[site] != App.TC.RangeData[(int)range].ExtOffsetTrimCode[site])
							passFail[site]++;
					}

					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Gain Trim Code: {1}", App.TC.RangeData[(int)range].RangeName, App.TC.RangeData[(int)range].GainTrimCode);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Offset Trim Code: {1}", App.TC.RangeData[(int)range].RangeName, App.TC.RangeData[(int)range].OffsetTrimCode);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");

					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Gain Code Readback: {1}", App.TC.RangeData[(int)range].RangeName, gainReadback);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral, "Range: {0}, Offset Code Readback: {1}", App.TC.RangeData[(int)range].RangeName, offsetReadback);
					TP.Console.WriteLineIf(App.Globals.VerbosityGeneral,"");
				}
			}

			Utl.RunPattern(DP.hw_reset);


			//For the HV part, need to power back up using HVS 
			if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				MsDouble zeroVolts = 0.0;

				//Connect Digital Pins & set up logic levels
				HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.DISCONNECT);
				//Force 0V on Vin
				HW.Dcs.VOut(PM.VIN, zeroVolts);
				App.Time.UsDelay(100);
				//Set Vref to 0V
				HW.Dcs.VOut(PM.VREF, zeroVolts);
				App.Time.UsDelay(100);

				//Set DVcc to 0V
				foreach(Site site in TP.MS.SerialLoop)
				{
					if(App.TC.CurrentVcc[site] != 0.0)
					{
						HW.Dvi.WriteV(PM.DVCC, App.TC.DVcc/2.0);
						App.Time.UsDelay(100);
					}
				}
				HW.Dvi.WriteV(PM.DVCC, zeroVolts);
				App.Time.UsDelay(100);

				//Set AVdd = 0.0
				if(App.Globals.GenericType == App.GenericType.LV_GEN)
				{
					//Setup AVdd using VIE
					Utl.StepSupplyVoltageTo(PM.AVDD, zeroVolts, App.TC.CurrentVdd);
					App.Time.UsDelay(100);
				}

				App.TC.CurrentVdd[Site.S1] = (double)zeroVolts;
				App.TC.CurrentVdd[Site.S2] = (double)zeroVolts;
				App.TC.CurrentVdd[Site.S3] = (double)zeroVolts;
				App.TC.CurrentVdd[Site.S4] = (double)zeroVolts;

				App.TC.CurrentVss[Site.S1] = (double)zeroVolts;
				App.TC.CurrentVss[Site.S2] = (double)zeroVolts;
				App.TC.CurrentVss[Site.S3] = (double)zeroVolts;
				App.TC.CurrentVss[Site.S4] = (double)zeroVolts;

				App.TC.CurrentVcc[Site.S1] = (double)zeroVolts;
				App.TC.CurrentVcc[Site.S2] = (double)zeroVolts;
				App.TC.CurrentVcc[Site.S3] = (double)zeroVolts;
				App.TC.CurrentVcc[Site.S4] = (double)zeroVolts;

				//Setup relays correctly
				HW.Rdc.Set(PM.D3, OpenClose.OPEN);
				HW.Rdc.Set(PM.D7, OpenClose.OPEN);
				HW.Rdc.Set(PM.D6, OpenClose.OPEN);

				//Open VI gates
				HW.Dvi.Gate(PM.DVCC, OpenClose.OPEN);
				HW.Vi.Gate(PM.AVDD, OpenClose.OPEN);
				HW.Vi.Gate(PM.AVSS, OpenClose.OPEN);

				//Now powerup Device as normal
				Utl.PowerUpDevice();
				Utl.SetDeviceMode(App.OpMode.SOFTWARE);
				Utl.SetAddressPins(App.TC.DutAddress);

				//Connect outputs to relevant loads/feedback pins
				//VsenseN/Vsensep connection
				HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);

				HW.Rdc.Set(PM.D9, OpenClose.CLOSE);
				HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.CLOSE);
				//Default to 300ohm load
				HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);
			}

			App.Test[IDs.BlowFuseMem].Result = passFail;
		}
		#endregion
	}// end of class BlowFuses
	#endregion


	//
	// BlowCoor Test Function
	//
	#region BlowCoordinates                       :
	/// <summary>
	/// Blows all fuses for AD5750/1 trims
	/// </summary>
	public class BlowCoor : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region BlowCoor                       :
		public BlowCoor()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt passFail = 0;
			MsInt biasReadback = 0,
					tcReadback = 0,
					readback = 0;

			MsInt gainReadback = 0, 
				offsetReadback = 0;

			double PassFailCoordinates = 0;

			App.RangeOptions range;
			MsInt partId = 0;
			MsDouble hvAvdd = 40.0;

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Blow Fuses");

			
			if((App.TC.BlowXcoordinates)&&(App.TC.BlowYcoordinates)&&(App.TC.MasterFuse == 0))
			{
				//Increase DVcc to blow voltage level
				if(App.TC.CurrentVcc != App.TC.FuseV)
				{   
					Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
					HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
					App.Time.MsDelay(10);
				}

				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits,
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
					App.ResSel.R_INT, App.SoftResetEn.NO_RESET);


				//getting coordinates from tester and writing them to memory
				int memory_offsetCode = 0;
				int memory_gainCode = 0;


				#region Coordinates

//				App.TC.xCoord = Convert.ToInt32(App.TC.xCoordinate);
//				App.TC.yCoord = Convert.ToInt32(App.TC.yCoordinate);
//				App.TC.waf_no = Convert.ToInt32(App.TC.Wafer_no);
					
			
				App.TC.xCoord = TP.Part[Site.S1].PartDetails.WaferXCoord;
				App.TC.yCoord = TP.Part[Site.S1].PartDetails.WaferYCoord;
			
				if ((App.TC.xCoord<10) || (App.TC.xCoord>100) || (App.TC.yCoord<10) || (App.TC.yCoord>100))
				{	
					PassFailCoordinates++;
				}

				#endregion

				#region Wafer no

				int index = 0;
				int wafer_read_error = 0;
				int wafer_match_error = 0;

				int wafer_no_from_file = 0;
				int wafer_no = 0;

				int get_wafer_number = 1;
				const int max_len = 20;

				string filename = "File OpenClose.OPEN ... ";

				// reading wafer information file
			

				// getting the wafer no from file
				if (get_wafer_number != 0)
				{
					//TP.Console.WriteLine("Trying to open file for reading... ");

					using (System.IO.StreamReader dataFile = new System.IO.StreamReader(@"Q:\wafernum"))
					{
						TP.Console.WriteLine("File OpenClose.OPEN ... ");
						wafer_no_from_file = int.Parse(dataFile.ReadLine());
						//TP.Console.WriteLine("\nWafer number from file {0}: ", wafer_no_from_file);

					}
				}
				
				// getting the wafer number from system
				if (get_wafer_number != 0)
				{
					index = 0;

					while ( (TP.SubLot.Details.ID[index]!='-') && (index<max_len-2) )
					{
						index++;
					}

					if ( index < max_len-3 )
					{
						wafer_no = int.Parse(TP.SubLot.Details.ID.Substring(index +1, 2));
						if((wafer_no<1) || (wafer_no>25))
						{
							// Error reading wafer number
							wafer_read_error++;
							TP.Console.WriteLine("Error reading wafer numer");
						}
						else
						{
							//TP.Console.WriteLine("Wafer number OK!!1");
						}
					}

					// Check if wafer number read from file match waver number read from system

					// Print data to screen
					//TP.Console.WriteLine("\nWafer number from FILE {0}: ", wafer_no_from_file);
					//TP.Console.WriteLine("Wafer number from SYSTEM {0}: ", wafer_no);

					// Check if wafer number and file wafer number are the same
					if (wafer_no != wafer_no_from_file)
					{
						// Do not write to device
						wafer_match_error++;
						TP.Console.AskConfirm("\nWafer Number on Tester does not match Wafer Number on Integrator \n\nPlease do the following: \n * Press STOP button on Integrator \n * Select [OK] on this Prompt \n * Abort the lot on Integrator and discard the Wafer map \n * Reload the Program and Restart the current Wafer. \n\n");
					}

				}

				App.TC.waf_no = wafer_no;

				#endregion


				memory_gainCode = App.TC.xCoord;
				memory_offsetCode = App.TC.waf_no + (App.TC.yCoord<<5);
				
				range = App.RangeOptions.FORTY_V;
				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.GAIN_BLOCK, memory_gainCode);
				Utl.BlowFuseMem(App.ResSel.R_EXT, range, App.BlowBlockBits.OFFSET_BLOCK, memory_offsetCode);


				//Return DVcc to normal operating voltage
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);


				//Check 40V programming
				range = App.RangeOptions.FORTY_V;
				gainReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.GAIN_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(gainReadback[site] != memory_gainCode)
						passFail[site]++;
				}

				offsetReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.OFFSET_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(offsetReadback[site] != memory_offsetCode)
						passFail[site]++;
				}

				App.TC.xCoord = 0;
				App.TC.yCoord = 0;
				App.TC.waf_no = 0;

				App.TC.xCoord = gainReadback[Site.S1];
				App.TC.yCoord = (offsetReadback[Site.S1]/32);
				App.TC.waf_no = offsetReadback[Site.S1] - (32*App.TC.yCoord);
						


			}

			Utl.RunPattern(DP.hw_reset);


			App.Test[IDs.X_Coordinate].Result = App.TC.xCoord;
			App.Test[IDs.Y_Coordinate].Result = App.TC.yCoord;
			App.Test[IDs.Wafer_number].Result = App.TC.waf_no;

			App.Test[IDs.PassFailCoordinates].Result = PassFailCoordinates;
			
			App.Test[IDs.BlowCoordinatesMem].Result = passFail;

		}
		#endregion

	}// end of class BlowCoor
	#endregion


	
	//
	// BlowCoor Test Function
	//
	#region ReadCoordinates                       :
	/// <summary>
	/// Blows all fuses for AD5750/1 trims
	/// </summary>
	public class ReadCoordinates : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region ReadCoordinates                       :
		public ReadCoordinates()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{

			MsInt gainReadback = 0;
			MsInt offsetReadback = 0;

			App.RangeOptions range;
			App.TC.ReadxCoord = 0;
			App.TC.ReadyCoord = 0;
			App.TC.Readwaf_no = 0;
			

			Utl.EnterTM();
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits,
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);


			//Check 40V programming
			range = App.RangeOptions.FORTY_V;


			gainReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.GAIN_BLOCK);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(gainReadback[site] != 0)
					App.TC.BlowXcoordinates = false;
			}

			offsetReadback = Utl.ReadFuseMem(App.ResSel.R_EXT, range, App.BlockBits.OFFSET_BLOCK);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(offsetReadback[site] != 0)
				{
				App.TC.BlowYcoordinates = false;
				App.TC.BlowWaferNo = false;
				}
				
			}

			App.TC.ReadxCoord = gainReadback[Site.S1];
			App.TC.ReadyCoord = (offsetReadback[Site.S1]/32);

			if(App.TC.ReadyCoord != 0)
			App.TC.Readwaf_no = offsetReadback[Site.S1] - (32*App.TC.ReadyCoord);
			else
				App.TC.Readwaf_no = 0;
					
			Utl.RunPattern(DP.hw_reset);

			
			#region Bin Results
			App.Test[IDs.Read_X_Coordinate].Result = App.TC.ReadxCoord;
			App.Test[IDs.Read_Y_Coordinate].Result = App.TC.ReadyCoord;
			App.Test[IDs.Read_Wafer_number].Result = App.TC.Readwaf_no;
			#endregion

		
		}
		#endregion

	}// end of class BlowCoor
	#endregion


	//
	// MasterFuseBlow Test Function
	//
	#region MasterFuseBlow                  :
	/// <summary>
	/// Function to blow master fuse and to verify fuse blow
	/// </summary>
	public class MasterFuseBlow : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region MasterFuseBlow                  :
		public MasterFuseBlow()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt readback = 0, masterFuse = 0, 
				spareFuse = 0;
			MsInt passFail = 0;

			if(App.Globals.FuseBlowEnable && (App.TC.MasterFuse == 0))
			{
				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("Master Fuse Blow");

				Utl.BlowMasterFuse();

				Utl.RunPattern(DP.hw_reset);
				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				//Readback masterfuse
				readback = Utl.ReadFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlockBits.BIAS_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					masterFuse[site] = (readback[site] >> 9) & 0x1;
					if(masterFuse[site] != 1)
						passFail[site]++;
				}

				//Attempt to blow another fuse location to verify no more locations can be blown.
				//Increase DVcc to blow voltage level
				if(App.TC.CurrentVcc != App.TC.FuseV)
				{   
					Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
					HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
					App.Time.MsDelay(10);
				}

				Utl.RunPattern(DP.hw_reset);
				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				Utl.BlowFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlowBlockBits.WAFER_BLOCK, 0x18);
				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);

				readback = Utl.ReadFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlockBits.BIAS_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					spareFuse[site] = (readback[site] >> 7) & 0x3;
					if(spareFuse[site] != 0)
						passFail[site]++;
				}

				Utl.RunPattern(DP.hw_reset);
			}
		
			App.Test[IDs.BlowMasterFuse].Result = passFail;
		}
		#endregion
	}// end of class MasterFuseBlow
	#endregion

	//
	// Blow5751Fuse Test Function
	//
	#region Blow5751Fuse                    :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class Blow5751Fuse : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region Blow5751Fuse                    :
		public Blow5751Fuse()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt readback, highVoltageBit = 0;
			MsInt passFail = 0;

			if(App.Globals.FuseBlowEnable && (App.TC.MasterFuse == 0))
			{
				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("5751 Fuse Blow");

				//Increase DVcc to blow voltage level
				if(App.TC.CurrentVcc != App.TC.FuseV)
				{   
					Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.FuseV);
					HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_250_MA);
					App.Time.MsDelay(10);
				}

				//Enter Test Mode
				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				Utl.BlowFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlowBlockBits.WAFER_BLOCK, 0x4);

				Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);

				Utl.RunPattern(DP.hw_reset);
				Utl.EnterTM();
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, App.ClearMode.CLR_TO_ZERO, 
					App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

				//Readback 5751 fuse bit
				readback = Utl.ReadFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlockBits.BIAS_BLOCK);
				foreach(Site site in TP.MS.ActiveSites)
				{
					highVoltageBit[site] = (readback[site] >> 6) & 0x1;
					if(highVoltageBit[site] != 1)
						passFail[site]++;
				}

				Utl.RunPattern(DP.hw_reset);
			}
		
			App.Test[IDs.BlowHighVoltage].Result = passFail;
		}
		#endregion
	}// end of class Blow5751Fuse
	#endregion

	//
	// MasterFuseRead Test Function
	//
	#region MasterFuseRead                  :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class MasterFuseRead : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region MasterFuseRead                  :
		public MasterFuseRead()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt masterFuse = 0, readback = 0;

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Master Fuse Read");

			//Readback masterfuse
			readback = Utl.ReadFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlockBits.BIAS_BLOCK);
			masterFuse = (readback >> 9) & 0x1;

			App.TC.MasterFuse = masterFuse;

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(App.TC.MasterFuse[site] == 1)
					App.TC.BlowFuses = false;
			}
			App.Test[IDs.readMasterFuse].Result = masterFuse;
		}
		#endregion
	}// end of class MasterFuseRead
	#endregion

	//
	// DeviceID Test Function
	//
	#region DeviceID                        :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class DeviceID : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region DeviceID                        :
		public DeviceID()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			//ulong timeStamp = 0;
			//MsInt sumCodes = 0, checkSum = 0;
			//int i;
			MsInt partId = 0;

			//timeStamp = TP.Time.GetHrTime();
			
			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Device ID");

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(App.TC.MasterFuse[site] == 1)
					partId = Utl.ReadFuseMem(App.ResSel.R_INT, App.RangeOptions.FIVE_V, App.BlockBits.WAFER_BLOCK);
				else
					partId[site] = App.TC.DeviceId[site];
			}


			//Calculate checksum value by adding all possible range trim codes 
			//Invert sum value and return as 11bit number
			//foreach(Site site in TP.MS.ActiveSites)
			//{
				
			//for(i = 0; i < 18; i++)
			//{
			//sumCodes[site] = sumCodes[site] + App.TC.RangeData[i].OffsetTrimCode[site] + App.TC.RangeData[i].GainTrimCode[site] + 
			//App.TC.RangeData[i].ExtOffsetTrimCode[site] + App.TC.RangeData[i].ExtGainTrimCode[site];
			//}

			//checkSum[site] = ~(sumCodes[site]);
			//checkSum[site] = checkSum[site] & 0xFF;
			//}
			App.Test[IDs.DeviceID].Result = partId;
		}
		#endregion
	}// end of class DeviceID
	#endregion

	#endregion

	//
	//Ibias + all internal nodes measure tests.
	//
	#region Test Mode Tests
	//
	// VgenVoltages Test Function
	//
	#region VgenVoltages                    :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class VgenVoltages : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region VgenVoltages                    :
		public VgenVoltages()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble vgen5V = 0.0; 
			MsDouble vgen7V = 0.0;

			App.MeasOptions resourceSelect = App.MeasOptions.DMM;

			// to avoid hot socket relay switching
			HW.Dss.ConnectionSet(PM.NC_IFAULT, Dss.ConnectionMode.DISCONNECT);

			//Switch test mode pin Ifault to measure mux
			//RLX21 = D21,D34,D46,D58
			HW.Rdc.Set(PM.RLX21_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Enter testmode and switch out vgen5V and measure
			Utl.EnterTM();
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, 
				App.ResSel.R_INT, 0x0, (int)App.TmuxBits.VGEN_5V);
			App.Time.MsDelay(App.TC.OutputSettle);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Vgen Voltages");
				
			vgen5V = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, resourceSelect);

			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits,
				App.ResSel.R_INT, 0x0, (int)App.TmuxBits.VGEN_7V);
			App.Time.MsDelay(App.TC.OutputSettle);

			
			vgen7V = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, resourceSelect);
		

			App.Test[IDs.Vgen5V].Result = vgen5V;
			App.Test[IDs.Vgen7V].Result = vgen7V;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);

			//if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			HW.Rdc.Set(PM.RLX21_RELAYS, OpenClose.OPEN);

		}
		#endregion
	}// end of class VgenVoltages
	#endregion

	//
	// InternalNodes Test Function
	//
	#region InternalNodes                   :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class InternalNodes : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region InternalNodes                   :
		public InternalNodes()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble vinMeas = 0.0, vinBufOp = 0.0, vinBufOffset = 0.0,
				vrefMeas = 0.0, vrefBufOp = 0.0, vrefBufOffset = 0.0,
				vofsDac = 0.0, vofsIp = 0.0, vofsBufOffset = 0.0,
				vDacV = 0.0, //vinNeg = 0.0, opBufVinOffset = 0.0,
				//OpBufVofsIp = 0.0,
				vDacI = 0.0,
				vRef2 = 0.0, vToItestpoint1 = 0.0, VtoIobufOffset = 0.0;
			double setVin = 2.0;
			App.RangeOptions vRange = App.RangeOptions.TEN_V,
				iRange = App.RangeOptions.TWENTY_MA;
			
			//Change Dmm integration time for duration of this test
			HW.Dmm.Integration(PM.DMM, 0.02);

			//Configure the device in 0 - 10V range with Vin = 2.0V
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			HW.Dcs.VOut(PM.VIN, setVin);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Internal Nodes");

			//Measure Vin & Vref
			vrefMeas = Utl.MeasureNode(App.MuxNodes.VREF_MEAS, App.MeasOptions.DMM);
			vinMeas = Utl.MeasureNode(App.MuxNodes.VIN_MEAS, App.MeasOptions.DMM);

			//Switch test mode pin Ifault to measure mux
			HW.Rdc.Set(PM.RLX21_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Enter testmode and switch out various nodes and measure
			//1. Vin Buffer Offset
			Utl.EnterTM();
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_INT,
				0x0, (int)App.TmuxBits.VIN_OUT);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vinBufOp = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			vinBufOffset = vinBufOp - vinMeas;


			//2. VrefBuffer Offset
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_INT,
				0x0, (int)App.TmuxBits.VREF_OUT);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vrefBufOp = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			vrefBufOffset = vrefBufOp - vrefMeas;


			//3. Vofs Buffer Offset
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_INT,
				0x0, (int)App.TmuxBits.VOFS_DAC_OUT);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vofsDac = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_INT,
				0x0, (int)App.TmuxBits.VOFS_BUF_NEG);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vofsIp = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			vofsBufOffset = vofsDac - vofsIp;
			

			//4. Op Buffer 1Vin Offset
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_INT,
				0x0, (int)App.TmuxBits.V_DAC);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vDacV = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			/*
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_INT,
				0x0, (int)App.TmuxBits.VIN_1V_NEG);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vinNeg = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			opBufVinOffset = vDacV - vinNeg;
			*/

			//5. Op Buffer 1Vofs Offset
			/*
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_INT,
				0x0, (int)App.TmuxBits.VOFF_1V_NEG);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)vRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			OpBufVofsIp = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);
			*/

			HW.Dcs.VOut(PM.VIN, 0.0);

			//Configure the device in 0 - 20mA range with Vin = 2.0V
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)iRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			HW.Rdc.Set(PM.D4, OpenClose.CLOSE);

			HW.Dcs.VOut(PM.VIN, setVin);
			App.Time.MsDelay(App.TC.RelaySettle);

			//6. VtoI Buffer Offset

			//Can't measure Rext1 pad ...
			/*HW.Dvi.VRange(PM.REXT1_RES_MEAS, Dvi.VRanges.V_5_V);
			HW.Dvi.Mode(PM.REXT1_RES_MEAS, Dvi.FMMode.FVMV);
			HW.Dvi.WriteV(PM.REXT1_RES_MEAS, 0.0);
			vRext = HW.Dvi.ReadV(PM.REXT1_RES_MEAS);*/

			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)vRange].ProgBits, App.ResSel.R_EXT,
				0x0, (int)App.TmuxBits.V_DAC);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)iRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vDacI = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			//VtoIbufOffset = vDacI - vRext;

			HW.Dvi.Mode(PM.REXT1_RES_MEAS, Dvi.FMMode.FIMV);
			HW.Dvi.VRange(PM.REXT1_RES_MEAS, Dvi.VRanges.V_20_V);
			
			//7. VtoIo Buffer Offset
			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)iRange].ProgBits, App.ResSel.R_EXT,
				0x0, (int)App.TmuxBits.VREF_DIV_2);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)iRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vRef2 = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			Utl.TmWrite(App.TestModes.TM_TMUX, App.TC.RangeData[(int)iRange].ProgBits, App.ResSel.R_EXT,
				0x0, (int)App.TmuxBits.VTOI_1);
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)iRange].ProgBits, 
				App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			App.Time.MsDelay(App.TC.OutputSettle);
			vToItestpoint1 = Utl.MeasureNode(App.MuxNodes.IFAULT_MEAS, App.MeasOptions.DMM);

			VtoIobufOffset = vToItestpoint1 - vRef2;

			//Cleanup
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.RunPattern(DP.hw_reset);
			HW.Dmm.Integration(PM.DMM, 0.002);
			HW.Rdc.Set(PM.RLX21_RELAYS, OpenClose.OPEN);

			App.Test[IDs.vinMeas].Result = vinMeas;
			App.Test[IDs.vinBufOp].Result = vinBufOp;
			App.Test[IDs.vinBufOffset].Result = vinBufOffset;

			App.Test[IDs.vrefMeas].Result = vrefMeas;
			App.Test[IDs.vrefBufOp].Result = vrefBufOp;
			App.Test[IDs.vrefBufOffset].Result = vrefBufOffset;

			App.Test[IDs.vOfsDac].Result = vofsDac;
			App.Test[IDs.vOfsIp].Result = vofsIp;
			App.Test[IDs.vOfsBufOffset].Result = vofsBufOffset;

			App.Test[IDs.vDacVmode].Result = vDacV;
			//App.Test[IDs.vinNeg].Result = vinNeg;
			//App.Test[IDs.opBufVinOffset].Result = opBufVinOffset;

			//App.Test[IDs.OpBufVofsIp].Result = OpBufVofsIp;

			App.Test[IDs.vDacImode].Result = vDacI;

			App.Test[IDs.Vref_div2].Result = vRef2;
			App.Test[IDs.VtoItestpoint].Result = vToItestpoint1;
			App.Test[IDs.VtoIoBufOffs].Result = VtoIobufOffset;
		}
		#endregion
	}// end of class InternalNodes
	#endregion

	//
	// IbiasTrim Test Function
	//
	#region IbiasTrim                       :
	/// <summary>
	/// Trim function for internal Ibias current
	/// </summary>
	public class IbiasTrim : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region IbiasTrim                       :
		public IbiasTrim()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double targetCurr = 30.0e-6;
			MsDouble preTrimCurr = 0.0, 
				zsCurr = 0.0, fsCurr,
				postTrimCurr = 0.0;
			MsInt trimCode = 0, origCode = 0, tempCode = 0, tcTrimCode = 0;
			int numTrimBits = 4;
			int code;
			double fsCode, msCode, zsCode;
			App.RangeOptions range = App.RangeOptions.FIVE_V;
			MsDouble currError = 0.0, origCurrError = 0.0, trimStep = 0.0;
			MsDouble [] outputArray = MsDouble.CreateArray(16, 0);
			int origNumAvgs = App.Globals.NumPmuAverages;
			MsInt readData = 0;

			App.Globals.NumPmuAverages = 20;

			fsCode = Math.Pow(2, numTrimBits) - 1;
			msCode = Math.Pow(2, numTrimBits) / 2.0;
			zsCode = 0;

			//Need to set Vin to 0V initially to avoid voltage ranges defaulting to unknown values when entering bypass mode
			HW.Dcs.VOut(PM.VIN, 0.0);

			//Set up PMU on Ifault pin to measure Ibias
			HW.Dss.ConnectionSet(PM.NC_IFAULT, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuConnectMode(PM.NC_IFAULT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_200_UA);

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(App.TC.MasterFuse[site] == 1)
				{
					readData = Utl.ReadFuseMem(App.ResSel.R_INT, range, App.BlockBits.BIAS_BLOCK);
					trimCode[site] =  readData[site] & 0xF;
					App.TC.TcTrimCode[site] = (readData[site] >> 4) & 0x3;
				}
				else if(App.TC.MasterFuse[site] == 0)
				{
					Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
						App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
					Utl.EnterTM();
					Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, 
						App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
					//Switch out Ibias to Ifault pin & load MS (8) to bypass register (MS code loads minimum output)
					Utl.TmWrite(App.TestModes.TM_FUSE_BYPASS, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, 0);

					if(App.Globals.PincheckEnable)
						Utl.MeasPinVoltage("Ibias Test");

					Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, (int)msCode);
					preTrimCurr = HW.Dss.PmuRead(PM.NC_IFAULT, App.Globals.NumPmuAverages);
					preTrimCurr[site] = -preTrimCurr[site];
					zsCurr[site] = preTrimCurr[site];

					currError[site] = preTrimCurr[site] - targetCurr;

					//Load zs Code to find maximum output
					Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, (int)zsCode);
					fsCurr = HW.Dss.PmuRead(PM.NC_IFAULT, App.Globals.NumPmuAverages);
					fsCurr[site] = -fsCurr[site];

					trimStep[site] = (fsCurr[site] - zsCurr[site]) /  (fsCode - 1);
					trimCode[site] = (int)Math.Floor((-1 * (currError[site] / trimStep[site])) + 0.5);

					//Code 0 always has the highest Ibias. Code MS always has the min Ibias. Ibias min increases from
					//Code MS to Code FS and then from Code MS - 1 to Code ZS
					//i.e. Current increases in the following code order:
					//8, 9, 10, 11, 12, 13, 14, 15, 7, 6, 5, 4, 3, 2, 1
					if(trimCode[site] > 7)
					{
						tempCode[site] = trimCode[site];
						trimCode[site] = (int)msCode - (tempCode[site] - 7);
					}
					else
						trimCode[site] = (int)msCode + trimCode[site];

					//Load calculated trim code and measure Ibias
					Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, trimCode);

					postTrimCurr = HW.Dss.PmuRead(PM.NC_IFAULT, App.Globals.NumPmuAverages);
					postTrimCurr[site] = -postTrimCurr[site];
					currError[site] = postTrimCurr[site] - targetCurr;

					origCurrError[site] = currError[site];
					origCode[site] = trimCode[site];

					if(((currError[site] > 0) && (trimCode[site] > msCode)) || ((currError[site] < 0) && (trimCode[site] < msCode)))
					{
						trimCode[site]--;
						Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, trimCode);
						postTrimCurr = HW.Dss.PmuRead(PM.NC_IFAULT, App.Globals.NumPmuAverages);
						postTrimCurr[site] = -postTrimCurr[site];
						currError[site] = postTrimCurr[site] - targetCurr;
					}
					else if(((currError[site] < 0) && (trimCode[site] > msCode)) || ((currError[site] > 0) && (trimCode[site] < msCode)))
					{
						trimCode[site]++;
						Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, trimCode);
						postTrimCurr = HW.Dss.PmuRead(PM.NC_IFAULT, App.Globals.NumPmuAverages);
						postTrimCurr[site] = -postTrimCurr[site];
						currError[site] = postTrimCurr[site] - targetCurr;
					}

					if(Math.Abs(currError[site]) > Math.Abs(origCurrError[site]))
					{
						trimCode[site] = origCode[site];
					}

					//Setup Tempco trim code based on Ibias trimcode:
					//During characterisation, it was shown that wafers with high thin film resistivity 
					//had higher Ibias trimcode and also higher tempcos. 
					//Therefore, a different tempco trim code is required depending on the resistivity
					//This is defined by the Ibias trimcode.
					if((trimCode[site] < 13) && (trimCode[site] > 7))
						App.TC.TcTrimCode[site] = 0;
					else if(trimCode[site] > 12)
						App.TC.TcTrimCode[site] = 1;
						//No data for ibias codes <7...possible tempco code 2 required...??
					else if(trimCode[site] < 8)
						App.TC.TcTrimCode[site] = 1;
				}

				Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, trimCode);
			}
			postTrimCurr = HW.Dss.PmuRead(PM.NC_IFAULT, App.Globals.NumPmuAverages);
			postTrimCurr = -postTrimCurr;

			if(App.Globals.DebugEnable)
			{
				for(code = 0; code<16; code++)
				{
					Utl.TmWrite(App.TestModes.TM_BIAS_REG, App.TC.RangeData[(int)range].ProgBits, App.ResSel.R_INT, 0, code);
					outputArray[code] = HW.Dss.PmuRead(PM.NC_IFAULT, App.Globals.NumPmuAverages);
				}
			}

			//Set global variable to correct trim code
			App.TC.IbiasTrimCode = trimCode; 

			App.Test[IDs.IbiasTrimCode].Result = trimCode;
			App.Test[IDs.IbiasPostTrim].Result = postTrimCurr;
			App.Test[IDs.TempcoTrimCode].Result = App.TC.TcTrimCode;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);
			App.Globals.NumPmuAverages = origNumAvgs;
			HW.Dss.PmuConnectMode(PM.NC_IFAULT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_200_UA);
			HW.Dss.ConnectionSet(PM.NC_IFAULT, Dss.ConnectionMode.DISCONNECT);

		}
		#endregion
	}// end of class IbiasTrim
	#endregion

	#endregion

	//
	// DigLevelsFunc Test Function
	//
	#region DigLevelsFunc              :
	/// <summary>
	/// Test checks operation of datasheet input/output digital levels
	/// </summary>
	public class DigLevelsFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region DigLevelsFunc              :
		public DigLevelsFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsInt passFail = 0;
			MsInt readData = 0;
			MsInt pecCheck = 0;

			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);

			int addr = 0x5;
			App.RangeOptions range = App.RangeOptions.FIVE_V;
			double volSpec = 0.4,
				vohSpec = App.TC.DVcc - 0.4,
				vilSpec = 0.8,
				vihSpec = 2.0,
				guardband = 100.0e-3,
				interfaceFreq = 10.0e6;

			double vihLevel = vihSpec,	//No guardband here as some parts fail @-40C with Vih = 1.9V
				vilLevel = vilSpec + guardband, 
				vohLevel = vohSpec + guardband,
				volLevel = volSpec - guardband;
			

			App.MeasOptions resourceSelect = App.MeasOptions.DMM;
			

			//status += adjust_dvcc(5.5);

			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, vihLevel);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, vilLevel);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, vohLevel);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, volLevel);
			HW.Dss.ConnectionSet(PM.SDO_VFAULT, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.SDO_VFAULT, Dss.Control.IOH, 0.0002);
			HW.Dss.ControlValue(PM.SDO_VFAULT, Dss.Control.IOL, 0.0002);
			HW.Dss.ControlValue(PM.SDO_VFAULT, Dss.Control.VTH, ((vohLevel - volLevel)/2));

			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);

			Utl.SetAddressPins(addr);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("Digital Levels");

			//Construct 24 bit write so that word is almost fully checkerboard
			//Since Logic levels are compliant with JEDEC, need to run interface at a slower frequency.
			//Construct another 24 bit write so that word is almost fully inverse checkerboard
			Utl.SetInterfaceTiming(interfaceFreq);
			Utl.write24Bits(addr, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR,
				App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
			readData = Utl.ReadAddr(0x5);

			foreach(Site site in TP.MS.ActiveSites)
			{
				if(readData[site] != 0x2A0)
					passFail[site]++;
			}

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				pecCheck += Utl.TestVout(App.TC.RangeData[(int)range].MaxValue, resourceSelect);
			}

			//Output should be disabled, so tie Vout to gnd via load resistor.
			//If output disabled, Vout will hold at 0V. 
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.OPEN);

			range = App.RangeOptions.TWELVE_V;

			Utl.SetInterfaceTiming(interfaceFreq);
			Utl.write24Bits(addr, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_MID, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
				App.ResSel.R_INT, App.SoftResetEn.NO_RESET);
			readData = Utl.ReadAddr(0x5);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(readData[site] != 0x550)
					passFail[site]++;
			}

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				pecCheck += Utl.TestVout(0.0, resourceSelect);
			}

			//CLEANUP
			HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);
			Utl.SetAddressPins(App.TC.DutAddress);
			Utl.RunPattern(DP.hw_reset);
			
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.OPEN);

			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, App.TC.Voh);
			HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, App.TC.Vol);
		
			HW.Dss.ConnectionSet(PM.SDO_VFAULT, Dss.ConnectionMode.OUTPUT);

			App.Test[IDs.DigLevelFunc].Result = passFail;

			if(App.Globals.ActiveSelector != App.Selectors.AD575x_Probe)
			{
				App.Test[IDs.PecFunc].Result = pecCheck;
			}
		}
		#endregion
	}// end of class DigInputLevelsFunc
	#endregion

	//
	//Hardware Mode Tests
	//
	#region Hardware Mode Tests
	//
	// HWranges Test Function
	//
	#region HWranges                        :
	/// <summary>
	/// Selects & Verifies each range in hardware mode
	/// </summary>
	public class HWranges : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region HWranges                        :
		public HWranges()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			App.RangeOptions range;
			App.ResSel rSel;
			int rangeIndex;
			double vinFs, vinZs, vinMs, 
				idealZs, idealFs, idealMs,
				idealGain;
			MsDouble outZs, outFs, 
				offset = 0.0,
				fsError = 0.0,
				gain = 0.0, 
				gainError = 0.0,
				yIntersect = 0.0;
			MsInt hwTrimRangesCheck = 0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;
			int numSteps = 1000;
			double [] outputArray = new double[numSteps];


			// ** Note ZS is treated as a non-zero value close to the bottom of the transfer function
			// ** to avoid deadband at 0V.
			vinFs = App.TC.MaxInputVoltage;
			vinMs = App.TC.MaxInputVoltage/2;
			vinZs = 0.020;
			
			//********Check all ranges in hardware mode and check for offset/gain********

			//Set Vin to ZS value
			HW.Dcs.VOut(PM.VIN, vinZs);
			App.Time.MsDelay(App.TC.OutputSettle);

			//Ensure output is enabled
			Utl.HWOutputEn(App.OutputEn.OP_ENABLE);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("HW Ranges Test");

			for(rSel = App.ResSel.R_EXT; rSel < (App.ResSel.R_INT + 1); rSel++)
			{
				//Check all ranges with Ext Resistor selected
				for(rangeIndex = 0; rangeIndex < App.TC.NumActiveRanges; rangeIndex++)
				{
					range = App.TC.ActiveRanges[rangeIndex];

					if(App.TC.RangeData[(int)range].RangeAccType == App.RangeAccType.TRIM_RANGE)
					{
						if( ((range == App.RangeOptions.FORTY_V) && (rSel == App.ResSel.R_INT)) ||
							((range == App.RangeOptions.FORTY_V) && (App.TC.AVdd < 44.0)) )
						{
						}
						else
						{		
							if(range == App.RangeOptions.FORTY_V)
								HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.CLOSE);

							idealMs = App.TC.RangeData[(int)range].MinValue + (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue)/2;

							if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
							{
								HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
							}
							else
							{
								HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
							}

							Utl.SetHwRange(range, rSel);

							//Change VIN voltage to MS and measure corresponding output
							HW.Dcs.VOut(PM.VIN, vinMs);
							App.Time.MsDelay(App.TC.OutputSettle);
							hwTrimRangesCheck += Utl.TestOutput(range, idealMs, resourceSelect);

							if(range == App.RangeOptions.FORTY_V)
								HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);

							//Set VIN back to Zero Volts
							HW.Dcs.VOut(PM.VIN, 0.0);
							App.Time.MsDelay(App.TC.OutputSettle);
						}
					}
					else if(App.TC.RangeData[(int)range].RangeAccType == App.RangeAccType.OVER_RANGE)
					{
						if( ((range == App.RangeOptions.TWO_P_FIVE_V_BIP) && (rSel == App.ResSel.R_INT)) ||
							((range == App.RangeOptions.FORTY_FOUR_V) && (rSel == App.ResSel.R_INT)) ||
							((range == App.RangeOptions.THREE_TWENTY_MA) && (rSel == App.ResSel.R_EXT)) ||
							((range == App.RangeOptions.TWENTY_P_FOUR_MA) && (rSel == App.ResSel.R_EXT)) ||
							((range == App.RangeOptions.TWENTY_FOUR_P_FIVE_MA) && (rSel == App.ResSel.R_EXT)) ||
							((range == App.RangeOptions.TWELVE_V) && (App.TC.AVdd < 14.0)) ||
							((range == App.RangeOptions.TWELVE_V_BIP) && (App.TC.AVdd < 14.0)) ||
							((range == App.RangeOptions.FORTY_FOUR_V) && (App.TC.AVdd < 44.0)) )
						{
						}
						else
						{
							if(range == App.RangeOptions.FORTY_FOUR_V)
								HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.CLOSE);


							if((App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.VOLTAGE) && (rSel == App.ResSel.R_EXT))
								resourceSelect = App.MeasOptions.DIG;

							idealZs = App.TC.RangeData[(int)range].MinValue + ((vinZs/App.TC.MaxInputVoltage) * (App.TC.RangeData[(int)range].MaxValue - App.TC.RangeData[(int)range].MinValue));
							idealFs = App.TC.RangeData[(int)range].MaxValue;

							if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
							{
								HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
							}
							else
							{
								HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
							}

							Utl.SetHwRange(range, rSel);

							//Change VIN voltage to FS and measure corresponding output
							HW.Dcs.VOut(PM.VIN, vinFs);
							App.Time.MsDelay(App.TC.OutputSettle);
							outFs = Utl.MeasureOutput(range, idealFs, resourceSelect);

							//Set VIN back to ZS voltage
							HW.Dcs.VOut(PM.VIN, vinZs);
							App.Time.MsDelay(App.TC.OutputSettle);
							outZs = Utl.MeasureOutput(range, idealZs, resourceSelect);

							if(range == App.RangeOptions.FORTY_FOUR_V)
								HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);

							//Calculations
							foreach(Site site in TP.MS.ActiveSites)
							{
								idealGain = (idealFs - idealZs)/(vinFs - vinZs);
								gain[site] = (outFs[site] - outZs[site])/(vinFs - vinZs);
								gainError[site] = ((gain[site] - idealGain)/idealGain)*100;

								if((range == App.RangeOptions.THREE_TWENTY_MA) 
									|| (range == App.RangeOptions.TWENTY_P_FOUR_MA) 
									|| (range == App.RangeOptions.TWENTY_FOUR_P_FIVE_MA))
								{
									//idealGain = (ideal3Q - ideal1Q)/(vin3Q - vin1Q);
									//gain[site] = (out3Q[site] - out1Q[site])/(vin3Q - vin1Q);
									//gainError[site] = ((gain[site] - idealGain)/idealGain)*100;

									//y = mx + c
									//c = y1 - mx1
									yIntersect[site] = outZs[site] - (gain[site] * vinZs);
									//Offset indicates Vin voltage at which linear region of the range begins.
									//x(y = zs) = (y(zs) - c) / m
									//=> x(y = 0) = (idealZs - c) / m
									offset[site] = (idealZs - yIntersect[site]) / gain[site];
								}
								else
								{
									//idealGain = (idealFs - idealZs)/(vinFs - vinZs);
									//gain[site] = (outFs[site] - outZs[site])/(vinFs - vinZs);
									//gainError[site] = ((gain[site] - idealGain)/idealGain)*100;

									//offset = actual - ideal
									offset[site] = outZs[site] - idealZs;
								}
								fsError[site] = outFs[site] - idealFs;
								
								//Set VIN back to Zero Volts
								HW.Dcs.VOut(PM.VIN, 0.0);
								App.Time.MsDelay(App.TC.OutputSettle);
							}

							#region binData
							if(rSel == App.ResSel.R_INT)
							{
								if((range == App.RangeOptions.THREE_TWENTY_MA) ||
									(range == App.RangeOptions.TWENTY_P_FOUR_MA) ||
									(range == App.RangeOptions.TWENTY_FOUR_P_FIVE_MA))
									App.Test[String.Format("HW {0} IntR Vin Offset", App.TC.RangeData[(int)range].RangeName)].Result = offset;
								else
									App.Test[String.Format("HW {0} IntR Offset", App.TC.RangeData[(int)range].RangeName)].Result = offset;

								App.Test[String.Format("HW {0} IntR FS Error", App.TC.RangeData[(int)range].RangeName)].Result = fsError;
								App.Test[String.Format("HW {0} IntR Gain", App.TC.RangeData[(int)range].RangeName)].Result = gainError;
							}
							else if(rSel == App.ResSel.R_EXT)
							{
								if(App.TC.RangeData[(int)range].VoltageCurrentIdentifier == App.RangeType.CURRENT)
								{
									App.Test[String.Format("HW {0} ExtR Offset", App.TC.RangeData[(int)range].RangeName)].Result = offset;
									App.Test[String.Format("HW {0} ExtR FS Error", App.TC.RangeData[(int)range].RangeName)].Result = fsError;
									App.Test[String.Format("HW {0} ExtR Gain", App.TC.RangeData[(int)range].RangeName)].Result = gainError;
								}
								else
								{
									App.Test[String.Format("HW {0} ExtR Offset,DIG", App.TC.RangeData[(int)range].RangeName)].Result = offset;
									App.Test[String.Format("HW {0} ExtR FS Error,DIG", App.TC.RangeData[(int)range].RangeName)].Result = fsError;
									App.Test[String.Format("HW {0} ExtR Gain,DIG", App.TC.RangeData[(int)range].RangeName)].Result = gainError;
								}
							}
							#endregion
						}
					}
				}
			}

			App.Test[IDs.HwTrimmedRangesFunc].Result = hwTrimRangesCheck;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);
			HW.Dcs.VOut(PM.VIN, 0.0);
			//Switch out external resistor
			HW.Rdc.Set(PM.D4, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class HWranges
	#endregion

	//
	// HWclear Test Function
	//
	#region HWclear                         :
	/// <summary>
	/// Checks CLEAR functionality in Hardware Mode
	/// </summary>
	public class HWclear : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region HWclear                         :
		public HWclear()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			App.RangeOptions range;
			App.ResSel rSel;
			double expectedOutput;
			MsInt passFail = 0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			//Set Vin voltage to FS
			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);
			//Ensure output is enabled
			Utl.HWOutputEn(App.OutputEn.OP_ENABLE);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("HW Clear Test");

			range = App.RangeOptions.FOUR_TWENTY_MA;
			rSel = App.ResSel.R_INT;

			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			expectedOutput = App.TC.RangeData[(int)range].MaxValue;
			Utl.SetHwRange(range, rSel);
			App.Time.MsDelay(App.TC.OutputSettle);

			passFail += Utl.TestOutput(range, expectedOutput, resourceSelect);

			Utl.HwClearMode(App.ClearMode.CLR_TO_ZERO);
			Utl.HwClearEn(App.ClearEn.CLEAR);

			App.Time.MsDelay(App.TC.OutputSettle);
			expectedOutput = App.TC.RangeData[(int)range].MinValue;
			passFail += Utl.TestOutput(range, expectedOutput, resourceSelect);

			Utl.HwClearMode(App.ClearMode.CLR_TO_MID);

			App.Time.MsDelay(App.TC.OutputSettle);
			expectedOutput = App.TC.RangeData[(int)range].MidValue;
			passFail += Utl.TestOutput(range, expectedOutput, resourceSelect);

			Utl.HwClearEn(App.ClearEn.NO_CLEAR);

			App.Test[IDs.HwClearFunc].Result = passFail;

			//Cleanup
			HW.Dcs.VOut(PM.VIN, 0.0);

			//Switch out external resistor
			HW.Rdc.Set(PM.D4, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class HWclear
	#endregion

	//
	// HWreset Test Function
	//
	#region HWreset                         :
	/// <summary>
	/// Checks RESET functionality in Hardware Mode
	/// </summary>
	public class HWreset : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region HWreset                         :
		public HWreset()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double expectedOutput, zeroVolts = 0.0;
			MsInt passFail = 0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			//Set Vin to max value for this test
			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);

			//First check enable/disable functionality
			Utl.HWOutputEn(App.OutputEn.OP_DISABLE);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			//Measure vout voltage
			passFail += Utl.TestVout(zeroVolts, resourceSelect);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			//Enable output and set up 5V range and verify output goes to FS 
			Utl.HWOutputEn(App.OutputEn.OP_ENABLE);
			Utl.SetHwRange(App.RangeOptions.FIVE_V, App.ResSel.R_INT);
	  
			//Measure vout voltage
			expectedOutput = App.TC.RangeData[(int)App.RangeOptions.FIVE_V].MaxValue;
			passFail += Utl.TestVout(expectedOutput, resourceSelect);

			//Reset the device using RESET pin and verify reset
			Utl.RunPattern(DP.hw_reset);

			//Expecting output to be disabled -> i.e. floating. 
			//Close Rlyx17 to switch Vout to ground via load resistor.
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);

			//Measure vout voltage
			passFail += Utl.TestVout(zeroVolts, resourceSelect);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);

			App.Test[IDs.HwReset].Result = passFail;

			//Cleanup
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.RunPattern(DP.hw_reset);

		}
		#endregion
	}// end of class HWreset
	#endregion

	//
	// HWalarms Test Function
	//
	#region HWalarms                         :
	/// <summary>
	/// Checks alarm functionality in Hardware Mode
	/// </summary>
	public class HWalarms : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region HWalarms                         :
		public HWalarms()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			double vddSupply;
			MsInt vFaultPinFunc = 0, iFaultPinFunc = 0, vfault2mA5Func = 0, ifault2mA5Func = 0;
			MsBool passFail = false;
			double volSpec10k = 0.4,
				volSpec2mA5 = 0.6,
				guardband = 100.0e-3,
				pullupVoltage;
			double loadCurrent = App.TC.DVcc / 10.0e3;
			
			if(App.TC.DVcc > 5.0)
				pullupVoltage = 5.0;
			else
				pullupVoltage = App.TC.DVcc;

			//Ensure fault pins have correct pull-up
			HW.Dss.ConnectionSet(PM.HW_FAULT_PINS, Dss.ConnectionMode.OUTPUT_LOAD);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VTH, pullupVoltage);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VOL, (volSpec10k - guardband));

			//1. Verify Vout Short Circuit Faults
			//Ensure a voltage range is selected, then switch Vout to pincard and short to ground. 
			//Check fault pin
			Utl.HWOutputEn(App.OutputEn.OP_ENABLE);

			if((App.Globals.GenericType == App.GenericType.HV_GEN) || (App.TC.AVdd < 44.0) )
			{
				Utl.SetHwRange(App.RangeOptions.FIVE_V, App.ResSel.R_INT);

				//Set Vin to 1/2 scale - Vout will try to force to 2.5V
				HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage/2);
				HW.Rdc.Set(PM.D15, OpenClose.OPEN);

				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FVMI_100_MA);
				HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_100_MA, 0.0);
				App.Time.MsDelay(App.TC.VfaultDelay);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("HW Vout Alarm");

				//Check fault pin
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.SDO_VFAULT, Dss.Status.PASS);

				foreach(Site site in TP.MS.ActiveSites)
				{
					if(!passFail[site])
						vFaultPinFunc[site]++;
				}

				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, 2.5e-3);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, 2.5e-3);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VOL, (volSpec2mA5 - guardband));

				//Check fault pin
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.SDO_VFAULT, Dss.Status.PASS);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(!passFail[site])
						vfault2mA5Func[site]++;
				}

				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, loadCurrent);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, loadCurrent);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VOL, (volSpec10k - guardband));

				//Clear Fault Condition
				HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FIMV_200_UA);
				HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);
				HW.Rdc.Set(PM.D15, OpenClose.CLOSE);
			}
			else if(App.Globals.GenericType == App.GenericType.HV_GEN)
			{
				Utl.SetHwRange(App.RangeOptions.FORTY_V, App.ResSel.R_EXT);

				HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.CLOSE);
				HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
				HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.CLOSE);
				App.Time.MsDelay(App.TC.RelaySettle);

				//Set Vin to full scale - Vout will try to force to 40V
				HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);
				HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.OPEN);
		
				//30ms timeout required.
				App.Time.MsDelay(App.TC.VfaultDelay);

				if(App.Globals.PincheckEnable)
					Utl.MeasPinVoltage("HW Vout Alarm");

				//Check fault pin
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.SDO_VFAULT, Dss.Status.PASS);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(!passFail[site])
						vFaultPinFunc[site]++;
				}

				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, 2.5e-3);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, 2.5e-3);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VOL, (volSpec2mA5 - guardband));

				//Check fault pin
				Utl.RunPattern(DP.checkFaultCond);
				passFail = HW.Dss.PatStatus(PM.SDO_VFAULT, Dss.Status.PASS);
				foreach(Site site in TP.MS.ActiveSites)
				{
					if(!passFail[site])
						vfault2mA5Func[site]++;
				}

				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, loadCurrent);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, loadCurrent);
				HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VOL, (volSpec10k - guardband));

				//Clear Fault Condition
				HW.Rdc.Set(PM.RLX18_RELAYS, OpenClose.CLOSE);
				HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);
				HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
				HW.Rdc.Set(PM.RLX16_RELAYS, OpenClose.OPEN);
			}

			//2. Verify Iout Open Circuit Fault
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			//Set Iout to drop across 2.1K resistor. Output 1/3 scale on 20mA range (~6.67mA). 
			//6.67mA * 2100 = 14V. Ensure positive supplies are at 14.5V. 14V within compliance level (~2V) 
			// -> alarm should be set

			Utl.SetHwRange(App.RangeOptions.TWENTY_MA, App.ResSel.R_INT);
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.OPEN);

			vddSupply = 13.5;
			Utl.ModifySupplies(vddSupply, App.TC.AVss, App.TC.DVcc);
			HW.Dcs.VOut(PM.VIN, (App.TC.MaxInputVoltage/3));

			App.Time.MsDelay(App.TC.IfaultDelay);

			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("HW Iout Alarm");

			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.NC_IFAULT, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
					iFaultPinFunc[site]++;
			}

			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, 2.5e-3);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, 2.5e-3);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VOL, (volSpec2mA5 - guardband));

			//Check fault pin
			Utl.RunPattern(DP.checkFaultCond);
			passFail = HW.Dss.PatStatus(PM.NC_IFAULT, Dss.Status.PASS);
			foreach(Site site in TP.MS.ActiveSites)
			{
				if(!passFail[site])
					ifault2mA5Func[site]++;
			}

			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOH, loadCurrent);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.IOL, loadCurrent);
			HW.Dss.ControlValue(PM.HW_FAULT_PINS, Dss.Control.VOL, (volSpec10k - guardband));

			//Clear Fault condition
			HW.Dcs.VOut(PM.VIN, 0.0);
			Utl.ModifySupplies(App.TC.AVdd, App.TC.AVss, App.TC.DVcc);

			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);

			App.Test[IDs.HwVFaultFunc].Result = vFaultPinFunc;
			App.Test[IDs.HwIFaultFunc].Result = iFaultPinFunc;
			App.Test[IDs.HwVFault2mA5Func].Result = vfault2mA5Func;
			App.Test[IDs.HwIFault2mA5Func].Result = ifault2mA5Func;

			//Cleanup
			Utl.RunPattern(DP.hw_reset);
			HW.Rdc.Set(PM.RLX17_RELAYS, OpenClose.OPEN);
		}
		#endregion
	}// end of class HWalarms
	

	#endregion
	#endregion

	//
	// VsensenFunc Test Function
	//
	#region VsensenFunc                     :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class VsensenFunc : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region VsensenFunc                     :
		public VsensenFunc()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			int i,
				numPoints = 3;
			App.RangeOptions range;
			double vinVoltage = 2.0, vsensenV;
			MsDouble [] vout = new MsDouble[numPoints];
			MsDouble [] vsensenIn = new MsDouble[numPoints];
			MsDouble [] vDiff = new MsDouble[numPoints];
			MsDouble [] delta = new MsDouble[numPoints];
			MsDouble result = 0.0;
			App.MeasOptions resourceSelect = App.MeasOptions.DIG;

			range = App.RangeOptions.TEN_V;

			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)range].ProgBits, App.ClearMode.CLR_TO_ZERO,
				App.OutputEn.OP_ENABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			//Disconnect VsenseN/VsenseP from Dutgnd/Vout and connect VIF to VsenseN
			//Also, ensure vout is connected to measure cct.
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX14_RELAYS, OpenClose.CLOSE);
			App.Time.MsDelay(App.TC.RelaySettle);

			HW.Dmm.Integration(PM.DMM, 0.02);

			//Set Vin to 2V
			HW.Dcs.VOut(PM.VIN, vinVoltage);
			App.Time.MsDelay(App.TC.OutputSettle);


			if(App.Globals.PincheckEnable)
				Utl.MeasPinVoltage("VsenseN Functionality");

			for(i = 0; i < numPoints; i++)
			{
				vsensenV = -3 + i*3;
				HW.Dvi.WriteV(PM.VSENSEN, vsensenV);
				App.Time.MsDelay(App.TC.VsenseNSettle);
				vsensenIn[i] = Utl.MeasureNode(App.MuxNodes.VSENSEN_MEAS, resourceSelect);
				vout[i] = Utl.MeasureNode(App.MuxNodes.VOUT_MEAS, resourceSelect);
				vDiff[i] = vout[i] - vsensenIn[i];
				if(i>0)
				{
					delta[i] = (vDiff[i] - vDiff[i-1])/(vsensenIn[i] - vsensenIn[i-1]);
				}
			}

			foreach(Site site in TP.MS.ActiveSites)
			{
				if((Math.Abs(delta[2][site])) > (Math.Abs(delta[1][site])))
					result[site] = delta[2][site];
				else
					result[site] = delta[1][site];
			}
			App.Test[IDs.VsensenFunc].Result = result;


			//Cleanup
			HW.Dmm.Integration(PM.DMM, 0.002);	
			HW.Dvi.WriteV(PM.VSENSEN, 0.0);
			HW.Rdc.Set(PM.RLX14_RELAYS, OpenClose.OPEN);
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
		}
		#endregion
	}// end of class VsensenFunc
	#endregion

	//
	// ConditionsCheck Test Function
	//
	#region ConditionsCheck                 :
	/// <summary>
	/// Test to measure Vin/Vref and Iload 
	/// </summary>
	public class ConditionsCheck : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region ConditionsCheck                 :
		public ConditionsCheck()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble vrefMeas, vinMeasMin, vinMeasMax, vrefError, vinMinError, vinMaxError;

			HW.Dmm.Integration(PM.DMM, 0.02);

			//Measure Vref voltage
			vrefMeas = Utl.MeasureNode(App.MuxNodes.VREF_MEAS, App.MeasOptions.DMM);
			vrefError = App.TC.MaxInputVoltage - vrefMeas;

			//Measure Vin voltage
			HW.Dcs.VOut(PM.VIN, App.TC.MinInputVoltage);
			vinMeasMin = Utl.MeasureNode(App.MuxNodes.VIN_MEAS, App.MeasOptions.DMM);
			vinMinError = App.TC.MinInputVoltage - vinMeasMin;

			HW.Dcs.VOut(PM.VIN, App.TC.MaxInputVoltage);
			vinMeasMax = Utl.MeasureNode(App.MuxNodes.VIN_MEAS, App.MeasOptions.DMM);
			vinMaxError = App.TC.MaxInputVoltage - vinMeasMax;

			//BoardCheckUtl.MeasureOnboardResistances();

			//App.Test[IDs.VrefMeas].Result = vrefError;
			App.Test[IDs.VinLowMeas].Result = vinMinError;
			App.Test[IDs.VinHighMeas].Result = vinMaxError;
			App.Test[IDs.IloadLowMeas].Result = App.TC.BoardVars.IoutLowRes;
			App.Test[IDs.IloadHighMeas].Result = App.TC.BoardVars.IoutHighRes;
			App.Test[IDs.VscaleHighLoad].Result = App.TC.BoardVars.VoutScaleHighLoad;
			App.Test[IDs.VscaleHighRatio].Result = App.TC.BoardVars.VoutScaleHighGain;
			App.Test[IDs.VscaleLowLoad].Result = App.TC.BoardVars.VoutScaleLowLoad;
			App.Test[IDs.VscaleLowRatio].Result = App.TC.BoardVars.VoutScaleLowGain;

		}
		#endregion
	}// end of class ConditionsCheck
	#endregion

	//
	// PowerUpCondition Test Function
	//
	#region PowerUpCondition                :
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class PowerUpCondition : TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//
		#region PowerUpCondition                :
		public PowerUpCondition()
		{
		}
		#endregion

		//
		// Run Method - contains the implementation details for this test function
		//
		#region Run                             :
		public override void Run()
		{
			MsDouble voutZS = 0.0, voutMS = 0.0, voutTristateLkg = 0.0;
			MsInt passFail = 0;
			MsDouble expectedZero = 0.0, expectedMS = 2.5, tolerance = 0.1;

			//Setup pincard on Vout
			HW.Rdc.Set(PM.D15, OpenClose.OPEN);
			//Connect Vout to pincard to verify tristate/vout value
			HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.PMU_TO_PIN);
			HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.PMU_PIN, Dss.PmuMode.FIMV_200_UA);
			HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FIMV_200_UA, 0.0);

			//Disable the outputs
			Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V].ProgBits, App.ClearMode.CLR_TO_ZERO,
				App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, App.ResSel.R_INT, App.SoftResetEn.NO_RESET);

			//Force CLR pin high, CLRSEL pin low
			Utl.HwClearEn(App.ClearEn.CLEAR);
			Utl.HwClearMode(App.ClearMode.CLR_TO_ZERO);

			//Verify that Vout defaults 0V
			HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FIMV_200_UA, 100e-6);
			voutZS = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);

			//Change CLRSEL pin to High and verify vout goes to MS
			Utl.HwClearMode(App.ClearMode.CLR_TO_MID);
			voutMS = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);

			HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FIMV_200_UA, 0.0);
			HW.Dss.PmuModeValue(PM.VOUT, Dss.PmuMode.FVMI_20_UA, 0.0);

			//Pull clear pin low and verify that Vout goes tristate
			Utl.HwClearMode(App.ClearMode.CLR_TO_ZERO);
			Utl.HwClearEn(App.ClearEn.NO_CLEAR);

			voutTristateLkg = HW.Dss.PmuRead(PM.VOUT, App.Globals.NumPmuAverages);

			HW.Dss.PmuConnectMode(PM.VOUT, Dss.PmuConnectionMode.DISCONNECT, Dss.PmuMode.FVMI_20_UA);
			HW.Dss.ConnectionSet(PM.VOUT, Dss.ConnectionMode.DISCONNECT);

			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);

			App.Test[IDs.PowerupToZero].Result = voutZS;
			App.Test[IDs.PowerupToMid].Result = voutMS;
			App.Test[IDs.PowerupTristate].Result = voutTristateLkg;
		}
		#endregion
	}// end of class PowerUpCondition
	#endregion

	//
	// Power Up Test Function
	//
	#region PowerUpTest						:
	/// <summary>
	/// Add summary description of this test function here
	/// </summary>
	public class PowerUpTest	: TestFunction
	{
		//
		// Constructor - parameters are assigned to this class instance here
		//

		#region PowerUpTest				:
		public PowerUpTest()
		{
		}
		#endregion


		#region Run						:
		public override void Run()
		{

			//
			// sequential Power Up set up, anything that can be set outside of teh foreach loop
			//

			#region Power Up General Set Up

			MsDouble dvccValue = 0.0;
			double pullupVoltage;

			MsDouble Iss_site = 0;

			MsDouble Iss = 0;

			double Iss_Site_1 = 0;
			double Iss_Site_2 = 0;
			double Iss_Site_3 = 0;
			double Iss_Site_4 = 0;


			double Iss_Site_1_Bin = 0;
			double Iss_Site_2_Bin = 0;
			double Iss_Site_3_Bin = 0;
			double Iss_Site_4_Bin = 0;

			// variable for detecting failing sites
			MsDouble IssPass = 0;

			double Iss_Site_1_Pass = 0;
			double Iss_Site_2_Pass = 0;
			double Iss_Site_3_Pass = 0;
			double Iss_Site_4_Pass = 0;

			MsInt readbackWord = 0;

			// disconnect GND1_PMU, cant use pinlist as need to make sure all sites get disconnected
			// while when using pinlist and S1 failing o/s this wont switch it off
			// HW.Dss.ConnectionSet(PM.GND1_PMU, Dss.ConnectionMode.DISCONNECT);

			HW.Dss.ConnectionSet(Pc.D06PCG, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.ConnectionSet(Pc.D06PCH, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.ConnectionSet(Pc.D10PCG, Dss.ConnectionMode.DISCONNECT);
			HW.Dss.ConnectionSet(Pc.D10PCH, Dss.ConnectionMode.DISCONNECT);

			// close relay driver RL22 to close relays 122, 222, 322, 422
			// to connect individual grounds to individual PMUs
			HW.Rdc.Set(Rdc.A16RDC_K22, OpenClose.CLOSE);

			#endregion

			//
			// Power Up
			// 

			#region Power Up

			//TP.Console.WriteLine("Powering Up the DUT!!!");

			foreach (Site site in TP.MS.SerialLoop)
			{

				#region Power Up Individual Site Set Up

				// connect PMU to POGO and set PMU ranges, force 0V
				HW.Dss.PmuConnectMode(PM.GND1_PMU, Dss.PmuConnectionMode.PMU_POGO, Dss.PmuMode.FVMI_2_MA);
				HW.Dss.PmuModeValue(PM.GND1_PMU, Dss.PmuMode.FVMI_2_MA, 0);

				// all grounds are now seperated, for each site ground there is different PMU used
				// and PMU will be forcing 0V on each ground

				#endregion

				
				#region Power Up

				//Power up the DUT & Setup in software mode with default address

				// Close DVCC gate
				HW.Dvi.Gate(PM.DVCC, OpenClose.CLOSE);

				// Close AVDD (all sites) gates
				HW.Vi.Gate(PM.AVDD, OpenClose.CLOSE);

				// Close only one VIE gate for AVSS, due to common AVSS on wafer!!!
				HW.Vi.Gate(Vi.V02VIB, OpenClose.CLOSE);

				// Ensure decoupling caps are switched in
				HW.Rdc.Set(PM.CONT_RELAYS_CLOSE, OpenClose.OPEN);

				// Setup AVdd using VIE
				Utl.StepSupplyVoltageTo(PM.AVDD, App.TC.AVdd, App.TC.CurrentVdd);
				App.Time.UsDelay(100);

				// Setup AVss using one VIE
				if(App.TC.CurrentAvssVoltage == 0)
					Utl.StepSupplyVoltageToAvss(App.TC.AVss, App.TC.CurrentAvssVoltage);

				App.Time.UsDelay(100);

				//Set up DVcc
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_50_UA);
				dvccValue[site] = App.TC.DVcc;

				HW.Dvi.WriteV(PM.DVCC, dvccValue);
				App.Time.UsDelay(100);

				// Set up Vref
				HW.Dcs.VOut(PM.VREF, App.TC.VRef);
				App.Time.UsDelay(100);

				// Force 0V on Vin initially
				HW.Dcs.VOut(PM.VIN, 0.0);
				App.Time.UsDelay(100);

				// Connect Digital Pins & set up logic levels
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOH, App.TC.Voh);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VOL, App.TC.Vol);
				HW.Dss.DriverInputSelect(PM.DIG_PINS, Dss.DriveData.DRIVE_PATTERN);
				HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.OUTPUT);


				if(App.TC.DVcc > 5.0)
					pullupVoltage = 5.0;
				else
					pullupVoltage = App.TC.DVcc;

				HW.Dss.ConnectionSet(PM.FAULT_TEMP, Dss.ConnectionMode.OUTPUT_LOAD);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOH, 0.0002);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.IOL, 0.0002);
				HW.Dss.ControlValue(PM.FAULT_TEMP, Dss.Control.VTH, pullupVoltage);
				
				//Setup correct timing
				Utl.SetInterfaceTiming(App.TC.Frequency);

				Utl.SetDeviceMode(App.OpMode.SOFTWARE);
				Utl.SetAddressPins(App.TC.DutAddress);

				#endregion

				#region Measure Current

				//Setup device conditions
				Utl.ShortWrite(App.TC.DutAddress, App.TC.RangeData[(int)App.RangeOptions.FIVE_V_BIP].ProgBits, 
					App.ClearMode.CLR_TO_ZERO, App.OutputEn.OP_DISABLE, App.ClearEn.NO_CLEAR, 
					App.ResSel.R_EXT, App.SoftResetEn.NO_RESET);
				
				// Close relays to disconnect supplies from decoupling caps
				HW.Rdc.Set(PM.D3, OpenClose.CLOSE);
				HW.Rdc.Set(PM.D7, OpenClose.CLOSE);

				//Set up logic levels to 0 and DVcc
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.DVcc);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, 0.0);
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_50_UA);

				App.Time.MsDelay(App.TC.VfaultDelay);

				Iss_site[site] = HW.Vi.ReadI(Vi.V02VIB)[site];


				if(site == Site.S1)
				{
					Iss_Site_1 = Iss_site[site];
					Iss_Site_1_Bin = Iss_Site_1;

					if((Iss_Site_1 < - 0.0062) || (Iss_Site_1 > -0.0001))
					{
						Iss_Site_1_Pass++;
						Iss_Site_1 =0;
						IssPass[Site.S1] = Iss_Site_1_Pass;
					}

				}

				if(site == Site.S2)
				{
					Iss_Site_2 = Iss_site[site] - Iss_Site_1;
					Iss_Site_2_Bin = Iss_Site_2;

					if((Iss_Site_2 < - 0.0062) || (Iss_Site_2 > -0.0001))
					{
						Iss_Site_2_Pass++;
						Iss_Site_2 = 0;
						IssPass[Site.S2] = Iss_Site_2_Pass;
					}
				}

				if(site == Site.S3)
				{
					Iss_Site_3 = Iss_site[site] - Iss_Site_2 - Iss_Site_1;
					Iss_Site_3_Bin = Iss_Site_3;


					if((Iss_Site_3 < - 0.0062) || (Iss_Site_3 > -0.0001))
					{
						Iss_Site_3_Pass++;
						Iss_Site_3 = 0;
						IssPass[Site.S3] = Iss_Site_3_Pass;
					}
				}

				if(site == Site.S4)
				{
					Iss_Site_4 = Iss_site[site] - Iss_Site_3 - Iss_Site_2 - Iss_Site_1;
					Iss_Site_4_Bin = Iss_Site_4;


					if((Iss_Site_4 < - 0.0062) || (Iss_Site_4 > -0.0001))
					{
						Iss_Site_4_Pass++;
						Iss_Site_4 = 0;
						IssPass[Site.S4] = Iss_Site_4_Pass;
					}
				}	


				if(App.Globals.OfflineDev)
				{
					Iss_site = -2.0e-3;
				}

				
				//Cleanup
				HW.Dvi.IRange(PM.DVCC, Dvi.IRanges.I_10_MA);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIH, App.TC.Vih);
				HW.Dss.ControlValue(PM.DIG_PINS, Dss.Control.VIL, App.TC.Vil);
				HW.Rdc.Set(PM.D3, OpenClose.OPEN);
				HW.Rdc.Set(PM.D7, OpenClose.OPEN);
				Utl.RunPattern(DP.hw_reset);

				#endregion

				#region Iss[site] Failed Powering Down [site]

				if(IssPass[site] != 0)
				{
					// power down device on failing site here

					MsDouble zeroVolts = 0.0;

					//TP.Console.WriteLine("Powering Down the DUT!!!");

					//Connect Digital Pins & set up logic levels
					HW.Dss.ConnectionSet(PM.DIG_PINS, Dss.ConnectionMode.DISCONNECT);

					//Force 0V on Vin
					HW.Dcs.VOut(PM.VIN, zeroVolts);
					App.Time.UsDelay(100);

					//Set Vref to 0V
					HW.Dcs.VOut(PM.VREF, zeroVolts);
					App.Time.UsDelay(100);

					if(App.TC.CurrentVcc[site] != 0.0)
					{
						HW.Dvi.WriteV(PM.DVCC, App.TC.DVcc/2.0);
						App.Time.UsDelay(100);
					}
					
					HW.Dvi.WriteV(PM.DVCC, zeroVolts);
					App.Time.UsDelay(100);

					//Set AVss to 0v
					Utl.StepSupplyVoltageTo(PM.AVSS, zeroVolts, App.TC.CurrentVss);
					App.Time.UsDelay(100);

					//Set up AVdd
				
				
					//Setup AVdd using VIE
					Utl.StepSupplyVoltageTo(PM.AVDD, zeroVolts, App.TC.CurrentVdd);
					App.Time.UsDelay(100);
				

					App.TC.CurrentVdd[Site.S1] = (double)zeroVolts;
					App.TC.CurrentVdd[Site.S2] = (double)zeroVolts;
					App.TC.CurrentVdd[Site.S3] = (double)zeroVolts;
					App.TC.CurrentVdd[Site.S4] = (double)zeroVolts;

					App.TC.CurrentVss[Site.S1] = (double)zeroVolts;
					App.TC.CurrentVss[Site.S2] = (double)zeroVolts;
					App.TC.CurrentVss[Site.S3] = (double)zeroVolts;
					App.TC.CurrentVss[Site.S4] = (double)zeroVolts;

					App.TC.CurrentVcc[Site.S1] = (double)zeroVolts;
					App.TC.CurrentVcc[Site.S2] = (double)zeroVolts;
					App.TC.CurrentVcc[Site.S3] = (double)zeroVolts;
					App.TC.CurrentVcc[Site.S4] = (double)zeroVolts;

					//Setup relays correctly
					HW.Rdc.Set(PM.D3, OpenClose.OPEN);
					HW.Rdc.Set(PM.D7, OpenClose.OPEN);
					HW.Rdc.Set(PM.D6, OpenClose.OPEN);

					//Open VI gates
					HW.Dvi.Gate(PM.DVCC, OpenClose.OPEN);
					HW.Vi.Gate(PM.AVDD, OpenClose.OPEN);
					HW.Vi.Gate(PM.AVSS, OpenClose.OPEN);
				}

				#endregion

			}
			#endregion

			//Connect outputs

			// Vout section relays
			HW.Rdc.Set(PM.RLX13_RELAYS, OpenClose.CLOSE);
			HW.Rdc.Set(PM.D15, OpenClose.CLOSE);

			// Iout section relays
			HW.Rdc.Set(PM.D9, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX10_RELAYS, OpenClose.CLOSE);
			HW.Rdc.Set(PM.RLX11_RELAYS, OpenClose.CLOSE);

			App.Time.MsDelay(App.TC.RelaySettle);

			Iss[Site.S1] = Iss_Site_1_Bin;
			Iss[Site.S2] = Iss_Site_2_Bin;
			Iss[Site.S3] = Iss_Site_3_Bin;
			Iss[Site.S4] = Iss_Site_4_Bin;


			// 
			//Bin Result
			// 
			#region Bin Results

			App.Test[IDs.Iss_site].Result	= Iss;
			App.Test[IDs.IssPass].Result	= IssPass;

			#endregion


		}
		#endregion

	}// End of class PowerUpTest
	#endregion


}  // end of namespace Adi.Cts.TestProgram
